/*
 * ファイル：DicListUiActivity.java
 * 概要：辞書一覧画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.dictionary;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetDictionaryListResultListener;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.adapter.AdapterDicList;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * dic-02
 *
 * @author Systena
 * @version 1.0
 */
public class DicListUiActivity extends BaseUiActivity implements View.OnClickListener,
        OnDicListChangedListener, IOnClickItemDicList, OnStartDragListener, GetDictionaryListResultListener {
    private AdapterDicList mAdapterDicList;
    private RecyclerView mRecyclerDicList;
    private TextView mTvTitle;
    private TextView mTvCount;
    private TextView mTvNotificationEmpty;
    private RelativeLayout mViewDicEmpty;
    private TextView mBtnSort;
    private ImageView mBtnAddDic;
    private RelativeLayout mBtnBack;
    private ItemTouchHelper mItemTouchHelper;
    private TextView mTvBack;
    private ImageView mImvBack;
    private TextView mTvGuideSort;
    private int mColorBackgroundItem;
    private int mColorFlagItem;
    private List<DictionaryInfo> mListDictionary = new ArrayList<>();
    private List<DictionaryInfo> mListDictionaryBeforeDrag = new ArrayList<>();
    private CategoryInfo mCategoryInfo;
    private List<CategoryInfo> mCategoryInfoList = new ArrayList<>();
    private String mDialogTag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dictionary_list);
        mCategoryInfoList = getIntentListCategory();
        mCategoryInfo = getIntentCategory();
        mTvGuideSort = findViewById(R.id.tv_guide);
        mImvBack = findViewById(R.id.imv_back_dic_list);
        mTvBack = findViewById(R.id.tv_back_dic_list);
        mRecyclerDicList = findViewById(R.id.recycle_dic_list);
        mBtnAddDic = findViewById(R.id.dic_add);
        mTvNotificationEmpty = findViewById(R.id.tv_dic_empty);
        mBtnSort = findViewById(R.id.tv_dic_sort);
        mBtnBack = findViewById(R.id.rlt_dic_list_back);
        mBtnBack.setOnClickListener(this);
        mBtnSort.setOnClickListener(this);
        mBtnAddDic.setOnClickListener(this);
        mViewDicEmpty = findViewById(R.id.rlt_view_dic_empty);
        mTvTitle = findViewById(R.id.tv_dic_list_title);
        mTvCount = findViewById(R.id.tv_count);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        mLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerDicList.setLayoutManager(mLayoutManager);
        if (mCategoryInfo != null) {
            setEnableListDic(mListDictionary.isEmpty());
            mTvTitle.setText(mCategoryInfo.getName());
            mColorFlagItem = ResourcesUtils.getColorFlagItemDictionary(mCategoryInfo.getCategoryId());
            mColorBackgroundItem = ResourcesUtils.getColorBackgroundItemDictionary(mCategoryInfo.getCategoryId());
            initDictionaryList();
            AppController.getInstance().getAssistServerInterface().getDictionaryList(mCategoryInfo.getCategoryId(), this);
        }
    }


    /**
     * init DictionaryList
     */
    private void initDictionaryList() {
        mAdapterDicList = new AdapterDicList(this, this, this);
        ItemTouchHelper.Callback callback = new DicListItemCallback(mAdapterDicList);
        mAdapterDicList.setActivity(this);
        mItemTouchHelper = new ItemTouchHelper(callback);
        mItemTouchHelper.attachToRecyclerView(mRecyclerDicList);
        mRecyclerDicList.setAdapter(mAdapterDicList);
        mAdapterDicList.setListDictionary(mListDictionary);
        mAdapterDicList.setListOtherDictionary(createListOtherDictionary(mCategoryInfo.getCategoryId()));
        mAdapterDicList.setColorItem(mColorBackgroundItem, mColorFlagItem);
    }

    /**
     * get intent list category
     *
     * @return List<CategoryInfo>
     */
    private List<CategoryInfo> getIntentListCategory() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_LIST_CATEGORY)) {
            return (List<CategoryInfo>) getIntent().getExtras().getSerializable(Constants.Dictionary.KEY_LIST_CATEGORY);
        }
        return new ArrayList<>();
    }

    /**
     * get category intent
     *
     * @return CategoryInfo
     */
    private CategoryInfo getIntentCategory() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_TYPE_CATEGORY)) {
            return (CategoryInfo) getIntent().getExtras().getSerializable(Constants.Dictionary.KEY_TYPE_CATEGORY);
        } else {
            return null;
        }
    }

    /**
     * set show notification dic empty
     *
     * @param enableListDic
     */
    private void setEnableListDic(boolean enableListDic) {
        mTvCount.setText(getString(R.string.dic_whole) + Integer.toString(mListDictionary.size())
                + getString(R.string.dic_item));
        if (enableListDic) {
            mRecyclerDicList.setVisibility(View.INVISIBLE);
            mViewDicEmpty.setVisibility(View.VISIBLE);
            mBtnSort.setVisibility(View.INVISIBLE);
        } else {
            mRecyclerDicList.setVisibility(View.VISIBLE);
            mViewDicEmpty.setVisibility(View.INVISIBLE);
            mBtnSort.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.dic_add:
                goToScreenDicCreate();
                break;
            case R.id.tv_dic_sort:
                setOnClickSort();
                break;
            case R.id.rlt_dic_list_back:
                setOnClickBack();
                break;
            default:
                break;
        }
    }

    @Override
    public void onClickItemDic(DictionaryInfo dictionaryModel) {
        goToDicDetail(dictionaryModel);
    }

    @Override
    public void clickOtherCategory(CategoryInfo categoryModel) {
        setSelectCategoryOther(categoryModel);
        finish();
    }

    @Override
    public void onNoteListChanged(List<DictionaryInfo> dictionaryModels) {
    }

    @Override
    public void onStartDrag(RecyclerView.ViewHolder viewHolder) {
        mItemTouchHelper.startDrag(viewHolder);
    }

    /**
     * create list other category
     *
     * @param categoryId
     * @return
     */
    private List<CategoryInfo> createListOtherDictionary(long categoryId) {
        List<CategoryInfo> listDictionary = new ArrayList<>();
        listDictionary.addAll(mCategoryInfoList);
        for (CategoryInfo categoryInfo : listDictionary) {
            if (categoryInfo.getCategoryId() == categoryId) {
                listDictionary.remove(categoryInfo);
                return listDictionary;
            }
        }
        return listDictionary;
    }

    @Override
    public void onResult(AssistServerResult result, List<DictionaryInfo> list) {
        closeIndicator();
        if (result.mResult == AssistServerResult.Result.Success) {
            if (list.size() > 0) {
                mListDictionary.clear();
                mListDictionary.addAll(list);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mAdapterDicList.notifyDataSetChanged();
                        setEnableListDic(mListDictionary.isEmpty());
                    }
                });
            }
        }
    }

    @Override
    public void onStartConnection() {
        displayIndicator();
    }

    /**
     * show dialog can not sort
     */
    private void buildCanNotSortDialog() {
        BaseDialogFactory dialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_CAN_NOT_SORT);
        mDialogTag = dialogFactory.getDialogTag();
        new DialogGenerator(this, dialogFactory).show();
    }

    /**
     * set onclick button sort
     */
    private void setOnClickSort() {
        if (mAdapterDicList.getEnableButtonDrag()) {
            mBtnSort.setText(R.string.dic_sort);
            mTvBack.setText(R.string.dic_my_dic);
            mImvBack.setVisibility(View.VISIBLE);
            mTvGuideSort.setVisibility(View.GONE);
            mBtnAddDic.setVisibility(View.VISIBLE);
            mAdapterDicList.setEnableButtonDrag(!mAdapterDicList.getEnableButtonDrag());
            AppController.getInstance().getAssistServerInterface().saveDictionaryOrder(mListDictionary);
        } else {
            if (mListDictionary.size() == 1) {
                buildCanNotSortDialog();
            } else if (mListDictionary.size() > 1) {
                mBtnSort.setText(R.string.decision);
                mTvBack.setText(R.string.cancel);
                mImvBack.setVisibility(View.INVISIBLE);
                mTvGuideSort.setVisibility(View.VISIBLE);
                mListDictionaryBeforeDrag.clear();
                mListDictionaryBeforeDrag.addAll(mListDictionary);
                mBtnAddDic.setVisibility(View.GONE);
                mAdapterDicList.setEnableButtonDrag(!mAdapterDicList.getEnableButtonDrag());
            }

        }
    }

    /**
     * got to dic-cr-01
     */
    private void goToScreenDicCreate() {
        Bundle bundle = new Bundle();
        bundle.putString(Constants.Dictionary.KEY_TYPE_CATEGORY, String.valueOf(mCategoryInfo.getCategoryId()));
        bundle.putSerializable(Constants.Dictionary.KEY_LIST_CATEGORY, (Serializable) mCategoryInfoList);
        changeScreenResult(ScreenId.START_DIC_CREATE, Constants.Dictionary.REQUEST_CODE_DIC_CREATE, bundle);
    }

    /**
     * set onClick button back
     */
    private void setOnClickBack() {
        if (mAdapterDicList.getEnableButtonDrag()) {
            mAdapterDicList.setEnableButtonDrag(false);
            mListDictionary.clear();
            mListDictionary.addAll(mListDictionaryBeforeDrag);
            mBtnSort.setText(R.string.dic_sort);
            mTvBack.setText(R.string.dic_my_dic);
            mImvBack.setVisibility(View.VISIBLE);
            mTvGuideSort.setVisibility(View.GONE);
            mBtnAddDic.setVisibility(View.VISIBLE);
            mAdapterDicList.notifyDataSetChanged();
        } else {
            onBackPressed();
        }
    }

    /**
     * go to dic-03
     *
     * @param dictionaryInfo
     */
    private void goToDicDetail(DictionaryInfo dictionaryInfo) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Constants.Dictionary.KEY_DICTIONARY_INFO, dictionaryInfo);
        bundle.putSerializable(Constants.Dictionary.KEY_LIST_CATEGORY, (Serializable) mCategoryInfoList);
        changeScreen(ScreenId.START_DIC_DETAIL, bundle);
    }

    /**
     * set onClick category other
     *
     * @param categoryInfo
     */
    private void setSelectCategoryOther(CategoryInfo categoryInfo) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Constants.Dictionary.KEY_TYPE_CATEGORY, categoryInfo);
        bundle.putSerializable(Constants.Dictionary.KEY_LIST_CATEGORY, (Serializable) mCategoryInfoList);
        changeScreen(ScreenId.START_DIC_LIST, bundle);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constants.Dictionary.REQUEST_CODE_DIC_CREATE && resultCode == Constants.Dictionary.REQUEST_CODE_DIC_CREATE) {
            String idCategory = data.getStringExtra(Constants.Dictionary.KEY_TYPE_CATEGORY);
            if (!TextUtils.isEmpty(idCategory) && Long.valueOf(idCategory) == mCategoryInfo.getCategoryId()) {
                AppController.getInstance().getAssistServerInterface().getDictionaryList(mCategoryInfo.getCategoryId(), this);
            }
        }
    }
}
