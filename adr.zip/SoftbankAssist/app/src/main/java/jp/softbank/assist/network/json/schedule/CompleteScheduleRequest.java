/*
 * ファイル：CompleteScheduleRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.schedule;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

/**
 * スケジュール完了リクエスト.
 */
public class CompleteScheduleRequest extends RequestBody {

    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("schedule_id")
    private Long mScheduleId = null;
    @SerializedName("complete_flg")
    private Long mCompleteFlg = null;


    /**
     * 値初期化.
     */
    public void initializeValues() {
        mUserId = 0L;
        mScheduleId = 0L;
        mCompleteFlg = 0L;
    }

    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * スケジュール日時ID.
     */
    public Long getScheduleId() {
        return mScheduleId;
    }
    public void setScheduleId(Long scheduleId) {
        this.mScheduleId = scheduleId;
    }

    /**
     * 完了フラグ（0：未完了、1：完了）.
     */
    public Long getCompleteFlg() {
        return mCompleteFlg;
    }
    public void setCompleteFlg(Long completeFlg) {
        this.mCompleteFlg = completeFlg;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CompleteScheduleRequest scheduleRequest = (CompleteScheduleRequest) o;
        return (this.mUserId == null ? scheduleRequest.mUserId == null : this.mUserId.equals(scheduleRequest.mUserId)) &&
                (this.mScheduleId == null ? scheduleRequest.mScheduleId == null : this.mScheduleId.equals(scheduleRequest.mScheduleId)) &&
                (this.mCompleteFlg == null ? scheduleRequest.mCompleteFlg == null : this.mCompleteFlg.equals(scheduleRequest.mCompleteFlg));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mScheduleId == null ? 0: this.mScheduleId.hashCode());
        result = 31 * result + (this.mCompleteFlg == null ? 0: this.mCompleteFlg.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class CompleteScheduleRequest {\n");

        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mScheduleId: ").append(mScheduleId).append("\n");
        sb.append("  mCompleteFlg: ").append(mCompleteFlg).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
