/*
 * ファイル：EditDictionaryResultCardPos.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

/**
 * カード位置情報.
 */
public class EditDictionaryResultCardPos {

    @SerializedName("card_id")
    private Long mCardId = null;
    @SerializedName("next_card_id")
    private Long mNextCardId = null;


    /**
     * 値初期化.
     */
    public void initializeValues() {
        mCardId = 0L;
        mNextCardId = 0L;
    }

    /**
     * カードID.
     */
    public Long getCardId() {
        return mCardId;
    }
    public void setCardId(Long cardId) {
        this.mCardId = cardId;
    }

    /**
     * 次カードID.
     */
    public Long getNextCardId() {
        return mNextCardId;
    }
    public void setNextCardId(Long nextCardId) {
        this.mNextCardId = nextCardId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EditDictionaryResultCardPos cardPos = (EditDictionaryResultCardPos) o;
        return (this.mCardId == null ? cardPos.mCardId == null : this.mCardId.equals(cardPos.mCardId)) &&
                (this.mNextCardId == null ? cardPos.mNextCardId == null : this.mNextCardId.equals(cardPos.mNextCardId));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mCardId == null ? 0: this.mCardId.hashCode());
        result = 31 * result + (this.mNextCardId == null ? 0: this.mNextCardId.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class EditDictionaryResultCardPos {\n");

        sb.append("  mCardId: ").append(mCardId).append("\n");
        sb.append("  mNextCardId: ").append(mNextCardId).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
