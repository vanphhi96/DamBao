/*
 * ファイル：SchSaveDialogFactory.java
 * 概要：Schedule Save Dialog
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories.customfactories;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl.DialogType;

/**
 * sch-cr-02
 *
 * @author Systena
 * @version 1.0
 */
public class SchSaveDialogFactory extends BaseDialogFactory implements View.OnClickListener {
    private TextView mTvDateTime;
    private TextView mTvTitle;
    private TextView mTvComment;
    private TextView mBtnOk;
    private ImageView mImvSchedule;
    private ScheduleInfo mSchedule;
    private DialogType mDialogType;
    private ISchSaveDialog mISchSaveDialog;
    private TextView mTvTitleDialog;
    private String mTitleDialog;

    public SchSaveDialogFactory(ScheduleInfo scheduleInfo, DialogType dialogType, ISchSaveDialog iSchSaveDialog) {
        this.mSchedule = scheduleInfo;
        this.mDialogType = dialogType;
        this.mISchSaveDialog = iSchSaveDialog;
    }

    @Override
    public AlertDialog getReadyAlertDialog(FragmentActivity activity) {
        AlertDialog.Builder builder = createDialogBuilder(activity);
        LayoutInflater inflater = activity.getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_save_schedule, null);
        view.setClipToOutline(true);
        mTvTitleDialog = view.findViewById(R.id.tv_title_dialog_sch_cr);
        mTvTitle = view.findViewById(R.id.tv_title_schedule_dialog_sch_cr);
        mTvComment = view.findViewById(R.id.tv_user_name_dialog_sch_cr);
        mTvDateTime = view.findViewById(R.id.tv_date_time_dialog_sch_cr);
        mBtnOk = view.findViewById(R.id.tv_btn_ok_dialog_sch_cr);
        mImvSchedule = view.findViewById(R.id.imv_ic_schedule_dialog_sch_cr);
        mBtnOk.setOnClickListener(this);
        setData();
        setPositivelyDialog(false);
        setCancelable(false);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.setCancelable(false);
        return alertDialog;
    }

    @Override
    public String getDialogTag() {
        return mDialogType.name();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_btn_ok_dialog_sch_cr:
                mISchSaveDialog.onClickOkSchSave();
                break;
            default:
                break;
        }
    }


    /**
     * set data for dialog
     */
    public void setData() {
        mImvSchedule.setImageResource(ResourcesUtils.getScheduleIconResourceFromId(mSchedule.getIconName()));
        mTvTitleDialog.setText(mTitleDialog);
        mTvTitle.setText(mSchedule.getTitle());
        String strTime;
        if (mSchedule.isAllDay()) {
            if (DateUtils.compareEqualDate(mSchedule.getScheduleStartDate(), mSchedule.getScheduleEndDate())) {
                strTime = mTvDateTime.getContext().getString(R.string.sch_allday)
                        + " " + DateUtils.convertDateToString(mSchedule.getScheduleStartDate(), DateUtils.DATE_FORMAT_DIC_DETAIL);
            } else {
                strTime = mTvDateTime.getContext().getString(R.string.sch_allday)
                        + " " + DateUtils.convertDateToString(mSchedule.getScheduleStartDate(), DateUtils.DATE_FORMAT_DIC_DETAIL)
                        + "-" + DateUtils.convertDateToString(mSchedule.getScheduleEndDate(), DateUtils.DATE_FORMAT_DIC_DETAIL);
            }
        } else {
            if (DateUtils.compareEqualDate(mSchedule.getScheduleStartDate(), mSchedule.getScheduleEndDate())) {
                strTime = DateUtils.convertDateToString(mSchedule.getScheduleStartDate(), DateUtils.SCHEDULE_DETAIL_DATE_TIME_FORMAT)
                        + "-" + DateUtils.convertDateToString(mSchedule.getScheduleEndDate(), DateUtils.TIME_PICKER_FORMAT);
            } else {
                strTime = DateUtils.convertDateToString(mSchedule.getScheduleStartDate(), DateUtils.SCHEDULE_DETAIL_DATE_TIME_FORMAT)
                        + "-" + DateUtils.convertDateToString(mSchedule.getScheduleEndDate(), DateUtils.SCHEDULE_DETAIL_DATE_TIME_FORMAT);
            }
        }
        mTvDateTime.setText(strTime);
        mTvComment.setText(mSchedule.getNote());
    }

    /**
     * set value title dialog
     *
     * @param title title dialog
     */
    public void setTitleDialog(String title) {
        this.mTitleDialog = title;
    }

}
