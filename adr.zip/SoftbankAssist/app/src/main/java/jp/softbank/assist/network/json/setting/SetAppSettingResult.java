/*
 * ファイル：SetAppSettingResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.setting;

import com.google.gson.annotations.SerializedName;

/**
 * 位置情報取得可否設定結果.
 */
public class SetAppSettingResult {

    @SerializedName("mId")
    private Long mId = null;
    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("is_requested_location_on")
    private Long mIsRequestedLocationOn = null;
    @SerializedName("is_regular_location_on")
    private Long mIsRegularLocationOn = null;
    @SerializedName("regular_location_term_kind")
    private Long mRregularLocationTermKind = null;
    @SerializedName("regular_location_starttime")
    private String mRegularLocationStarttime = null;
    @SerializedName("regular_location_endtime")
    private String mRegularLocationEndtime = null;
    @SerializedName("is_fence_on")
    private Long mIsFenceOn = null;
    @SerializedName("created_at")
    private String mCreatedAt = null;
    @SerializedName("updated_at")
    private String mUpdatedAt = null;


    /**
     * ID.
     */
    public Long getId() {
        return mId;
    }
    public void setId(Long id) {
        this.mId = id;
    }

    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * リクエスト位置取得（0： 無効、1：有効）.
     */
    public Long getIsRequestedLocationOn() {
        return mIsRequestedLocationOn;
    }
    public void setIsRequestedLocationOn(Long isRequestedLocationOn) {
        this.mIsRequestedLocationOn = isRequestedLocationOn;
    }

    /**
     * 定期位置取得（0：無効、1：有効）.
     */
    public Long getIsRegularLocationOn() {
        return mIsRegularLocationOn;
    }
    public void setIsRegularLocationOn(Long isRegularLocationOn) {
        this.mIsRegularLocationOn = isRegularLocationOn;
    }

    /**
     * 定期位置取得期間種別（0：時刻指定、1：終日）.
     */
    public Long getRegularLocationTermKind() {
        return mRregularLocationTermKind;
    }
    public void setRegularLocationTermKind(Long regularLocationTermKind) {
        this.mRregularLocationTermKind = regularLocationTermKind;
    }

    /**
     * 定期位置取得開始時刻（hhmm）.
     */
    public String getRegularLocationStarttime() {
        return mRegularLocationStarttime;
    }
    public void setRegularLocationStarttime(String regularLocationStarttime) {
        this.mRegularLocationStarttime = regularLocationStarttime;
    }

    /**
     * 定期位置取得終了時刻（hhmm）.
     */
    public String getRegularLocationEndtime() {
        return mRegularLocationEndtime;
    }
    public void setRegularLocationEndtime(String regularLocationEndtime) {
        this.mRegularLocationEndtime = regularLocationEndtime;
    }

    /**
     * みまもるフェンス（0： 無効、1：有効）.
     */
    public Long getIsFenceOn() {
        return mIsFenceOn;
    }
    public void setIsFenceOn(Long isFenceOn) {
        this.mIsFenceOn = isFenceOn;
    }

    /**
     * 作成日時（YYYYMMDDhhmmss）.
     */
    public String getCreatedAt() {
        return mCreatedAt;
    }
    public void setCreatedAt(String createdAt) {
        this.mCreatedAt = createdAt;
    }

    /**
     * 更新日時（YYYYMMDDhhmmss）.
     */
    public String getUpdatedAt() {
        return mUpdatedAt;
    }
    public void setUpdatedAt(String updatedAt) {
        this.mUpdatedAt = updatedAt;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SetAppSettingResult resultAppSetting = (SetAppSettingResult) o;
        return (this.mId == null ? resultAppSetting.mId == null : this.mId.equals(resultAppSetting.mId)) &&
                (this.mUserId == null ? resultAppSetting.mUserId == null : this.mUserId.equals(resultAppSetting.mUserId)) &&
                (this.mIsRequestedLocationOn == null ? resultAppSetting.mIsRequestedLocationOn == null : this.mIsRequestedLocationOn.equals(resultAppSetting.mIsRequestedLocationOn)) &&
                (this.mIsRegularLocationOn == null ? resultAppSetting.mIsRegularLocationOn == null : this.mIsRegularLocationOn.equals(resultAppSetting.mIsRegularLocationOn)) &&
                (this.mRregularLocationTermKind == null ? resultAppSetting.mRregularLocationTermKind == null : this.mRregularLocationTermKind.equals(resultAppSetting.mRregularLocationTermKind)) &&
                (this.mRegularLocationStarttime == null ? resultAppSetting.mRegularLocationStarttime == null : this.mRegularLocationStarttime.equals(resultAppSetting.mRegularLocationStarttime)) &&
                (this.mRegularLocationEndtime == null ? resultAppSetting.mRegularLocationEndtime == null : this.mRegularLocationEndtime.equals(resultAppSetting.mRegularLocationEndtime)) &&
                (this.mIsFenceOn == null ? resultAppSetting.mIsFenceOn == null : this.mIsFenceOn.equals(resultAppSetting.mIsFenceOn)) &&
                (this.mCreatedAt == null ? resultAppSetting.mCreatedAt == null : this.mCreatedAt.equals(resultAppSetting.mCreatedAt)) &&
                (this.mUpdatedAt == null ? resultAppSetting.mUpdatedAt == null : this.mUpdatedAt.equals(resultAppSetting.mUpdatedAt));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mId == null ? 0: this.mId.hashCode());
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mIsRequestedLocationOn == null ? 0: this.mIsRequestedLocationOn.hashCode());
        result = 31 * result + (this.mIsRegularLocationOn == null ? 0: this.mIsRegularLocationOn.hashCode());
        result = 31 * result + (this.mRregularLocationTermKind == null ? 0: this.mRregularLocationTermKind.hashCode());
        result = 31 * result + (this.mRegularLocationStarttime == null ? 0: this.mRegularLocationStarttime.hashCode());
        result = 31 * result + (this.mRegularLocationEndtime == null ? 0: this.mRegularLocationEndtime.hashCode());
        result = 31 * result + (this.mIsFenceOn == null ? 0: this.mIsFenceOn.hashCode());
        result = 31 * result + (this.mCreatedAt == null ? 0: this.mCreatedAt.hashCode());
        result = 31 * result + (this.mUpdatedAt == null ? 0: this.mUpdatedAt.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class SetAppSettingResult {\n");

        sb.append("  mId: ").append(mId).append("\n");
        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mIsRequestedLocationOn: ").append(mIsRequestedLocationOn).append("\n");
        sb.append("  mIsRegularLocationOn: ").append(mIsRegularLocationOn).append("\n");
        sb.append("  mRregularLocationTermKind: ").append(mRregularLocationTermKind).append("\n");
        sb.append("  mRegularLocationStarttime: ").append(mRegularLocationStarttime).append("\n");
        sb.append("  mRegularLocationEndtime: ").append(mRegularLocationEndtime).append("\n");
        sb.append("  mIsFenceOn: ").append(mIsFenceOn).append("\n");
        sb.append("  mCreatedAt: ").append(mCreatedAt).append("\n");
        sb.append("  mUpdatedAt: ").append(mUpdatedAt).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
