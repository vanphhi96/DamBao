/*
 * ファイル：AssistServerInterface.java
 * 概要：アシストサーバー向けのI/Fを提供する
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.SparseLongArray;

import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.model.database.LocationInfo;
import jp.softbank.assist.model.database.LocationSettings;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.model.database.UserInfo;
import jp.softbank.assist.network.api.ApiBaseObject;
import jp.softbank.assist.network.api.WebApiInterface;
import jp.softbank.assist.network.listener.BaseResultListener;
import jp.softbank.assist.network.listener.CountScheduleResultListener;
import jp.softbank.assist.network.listener.GetAppVersionResultListener;
import jp.softbank.assist.network.listener.GetDictionaryListResultListener;
import jp.softbank.assist.network.listener.GetHistoryResultListener;
import jp.softbank.assist.network.listener.GetImageResultListener;
import jp.softbank.assist.network.listener.GetNoticeResultListener;
import jp.softbank.assist.network.listener.GetScheduleListResultListener;
import jp.softbank.assist.network.listener.GetUserInfoResultListener;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.Constants;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * アシストサーバー向けI/Fクラス.
 *
 * @author Systena
 * @version 1.0
 */
public abstract class AssistServerInterface {

//    /**
//     * 辞書カテゴリ一覧取得.
//     *
//     * @param listener コールバックリスナ
//     */
//    @Deprecated
//    public abstract void getCategoryList(final GetCategoryListResultListener listener);

    /**
     * 辞書カテゴリ一覧取得.
     *
     * @return カテゴリ情報一覧
     */
    public abstract List<CategoryInfo> getCategoryList();

    /**
     * 辞書差分一覧取得.
     */
    public abstract void getDifferenceListDictionary();

    /**
     * カテゴリ別辞書一覧取得.
     *
     * @param categoryId カテゴリID
     * @param listener   コールバックリスナ
     */
    public abstract void getDictionaryList(final long categoryId, final GetDictionaryListResultListener listener);

    /**
     * 辞書登録.
     *
     * @param info     辞書情報
     * @param listener コールバックリスナ
     */
    public abstract void addDictionary(final DictionaryInfo info, final NotifyOnlyResultListener listener);

    /**
     * 辞書編集.
     *
     * @param info     辞書情報
     * @param listener コールバックリスナ
     */
    public abstract void editDictionary(final DictionaryInfo info, final NotifyOnlyResultListener listener);

    /**
     * 辞書削除.
     *
     * @param dictionaryId 辞書ID
     * @param listener     コールバックリスナ
     */
    public abstract void deleteDictionary(final long dictionaryId, final NotifyOnlyResultListener listener);

    /**
     * 辞書画像取得.
     *
     * @param dictionaryId 辞書ID
     * @param listener     コールバックリスナ
     */
    public abstract void getDictionaryImage(final long dictionaryId, final GetImageResultListener listener);

    /**
     * カード画像取得.
     *
     * @param cardInfo   辞書
     * @param listener コールバックリスナ
     */
    public abstract void getCardImage(final CardInfo cardInfo, final GetImageResultListener listener);

    /**
     * 辞書の並び替えを保存.
     *
     * @param list 辞書一覧
     */
    public abstract void saveDictionaryOrder(final List<DictionaryInfo> list);

    /**
     * 辞書の並び替えを保存.
     *
     * @param categoryId カテゴリID
     * @param idArray    辞書ID配列
     */
    public abstract void saveDictionaryOrder(final long categoryId, final SparseLongArray idArray);

    /**
     * スケジュール同期.
     */
    public abstract void syncScheduleList();

    /**
     * スケジュール取得（日付指定）.
     *
     * @param date     日付
     * @param listener コールバックリスナ
     */
    public abstract void getScheduleList(final Date date, final GetScheduleListResultListener listener);

    /**
     * スケジュール追加.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    public abstract void addSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener);

    /**
     * スケジュール編集.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    public abstract void editSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener);

    /**
     * スケジュール削除.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    public abstract void deleteSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener);

    /**
     * スケジュール完了.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    public abstract void completeSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener);

    /**
     * スケジュール件数の取得.
     *
     * @param yearmonth 年月
     * @param listener  コールバックリスナ
     */
    public abstract void countSchedule(final Date yearmonth, final CountScheduleResultListener listener);

    /**
     * 位置測位結果の送信.
     *
     * @param info 位置測位結果.
     */
    public abstract void registLocation(final LocationInfo info);

    /**
     * 操作履歴取得.
     *
     * @param displayPage         表示ページ
     * @param displayCountPerPage ページあたりの表示件数
     * @param listener            コールバックリスナ
     */
    public abstract void getHistory(final int displayPage, final int displayCountPerPage, final GetHistoryResultListener listener);

    /**
     * 最新のお知らせ取得.
     *
     * @param listener コールバックリスナ
     * @deprecated WebViewへ変更
     */
    @Deprecated
    public abstract void getLatestNotice(final GetNoticeResultListener listener);

    /**
     * デバイス情報の登録・更新.
     */
    public abstract void registDeviceInfo();

    /**
     * FCMトークン更新.
     *
     * @param token トークン
     */
    public abstract void updateFcmToken(final String token);

    /**
     * 最新のアプリバージョン取得.
     *
     * @param listener コールバックリスナ
     */
    public abstract void getLatestAppVersion(final GetAppVersionResultListener listener);

    /**
     * 位置情報更新可否設定の取得.
     *
     * @return LocationSettings
     */
    public abstract LocationSettings getLocationSettings();

    /**
     * 位置情報更新可否設定の更新.
     *
     * @param settings 設定値
     */
    public abstract void setLocationSettings(final LocationSettings settings);

    /**
     * 位置情報更新可否設定の送信.
     */
    public abstract void sendLocationSettings(final LocationSettings settings, final NotifyOnlyResultListener listener);

    /**
     * 最新の利用者情報取得.
     *
     * @param listener コールバックリスナ
     */
    public abstract void getLatestUserInfo(final GetUserInfoResultListener listener);

    /**
     * 利用者情報の更新.
     *
     * @param info 利用者情報
     * @param listener コールバックリスナ
     */
    public abstract void editUserInfo(final UserInfo info, final NotifyOnlyResultListener listener);

    /**
     * 自身の利用者アイコンIDの取得.
     *
     * @return 利用者アイコンID（0:未設定もしくは初期設定未完了）
     */
    public abstract int getMyUserIcon();




    protected WebApiInterface mWebApiInterface; // WebApi用クラス
    protected WebApiThread mWebApiThread; // 非同期処理用スレッド
    protected PrivateHandler mUiHandler; // 非同期通知用ハンドラ
    protected ConcurrentLinkedQueue<ApiBaseObject> mRequestQueue; // リクエストキュー
    protected ConcurrentLinkedQueue<ApiBaseObject> mResponseQueue; // レスポンスキュー
    protected final Object mSyncObj = new Object(); // 同期オブジェクト

    /**
     * インスタンス生成.
     *
     * @param ctx コンテキスト
     * @return AssistServerInterface
     */
    public static AssistServerInterface newInstance(Context ctx) {
        AssistServerInterface assitIf;
//        if (Constants.DBG_ENABLE_MOCK) {
            assitIf = new AssistServerInterfaceStub(ctx);
//        } else {
//            assitIf = new AssistServerInterfaceImpl(ctx);
//        }
        assitIf.startThread();
        return assitIf;
    }

    /**
     * コンストラクタ（通常生成抑止）.
     */
    private AssistServerInterface() {
    }

    /**
     * コンストラクタ.
     *
     * @param ctx コンテキスト
     */
    protected AssistServerInterface(Context ctx) {
        mWebApiInterface = WebApiInterface.getInstance(ctx);

        mRequestQueue = new ConcurrentLinkedQueue<ApiBaseObject>();
        mResponseQueue = new ConcurrentLinkedQueue<ApiBaseObject>();

        // 非同期処理開始（UI向け）
        HandlerThread hThread = new HandlerThread(getClass().getSimpleName());
        hThread.start();
        mUiHandler = new PrivateHandler(hThread.getLooper());
    }

    /**
     * スレッド開始.
     */
    public void startThread() {
        if (mWebApiThread == null) {
            mWebApiThread = new WebApiThread();
            mWebApiThread.start();
        }
    }

    /**
     * スレッド終了.
     */
    public void finishThread() {
        if (mWebApiThread != null) {
            mWebApiThread.finish();
            mWebApiThread = null;
        }
    }

    /**
     * フォアグラウンドへ遷移.
     */
    public void notifyDidForeground() {
        // TODO:必要な場合は辞書とスケジュールのデータ同期を行う
    }

    /**
     * バックグラウンドへ遷移.
     */
    public void notifyDidBackground() {
        // TODO:次のデータ同期のための準備
    }

    /**
     * アプリケーションコンテキスト取得.
     *
     * @return Context
     */
    protected Context getAppContext() {
        return AppController.getInstance().getAppContext();
    }

    /**
     * アクセストークン取得.
     *
     * @return トークン
     */
    protected String getAccessToken() {
        // TODO:トークン
        return "";
    }

    /**
     * 利用者ID取得.
     *
     * @return 利用者ID
     */
    protected long getUserId() {
        // TODO:利用者ID
        return -1L;
    }

    /**
     * UIハンドラ取得.
     *
     * @return Handler
     */
    protected Handler getHandler() {
        return mUiHandler;
    }

    /**
     * リクエストとレスポンス用のキューに追加する.
     *
     * @param obj ApiBaseObject
     */
    protected void addQueue(ApiBaseObject obj) {
        synchronized (mSyncObj) {
            mRequestQueue.add(obj);
            mResponseQueue.add(obj);
        }
    }

    /**
     * リクエスト用キューから先頭を取り出す.
     *
     * @return ApiBaseObject (nullの場合は無し)
     */
    protected ApiBaseObject pollRequestQueue() {
        synchronized (mSyncObj) {
            return mRequestQueue.poll();
        }
    }

    /**
     * レスポンス用キューから削除する.
     *
     * @param obj ApiBaseObject
     */
    protected void removeResponseQueue(ApiBaseObject obj) {
        synchronized (mSyncObj) {
            mResponseQueue.remove(obj);
        }
    }

    /**
     * まとめてコールバック可能なリクエスト済みのレスポンスへ追加する.
     *
     * @param obj ApiBaseObject
     * @return true:追加した、false:無し
     */
    protected boolean addListenerToRegisteredResponse(ApiBaseObject obj, BaseResultListener listener) {
        synchronized (mSyncObj) {
            Iterator<ApiBaseObject> ite = mResponseQueue.iterator();
            while (ite.hasNext()) {
                ApiBaseObject temp = ite.next();
                if (temp.getApi() == obj.getApi()) {
                    temp.addCallback(listener);
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 非同期処理用（通信用）スレッド.
     */
    private class WebApiThread extends Thread {

        private boolean mLoop = true; // ループ実行フラグ

        /**
         * スレッド終了.
         */
        public void finish() {
            mLoop = false;
        }

        @Override
        public void run() {

            while (mLoop) {

                try {
                    sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                ApiBaseObject data = pollRequestQueue();
                if (data == null) {
                    continue;
                }

                data.asyncProcess(mWebApiInterface);
            }
        }
    }

    /**
     * UI向け非同期処理用ハンドラ.
     */
    private class PrivateHandler extends Handler {

        private PrivateHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            if (msg.obj instanceof ApiBaseObject) {
                ApiBaseObject obj = (ApiBaseObject)msg.obj;
                removeResponseQueue(obj);
                obj.postProcess();
            }
        }
    }
}
