/*
 * ファイル：WalMySbLoginWebActivity.java
 * 概要：MySB認証＆申し込み画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.walkthrough;

import jp.softbank.assist.view.activity.BaseWebActivity;

/**
 * wal-02
 * wal-03
 * wal-04
 *
 * @author Systena
 * @version 1.0
 */
public class WalMySbLoginWebActivity extends BaseWebActivity {
}
