/*
 * ファイル：BaseActivity.java
 * 概要：画面のベースクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;
import jp.softbank.assist.view.dialog.factories.customfactories.IndicatorDialogFactory;

/**
 * 画面のベースクラス
 *
 * @author Systena
 * @version 1.0
 */
public abstract class BaseActivity extends AppCompatActivity {

    public static final int TOAST_ID_NONE = -1;
    // 以下、引数渡し用アイテム名
    // Intent用
    public static final String INTENT_PUTKEY_TITLE = "intentMainTitle";
    public static final String INTENT_WEBVIEW_URL = "intentWebviewUrl";
    // Bundle用
    public static final String BUNDLE_PUTKEY_SUBTITLE = "bundleSubTitle";
    public static final String BUNDLE_PUT_KEY_DATA = "bundlePutKeyData";
    protected Handler mHandler = new Handler();
    private Toast mToast;
    private int mToastId = TOAST_ID_NONE;
    private DialogFragment mDialogSchDetail;

    /**
     * @param throwable
     * @param msg
     */
    protected void debugLog(Throwable throwable, String msg) {
        AssistLog.d(msg);
    }

    /**
     * スクリーンID取得.
     * ※各画面でオーバーライドすること
     *
     * @return ScreenId
     */
    public ScreenId getScreenId() {
        return AppController.getInstance().getViewManager().getScreenId();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        debugLog(new Throwable(), "onCreate");
        super.onCreate(savedInstanceState);
        AppController.getInstance().getViewManager().setActivity(this);
    }

    @Override
    protected void onStart() {
        debugLog(new Throwable(), "onStart");
        super.onStart();
    }

    @Override
    protected void onRestart() {
        debugLog(new Throwable(), "onRestart");
        super.onRestart();
    }

    @Override
    protected void onResume() {
        debugLog(new Throwable(), "onResume");
        super.onResume();
        AppController.getInstance().getViewManager().setActivity(this);
        AppController.getInstance().getAssistEventLog().handleSendEvent(this);
    }

    @Override
    protected void onPause() {
        closeIndicator();
        debugLog(new Throwable(), "onPause");
        super.onPause();

    }

    @Override
    protected void onStop() {
        debugLog(new Throwable(), "onStop");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        debugLog(new Throwable(), "onDestroy");
        AppController.getInstance().getViewManager().clearActivity(this);
        super.onDestroy();
    }

    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
    }

    /**
     * Toast表示（ショート）.
     *
     * @param resId リソースID
     */
    public void toastShowShort(int resId) {
        toastShow(getString(resId), Toast.LENGTH_SHORT, resId);
    }

    /**
     * Toast表示（ショート）.
     *
     * @param msg 表示テキスト
     */
    public void toastShowShort(final String msg) {
        toastShow(msg, Toast.LENGTH_SHORT, TOAST_ID_NONE);
    }

    /**
     * Toast表示（ロング）.
     *
     * @param resId リソースID
     */
    public void toastShowLong(int resId) {
        toastShow(getString(resId), Toast.LENGTH_LONG, resId);
    }

    /**
     * Toast表示（ロング）.
     *
     * @param msg 表示テキスト
     */
    public void toastShowLong(final String msg) {
        toastShow(msg, Toast.LENGTH_LONG, TOAST_ID_NONE);
    }

    /**
     * Toast表示メイン.
     *
     * @param msg     表示メッセージ
     * @param type    Toast.LENGTH_SHORT or Toast.LENGTH_LONG
     * @param toastId Toast ID (ToastをCancelする場合に使用)
     */
    private void toastShow(final String msg, final int type, final int toastId) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (msg != null) {
                    mToast = Toast.makeText(getBaseContext(), msg, type);
                } else {
                    mToastId = toastId;
                    mToast = Toast.makeText(getBaseContext(), toastId, type);
                }
                mToast.show();
            }
        });
    }

    /**
     * Toast表示キャンセル.
     *
     * @param toastId Toast ID
     */
    public void toastCancel(final int toastId) {
        // ToastIDが一致しない場合、キャンセルさせない
        if (mToastId != toastId) {
            return;
        }
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                mToastId = TOAST_ID_NONE;
                if (mToast != null) {
                    mToast.cancel();
                    mToast = null;
                }
            }
        });
    }

    /**
     * アクティビティ完了
     */
    public void finishActivity() {
        AppController.getInstance().getViewManager().finishActivity();
    }

    /**
     * アクティビティ変更
     *
     * @param id
     */
    public void changeScreen(ScreenId id) {
        AppController.getInstance().getViewManager().changeScreen(id);
    }

    /**
     * Change activity with data.
     *
     * @param id     screen id.
     * @param bundle bundle data
     */
    public void changeScreen(ScreenId id, Bundle bundle) {
        AppController.getInstance().getViewManager().changeScreen(id, bundle);
    }

    /**
     * change activity with startActivityResult
     *
     * @param id          screen id
     * @param requestCode request code
     * @param bundle      bundle data
     */
    public void changeScreenResult(ScreenId id, int requestCode, Bundle bundle) {
        AppController.getInstance().getViewManager().changeScreenResult(id, requestCode, bundle);
    }

    /**
     * send data from activity
     *
     * @param activity    activity back
     * @param bundle      bundle data
     * @param requestCode request code
     */
    public void backScreenResult(Activity activity, Bundle bundle, int requestCode) {
        AppController.getInstance().getViewManager().backScreenResult(activity, bundle, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        AssistLog.d(requestCode + " " + resultCode);
    }

    /**
     * show indicator loading
     */
    public synchronized void displayIndicator() {
        closeIndicator();
        IndicatorDialogFactory mDialogFactory = new IndicatorDialogFactory(DialogTypeControl.DialogType.INDICATOR_LOADING_DIALOG);
        mDialogSchDetail = new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * close indicator loading
     */
    public synchronized void closeIndicator() {
        if (mDialogSchDetail != null) {
            mDialogSchDetail.dismiss();
        }
        mDialogSchDetail = null;
    }
}

