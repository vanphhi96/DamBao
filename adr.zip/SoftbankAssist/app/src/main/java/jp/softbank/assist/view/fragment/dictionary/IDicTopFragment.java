/*
 * ファイル：IDicTopFragment.java
 * 概要：Interface click item in dic-01
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.fragment.dictionary;

import jp.softbank.assist.model.database.CategoryInfo;

/**
 * dic-01.
 *
 * @author Systena
 * @version 1.0
 */
public interface IDicTopFragment {
    /**
     * click item category dictionary
     *
     * @param categoryInfo
     */
    void onClickCategory(CategoryInfo categoryInfo);
}
