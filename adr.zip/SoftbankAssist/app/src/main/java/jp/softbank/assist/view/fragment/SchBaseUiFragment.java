/*
 * ファイル：SchBaseUiFragment.java
 * 概要：スケジュールベースクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.view.fragment.schedule.SchTopUiFragment;

/**
 * Sch Base
 *
 * @author Systena
 * @version 1.0
 */

public class SchBaseUiFragment extends BaseFragment {

    private boolean mIsFragShown = false;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sch_base, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Fragment childFragment = SchTopUiFragment.newInstance();
        replaceFragment(R.id.fr_sch_container, childFragment, false);
        if (!mIsFragShown) {
            AppController.getInstance().getViewManager().setFragment(childFragment);
            sendEventFirebaseScreenId();
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (getView() != null) {
                mIsFragShown = true;
                sendEventFirebaseScreenId(R.id.fr_sch_container);
            } else {
                mIsFragShown = false;
            }
        }
    }
}
