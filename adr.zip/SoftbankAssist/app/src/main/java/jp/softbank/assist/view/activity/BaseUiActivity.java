/*
 * ファイル：BaseUiActivity.java
 * 概要：UI画面のベースクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.DialogInterface;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.View;

import jp.softbank.assist.R;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.fragment.BaseFragment;
import jp.softbank.assist.view.fragmenttemp.DicTest_1;
import jp.softbank.assist.view.fragmenttemp.DicTest_2;
import jp.softbank.assist.view.fragmenttemp.SchTest_1;
import jp.softbank.assist.view.fragmenttemp.SchTest_2;

/**
 * UI画面のベースクラス
 *
 * @author Systena
 * @version 1.0
 */
public abstract class BaseUiActivity extends BaseActivity implements DialogInterface.OnClickListener {

    protected BaseFragment mCurrentFragment;

    public void setCurrentFraggment(BaseFragment fragment) {
        mCurrentFragment = fragment;
    }

    /**
     * replace fragment
     *
     * @param containerViewId  containerViewId
     * @param fragment         fragment
     * @param isAddToBackStack isBackStack
     */
    public void replaceFragment(int containerViewId, Fragment fragment, boolean isAddToBackStack) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if (isAddToBackStack) {
            transaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        transaction.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left, R.anim.enter_from_left, R.anim.exit_to_right);
        transaction.replace(containerViewId, fragment, fragment.getClass().getSimpleName());
        transaction.commitAllowingStateLoss();
    }

    /**
     * add fragment
     *
     * @param containerViewId  containerViewId
     * @param fragment         fragment
     * @param isAddToBackStack isBackStack
     */
    public void addFragment(int containerViewId, Fragment fragment, boolean isAddToBackStack) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if (isAddToBackStack) {
            transaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        transaction.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left, R.anim.enter_from_left, R.anim.exit_to_right);
        transaction.add(containerViewId, fragment, fragment.getClass().getSimpleName());
        transaction.commitAllowingStateLoss();
    }


    /**
     * Change fragment
     *
     * @param item item
     */
    public void changeFragmentInActivity(ScreenId item) {
        BaseFragment targetFragment = null;
        int containerViewId = 0;

        switch (item) {
            case START_FRAGMENT_SCHEDULE_ONE:
                targetFragment = new SchTest_1();
                containerViewId = R.id.fr_sch_container;
                break;
            case START_FRAGMENT_SCHEDULE_TWO:
                targetFragment = new SchTest_2();
                containerViewId = R.id.fr_sch_container;
                break;
            case START_FRAGMENT_DIC_ONE:
                targetFragment = new DicTest_1();
                containerViewId = R.id.fr_dic_container;
                break;
            case START_FRAGMENT_DIC_TWO:
                targetFragment = new DicTest_2();
                containerViewId = R.id.fr_dic_container;
                break;
            default:
                break;
        }

        if (targetFragment != null && containerViewId != 0) {
            replaceFragment(containerViewId, targetFragment, true);
        }
    }

    /**
     * Get Activity simple name
     *
     * @param activity activity
     */
    public String getSimpleName(Activity activity) {
        return activity.getClass().getSimpleName();
    }

    /**
     * ダイアログクリック時に使用
     */
    @Override
    public void onClick(DialogInterface dialog, int which) {
        if (mCurrentFragment != null) {
            mCurrentFragment.onClick(dialog, which);
        }
    }

    /**
     * Animation用
     *
     * @param view
     */
    public void showViewWithAnim(View view) {
        // TODO: 2019/04/18 Fix bug in Anim later
        view.setVisibility(View.VISIBLE);
        view.animate()
                .alpha(Constants.VISIBLE_ALPHA)
                .setDuration(Constants.FADE_DURATION).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
            }
        });
    }

    /**
     * Animation用
     *
     * @param view
     */
    public void hideViewWithAnim(final View view) {
        if (view.getVisibility() == View.GONE) {
            return;
        }
        view.animate()
                .alpha(Constants.GONE_ALPHA)
                .setDuration(Constants.FADE_DURATION)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        view.setVisibility(View.GONE);
                    }
                });
    }

}
