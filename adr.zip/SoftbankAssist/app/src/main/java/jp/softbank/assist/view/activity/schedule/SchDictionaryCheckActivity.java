/*
 * ファイル：SchDictionaryCheckActivity.java
 * 概要：Detail dictionary of schedule.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.schedule;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.activity.dictionary.IOnClickDetailDic;
import jp.softbank.assist.view.adapter.DetailDictionaryAdapter;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;
import jp.softbank.assist.view.dialog.factories.customfactories.DetailPictureDialogFactory;
import jp.softbank.assist.view.dialog.factories.customfactories.IDetailPicture;

/**
 * sch-dic-01.
 *
 * @author Systena
 * @version 1.0
 */
public class SchDictionaryCheckActivity extends BaseUiActivity implements IOnClickDetailDic, View.OnClickListener,
        IDetailPicture {
    private RecyclerView mRecycleView;
    private DetailDictionaryAdapter mAdapter;
    private RelativeLayout mBtnBack;
    private TextView mTvBack;
    private DialogFragment mDialogDetailPicture;
    private DictionaryInfo mDictionaryInfo;
    private int mColorBackgroundItem;
    private int mColorFlagItem;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_dictionary_check);
        mDictionaryInfo = getIntentDicInfo();
        mRecycleView = findViewById(R.id.recycle_dic_detail);
        mBtnBack = findViewById(R.id.rlt_dic_detail_back);
        mTvBack = findViewById(R.id.tv_back_dic_detail);
        mTvBack.setText(getString(R.string.sch_detail));
        mBtnBack.setOnClickListener(this);
        if (mDictionaryInfo != null) {
            mColorFlagItem = ResourcesUtils.getColorFlagItemDictionary(mDictionaryInfo.getCategoryId());
            mColorBackgroundItem = ResourcesUtils.getColorBackgroundItemDictionary(mDictionaryInfo.getCategoryId());
            initListDictionary();
        }
    }

    /**
     * get DictionaryInfo
     *
     * @return
     */
    private DictionaryInfo getIntentDicInfo() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_DICTIONARY_INFO)) {
            return (DictionaryInfo) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_DICTIONARY_INFO);
        } else {
            return null;
        }
    }

    /**
     * init list dictionary
     */
    private void initListDictionary() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayout.VERTICAL);
        mRecycleView.setLayoutManager(linearLayoutManager);

        mAdapter = new DetailDictionaryAdapter();
        mAdapter.setDictionary(mDictionaryInfo);
        mAdapter.setShowEdit(false);
        mAdapter.setActivity(this);
        mAdapter.setIOnClickDetailDic(this);
        mAdapter.setColorItem(mColorBackgroundItem, mColorFlagItem);
        mRecycleView.setAdapter(mAdapter);
    }

    @Override
    public void onClickSeeAgain() {
        mRecycleView.smoothScrollToPosition(0);
    }

    @Override
    public void onClickEdit() {
        changeScreen(ScreenId.START_DIC_EDIT);
    }

    @Override
    public void onClickZoomPicture(int position) {
        DetailPictureDialogFactory dialogFactory = new DetailPictureDialogFactory(DialogTypeControl.DialogType.DETAIL_PICTURE_DIALOG,
                this, mDictionaryInfo.getType());
        dialogFactory.setListCardInfo(mDictionaryInfo.getCardList());
        dialogFactory.setPositionStartPage(position);
        dialogFactory.setActivity(this);
        mDialogDetailPicture = new DialogGenerator(this, dialogFactory).show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rlt_dic_detail_back:
                onBackPressed();
                break;
            default:
                break;
        }
    }


    @Override
    public void dismissDialog() {
        mDialogDetailPicture.dismiss();
    }

    @Override
    public void onBackPressed() {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, mDictionaryInfo);
        backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_DICTIONARY);
    }
}
