/*
 * ファイル：ScheduleDetailDialogAdapter.java
 * 概要：Schedule Detail Dialog Adapter
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.RecyclerBaseAdapter;
import jp.softbank.assist.view.dialog.factories.customfactories.ISchDetailDialog;

import java.util.Date;


/**
 * adapter for sch-02
 *
 * @author Systena
 * @version 1.0
 */
public class ScheduleDetailDialogAdapter extends RecyclerBaseAdapter {
    private ISchDetailDialog mISchDetailDialog;
    private ScheduleInfo mScheduleInfo;
    private Date mDate;

    // set show header
    {
        setHeaderVisibility(true);//show header item
    }

    /**
     * Provide a suitable constructor (depends on the kind of data set)
     *
     * @param iSchDetailDialog
     */
    public ScheduleDetailDialogAdapter(ISchDetailDialog iSchDetailDialog) {
        this.mISchDetailDialog = iSchDetailDialog;
    }

    /**
     * set data to schedule info
     *
     * @param scheduleInfo
     */
    public void setData(ScheduleInfo scheduleInfo) {
        this.mScheduleInfo = scheduleInfo;
    }

    /**
     * set data date
     *
     * @param date
     */
    public void setDate(Date date) {
        this.mDate = date;
    }

    /**
     * Get content item count
     *
     * @return
     */
    @Override
    public int getContentItemCount() {
        return mScheduleInfo.getAttachedDictionaries() == null ? 0 : mScheduleInfo.getAttachedDictionaries().size();
    }

    /**
     * Create Header Holder
     *
     * @param parent
     * @return
     */
    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_sch_detail_header, parent, false);
        return new HeaderViewHolder(v);
    }

    /**
     * Create Footer Holder
     *
     * @param parent
     * @return
     */
    @Override
    public BaseViewHolder onCreateFooterHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int position) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_schedule_content_dialog, parent, false);
        return new ContentViewHolder(v);
    }

    /**
     * Class Content View Holder
     */
    private class HeaderViewHolder extends BaseViewHolder {
        private TextView mTvDateTime;
        private TextView mTvRepeat;
        private TextView mTvTitle;
        private TextView mTvContent;
        private TextView mTvAddressDetail;
        private RelativeLayout mRlHeader;
        private ImageView mImgSchedule;
        private View mViewLine;
        private LinearLayout mLnDictionary;

        HeaderViewHolder(View v) {
            super(v);
            mTvDateTime = v.findViewById(R.id.tv_date_time);
            mTvRepeat = v.findViewById(R.id.tv_repeat);
            mTvTitle = v.findViewById(R.id.tv_title);
            mTvContent = v.findViewById(R.id.tv_content);
            mTvAddressDetail = v.findViewById(R.id.tv_address_detail);
            mRlHeader = v.findViewById(R.id.rl_header);
            mImgSchedule = v.findViewById(R.id.img_schedule);
            mViewLine = v.findViewById(R.id.view_line);
            mLnDictionary = v.findViewById(R.id.ln_dictionary);
        }

        @Override
        public void onBindView(int position) {
            if (mScheduleInfo.getAttachedDictionaries() == null || mScheduleInfo.getAttachedDictionaries().size() == 0) {
                mRlHeader.setBackground(mRlHeader.getContext().getDrawable(R.drawable.bgr_radius_bottom_20dp));
                mViewLine.setVisibility(View.INVISIBLE);
                mLnDictionary.setVisibility(View.GONE);
            }
            if (mScheduleInfo.isAllDay()) {
                String strTime = mTvDateTime.getContext().getString(R.string.sch_allday);
                if (DateUtils.compareEqualDate(mScheduleInfo.getScheduleStartDate(), mScheduleInfo.getScheduleEndDate())) {
                    strTime = strTime + " " + DateUtils.convertDateToString(mScheduleInfo.getScheduleStartDate(), DateUtils.DATE_FORMAT_DIC_DETAIL);
                } else {
                    strTime = strTime + DateUtils.convertDateToString(mScheduleInfo.getScheduleStartDate(), DateUtils.DATE_FORMAT_DIC_DETAIL)
                            + "-" + DateUtils.convertDateToString(mScheduleInfo.getScheduleEndDate(), DateUtils.DATE_FORMAT_DIC_DETAIL);
                }
                mTvDateTime.setText(strTime);
            } else {
                String strTime;
                if (DateUtils.compareEqualDate(mScheduleInfo.getScheduleStartDate(), mScheduleInfo.getScheduleEndDate())) {
                    strTime = DateUtils.convertDateToString(mScheduleInfo.getScheduleStartDate(), DateUtils.SCHEDULE_DETAIL_DATE_TIME_FORMAT)
                            + "-" + DateUtils.convertDateToString(mScheduleInfo.getScheduleEndDate(), DateUtils.TIME_PICKER_FORMAT);
                } else {
                    strTime = DateUtils.convertDateToString(mScheduleInfo.getScheduleStartDate(), DateUtils.SCHEDULE_DETAIL_DATE_TIME_FORMAT)
                            + "-" + DateUtils.convertDateToString(mScheduleInfo.getScheduleEndDate(), DateUtils.SCHEDULE_DETAIL_DATE_TIME_FORMAT);
                }
                mTvDateTime.setText(strTime);
            }
            setTextRepeat(mTvRepeat, mScheduleInfo.getInterval());
            mTvTitle.setText(mScheduleInfo.getTitle());
            mTvContent.setText(mScheduleInfo.getNote());
            mTvAddressDetail.setText(mScheduleInfo.getLocation());
            mImgSchedule.setImageResource(ResourcesUtils.getScheduleIconResourceFromId(mScheduleInfo.getIconName()));

        }

    }

    /**
     * set text repeat
     *
     * @param tvRepeat TextView repeat
     * @param interval type repeat
     */
    private void setTextRepeat(TextView tvRepeat, ScheduleInfo.IntervalType interval) {
        if (interval == null) {
            tvRepeat.setVisibility(View.GONE);
            return;
        }
        switch (interval) {
            case Daily:
                tvRepeat.setText(tvRepeat.getContext().getString(R.string.sch_every_day));
                break;
            case Weekly:
                tvRepeat.setText(tvRepeat.getContext().getString(R.string.sch_every_week));
                break;
            case Monthly:
                tvRepeat.setText(tvRepeat.getContext().getString(R.string.sch_every_month));
                break;
            case Yearly:
                tvRepeat.setText(tvRepeat.getContext().getString(R.string.sch_every_year));
                break;
            case None:
            default:
                tvRepeat.setVisibility(View.GONE);
                break;
        }

    }

    /**
     * Class Content View Holder
     */
    private class ContentViewHolder extends BaseViewHolder {
        private LinearLayout mLayoutContent;
        private LinearLayout mLnParent;
        private ImageView mImgDictionary;
        private TextView mTvDictionary;
        private View mViewFlag;

        ContentViewHolder(View view) {
            super(view);
            mLnParent = view.findViewById(R.id.ln_parent);
            mViewFlag = view.findViewById(R.id.view_flag);
            mLayoutContent = view.findViewById(R.id.ln_schedule_content);
            mImgDictionary = view.findViewById(R.id.img_dictionary);
            mTvDictionary = view.findViewById(R.id.tv_dictionary);
            mLayoutContent.setClipToOutline(true);
            mImgDictionary.setClipToOutline(true);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mISchDetailDialog != null && getLayoutPosition() != RecyclerView.NO_POSITION) {
                        mISchDetailDialog.showDetailDictionary(mScheduleInfo.getAttachedDictionaries().get(getLayoutPosition() - 1));
                    }
                }
            });
        }

        @Override
        public void onBindView(int position) {
            DictionaryInfo dictionaryInfo = mScheduleInfo.getAttachedDictionaries().get(position - 1);
            mViewFlag.setBackgroundColor(mViewFlag.getContext().getColor(ResourcesUtils.getColorFlagItemDictionary(dictionaryInfo.getCategoryId())));
            if (position == mScheduleInfo.getAttachedDictionaries().size()) {
                mLnParent.setBackground(mLnParent.getContext().getDrawable(R.drawable.bgr_radius_bottom_20dp));
            }
            GradientDrawable drawable = (GradientDrawable) mLayoutContent.getBackground();
            drawable.setColor(mLayoutContent.getContext().getColor(ResourcesUtils.getColorBackgroundItemDictionary(dictionaryInfo.getCategoryId())));
            mTvDictionary.setText(dictionaryInfo.getName());
            Bitmap bitmap = ResourcesUtils.getImageFromPath(mImgDictionary.getContext(), dictionaryInfo.getImageFileAbsolutePath());
            if (bitmap == null) {
                mImgDictionary.setImageDrawable(mImgDictionary.getContext().getDrawable(R.drawable.ic_card_default));
            } else {
                mImgDictionary.setImageBitmap(bitmap);
            }
        }
    }
}
