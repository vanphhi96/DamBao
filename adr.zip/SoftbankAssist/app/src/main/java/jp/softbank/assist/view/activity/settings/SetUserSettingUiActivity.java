/*
 * ファイル：SetUserSettingUiActivity.java
 * 概要：利用者設定画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.settings;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.UserInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetUserInfoResultListener;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.adapter.SetUserPagerAdapter;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;

import java.util.List;

/**
 * set-acc-01
 *
 * @author Systena
 * @version 1.0
 */
public class SetUserSettingUiActivity extends BaseUiActivity implements View.OnClickListener,
        ISetOnIconItemClick,
        GetUserInfoResultListener,
        NotifyOnlyResultListener {

    public static final int LIMIT_ITEM = 8; // Maximum Item Icon for each Fragment

    private DialogFragment mDialogSave;
    private TextView mTvSave;
    private LinearLayout mLnBack;
    private ViewPager mVpIconList;
    private EditText mEdtNickName;
    private TabLayout mTabLayout;
    private SetUserPagerAdapter mPagerAdapter;
    private List<Integer> mIconListId;
    private View mFrPagerContainer;
    private View mFrEditContainer;
    private View mRlContainer;
    private ImageView mImgIcon;
    private long mIconId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_user);
        initView();
        initViewPagerAndAdapter();
        AppController.getInstance().getAssistServerInterface().getLatestUserInfo(this);
        displayIndicator();
    }

    /**
     * Viewを初期化
     */
    private void initView() {
        mTvSave = findViewById(R.id.tv_save);
        mLnBack = findViewById(R.id.ln_back);
        mImgIcon = findViewById(R.id.img_icon);
        mEdtNickName = findViewById(R.id.edit_text_nick_name);
        mVpIconList = findViewById(R.id.view_pager_list_icon);
        mTabLayout = findViewById(R.id.tab_layout);
        mFrPagerContainer = findViewById(R.id.fr_viewpager_container);
        mFrEditContainer = findViewById(R.id.fr_edit_icon_container);
        mRlContainer = findViewById(R.id.rl_set_container);
        mFrEditContainer.setOnClickListener(this);
        mTvSave.setOnClickListener(this);
        mLnBack.setOnClickListener(this);
        mRlContainer.setOnClickListener(this);
    }

    /**
     * ViewPager&Adapter初期化
     */
    private void initViewPagerAndAdapter() {
        mIconListId = ResourcesUtils.getUserIconResourceList();
        mTabLayout.setupWithViewPager(mVpIconList, true);
        mPagerAdapter = new SetUserPagerAdapter(getSupportFragmentManager());
        mPagerAdapter.setIconList(mIconListId);
        mVpIconList.setOffscreenPageLimit(getScreenLimit());
        mVpIconList.setAdapter(mPagerAdapter);
    }

    /**
     * 全てFragmentの数を取得
     *
     * @return
     */
    private int getScreenLimit() {
        int fragmentCount = mIconListId.size() / LIMIT_ITEM + 1;
        if (mIconListId.size() % LIMIT_ITEM == 0) {
            fragmentCount--;
        }
        return fragmentCount;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.rl_set_container:
                if (mEdtNickName.hasFocus()) {
                    hideKeyboard(mEdtNickName);
                    mEdtNickName.clearFocus();
                } else {
                    hideViewWithAnim(mFrPagerContainer);
                }
                break;
            case R.id.img_back:
                onBackPressed();
                break;
            case R.id.fr_edit_icon_container:
                showViewWithAnim(mFrPagerContainer);
                break;
            case R.id.tv_save:
                displayIndicator();
                AppController.getInstance().getAssistServerInterface().editUserInfo(getNewUserInfo(), this);
                break;
            case R.id.ln_back:
                onBackPressed();
            default:
                break;
        }
    }

    /**
     * Save Dialogを表示
     */
    private void buildSaveUserDialog() {
        AssistAlertDialogFactory mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.SET_SAVE_DIALOG);
        new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * List Iconを隠す (Animation用)
     *
     * @param itemPosition
     * @param fragmentPosition
     */
    private void hideListIcon(final int itemPosition, final int fragmentPosition) {
        mFrPagerContainer.animate()
                .alpha(Constants.GONE_ALPHA)
                .setDuration(Constants.FADE_DURATION)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        mIconId = getIconId(itemPosition, fragmentPosition);
                        mImgIcon.setImageResource((int) mIconId);
                        mFrPagerContainer.setVisibility(View.GONE);
                    }
                });
    }

    /**
     * 画像IDの取得
     *
     * @param itemPosition
     * @param fragmentPosition
     * @return 押した画像ID
     */
    private int getIconId(int itemPosition, int fragmentPosition) {
        return mIconListId.get(fragmentPosition * LIMIT_ITEM + itemPosition);
    }

    /**
     * Keyboardを隠す
     *
     * @param view
     */
    private void hideKeyboard(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private void updateUserInfo(UserInfo info) {
        mImgIcon.setImageResource(ResourcesUtils.getUserIconResourceFromId((int) info.getIconId()));
        mEdtNickName.setText(info.getNickname());
    }

    @Override
    public void onStartConnection() {

    }

    /**
     * 最新UserInfoを取得
     *
     * @return
     */
    private UserInfo getNewUserInfo() {
        UserInfo userInfo = new UserInfo();
        userInfo.setNickname(mEdtNickName.getText().toString());
        userInfo.setIconId(mIconId);
        return userInfo;
    }

    /**
     * NotifyOnlyResultListener
     *
     * @param result 処理結果
     */
    @Override
    public void onResult(AssistServerResult result) {
        closeIndicator();
        if (result.mResult != AssistServerResult.Result.Success) {
            // TODO: 2019/04/16 T.B.D
            return;
        }
        buildSaveUserDialog();
    }

    /**
     * GetUserInfoResultListener
     *
     * @param result 処理結果
     * @param info   アプリバージョン情報
     */
    @Override
    public void onResult(AssistServerResult result, final UserInfo info) {
        closeIndicator();
        if (info == null || result.mResult != AssistServerResult.Result.Success) {
            // TODO: 2019/04/16 T.B.D
            return;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mRlContainer.setVisibility(View.VISIBLE);
                updateUserInfo(info);
            }
        });
    }

    /**
     * ISetOnIconItemClick
     *
     * @param itemPosition
     * @param fragmentPosition
     */
    @Override
    public void onItemSelected(int itemPosition, int fragmentPosition) {
        mPagerAdapter.notifyDataSetChanged();
        hideListIcon(itemPosition, fragmentPosition);
    }
}
