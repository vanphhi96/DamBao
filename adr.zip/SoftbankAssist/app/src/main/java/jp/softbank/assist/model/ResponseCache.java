/*
 * ファイル：ResponseCache.java
 * 概要：レスポンスのキャッシュ管理を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model;

/**
 * レスポンス用キャッシュ管理.
 *
 * @author Systena
 * @version 1.0
 */
public class ResponseCache {
}
