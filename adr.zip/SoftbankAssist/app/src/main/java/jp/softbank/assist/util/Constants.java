/*
 * ファイル：Constants.java
 * 概要：アプリの定数定義
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.util;

import android.content.Context;

import jp.softbank.assist.BuildConfig;
import jp.softbank.assist.R;

import java.util.Locale;

/**
 * 定数定義.
 *
 * @author Systena
 * @version 1.0
 */
public final class Constants {
    /**
     * Hmdect Log出力判定フラグ.
     */
    public static final boolean DBG_LOG = BuildConfig.DEBUG; // リリースビルド時はfalse

    /**
     * モック版動作の有効化.
     */
    public static final boolean DBG_ENABLE_MOCK = true;

    /**
     * アップデート画面への遷移の無効化.
     */
    public static final boolean DBG_DISABLE_UPDATE = true;

    /**
     * Tag used for debugging/logging
     */
    public static final String TAG = "ASSIST";

    /**
     * 保存先ディレクトリ名.
     */
    public static final String SAVED_FILE_DIRECTORY = "Documents";

    public static final float VISIBLE_ALPHA = 1.0f;
    public static final float GONE_ALPHA = 0.0f;
    public static final int FADE_DURATION = 300; // 300ms

    /**
     * get category name
     *
     * @param categoryId Category ID
     * @param context    context
     * @return String
     */
    public static String getCategoryName(long categoryId, Context context) {
        if (categoryId == Ids.CATEGORY_ID_HOW_TO_DO) {
            return context.getString(R.string.how_to_do);
        } else if (categoryId == Ids.CATEGORY_ID_HOW_TO_GO) {
            return context.getString(R.string.how_to_go);
        } else if (categoryId == Ids.CATEGORY_ID_PROPERTY) {
            return context.getString(R.string.belongings);
        }
        return context.getString(R.string.nothing);
    }

    /**
     * 固定ID.
     */
    public static final class Ids {
        public static final long ID_NONE = 0L; // 未設定のID（共通）

        // 辞書カテゴリID
        public static final long CATEGORY_ID_HOW_TO_DO = 1L; // 「やりかた」
        public static final long CATEGORY_ID_HOW_TO_GO = 2L; // 「行きかた」
        public static final long CATEGORY_ID_PROPERTY = 3L; // 「持ちもの」
    }

    /**
     * メインタブ用
     */
    public static final class Tab {
        public static final int DEFAULT_TAB_POSITION = 0; // First tab position
        public static final int SPLASH_TIME_OUT = 5000; // After 5 seconds, trigger MainActivity
        public static final int TAB_ITEM_NUMBER_MENU = 3; // Number of tab icons in Menu
        public static final int TAB_ITEM_NUMBER_WELCOME = 2; // Number of tab icons in Welcome
    }

    /**
     * Type repeat schedule
     */
    public static final class CreateSchedule {
        public static final int NOT_REPEAT = 0;
        public static final int DAILY_REPEAT = 1;
        public static final int WEEKLY_REPEAT = 2;
        public static final int MONTHLY_REPEAT = 3;
        public static final int ANNUAL_REPEAT = 4;
    }

    /**
     * Dictionary constant definition
     */
    public static final class Dictionary {
        public static final String TAKE_PICTURE_TEMP_FILENAME = "photo_temp.png";
        public static final String FILE_PROVIDER_AUTHORITY = "jp.softbank.assist";

        public static final String DICTIONARY_DIR = "/dic%d/";
        public static final String DICTIONARY_TEMP_DIR = "/dic_temp/";

        public static final String DICTIONARY_IMAGE_FILENAME = "dic.png";
        public static final String DICTIONARY_TEMP_IMAGE_FILENAME = "dic_temp.png";

        public static final String CARD_IMAGE_FILENAME = "card%d.png";
        public static final String CARD_TEMP_IMAGE_FILENAME = "card_temp%d.png";
        public static final String CARD_EDIT_IMAGE_FILENAME = "card_edit%d.png";

        public static final int REQUEST_CODE_CATEGORY = 2;
        public static final int REQUEST_CODE_GALLERY = 2;
        public static final int REQUEST_IMAGE_CAPTURE = 1;
        public static final int FLAG_HIDE_INPUT_FORM = 0;
        public static final int PADDING_IMAGE_ITEM = 23;
        public static final int PADDING_IMAGE_DIC = 18;
        public static final int MAX_CARD_DICTIONARY = 99;
        public static final int REQUEST_CODE_DIC_CREATE = 4;
        public static final int REQUEST_CODE_DIC_EDIT = 3;

        public static final String KEY_NAME_SCREEN = "KEY_NAME_SCREEN";
        public static final String KEY_GO_BACK_CATEGORY = "KEY_GO_BACK_CATEGORY";
        public static final String PATH_IMAGE = "image/*";
        public static final String KEY_GET_PICTURE = "data";
        public static final String SELECT_PICTURE = "Select picture";
        public static final String KEY_TYPE_CATEGORY = "KEY_TYPE_CATEGORY";
        public static final String KEY_LIST_CATEGORY = "KEY_LIST_CATEGORY";
        public static final String KEY_CATEGORY_SELECT = "KEY_CATEGORY_SELECT";
        public static final String KEY_DICTIONARY_INFO = "KEY_DICTIONARY_INFO";
        public static final int MAX_IMAGE_WH = 1280;
        public static final long MAX_IMAGE_FILE_SIZE = (long) (1.8 * 1024 * 1024);
        public static final int MAX_CARD_NUM = 99;
        public static final int PADDING_IMAGE_DEFAULT = 140;

        /**
         * カード画像ファイル名取得.
         *
         * @param cardId カードID
         * @return String
         */
        public static String getCardFileName(final long cardId) {
            return String.format(Locale.ENGLISH, CARD_IMAGE_FILENAME, cardId);
        }

        /**
         * 編集時カード画像ファイル名取得.
         *
         * @param cardId カードID
         * @return String
         */
        public static String getEditCardFileName(final long cardId) {
            return String.format(Locale.ENGLISH, CARD_EDIT_IMAGE_FILENAME, cardId);
        }

        /**
         * 追加時カード画像ファイル名取得.
         *
         * @param cardId カードID
         * @return String
         */
        public static String getTempCardFileName(final long cardId) {
            return String.format(Locale.ENGLISH, CARD_TEMP_IMAGE_FILENAME, cardId);
        }
    }

    /**
     * タイマ関連定義
     */
    public static final class TimerControl {
        public static final int TIMER_SCHEDULE_NONE = 0; // タイマ種別なし
        public static final int TIMER_SCHEDULE_10MIN = 10; // タイマ種別:10分前
        public static final int TIMER_SCHEDULE_ONTIME = 20; // タイマ種別:定刻
        public static final int TIMER_DATE_CHANGED = 30; // タイマ種別:定刻

        public static final String TIMER_NOTIFICATION_TEXT = "text"; // NotificationText取得IntentKey
        public static final String TIMER_NOTIFICATION_TITLE = "title"; // NotificationTitle取得bundleKey

        public static final String TIMER_TYPE_DATE_CHANGED = "DateChanged"; // 日付変更タイマ用Type
        public static final int TIMER_CODE_DATE_CHANGED = 1; // 日付変更タイマ用RecCode(固定)

        public static final String TIMER_BUNDLE_KEY = "TIMER_BUNDLE_KEY"; // タイマ設定取得bundleKey
        public static final String TIMER_TYPE = "TIMER_TYPE"; // タイマ種別取得bundleKey
        public static final String SCHEDULE_ID = "SCHEDULE_ID"; // スケジュールID取得bundleKey
        public static final int TIMER_PRE_NOTICE = -10; // タイマ設定用定義(10分前計算)
    }

    /**
     * Notification関連定義
     */
    public static final class NotificationControl {
        public static final String NOTIFICATION_BUNDLE_KEY = "NOTIFICATION_BUNDLE_KEY"; // Notification設定取得bundleKey

        public static final int DEFAULT_NOTIFICATION_TAB = 0; // Notificationタップ時TAB指定
    }

    /**
     * Type view detail dictionary
     */
    public static final class DetailDictionary {
        public static final String POSITION = "position";
        public static final String CHECK = "check";
    }

    /**
     * schedule info
     */
    public static final class Schedule {
        public static final int MILLISECONDS = 60 * 1000;
        public static final int RESULT_CALENDAR = 1;
        public static final String KEY_DATA_SCHEDULE_INFO = "KEY_DATA_SCHEDULE_INFO";
        public static final String KEY_DATA_DATE = "KEY_DATA_DATE";
        public static final String KEY_DATE_CALENDAR = "KEY_DATE_CALENDAR";
        public static final int TIME_DELAY_HIDE_KEY_BOARD = 150;
        public static final int FLAG_HIDE_INPUT_FORM = 0;
        public static final int REQUEST_CODE_REPEAT = 2;
        public static final int REQUEST_CODE_DICTIONARY = 3;
        public static final int REQUEST_CODE_SCHEDULE_INFO = 4;
        public static final int REQUEST_CODE_SCHEDULE_CREATE = 5;
        public static final int REQUEST_CODE_SCHEDULE_COMPLETED = 6;
        public static final String KEY_DICTIONARY_INFO_OLD = "KEY_DICTIONARY_INFO_OLD";
        public static final String KEY_GO_BACK_REPEAT = "KEY_GO_BACK_REPEAT";
        public static final String REQUEST_EDIT = "REQUEST_EDIT";
        public static final String REQUEST_DELETE = "REQUEST_DELETE";
        public static final String KEY_DICTIONARY_INFO = "KEY_DICTIONARY_INFO";
        public static final String KEY_TYPE_BACK_RESULT = "KEY_TYPE_BACK_RESULT";
        public static final String KEY_INTERVAL_TYPE = "KEY_INTERVAL_TYPE";
        public static final String KEY_BACK_REPEAT_TITLE = "KEY_BACK_REPEAT_TITLE";
        public static final String BACK_EDIT = "BACK_EDIT";
        public static final String KEY_GO_TO_FROM = "KEY_GO_TO_FROM";
        public static final String KEY_TYPE_CATEGORY = "KEY_TYPE_CATEGORY";
        public static final String KEY_LIST_CATEGORY = "KEY_LIST_CATEGORY";
    }
}
