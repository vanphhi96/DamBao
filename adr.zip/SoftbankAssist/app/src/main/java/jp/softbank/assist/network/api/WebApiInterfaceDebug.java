/*
 * ファイル：WebApiInterfaceDebug.java
 * 概要：http(s)を使用した通信を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.api;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import jp.softbank.assist.network.json.dictionary.DeleteDictionaryRequest;
import jp.softbank.assist.network.json.dictionary.GetCategoriesParam;
import jp.softbank.assist.network.json.dictionary.SynchronizeDictionaryParam;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;

/**
 * デバッグ用WebApiクラス.
 *   必要なデータを折り返すのみ.
 */
class WebApiInterfaceDebug extends WebApiInterface {

    private static final String TAG = "Assit";


    WebApiInterfaceDebug(Context ctx) {
        super(ctx);
    }

    /**
     * AssetのファイルをUTF-8で読み込む.
     *
     * @param filename ファイル名
     * @return
     */
    private String readAssetFile(String filename) {
        AssetManager am = mCtx.getAssets();
        StringBuilder sb = new StringBuilder();

        try {
            InputStream is = am.open(filename);
            InputStreamReader isr = new InputStreamReader(is, "UTF-8");
            LineNumberReader lnr = new LineNumberReader(isr);

            String line = lnr.readLine();
            while (line != null) {
                sb.append(line).append("\n");

                line = lnr.readLine();
            }
            lnr.close();
            isr.close();
            is.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return sb.toString();
    }

    /**
     * ウェイト.
     *
     * @param millis ミリ秒（０以下は何もしません）
     */
    private void sleep(long millis) {
        try {
            if (millis > 0) {
                Thread.sleep(millis);
            }
        } catch (InterruptedException e) {
        }
    }


    @Override
    public boolean getCategories(final String access_token, final GetCategoriesParam params, final WebApiLinstener listener) {
        Log.d(TAG, "[ASI_DBG] getCategories start");

        // 必要な場合をウェイトを入れる
//        sleep(100);

        String response = readAssetFile("debug/GetCategoriesResultList.json");
//        byte[] error = readAssetFile("debug/ErrorResult101.json").getBytes();

        if (null != listener) {
            listener.onSuccessWebApi(response);
//            listener.onErrorWebApi(400, error);
        }

        Log.d(TAG, "[ASI_DBG] getCategories end");
        return true;
    }

    @Override
    public boolean deleteDictionary(final String access_token, final DeleteDictionaryRequest body, final WebApiLinstener listener) {
        Log.d(TAG, "[ASI_DBG] deleteDictionary start");

        // 必要な場合をウェイトを入れる
        sleep(100);

//        byte[] error = readAssetFile("debug/ErrorResult101.json").getBytes();

        if (null != listener) {
            listener.onSuccessWebApi("");
//            listener.onErrorWebApi(400, error);
        }

        Log.d(TAG, "[ASI_DBG] deleteDictionary end");
        return true;
    }

    @Override
    public boolean getSyncDictionaryList(final String access_token, final SynchronizeDictionaryParam params, final WebApiLinstener listener) {
        return true;
    }

}
