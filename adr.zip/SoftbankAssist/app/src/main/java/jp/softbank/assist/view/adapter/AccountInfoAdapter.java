/*
 * ファイル：AccountInfoAdapter.java
 * 概要：Account Info Adapter
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import jp.softbank.assist.R;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.RecyclerBaseAdapter;


/**
 * wal-08
 *
 * @author Systena
 * @version 1.0
 */

public class AccountInfoAdapter extends RecyclerBaseAdapter {

    private Context mContext;
    private ItemSelectedListener mListener;
    private int mNumber;
    // TODO: #3393 テスト用
    private static final int NUMBER_OF_DATA = 8;

    public AccountInfoAdapter(Context mContext, ItemSelectedListener mListener) {
        this.mContext = mContext;
        this.mListener = mListener;
        mNumber = NUMBER_OF_DATA;
    }

    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_account_infor, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BaseViewHolder holder, int position) {
        super.onBindViewHolder(holder, position);

    }

    /**
     * change data
     *
     * @param number number number of data
     */
    public void changeData(int number) {
        mNumber = number;
    }

    /*
    * ファイル：ViewHolder.java
    * 概要：Class of base view holder
    * ライセンス：
    * 著作権：Copyright(c) 2019 SoftBank Corp.
    *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
    */
    public class ViewHolder extends BaseViewHolder implements View.OnClickListener {

        public ImageView mImageView;
        FrameLayout mFrameLayoutCircle;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            mFrameLayoutCircle = itemView.findViewById(R.id.frameLayoutCircleSelected);
            mImageView = itemView.findViewById(R.id.img_acc_infor);

        }

        @Override
        public void onClick(View view) {
            mFrameLayoutCircle.setSelected(!mFrameLayoutCircle.isSelected());
            if (mListener != null) {
                mListener.onItemClick();
            }
        }

        @Override
        public void onBindView(int position) {

        }
    }

    @Override
    public int getContentItemCount() {
        return mNumber;
    }

    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public BaseViewHolder onCreateFooterHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        return null;
    }

    /**
     * set onClick item
     *
     * @author Systena
     * @version 1.0
     */
    public interface ItemSelectedListener {
        void onItemClick();
    }
}
