/*
 * ファイル：ScreenIds.java
 * 概要：画面ID定義
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view;

import jp.softbank.assist.R;

/**
 * 画面ID定義
 *
 * @author Systena
 * @version 1.0
 */
public enum ScreenId {

    // 起動画面
    START_UP("spr-01", R.string.fa_screen_spr_01),
    START_CHECK_APP("chk-01"), // 無し
    START_UPDATE_NOTICE("upd-01", R.string.fa_screen_upd_01),

    // ウォークスルー画面 / Wal Screen
    START_WAL_WELCOME("wal-01", R.string.fa_screen_wal_01),
    START_WAL_MY_SB_LOGIN("wal-02", R.string.fa_screen_wal_02),
    START_WAL_USER_ACCOUNT_EDIT("wal-08", R.string.fa_screen_wal_08),
    START_WAL_ACCOUNT_EDIT_END("wal-09"), // 無し
    START_WAL_LOCATION_CONFIRM("wal-06", R.string.fa_screen_wal_06),
    START_WAL_NOTIFICATION_CONFIRM("wal-10", R.string.fa_screen_wal_10),
    START_WAL_ADMINISTRATOR_LINK("wal-05", R.string.fa_screen_wal_05),
    START_WAL_FINISH("wal-07", R.string.fa_screen_wal_07),

    // Auth画面 / Auth Screen
    START_AUT_MY_SB_LOGIN("aut-01", R.string.fa_screen_aut_01),

    // “今日の予定”画面 / Sch Screen
    START_SCH_TOP("sch-01", R.string.fa_screen_sch_01),
    START_SCH_DETAIL("sch-02", R.string.fa_screen_sch_02),
    START_SCH_COMPLETE("sch-03", R.string.fa_screen_sch_03),
    START_SCH_EDIT("sch-ed-01", R.string.fa_screen_sch_ed_01),
    START_SCH_EDIT_END("sch-ed-02", R.string.fa_screen_sch_ed_02),
    START_SCH_DELETE("sch-del-01", R.string.fa_screen_sch_del_01),
    START_SCH_DELETE_END("sch-del-02", R.string.fa_screen_sch_del_02),
    START_SCH_DICTIONARY_CHECK("sch-dic-01", R.string.fa_screen_sch_dic_01),
    START_SCH_DICTIONARY_CHANGE_END("sch-dic-03", R.string.fa_screen_dic_ed_02),
    START_SCH_DICTIONARY_DELETE("sch-dic-del_01", R.string.fa_screen_sch_dic_del_01),
    START_SCH_DICTIONARY_DELETE_END("sch-dic-del_02", R.string.fa_screen_sch_dic_del_02),
    START_SCH_CREATE("sch-cr-01", R.string.fa_screen_sch_cr_01),
    START_SCH_CREATE_END("sch-cr-02", R.string.fa_screen_sch_cr_02),
    START_SCH_CALENDAR("sch-cal", R.string.fa_screen_sch_cal),
    START_SCH_HELP("sch-help", R.string.fa_screen_sch_help_01),
    START_SCH_REPEAT("sch_repeat"),// TODO[#3362]
    START_SCH_DICTIONARY_SELECT("sch-ed-dic-02",R.string.fa_screen_sch_ed_dic_02),
    START_SCH_DICTIONARY_EDIT("sch-ed-dic-01",R.string.fa_screen_sch_ed_dic_01),
    START_SCH_DICTIONARY_LIST("sch-ed-dic-03",R.string.fa_screen_sch_ed_dic_03),
    START_SCH_DICTIONARY_DETAIL("sch-ed-dic-04",R.string.fa_screen_sch_ed_dic_04),

    // “じぶん辞書”画面 / Dic Screen
    START_DIC_TOP("dic-01", R.string.fa_screen_dic_01),
    START_DIC_LIST("dic-02", R.string.fa_screen_dic_02),
    START_DIC_DETAIL("dic-03", R.string.fa_screen_dic_03),
    START_DIC_REMEMBERED("dic-04", R.string.fa_screen_dic_04),
    START_DIC_FAVORITE("dic-fav-01", R.string.fa_screen_dic_fav_01),
    START_DIC_EDIT("dic-ed-01", R.string.fa_screen_dic_ed_01),
    START_DIC_EDIT_END("dic-ed-02", R.string.fa_screen_dic_ed_02),
    START_DIC_DELETE("dic-del-01", R.string.fa_screen_dic_del_01),
    START_DIC_DELETE_END("dic-del-02", R.string.fa_screen_dic_del_02),
    START_DIC_CREATE("dic-cr-01", R.string.fa_screen_dic_cr_01),
    START_DIC_CREATE_END("dic-cr-02", R.string.fa_screen_dic_cr_02),
    START_DIC_HELP("dic-help", R.string.fa_screen_dic_help_01),
    START_DIC_CATEGORY("dic-cr-03",R.string.fa_screen_dic_cr_03),

    // “設定”画面 / Setting Screen
    START_SET_TOP("set-01", R.string.fa_screen_set_01),
    START_SET_USER_SETTING("set-acc-01", R.string.fa_screen_set_acc_01),
    START_SET_USER_INFO_EDIT("set-acc-ed_01", R.string.fa_screen_set_acc_01),
    START_SET_USER_INFO_EDIT_END("set-acc-ed_02", R.string.fa_screen_set_acc_ed_02),
    START_SET_RESET("set-acc-res-01"), // 無し
    START_SET_RESET_END("set-acc-res-02"), // 無し
    START_SET_UNSUBSCRIBED("set-acc-can",R.string.fa_screen_set_acc_can_01), // Webview
    START_SET_ADMINISTRATOR_SETTING("set-adm",R.string.fa_screen_set_adm_01), // Webview
    START_SET_LOCATION_SETTING("set-pos-01", R.string.fa_screen_set_pos_01),
    START_SET_LOCATION_TIME_RECORD("set-pos-02", 0),  //TODO Not yet in String.xml, fix 0 Later
    START_SET_ABOUT("set_abo-01", R.string.fa_screen_set_abo_01),
    START_SET_POLICY("set-abo-po-01",R.string.fa_screen_set_abo_pol_01), // Webview
    START_SET_VERSION(""), // 無し
    START_SET_PERSONAL_INFO("set-abo-prv-01",R.string.fa_screen_set_abo_prv_01),
    START_SET_FAQ("set-abo-faq-01",R.string.fa_screen_set_abo_faq_01),
    START_SET_CONTACT_US("set-abo-ctt-01",R.string.fa_screen_set_abo_ctt_01),
    START_SET_LOG_OUT("set-abo-log-01"), // 無し
    START_SET_INFORMATION_DETAIL("set-abo-inf-01"), // 無し
    START_SET_HISTORY("set-log-01", R.string.fa_screen_set_log_01),
    START_SET_LICENSE("set-lic-01", R.string.set_license),

    // これらのフラグメントはテストのため、後で消す/ These fragments are just for test, delete later
    START_FRAGMENT_SCHEDULE_ONE("sch-01-01"),
    START_FRAGMENT_SCHEDULE_TWO("sch-01-02"),
    START_FRAGMENT_SAMPLE("test_fragment_sample", 0),
    START_FRAGMENT_DIC_ONE("dic_01_01"),
    START_FRAGMENT_DIC_TWO("dic_01_02"),
    // 資料に書いてない画面ID
    START_MENU("start_menu"),

    NONE("");

    private String mScreenName;
    private int mFirebaseId;

    ScreenId(final String screenName) {
        this.mScreenName = screenName;
    }

    ScreenId(final String screenName, int firebaseName) {
        this.mScreenName = screenName;
        mFirebaseId = firebaseName;
    }

    public String getScreenName() {
        return mScreenName;
    }

    public int getFirebaseId() {
        return mFirebaseId;
    }


}
