/*
 * ファイル：ScheduleInfo.java
 * 概要：スケジュール情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import jp.softbank.assist.util.Constants;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * スケジュール情報.
 *
 * @author Systena
 * @version 1.0
 */
public class ScheduleInfo implements Serializable {

    public static final int MAX_ATTACHED_DICTIONARIES = 3; // 関連辞書最大数

    /**
     * インターバル.
     */
    public enum IntervalType {
        None(0), // 設定なし
        Daily(10), // 毎日
        Weekly(20), // 毎週
        Monthly(30), // 毎月
        Yearly(40), // 毎年
        ;

        private final long mValue;

        private IntervalType(long value) {
            this.mValue = value;
        }

        public long getValue() {
            return this.mValue;
        }

        /**
         * 数値からenumへの変換.
         *
         * @param value 数値
         * @return IntervalType
         */
        public static IntervalType fromValue(final long value) {
            IntervalType[] list = IntervalType.values();
            for (IntervalType item : list) {
                if (item.getValue() == value) {
                    return item;
                }
            }
            return None;
        }
    }


    private long mScheduleId; // スケジュール日時ID
    private Date mScheduleStartDate; // スケジュール開始日時
    private Date mScheduleEndDate; // スケジュール終了日時
    private boolean mIsCompleted; // 完了済みフラグ
    private boolean mIsAllDay; // 終日フラグ
    private long mScheduleMetaId; // スケジュール内容ID
    private String mTitle; // スケジュールタイトル
    private String mNote; // スケジュールノート
    private String mLocation; // 場所
    private String mIconName; // 予定アイコン名
    private long mCreatorIconId; // 作成者アイコンID
    private String mCreatorNickname; // 作成者ニックネーム
    private Date mCreatedDate; // 作成日時
    private Date mUpdatedDate; // 更新日時
    private List<DictionaryInfo> mAttachedDictionaries; // 関連辞書
    private Date mRepeatStartDate; // 繰り返し開始日時
    private Date mRepeatEndDate; // 繰り返し終了日時
    private IntervalType mInterval; // インターバル
    private boolean mRepeatSunday; // 日曜日繰り返し
    private boolean mRepeatMonday; // 月曜日繰り返し
    private boolean mRepeatTuesday; // 火曜日繰り返し
    private boolean mRepeatWednesday; // 水曜日繰り返し
    private boolean mRepeatThursday; // 木曜日繰り返し
    private boolean mRepeatFriday; // 金曜日繰り返し
    private boolean mRepeatSaturday; // 土曜日繰り返し


    public long getScheduleId() {
        return mScheduleId;
    }

    public void setScheduleId(long scheduleId) {
        this.mScheduleId = scheduleId;
    }

    public Date getScheduleStartDate() {
        return mScheduleStartDate;
    }

    public void setScheduleStartDate(Date scheduleStartDate) {
        this.mScheduleStartDate = scheduleStartDate;
    }

    public Date getScheduleEndDate() {
        return mScheduleEndDate;
    }

    public void setScheduleEndDate(Date scheduleEndDate) {
        this.mScheduleEndDate = scheduleEndDate;
    }

    public boolean isCompleted() {
        return mIsCompleted;
    }

    public void setIsCompleted(boolean completed) {
        mIsCompleted = completed;
    }

    public boolean isAllDay() {
        return mIsAllDay;
    }

    public void setIsAllDay(boolean allDay) {
        mIsAllDay = allDay;
    }

    public long getScheduleMetaId() {
        return mScheduleMetaId;
    }

    public void setScheduleMetaId(long scheduleMetaId) {
        this.mScheduleMetaId = scheduleMetaId;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        this.mTitle = title;
    }

    public String getNote() {
        return mNote;
    }

    public void setNote(String note) {
        this.mNote = note;
    }

    public String getLocation() {
        return mLocation;
    }

    public void setLocation(String location) {
        this.mLocation = location;
    }

    public String getIconName() {
        return mIconName;
    }

    public void setIconName(String iconName) {
        this.mIconName = iconName;
    }

    public long getCreatorIconId() {
        return mCreatorIconId;
    }

    public void setCreatorIconId(long creatorIconId) {
        this.mCreatorIconId = creatorIconId;
    }

    public String getCreatorNickname() {
        return mCreatorNickname;
    }

    public void setCreatorNickname(String creatorNickname) {
        this.mCreatorNickname = creatorNickname;
    }

    public Date getCreatedDate() {
        return mCreatedDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.mCreatedDate = createdDate;
    }

    public Date getUpdatedDate() {
        return mUpdatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.mUpdatedDate = updatedDate;
    }

    public List<DictionaryInfo> getAttachedDictionaries() {
        return mAttachedDictionaries;
    }

    public void setAttachedDictionaries(List<DictionaryInfo> dictionaries) {
        this.mAttachedDictionaries = dictionaries;
    }

    public Date getRepeatStartDate() {
        return mRepeatStartDate;
    }

    public void setRepeatStartDate(Date repeatStartDate) {
        this.mRepeatStartDate = repeatStartDate;
    }

    public Date getRepeatEndDate() {
        return mRepeatEndDate;
    }

    public void setRepeatEndDate(Date repeatEndDate) {
        this.mRepeatEndDate = repeatEndDate;
    }

    public IntervalType getInterval() {
        return mInterval;
    }

    public void setInterval(IntervalType interval) {
        this.mInterval = interval;
    }

    public boolean isRepeatSunday() {
        return mRepeatSunday;
    }

    public void setIsRepeatSunday(boolean repeatSunday) {
        this.mRepeatSunday = repeatSunday;
    }

    public boolean isRepeatMonday() {
        return mRepeatMonday;
    }

    public void setIsRepeatMonday(boolean repeatMonday) {
        this.mRepeatMonday = repeatMonday;
    }

    public boolean isRepeatTuesday() {
        return mRepeatTuesday;
    }

    public void setIsRepeatTuesday(boolean repeatTuesday) {
        this.mRepeatTuesday = repeatTuesday;
    }

    public boolean isRepeatWednesday() {
        return mRepeatWednesday;
    }

    public void setIsRepeatWednesday(boolean repeatWednesday) {
        this.mRepeatWednesday = repeatWednesday;
    }

    public boolean isRepeatThursday() {
        return mRepeatThursday;
    }

    public void setIsRepeatThursday(boolean repeatThursday) {
        this.mRepeatThursday = repeatThursday;
    }

    public boolean isRepeatFriday() {
        return mRepeatFriday;
    }

    public void setIsRepeatFriday(boolean repeatFriday) {
        this.mRepeatFriday = repeatFriday;
    }

    public boolean isRepeatSaturday() {
        return mRepeatSaturday;
    }

    public void setIsRepeatSaturday(boolean repeatSaturday) {
        this.mRepeatSaturday = repeatSaturday;
    }

    /**
     * 関連辞書のIDを返す.
     *
     * @param index 関連辞書のインデックス
     * @return 辞書ID
     */
    public long getAttachedDictionaryId(int index) {
        if (mAttachedDictionaries != null) {
            try {
                DictionaryInfo info = mAttachedDictionaries.get(index);
                return info.getDictionaryId();
            } catch (IndexOutOfBoundsException e) {
                // no data
            }
        }
        return Constants.Ids.ID_NONE;
    }
}
