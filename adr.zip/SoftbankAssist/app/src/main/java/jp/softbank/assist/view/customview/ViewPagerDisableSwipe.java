/*
 * ファイル：ViewPagerDisableSwipe.java
 * 概要：CustomViewPager disable swipe
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.customview;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

/**
 * CustomViewPager disable swipe
 *
 * @author Systena
 * @version 1.0
 */
public class ViewPagerDisableSwipe extends ViewPager {
    public ViewPagerDisableSwipe(Context context) {
        super(context);
    }

    public ViewPagerDisableSwipe(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        return false;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        return false;
    }

    @Override
    public void setCurrentItem(int item, boolean smoothScroll) {
        super.setCurrentItem(item, true);
    }

    @Override
    public void setCurrentItem(int item) {
        super.setCurrentItem(item, true);
    }
}
