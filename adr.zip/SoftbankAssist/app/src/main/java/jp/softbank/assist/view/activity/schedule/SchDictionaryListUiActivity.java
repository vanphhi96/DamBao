/*
 * ファイル：SchDictionaryListUiActivity.java
 * 概要：
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.activity.schedule;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetDictionaryListResultListener;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.activity.dictionary.IOnClickItemDicList;
import jp.softbank.assist.view.adapter.AdapterSchDicList;

import java.util.ArrayList;
import java.util.List;


/**
 * sch-ed-dic-03
 *
 * @author Systena
 * @version 1.0
 */
public class SchDictionaryListUiActivity extends BaseUiActivity implements View.OnClickListener, IOnClickItemDicList, GetDictionaryListResultListener {
    private AdapterSchDicList mAdapterSchDicList;
    private RecyclerView mRecyclerDicList;
    private TextView mTvTitle;
    private TextView mTvTimeFinish;
    private RelativeLayout mViewDicEmpty;
    private RelativeLayout mBtnBack;
    private TextView mTvCancel;
    private CategoryInfo mCategoryInfo;
    private List<CategoryInfo> mCategoryInfoList;
    private int mColorBackgroundItem;
    private int mColorFlagItem;
    private List<DictionaryInfo> mListDictionary = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sch_dic_list);
        mCategoryInfoList = getIntentListCategory();
        mCategoryInfo = getIntentCategory();
        mTvCancel = findViewById(R.id.tv_guide_sch_dic_list);
        mRecyclerDicList = findViewById(R.id.recycle_dic_list);
        mBtnBack = findViewById(R.id.rlt_dic_list_back);
        mViewDicEmpty = findViewById(R.id.rlt_view_dic_empty);
        mTvTitle = findViewById(R.id.tv_dic_list_title);
        mTvTimeFinish = findViewById(R.id.tv_time_finish_dic_list);
        mTvCancel.setOnClickListener(this);
        mBtnBack.setOnClickListener(this);
        if (mCategoryInfo != null) {
            initListDictionary();
            AppController.getInstance().getAssistServerInterface().getDictionaryList(mCategoryInfo.getCategoryId(), this);
        }
    }

    /**
     * get intent list category
     *
     * @return List<CategoryInfo>
     */
    private List<CategoryInfo> getIntentListCategory() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_LIST_CATEGORY)) {
            return (List<CategoryInfo>) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_LIST_CATEGORY);
        }
        return new ArrayList<>();
    }

    /**
     * get category intent
     *
     * @return CategoryInfo
     */
    private CategoryInfo getIntentCategory() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_TYPE_CATEGORY)) {
            return (CategoryInfo) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_TYPE_CATEGORY);
        } else {
            return null;
        }
    }

    /**
     * get DictionaryInfo
     *
     * @return dictionary info
     */
    private DictionaryInfo getIntentDicInfo() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_DICTIONARY_INFO)) {
            return (DictionaryInfo) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_DICTIONARY_INFO);
        } else {
            return null;
        }
    }

    /**
     * init list dictionary
     */
    private void initListDictionary() {
        mTvTitle.setText(mCategoryInfo.getName());
        mTvTimeFinish.setText(getString(R.string.dic_whole) + Integer.toString(mListDictionary.size())
                + getString(R.string.dic_item));
        setEnableListDic(mListDictionary.isEmpty());
        mColorFlagItem = ResourcesUtils.getColorFlagItemDictionary(mCategoryInfo.getCategoryId());
        mColorBackgroundItem = ResourcesUtils.getColorBackgroundItemDictionary(mCategoryInfo.getCategoryId());
        // reset when click another category
        mRecyclerDicList.setLayoutManager(null);
        mRecyclerDicList.setAdapter(null);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        mLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerDicList.setLayoutManager(mLayoutManager);
        mAdapterSchDicList = new AdapterSchDicList();
        mAdapterSchDicList.setColorItem(mColorBackgroundItem, mColorFlagItem);
        mAdapterSchDicList.setListDictionary(mListDictionary);
        mAdapterSchDicList.setListCategoryOther(createListOtherDictionary(mCategoryInfo.getCategoryId()));
        mAdapterSchDicList.setActivity(this);
        mAdapterSchDicList.setOnClickItemDicList(this);
        mRecyclerDicList.setAdapter(mAdapterSchDicList);
    }

    /**
     * set show notification dic empty
     *
     * @param enableListDic
     */
    private void setEnableListDic(boolean enableListDic) {
        if (enableListDic) {
            mRecyclerDicList.setVisibility(View.INVISIBLE);
            mViewDicEmpty.setVisibility(View.VISIBLE);
            mTvCancel.setVisibility(View.GONE);
        } else {
            mRecyclerDicList.setVisibility(View.VISIBLE);
            mViewDicEmpty.setVisibility(View.INVISIBLE);
            mTvCancel.setVisibility(View.VISIBLE);
        }
    }

    /**
     * create list other category
     *
     * @param categoryId
     * @return
     */
    private List<CategoryInfo> createListOtherDictionary(long categoryId) {
        List<CategoryInfo> listDictionary = new ArrayList<>();
        listDictionary.addAll(mCategoryInfoList);
        for (CategoryInfo categoryInfo : listDictionary) {
            if (categoryInfo.getCategoryId() == categoryId) {
                listDictionary.remove(categoryInfo);
                return listDictionary;
            }
        }
        return listDictionary;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rlt_dic_list_back:
                onBackPressed();
            case R.id.tv_guide_sch_dic_list:
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, getIntentDicInfo());
                backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_DICTIONARY);
            default:
                break;
        }

    }

    @Override
    public void onClickItemDic(DictionaryInfo dictionaryInfo) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, dictionaryInfo);
        bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO_OLD, getIntentDicInfo());
        changeScreenResult(ScreenId.START_SCH_DICTIONARY_DETAIL, Constants.Schedule.REQUEST_CODE_DICTIONARY, bundle);
    }

    @Override
    public void clickOtherCategory(CategoryInfo categoryInfo) {
        if (categoryInfo != null) {
            mCategoryInfo = categoryInfo;
            mTvTitle.setText(mCategoryInfo.getName());
            mTvTimeFinish.setText(getString(R.string.dic_whole) + 0
                    + getString(R.string.dic_item));
            AppController.getInstance().getAssistServerInterface().getDictionaryList(categoryInfo.getCategoryId(), this);
        }

    }

    @Override
    public void onResult(AssistServerResult result, final List<DictionaryInfo> list) {
        closeIndicator();
        if (result.mResult == AssistServerResult.Result.Success) {
            mListDictionary.clear();
            mListDictionary.addAll(list);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    initListDictionary();
                }
            });
        }
    }

    @Override
    public void onStartConnection() {
        mTvCancel.setVisibility(View.GONE);
        mViewDicEmpty.setVisibility(View.VISIBLE);
        mRecyclerDicList.setVisibility(View.GONE);
        displayIndicator();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.Schedule.REQUEST_CODE_DICTIONARY && resultCode == Constants.Schedule.REQUEST_CODE_DICTIONARY) {
            DictionaryInfo dictionaryInfo = (DictionaryInfo) data.getSerializableExtra(Constants.Schedule.KEY_DICTIONARY_INFO);
            Bundle bundle = new Bundle();
            bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, dictionaryInfo);
            backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_DICTIONARY);
        }
    }
}
