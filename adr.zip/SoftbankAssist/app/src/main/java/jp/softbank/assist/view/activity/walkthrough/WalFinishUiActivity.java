/*
 * ファイル：WalFinishUiActivity.java
 * 概要：ウォークスルー終了画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.walkthrough;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


import jp.softbank.assist.R;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;

/**
 * wal-07
 *
 * @author Systena
 * @version 1.0
 */
public class WalFinishUiActivity extends BaseUiActivity implements View.OnClickListener {

    private TextView mTvFinishWalk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wal_finish);
        mTvFinishWalk = findViewById(R.id.tv_wal07_finish_walk);
        mTvFinishWalk.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_wal07_finish_walk:
                changeScreen(ScreenId.START_MENU);
                finishActivity();
                break;
            default:
                break;
        }
    }
}
