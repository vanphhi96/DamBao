/*
 * ファイル：ApiDeleteDictionary.java
 * 概要：リクエスト用オブジェクト
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.api;

import android.os.Handler;

import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.json.dictionary.DeleteDictionaryRequest;
import jp.softbank.assist.network.listener.BaseResultListener;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.AssistLog;

import java.util.Iterator;

/**
 * 辞書削除リクエスト.
 */
public class ApiDeleteDictionary extends ApiBaseObject {

    private DeleteDictionaryRequest mRequestBody;


    private ApiDeleteDictionary() {
        super();
    }

    public static ApiDeleteDictionary newInstance(Handler handler,
                                                  String token,
                                                  long userId,
                                                  long dictionaryId,
                                                  NotifyOnlyResultListener callback) {
        ApiDeleteDictionary data = new ApiDeleteDictionary();

        data.mSeqNo = nextSeqNo();
        data.mHandler = handler;
        data.mAccessToken = token;
        data.addCallback(callback);

        DeleteDictionaryRequest body = new DeleteDictionaryRequest();
        body.setUserId(userId);
        body.setDictionaryId(dictionaryId);
        data.mRequestBody = body;

        return data;
    }

    @Override
    public WebApiInterface.Api getApi() {
        return WebApiInterface.Api.DELETE_DICTIONARY;
    }

    @Override
    public void asyncProcess(WebApiInterface webApiIf) {
        AssistLog.d("[ASI_DBG] asyncProcess start");

        // 接続開始前通知
        notifyStartConnection();
        // サーバーへ問い合わせ
        webApiIf.deleteDictionary(mAccessToken, mRequestBody, this);

        AssistLog.d("[ASI_DBG] asyncProcess end");
    }

    @Override
    public void resultSuccess(String response) {
        AssistLog.d("[ASI_DBG] resultSuccess start");


        AssistLog.d("[ASI_DBG] resultSuccess end");
    }

    @Override
    public void resultError(int status, byte[] response) {
        AssistLog.d("[ASI_DBG] resultError start");

        mStatusCode = status;
        mError = WebApiUtil.convertToError(response);

        AssistLog.d("[ASI_DBG] resultError end");
    }

    @Override
    public void postProcess() {
        AssistLog.d("[ASI_DBG] postProcess start");

        if (mError != null) {
            // エラーあり
            AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
                    mError.getCode(), mError.getMessage(), mError.getItem());
            Iterator<BaseResultListener> ite = mCallbacks.iterator();
            while (ite.hasNext()) {
                BaseResultListener temp = ite.next();
                if (temp instanceof NotifyOnlyResultListener) {
                    NotifyOnlyResultListener listener = (NotifyOnlyResultListener)temp;
                    listener.onResult(result);
                }
            }
        } else {
            // 正常
            AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
            Iterator<BaseResultListener> ite = mCallbacks.iterator();
            while (ite.hasNext()) {
                BaseResultListener temp = ite.next();
                if (temp instanceof NotifyOnlyResultListener) {
                    NotifyOnlyResultListener listener = (NotifyOnlyResultListener)temp;
                    listener.onResult(result);
                }
            }
        }

        AssistLog.d("[ASI_DBG] postProcess end");
    }
}
