/*
 * ファイル：GetHistoryParam.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.history;

import jp.softbank.assist.network.json.RequestParam;

/**
 * 操作履歴取得パラメータ.
 */
public class GetHistoryParam extends RequestParam {

    private Long mOperateUserId;
    private Long mPage;
    private Long mNumberRecord;


    /**
     * 操作ユーザID.
     */
    public Long getOperateUserId() {
        return mOperateUserId;
    }
    public void setOperateUserId(Long operateUserId) {
        this.mOperateUserId = operateUserId;
    }

    /**
     * 表示ページ.
     */
    public Long getPage() {
        return mPage;
    }
    public void setPage(Long page) {
        this.mPage = page;
    }

    /**
     * 表示件数.
     */
    public Long getNumberRecord() {
        return mNumberRecord;
    }
    public void setNumberRecord(Long numberRecord) {
        this.mNumberRecord = numberRecord;
    }
}
