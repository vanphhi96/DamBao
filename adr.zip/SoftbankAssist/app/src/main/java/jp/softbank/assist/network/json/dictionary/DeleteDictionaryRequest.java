/*
 * ファイル：DeleteDictionaryRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

/**
 * 辞書削除リクエスト.
 */
public class DeleteDictionaryRequest extends RequestBody {

    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("dictionary_id")
    private Long mDictionaryId = null;


    /**
     * 値初期化.
     */
    public void initializeValues() {
        mUserId = 0L;
        mDictionaryId = 0L;
    }

    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * 辞書ID.
     */
    public Long getDictionaryId() {
        return mDictionaryId;
    }
    public void setDictionaryId(Long dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DeleteDictionaryRequest dictionaryRequest = (DeleteDictionaryRequest) o;
        return (this.mUserId == null ? dictionaryRequest.mUserId == null : this.mUserId.equals(dictionaryRequest.mUserId)) &&
                (this.mDictionaryId == null ? dictionaryRequest.mDictionaryId == null : this.mDictionaryId.equals(dictionaryRequest.mDictionaryId));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mDictionaryId == null ? 0: this.mDictionaryId.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class DeleteDictionaryRequest {\n");

        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mDictionaryId: ").append(mDictionaryId).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
