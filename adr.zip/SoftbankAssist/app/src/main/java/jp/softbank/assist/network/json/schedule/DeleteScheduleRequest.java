/*
 * ファイル：DeleteScheduleRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.schedule;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

/**
 * スケジュール削除リクエスト.
 */
public class DeleteScheduleRequest extends RequestBody {

    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("schedule_meta_id")
    private Long mScheduleMetaId = null;
    @SerializedName("schedule_id")
    private Long mScheduleId = null;
    @SerializedName("delete_following_all_flg")
    private Long mDeleteFollowingAllFlg = null;


    /**
     * 値初期化.
     */
    public void initializeValues() {
        mUserId = 0L;
        mScheduleMetaId = 0L;
        mDeleteFollowingAllFlg = 0L;
    }

    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * スケジュール内容ID.
     */
    public Long getScheduleMetaId() {
        return mScheduleMetaId;
    }
    public void setScheduleMetaId(Long scheduleMetaId) {
        this.mScheduleMetaId = scheduleMetaId;
    }

    /**
     * スケジュール日時ID.
     */
    public Long getScheduleId() {
        return mScheduleId;
    }
    public void setScheduleId(Long scheduleId) {
        this.mScheduleId = scheduleId;
    }

    /**
     * 以降のスケジュール全削除フラグ（0：無効、1：有効）.
     */
    public Long getDeleteFollowingAllFlg() {
        return mDeleteFollowingAllFlg;
    }
    public void setDeleteFollowingAllFlg(Long deleteFollowingAllFlg) {
        this.mDeleteFollowingAllFlg = deleteFollowingAllFlg;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DeleteScheduleRequest scheduleRequest = (DeleteScheduleRequest) o;
        return (this.mUserId == null ? scheduleRequest.mUserId == null : this.mUserId.equals(scheduleRequest.mUserId)) &&
                (this.mScheduleMetaId == null ? scheduleRequest.mScheduleMetaId == null : this.mScheduleMetaId.equals(scheduleRequest.mScheduleMetaId)) &&
                (this.mScheduleId == null ? scheduleRequest.mScheduleId == null : this.mScheduleId.equals(scheduleRequest.mScheduleId)) &&
                (this.mDeleteFollowingAllFlg == null ? scheduleRequest.mDeleteFollowingAllFlg == null : this.mDeleteFollowingAllFlg.equals(scheduleRequest.mDeleteFollowingAllFlg));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mScheduleMetaId == null ? 0: this.mScheduleMetaId.hashCode());
        result = 31 * result + (this.mScheduleId == null ? 0: this.mScheduleId.hashCode());
        result = 31 * result + (this.mDeleteFollowingAllFlg == null ? 0: this.mDeleteFollowingAllFlg.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class DeleteScheduleRequest {\n");

        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mScheduleMetaId: ").append(mScheduleMetaId).append("\n");
        sb.append("  mScheduleId: ").append(mScheduleId).append("\n");
        sb.append("  mDeleteFollowingAllFlg: ").append(mDeleteFollowingAllFlg).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
