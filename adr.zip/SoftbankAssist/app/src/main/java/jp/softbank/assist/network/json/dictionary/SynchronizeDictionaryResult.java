/*
 * ファイル：SynchronizeDictionaryResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * 辞書一覧（差分）取得結果.
 */
public class SynchronizeDictionaryResult {

    @SerializedName("mDictionary")
    private List<SynchronizeDictionaryResultDictionary> mDictionary = null;
    @SerializedName("mCard")
    private List<SynchronizeDictionaryResultCard> mCard = null;


    /**
     * 辞書情報.
     */
    public List<SynchronizeDictionaryResultDictionary> getDictionary() {
        return mDictionary;
    }
    public void setDictionary(List<SynchronizeDictionaryResultDictionary> dictionary) {
        this.mDictionary = dictionary;
    }

    /**
     * カード情報.
     */
    public List<SynchronizeDictionaryResultCard> getCard() {
        return mCard;
    }
    public void setCard(List<SynchronizeDictionaryResultCard> card) {
        this.mCard = card;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SynchronizeDictionaryResult dictionaryResult = (SynchronizeDictionaryResult) o;
        return (this.mDictionary == null ? dictionaryResult.mDictionary == null : this.mDictionary.equals(dictionaryResult.mDictionary)) &&
                (this.mCard == null ? dictionaryResult.mCard == null : this.mCard.equals(dictionaryResult.mCard));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mDictionary == null ? 0: this.mDictionary.hashCode());
        result = 31 * result + (this.mCard == null ? 0: this.mCard.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class SynchronizeDictionaryResult {\n");

        sb.append("  mDictionary: ").append(mDictionary).append("\n");
        sb.append("  mCard: ").append(mCard).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
