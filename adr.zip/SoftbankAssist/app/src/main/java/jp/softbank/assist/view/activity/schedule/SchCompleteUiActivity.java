/*
 * ファイル：SchCompleteUiActivity.java
 * 概要：予定完了画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.schedule;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.activity.BaseUiActivity;

import java.util.Calendar;
import java.util.Date;

/**
 * sch-03
 *
 * @author Systena
 * @version 1.0
 */
public class SchCompleteUiActivity extends BaseUiActivity implements View.OnClickListener {
    private LinearLayout mLnContent;
    private TextView mTvMonth;
    private TextView mTvDay;
    private TextView mTvDayOfWeek;
    private TextView mTvDateTime;
    private TextView mTvTitle;
    private TextView mTvComment;
    private TextView mTvTodayBack;
    private ImageView mImgCreator;
    private ImageView mImgSchedule;
    private ImageView mImgUser;
    private ImageView mImgDictionary;
    private ScheduleInfo mScheduleInfo;
    private int mIdIconUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_complete);
        mImgUser = findViewById(R.id.img_user);
        mImgCreator = findViewById(R.id.img_creator);
        mImgSchedule = findViewById(R.id.img_schedule);
        mLnContent = findViewById(R.id.ln_content);
        mTvMonth = findViewById(R.id.tv_month);
        mTvDay = findViewById(R.id.tv_day);
        mTvDayOfWeek = findViewById(R.id.tv_day_of_week);
        mTvDateTime = findViewById(R.id.tv_time);
        mTvTitle = findViewById(R.id.tv_title);
        mTvComment = findViewById(R.id.tv_comment);
        mTvTodayBack = findViewById(R.id.tv_today_back);
        mImgDictionary = findViewById(R.id.ic_card);
        mLnContent.setClipToOutline(true);
        mTvTodayBack.setOnClickListener(this);
        mScheduleInfo = getIntentSchedule();
        mIdIconUser = AppController.getInstance().getAssistServerInterface().getMyUserIcon();
        setData(getIntentDate(), mScheduleInfo);
    }

    /**
     * get string key repeat from intent
     *
     * @return string
     */
    private ScheduleInfo getIntentSchedule() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_DATA_SCHEDULE_INFO)) {
            return (ScheduleInfo) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_DATA_SCHEDULE_INFO);
        }
        return null;
    }

    /**
     * get date from intent
     *
     * @return date
     */
    private Date getIntentDate() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_DATA_DATE)) {
            return (Date) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_DATA_DATE);
        }
        return null;
    }

    /**
     * set data
     *
     * @param date
     * @param scheduleInfo
     */
    private void setData(Date date, ScheduleInfo scheduleInfo) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        mTvMonth.setText(String.valueOf(calendar.get(Calendar.MONTH) + 1));
        mTvDay.setText(String.valueOf(calendar.get(Calendar.DAY_OF_MONTH)));
        mTvDayOfWeek.setText(DateUtils.convertDateToStringJapan(calendar.get(Calendar.DAY_OF_WEEK), this));
        if (scheduleInfo.isAllDay()) {
            String strTime = mTvDateTime.getContext().getString(R.string.sch_allday);
            if (DateUtils.compareEqualDate(scheduleInfo.getScheduleStartDate(), scheduleInfo.getScheduleEndDate())) {
                strTime = strTime + " " + DateUtils.convertDateToString(scheduleInfo.getScheduleStartDate(), DateUtils.DATE_FORMAT_DIC_DETAIL);
            } else {
                strTime = strTime + DateUtils.convertDateToString(scheduleInfo.getScheduleStartDate(), DateUtils.DATE_FORMAT_DIC_DETAIL)
                        + "-" + DateUtils.convertDateToString(scheduleInfo.getScheduleEndDate(), DateUtils.DATE_FORMAT_DIC_DETAIL);
            }
            mTvDateTime.setText(strTime);
        } else {
            String strTime;
            if (DateUtils.compareEqualDate(scheduleInfo.getScheduleStartDate(), scheduleInfo.getScheduleEndDate())) {
                strTime = DateUtils.convertDateToString(scheduleInfo.getScheduleStartDate(), DateUtils.SCHEDULE_DETAIL_DATE_TIME_FORMAT)
                        + "-" + DateUtils.convertDateToString(scheduleInfo.getScheduleEndDate(), DateUtils.TIME_PICKER_FORMAT);
            } else {
                strTime = DateUtils.convertDateToString(scheduleInfo.getScheduleStartDate(), DateUtils.SCHEDULE_DETAIL_DATE_TIME_FORMAT)
                        + "-" + DateUtils.convertDateToString(scheduleInfo.getScheduleEndDate(), DateUtils.SCHEDULE_DETAIL_DATE_TIME_FORMAT);
            }
            mTvDateTime.setText(strTime);
        }
        if (scheduleInfo.getAttachedDictionaries() == null || scheduleInfo.getAttachedDictionaries().size() == 0) {
            mImgDictionary.setVisibility(View.INVISIBLE);
        } else {
            mImgDictionary.setVisibility(View.VISIBLE);
        }
        mTvTitle.setText(scheduleInfo.getTitle());
        mTvComment.setText(scheduleInfo.getNote());
        mImgSchedule.setImageResource(ResourcesUtils.getScheduleIconResourceFromId(scheduleInfo.getIconName()));
        try {
            mImgCreator.setVisibility(View.VISIBLE);
            mImgCreator.setImageDrawable(mImgCreator.getContext().getDrawable(ResourcesUtils.getUserIconResourceFromId((int) mScheduleInfo.getCreatorIconId())));
        } catch (Resources.NotFoundException e) {
            mImgCreator.setVisibility(View.INVISIBLE);
            AssistLog.e(e.toString());
        }
        try {
            mImgUser.setVisibility(View.VISIBLE);
            mImgUser.setImageDrawable(mImgUser.getContext().getDrawable(ResourcesUtils.getUserIconResourceFromId(mIdIconUser)));
        } catch (Resources.NotFoundException e) {
            mImgUser.setVisibility(View.INVISIBLE);
            AssistLog.e(e.toString());
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_today_back:
                onBackPressed();
                break;
            default:
                break;
        }
    }

    @Override
    public void onBackPressed() {
        backScreenResult(this, new Bundle(), Constants.Schedule.REQUEST_CODE_SCHEDULE_COMPLETED);
    }
}
