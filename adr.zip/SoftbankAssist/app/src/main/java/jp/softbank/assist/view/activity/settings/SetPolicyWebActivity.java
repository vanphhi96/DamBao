/*
 * ファイル：SetPolicyWebActivity.java
 * 概要：利用規約画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.settings;

import jp.softbank.assist.R;
import jp.softbank.assist.view.activity.BaseWebActivity;

/**
 * set-abo-pol-01
 *
 * @author Systena
 * @version 1.0
 */
public class SetPolicyWebActivity extends BaseWebActivity {
    @Override
    protected void getDataIntent() {
        super.getDataIntent();
        //TODO[3420] fix data to test
        mTextBack = getString(R.string.set_about_app);
        mTitleWeb = getString(R.string.set_tos);
        mUrlWebView = "https://google.com";
    }
}
