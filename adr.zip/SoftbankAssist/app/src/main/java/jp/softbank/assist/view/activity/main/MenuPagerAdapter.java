/*
 * ファイル：MenuPagerAdapter.java
 * 概要：メニュー画面のフラグメント切り替えを行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.main;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import jp.softbank.assist.util.Constants;

import java.util.List;

/**
 * フラグメント管理クラス
 *
 * @author Systena
 * @version 1.0
 */
public class MenuPagerAdapter extends FragmentPagerAdapter {
    private List<Fragment> mFragments;

    public MenuPagerAdapter(FragmentManager fm, List<Fragment> fragments) {
        super(fm);
        mFragments = fragments;
    }

    @Override
    public Fragment getItem(int position) {
        return mFragments.get(position);
    }

    @Override
    public int getCount() {
        return Constants.Tab.TAB_ITEM_NUMBER_MENU;
    }
}
