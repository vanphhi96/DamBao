/*
 * ファイル：AddDictionaryResultCard.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

/**
 * 辞書登録結果カード情報.
 */
public class AddDictionaryResultCard {

    @SerializedName("card_id")
    private Long mCardId = null;
    @SerializedName("next_card_id")
    private Long mNextCardId = null;
    @SerializedName("card_version")
    private Long mCardVersion = null;


    /**
     * カードID.
     */
    public Long getCardId() {
        return mCardId;
    }
    public void setCardId(Long cardId) {
        this.mCardId = cardId;
    }

    /**
     * 次カードID.
     */
    public Long getNextCardId() {
        return mNextCardId;
    }
    public void setNextCardId(Long nextCardId) {
        this.mNextCardId = nextCardId;
    }

    /**
     * バージョン.
     */
    public Long getCardVersion() {
        return mCardVersion;
    }
    public void setCardVersion(Long cardVersion) {
        this.mCardVersion = cardVersion;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AddDictionaryResultCard dictionaryResultCard = (AddDictionaryResultCard) o;
        return (this.mCardId == null ? dictionaryResultCard.mCardId == null : this.mCardId.equals(dictionaryResultCard.mCardId)) &&
                (this.mNextCardId == null ? dictionaryResultCard.mNextCardId == null : this.mNextCardId.equals(dictionaryResultCard.mNextCardId)) &&
                (this.mCardVersion == null ? dictionaryResultCard.mCardVersion == null : this.mCardVersion.equals(dictionaryResultCard.mCardVersion));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mCardId == null ? 0: this.mCardId.hashCode());
        result = 31 * result + (this.mNextCardId == null ? 0: this.mNextCardId.hashCode());
        result = 31 * result + (this.mCardVersion == null ? 0: this.mCardVersion.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class AddDictionaryResultCard {\n");

        sb.append("  mCardId: ").append(mCardId).append("\n");
        sb.append("  mNextCardId: ").append(mNextCardId).append("\n");
        sb.append("  mCardVersion: ").append(mCardVersion).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
