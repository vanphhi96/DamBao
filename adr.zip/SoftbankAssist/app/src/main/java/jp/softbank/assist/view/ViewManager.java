/*
 * ファイル：ViewManager.java
 * 概要：画面制御を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import jp.softbank.assist.R;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.view.activity.BaseActivity;
import jp.softbank.assist.view.activity.dictionary.DicCreateUiActivity;
import jp.softbank.assist.view.activity.dictionary.DicDetailUiActivity;
import jp.softbank.assist.view.activity.dictionary.DicEditUiActivity;
import jp.softbank.assist.view.activity.dictionary.DicHelpWebActivity;
import jp.softbank.assist.view.activity.dictionary.DicListUiActivity;
import jp.softbank.assist.view.activity.dictionary.DicRememberedUiActivity;
import jp.softbank.assist.view.activity.dictionary.DicSelectCategoryActivity;
import jp.softbank.assist.view.activity.login.AutMySbLoginWebActivity;
import jp.softbank.assist.view.activity.main.CheckAppUiActivity;
import jp.softbank.assist.view.activity.main.MenuUiActivity;
import jp.softbank.assist.view.activity.main.UpdateNoticeUiActivity;
import jp.softbank.assist.view.activity.schedule.SchCalendarUiActivity;
import jp.softbank.assist.view.activity.schedule.SchCompleteUiActivity;
import jp.softbank.assist.view.activity.schedule.SchCreateUiActivity;
import jp.softbank.assist.view.activity.schedule.SchDicDetailUiActivity;
import jp.softbank.assist.view.activity.schedule.SchDicEditUiActivity;
import jp.softbank.assist.view.activity.schedule.SchDicSelectUiActivity;
import jp.softbank.assist.view.activity.schedule.SchDictionaryCheckActivity;
import jp.softbank.assist.view.activity.schedule.SchDictionaryListUiActivity;
import jp.softbank.assist.view.activity.schedule.SchEditUiActivity;
import jp.softbank.assist.view.activity.schedule.SchHelpWebActivity;
import jp.softbank.assist.view.activity.schedule.SchRepeatChangeUiActivity;
import jp.softbank.assist.view.activity.settings.SetAboutUiActivity;
import jp.softbank.assist.view.activity.settings.SetAdministratorSettingWebActivity;
import jp.softbank.assist.view.activity.settings.SetContactUsWebActivity;
import jp.softbank.assist.view.activity.settings.SetFaqWebActivity;
import jp.softbank.assist.view.activity.settings.SetHistoryUiActivity;
import jp.softbank.assist.view.activity.settings.SetInformationDetailWebActivity;
import jp.softbank.assist.view.activity.settings.SetLicenseUiActivity;
import jp.softbank.assist.view.activity.settings.SetLocationSettingUiActivity;
import jp.softbank.assist.view.activity.settings.SetLocationTimeRecordUiActivity;
import jp.softbank.assist.view.activity.settings.SetPersonalInfoWebActivity;
import jp.softbank.assist.view.activity.settings.SetPolicyWebActivity;
import jp.softbank.assist.view.activity.settings.SetUserSettingUiActivity;
import jp.softbank.assist.view.activity.walkthrough.WalAdministratorLinkWebActivity;
import jp.softbank.assist.view.activity.walkthrough.WalFinishUiActivity;
import jp.softbank.assist.view.activity.walkthrough.WalLocationConfirmUiActivity;
import jp.softbank.assist.view.activity.walkthrough.WalMySbLoginWebActivity;
import jp.softbank.assist.view.activity.walkthrough.WalNotificationConfirmUiActivity;
import jp.softbank.assist.view.activity.walkthrough.WalUserAccountEditEndUiActivity;
import jp.softbank.assist.view.activity.walkthrough.WalUserAccountEditUiActivity;
import jp.softbank.assist.view.activity.walkthrough.WalWelcomeUiActivity;
import jp.softbank.assist.view.fragment.BaseFragment;
import jp.softbank.assist.view.fragment.dictionary.DicTopUiFragment;
import jp.softbank.assist.view.fragment.schedule.SchTopUiFragment;
import jp.softbank.assist.view.fragment.settings.SetTopUiFragment;
import jp.softbank.assist.view.fragment.settings.SetUserInfoEditUiFragment;
import jp.softbank.assist.view.fragment.settings.SetVersionUiFragment;
import jp.softbank.assist.view.fragmenttemp.FragmentSample;
import jp.softbank.assist.view.fragmenttemp.SchTest_2;

import java.util.List;

/**
 * 画面切り替え用クラス
 *
 * @author Systena
 * @version 1.0
 */
public class ViewManager {

    protected BaseActivity mCurrentActivity = null;
    protected Fragment mCurrentFragment = null;


    /**
     * コンストラクタ.
     */
    public ViewManager() {
    }

    /**
     * @param activity
     */
    public void setActivity(BaseActivity activity) {
        mCurrentActivity = activity;
    }

    /**
     * @param fragment
     */
    public synchronized void setFragment(Fragment fragment) {
        mCurrentFragment = fragment;
    }

    /**
     * @param activity
     */
    public void clearActivity(BaseActivity activity) {
        if (mCurrentActivity == activity) {
            mCurrentActivity = null;
        }
    }

    /**
     * @param fragment
     */
    public void clearFragment(Fragment fragment) {
        if (mCurrentFragment == fragment) {
            mCurrentFragment = null;
        }
    }

    /**
     * @return
     */
    public Context getContext() {
        Context context = null;
        if (mCurrentActivity != null) {
            context = mCurrentActivity.getApplicationContext();
        }
        return context;
    }

    /**
     * @return
     */
    public boolean isActivityExist() {
        return (null != mCurrentActivity);
    }

    /**
     * @param id
     * @return
     */
    public Class<?> getActivity(ScreenId id) {
        AssistLog.d("getActivity()=" + String.valueOf(id));
        return convertKeyToClass(id);
    }

    /**
     * @param id
     * @return
     */
    public static Class<? extends BaseActivity> convertKeyToClass(ScreenId id) {
        switch (id) {
            case START_MENU:
                return MenuUiActivity.class;
            // App起動画面
            case START_CHECK_APP:
                return CheckAppUiActivity.class;
            case START_UPDATE_NOTICE:
                return UpdateNoticeUiActivity.class;

            // ウォークスルー画面 / Wal Screen
            case START_WAL_WELCOME:
                return WalWelcomeUiActivity.class;
            case START_WAL_MY_SB_LOGIN:
                return WalMySbLoginWebActivity.class;
            case START_WAL_USER_ACCOUNT_EDIT:
                return WalUserAccountEditUiActivity.class;
            case START_WAL_ACCOUNT_EDIT_END:
                return WalUserAccountEditEndUiActivity.class;
            case START_WAL_LOCATION_CONFIRM:
                return WalLocationConfirmUiActivity.class;
            case START_WAL_NOTIFICATION_CONFIRM:
                return WalNotificationConfirmUiActivity.class;
            case START_WAL_ADMINISTRATOR_LINK:
                return WalAdministratorLinkWebActivity.class;
            case START_WAL_FINISH:
                return WalFinishUiActivity.class;

            // Auth画面 / Auth Screen
            case START_AUT_MY_SB_LOGIN:
                return AutMySbLoginWebActivity.class;

            // “今日の予定”画面 / Sch Screen
            case START_SCH_COMPLETE:
                return SchCompleteUiActivity.class;
            case START_SCH_EDIT:
                return SchEditUiActivity.class;
            case START_SCH_CREATE:
                return SchCreateUiActivity.class;
            case START_SCH_CALENDAR:
                return SchCalendarUiActivity.class;
            case START_SCH_HELP:
                return SchHelpWebActivity.class;
            case START_SCH_REPEAT:
                return SchRepeatChangeUiActivity.class;
            case START_SCH_DICTIONARY_SELECT:
                return SchDicSelectUiActivity.class;
            case START_SCH_DICTIONARY_EDIT:
                return SchDicEditUiActivity.class;
            case START_SCH_DICTIONARY_LIST:
                return SchDictionaryListUiActivity.class;
            case START_SCH_DICTIONARY_DETAIL:
                return SchDicDetailUiActivity.class;
            case START_SCH_DICTIONARY_CHECK:
                return SchDictionaryCheckActivity.class;

            // “じぶん辞書”画面 / Dic Screen
            case START_DIC_DETAIL:
                return DicDetailUiActivity.class;
            case START_DIC_REMEMBERED:
                return DicRememberedUiActivity.class;
            case START_DIC_EDIT:
                return DicEditUiActivity.class;
            case START_DIC_CREATE:
                return DicCreateUiActivity.class;
            case START_DIC_HELP:
                return DicHelpWebActivity.class;
            case START_DIC_CATEGORY:
                return DicSelectCategoryActivity.class;
            case START_DIC_LIST:
                return DicListUiActivity.class;
            // “設定”画面 / Setting Screen
            case START_SET_ABOUT:
                return SetAboutUiActivity.class;
            case START_SET_HISTORY:
                return SetHistoryUiActivity.class;
            case START_SET_ADMINISTRATOR_SETTING:
                return SetAdministratorSettingWebActivity.class;
            case START_SET_INFORMATION_DETAIL:
                return SetInformationDetailWebActivity.class;
            case START_SET_USER_SETTING:
                return SetUserSettingUiActivity.class;
            case START_SET_LOCATION_SETTING:
                return SetLocationSettingUiActivity.class;
            case START_SET_LOCATION_TIME_RECORD:
                return SetLocationTimeRecordUiActivity.class;
            case START_SET_POLICY:
                return SetPolicyWebActivity.class;
            case START_SET_CONTACT_US:
                return SetContactUsWebActivity.class;
            case START_SET_PERSONAL_INFO:
                return SetPersonalInfoWebActivity.class;
            case START_SET_FAQ:
                return SetFaqWebActivity.class;
            case START_SET_LICENSE:
                return SetLicenseUiActivity.class;
            default:
                break;
        }
        return null;
    }

    /**
     * ActivityからScreenIDにコンバート / Convert Activity to ScreenID
     *
     * @param className
     * @return
     */
    public ScreenId convertActivityNameToKey(String className) {
        switch (className) {
            case "StartUpUiActivity":
                return ScreenId.START_UP;
            case "CheckAppUiActivity":
                return ScreenId.START_CHECK_APP;
            case "UpdateNoticeUiActivity":
                return ScreenId.START_UPDATE_NOTICE;
            case "MenuUiActivity":
                return ScreenId.START_MENU;

            // ウォークスルー画面 / Wal Screen
            case "WalWelcomeUiActivity":
                return ScreenId.START_WAL_WELCOME;
            case "WalMySbLoginWebActivity":
                return ScreenId.START_WAL_MY_SB_LOGIN;
            case "WalUserAccountEditUiActivity":
                return ScreenId.START_WAL_USER_ACCOUNT_EDIT;
            case "WalUserAccountEditEndUiActivity":
                return ScreenId.START_WAL_ACCOUNT_EDIT_END;
            case "WalLocationConfirmUiActivity":
                return ScreenId.START_WAL_LOCATION_CONFIRM;
            case "WalNotificationConfirmUiActivity":
                return ScreenId.START_WAL_NOTIFICATION_CONFIRM;
            case "WalAdministratorLinkWebActivity":
                return ScreenId.START_WAL_ADMINISTRATOR_LINK;
            case "WalFinishUiActivity":
                return ScreenId.START_WAL_FINISH;

            // Auth画面 / Auth Screen
            case "AutMySbLoginWebActivity":
                return ScreenId.START_AUT_MY_SB_LOGIN;

            // “今日の予定”画面 / Sch Screen
            case "SchCompleteUiActivity":
                return ScreenId.START_SCH_COMPLETE;
            case "SchEditUiActivity":
                return ScreenId.START_SCH_EDIT;
            case "SchCreateUiActivity":
                return ScreenId.START_SCH_CREATE;
            case "SchCalendarUiActivity":
                return ScreenId.START_SCH_CALENDAR;
            case "SchHelpWebActivity":
                return ScreenId.START_SCH_HELP;
            case "SchRepeatChangeUiActivity":
                return ScreenId.START_SCH_REPEAT;
            case "SchDicSelectUiActivity":
                return ScreenId.START_SCH_DICTIONARY_SELECT;
            case "SchDicEditUiActivity":
                return ScreenId.START_SCH_DICTIONARY_EDIT;
            case "SchDictionaryListUiActivity":
                return ScreenId.START_SCH_DICTIONARY_LIST;
            case "SchDicDetailUiActivity":
                return ScreenId.START_SCH_DICTIONARY_DETAIL;
            case "SchDictionaryCheckActivity":
                return ScreenId.START_SCH_DICTIONARY_CHECK;

            // “じぶん辞書”画面 / Dic Screen
            case "DicDetailUiActivity":
                return ScreenId.START_DIC_DETAIL;
            case "DicRememberedUiActivity":
                return ScreenId.START_DIC_REMEMBERED;
            case "DicEditUiActivity":
                return ScreenId.START_DIC_EDIT;
            case "DicCreateUiActivity":
                return ScreenId.START_DIC_CREATE;
            case "DicHelpWebActivity":
                return ScreenId.START_DIC_HELP;
            case "DicListUiActivity":
                return ScreenId.START_DIC_LIST;

            // “設定”画面 / Setting Screen
            case "SetAdministratorSettingWebActivity":
                return ScreenId.START_SET_ADMINISTRATOR_SETTING;
            case "SetContactUsWebActivity":
                return ScreenId.START_SET_CONTACT_US;
            case "SetFaqWebActivity":
                return ScreenId.START_SET_FAQ;
            case "SetHistoryUiActivity":
                return ScreenId.START_SET_HISTORY;
            case "SetPersonalInfoWebActivity":
                return ScreenId.START_SET_PERSONAL_INFO;
            case "SetPolicyWebActivity":
                return ScreenId.START_SET_POLICY;
            case "SetUnsubscribedWebActivity":
                return ScreenId.START_SET_UNSUBSCRIBED;
            case "SetAboutUiActivity":
                return ScreenId.START_SET_ABOUT;
            case "SetInformationDetailWebActivity":
                return ScreenId.START_SET_INFORMATION_DETAIL;
            case "SetUserSettingUiActivity":
                return ScreenId.START_SET_USER_SETTING;
            case "SetLocationSettingUiActivity":
                return ScreenId.START_SET_LOCATION_SETTING;
            case "SetLocationTimeReportUiActivity":
                return ScreenId.START_SET_LOCATION_TIME_RECORD;
            case "SetLicenseUiActivity":
                return ScreenId.START_SET_LICENSE;

            default:
                break;
        }
        return null;
    }

    /**
     * FragmentからScreenIDにコンバート / Convert Fragment to ScreenID
     *
     * @param className
     * @return
     */
    public ScreenId convertFragmentNameToKey(String className) {
        switch (className) {

            // “じぶん辞書”画面 / Dic Screen
            case "DicTopUiFragment":
                return ScreenId.START_DIC_TOP;

            // “今日の予定”画面 / Sch Screen
            case "SchTopUiFragment":
                return ScreenId.START_SCH_TOP;

            // “設定”画面 / Setting Screen
            case "SetTopUiFragment":
                return ScreenId.START_SET_TOP;
            case "SetUserInfoEditUiFragment":
                return ScreenId.START_SET_USER_INFO_EDIT;
            case "SetVersionUiFragment":
                return ScreenId.START_SET_VERSION;

            // Test Screen
            case "SchTest_1":
                return ScreenId.START_FRAGMENT_SCHEDULE_ONE;
            case "SchTest_2":
                return ScreenId.START_FRAGMENT_SCHEDULE_TWO;
            case "FragmentSample":
                return ScreenId.START_FRAGMENT_SAMPLE;
            case "DicBaseUiFragment":
                return ScreenId.NONE;

            default:
                break;
        }
        return null;
    }

    /**
     * アクティビティ完了
     */
    public void finishActivity() {
        BaseActivity activity = mCurrentActivity;
        if (activity == null) {
            return;
        }
        activity.finish();
    }

    /**
     * アクティビティ起動
     */
    private void viewActivity(Class<?> cls) {
        BaseActivity activity = mCurrentActivity;
        if (activity == null) {
            return;
        }

        Intent intent = new Intent(activity.getApplicationContext(), cls);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        activity.startActivity(intent);
    }

    /**
     * アクティビティ起動
     */
    private void viewActivity(Class<?> cls, Bundle bundle) {
        BaseActivity activity = mCurrentActivity;
        if (activity == null) {
            return;
        }

        Intent intent = new Intent(activity.getApplicationContext(), cls);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtras(bundle);
        activity.startActivity(intent);
    }

    /**
     * start activity with activityForResult
     *
     * @param cls         class name
     * @param requestCode request code
     * @param bundle      bundle data
     */
    private void viewActivityResult(Class<?> cls, int requestCode, Bundle bundle) {
        BaseActivity activity = mCurrentActivity;
        if (activity == null) {
            return;
        }
        Intent intent = new Intent(activity.getApplicationContext(), cls);
        if (bundle!=null){
            intent.putExtras(bundle);
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        activity.startActivityForResult(intent, requestCode);
    }

    /**
     * send data from activity
     *
     * @param activity    bundle activity back
     * @param bundle      bundle data
     * @param requestCode request code
     */
    private void backActivityResult(Activity activity, Bundle bundle, int requestCode) {
        if (activity == null) {
            return;
        }
        Intent intent = new Intent();
        intent.putExtras(bundle);
        activity.setResult(requestCode, intent);
        activity.finish();
    }

    /**
     * Change Activity
     *
     * @param id
     */
    public void changeScreen(ScreenId id) {
        viewActivity(convertKeyToClass(id));
    }

    /**
     * Change Activity
     *
     * @param id
     */
    public void changeScreen(ScreenId id, Bundle bundle) {
        viewActivity(convertKeyToClass(id), bundle);
    }

    /**
     * change activity with startActivityForResult
     *
     * @param id          screen Id
     * @param requestCode request code
     * @param bundle      bundle data
     */
    public void changeScreenResult(ScreenId id, int requestCode, Bundle bundle) {
        viewActivityResult(convertKeyToClass(id), requestCode, bundle);
    }

    /**
     * send data from activity
     *
     * @param activity    activity back
     * @param bundle      bundle data
     * @param requestCode request code
     */
    public void backScreenResult(Activity activity, Bundle bundle, int requestCode) {
        backActivityResult(activity, bundle, requestCode);
    }


    /**
     * @return ScreenId
     */
    public ScreenId getScreenId() {
        if (isHasFragment()) {
            return convertFragmentNameToKey(mCurrentFragment.getClass().getSimpleName());
        }
        if (isActivityExist()) {
            return convertActivityNameToKey(mCurrentActivity.getClass().getSimpleName());
        }
        return ScreenId.NONE;
    }

    /**
     * Change Fragment
     *
     * @param item
     */
    public void changeFragment(ScreenId item) {
        BaseFragment targetFragment = null;
        int containerViewId = 0;
        switch (item) {
            case START_SCH_TOP:
                targetFragment = SchTopUiFragment.newInstance();
                containerViewId = R.id.fr_sch_container;
                break;
            case START_DIC_TOP:
                targetFragment = DicTopUiFragment.newInstance();
                containerViewId = R.id.fr_dic_container;
                break;
            case START_SET_TOP:
                targetFragment = SetTopUiFragment.newInstance();
                containerViewId = R.id.fr_set_container;
                break;
            case START_SET_USER_INFO_EDIT:
                targetFragment = new SetUserInfoEditUiFragment();
                containerViewId = R.id.fr_set_container;
                break;
            case START_SET_VERSION:
                targetFragment = new SetVersionUiFragment();
                containerViewId = R.id.fr_set_container;
                break;
            // TODO: 2019/01/23 このケースはテストのため、後で消す/ This case is just for test, delete later。
            case START_FRAGMENT_SCHEDULE_TWO:
                targetFragment = new SchTest_2();
                containerViewId = R.id.fr_sch_container;
                break;
            case START_FRAGMENT_SAMPLE:
                targetFragment = new FragmentSample();
                containerViewId = R.id.fr_set_container;
                break;
            default:
                break;
        }

        if (targetFragment != null && containerViewId != 0) {
            replaceFragment(containerViewId, targetFragment, true);
        }

    }

    /**
     * replace fragment
     *
     * @param containerViewId  containerViewId
     * @param fragment         fragment
     * @param isAddToBackStack isBackStack
     */
    public void replaceFragment(int containerViewId, Fragment fragment,
                                boolean isAddToBackStack) {
        FragmentTransaction transaction = mCurrentActivity.getSupportFragmentManager().beginTransaction();
        if (isAddToBackStack) {
            transaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        transaction.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left, R.anim.enter_from_left, R.anim.exit_to_right);
        transaction.replace(containerViewId, fragment, fragment.getClass().getSimpleName());
        transaction.commitAllowingStateLoss();
    }

    /**
     * Check if there is fragment in Activity
     *
     * @return
     */
    private boolean isHasFragment() {
        FragmentManager fragmentManager = mCurrentActivity.getSupportFragmentManager();
        List<Fragment> fragments = fragmentManager.getFragments();
        if (fragments != null) {
            for (Fragment fragment : fragments) {
                if (fragment != null && fragment.isVisible())
                    return true;
            }
        }
        return false;
    }
}
