/*
 * ファイル：AppVersionInfo.java
 * 概要：最新アプリバージョン情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import jp.softbank.assist.BuildConfig;

import java.io.Serializable;

/**
 * 最新アプリバージョン情報.
 *
 * @author Systena
 * @version 1.0
 */
public class AppVersionInfo implements Serializable {

    private boolean mMustUpdate; // アップデート可否
    private String mMessage; // メッセージ
    private String mUrl; // URL
    private String mVersion; // 最新バージョン

    public boolean isMustUpdate() {
        return mMustUpdate;
    }

    public void setMustUpdate(boolean mustUpdate) {
        this.mMustUpdate = mustUpdate;
    }

    public String getMessage() {
        return mMessage;
    }

    public void setMessage(String message) {
        this.mMessage = message;
    }

    public String getUrl() {
        return mUrl;
    }

    public void setUrl(String url) {
        this.mUrl = url;
    }

    public String getVersion() {
        return mVersion;
    }

    public void setVersion(String version) {
        this.mVersion = version;
    }

    /**
     * バックアップを強制
     *
     * @return true  現在と最新のバージョンが一致していない。
     *         false 現在と最新のバージョンが一致している。
     */
    public boolean isForceUpdate() {
        return !mVersion.equalsIgnoreCase(BuildConfig.VERSION_NAME);
    }
}
