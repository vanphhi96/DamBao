/*
 * ファイル：GetNoticeResultListener.java
 * 概要：アシストサーバI/Fのコールバック
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.listener;

import jp.softbank.assist.model.database.NoticeInfo;
import jp.softbank.assist.network.AssistServerResult;

/**
 * お知らせ情報取得結果.
 */
public interface GetNoticeResultListener extends BaseResultListener {

    /**
     * 処理結果通知.
     *
     * @param result 処理結果
     * @param info お知らせ情報
     */
    public void onResult(AssistServerResult result, NoticeInfo info);
}
