/*
 * ファイル：LocationSettings.java
 * 概要：位置情報更新可否設定
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import java.io.Serializable;
import java.util.Date;

/**
 * 位置情報更新可否設定.
 *
 * @author Systena
 * @version 1.0
 */
public class LocationSettings implements Serializable {

    /**
     * 期間種別.
     */
    public enum TermType {
        Times(0), // 時刻指定
        AllDay(1), // 終日
        ;

        private final long mValue;

        TermType(long value) {
            this.mValue = value;
        }

        public long getValue() {
            return this.mValue;
        }

        /**
         * 数値からenumへの変換.
         *
         * @param value 数値
         * @return TermType
         */
        public static TermType fromValue(final long value) {
            TermType[] list = TermType.values();
            for (TermType item : list) {
                if (item.getValue() == value) {
                    return item;
                }
            }
            return AllDay;
        }
    }


    private boolean mRequestedLocation; // リクエスト位置取得可否
    private boolean mRegularLocation; // 定期位置取得可否
    private TermType mRegularLocationTermKind; // 定期位置取得期間種別
    private Date mRegularLocationStartTime; // 定期位置取得開始時刻
    private Date mRegularLocationEndTime; // 定期位置取得終了時刻
    private boolean mIsFence; // みまもるフェンス可否

    public boolean isRequestedLocation() {
        return mRequestedLocation;
    }

    public void setRequestedLocation(boolean requestedLocation) {
        this.mRequestedLocation = requestedLocation;
    }

    public boolean isRegularLocation() {
        return mRegularLocation;
    }

    public void setRegularLocation(boolean regularLocation) {
        this.mRegularLocation = regularLocation;
    }

    public TermType getRegularLocationTermKind() {
        return mRegularLocationTermKind;
    }

    public void setRegularLocationTermKind(TermType regularLocationKind) {
        this.mRegularLocationTermKind = regularLocationKind;
    }

    public Date getRegularLocationStartTime() {
        return mRegularLocationStartTime;
    }

    public void setRegularLocationStartTime(Date regularLocationStartTime) {
        this.mRegularLocationStartTime = regularLocationStartTime;
    }

    public Date getRegularLocationEndTime() {
        return mRegularLocationEndTime;
    }

    public void setRegularLocationEndTime(Date regularLocationEndTime) {
        this.mRegularLocationEndTime = regularLocationEndTime;
    }

    public boolean isFence() {
        return mIsFence;
    }

    public void setIsFence(boolean fence) {
        this.mIsFence = fence;
    }
}
