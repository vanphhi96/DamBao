/*
 * ファイル：RealmAuthInfo.java
 * 概要：Realm認証情報テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Realm認証情報テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmAuthInfo extends RealmObject {

    @PrimaryKey
    private int mId; // 認証情報 ID
    private boolean mIsCertified; //回線認証状態
    private String mAccessToken; //アクセストークン

    public int getId() {
        return mId;
    }

    public void setId(int mId) {
        this.mId = mId;
    }

    public boolean isCertified() {
        return mIsCertified;
    }

    public void setCertified(boolean mIsCertified) {
        this.mIsCertified = mIsCertified;
    }

    public String getAccessToken() {
        return mAccessToken;
    }

    public void setAccessToken(String mAccessToken) {
        this.mAccessToken = mAccessToken;
    }
}
