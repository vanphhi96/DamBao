package jp.softbank.assist.view.fragmenttemp;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.main.MenuUiActivity;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl.DialogType;
import jp.softbank.assist.view.dialog.factories.SingleChoiceDialogFactory;
import jp.softbank.assist.view.dialog.factories.customfactories.CustomSampleDialogFactory;
import jp.softbank.assist.view.fragment.BaseFragment;

/**
 * Created by Tan N. Truong on 2019/01/09.
 */

// TODO: 2019/01/09 Just an example Fragment, can be deleted later

public class DicTest_2 extends BaseFragment implements View.OnClickListener, DialogInterface.OnClickListener, DialogInterface.OnKeyListener {
    private Button mButton1;
    private Button mButton2;
    private Button mButton3;
    private Button mButton4;
    private TextView mText;
    private ImageView mImage;
    private int mColor;

    private int mPushCount = 0;

    String mDialogTag = null;
    BaseDialogFactory mDialogFactory;
    MenuUiActivity mCurrentActivity;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCurrentActivity = (MenuUiActivity) getActivity();
        mCurrentActivity.setCurrentFraggment(this);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_temp_dic_two, container, false);
        mButton1 = view.findViewById(R.id.button_DialogTest1);
        mButton1.setOnClickListener(this);
        mButton2 = view.findViewById(R.id.button_DialogTest2);
        mButton2.setOnClickListener(this);
        mButton3 = view.findViewById(R.id.button_DialogTest3);
        mButton3.setOnClickListener(this);
        mButton4 = view.findViewById(R.id.button_DialogTest4);
        mButton4.setOnClickListener(this);

        view.findViewById(R.id.button_PushTest1).setOnClickListener(this);
        view.findViewById(R.id.button_PushTest2).setOnClickListener(this);
        view.findViewById(R.id.button_PushTest3).setOnClickListener(this);
        view.findViewById(R.id.button_PushTest4).setOnClickListener(this);
        view.findViewById(R.id.button_PushTestClear).setOnClickListener(this);
        view.findViewById(R.id.button_dbTest1).setOnClickListener(this);
        view.findViewById(R.id.button_dbTest2).setOnClickListener(this);
        view.findViewById(R.id.button_dbTest3).setOnClickListener(this);

        mImage = (ImageView) view.findViewById(R.id.view_Image);

        mText = view.findViewById(R.id.fragmentText);
        mColor = Color.GRAY;
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_DialogTest1:
                buildTestAlertDialog();
                break;
            case R.id.button_DialogTest2:
                buildTestSingleChoiceDialog();
                break;
            case R.id.button_DialogTest3:
                buildSingleChoiceDialogCustom();
                break;
            case R.id.button_DialogTest4:
                buildCustomSampleDialog();
                break;
            case R.id.button_PushTest1:
                buildPushSelf1();
                break;
            case R.id.button_PushTest2:
                buildPushSelf2();
                break;
            case R.id.button_PushTest3:
                buildPushSelf3();
                break;
            case R.id.button_PushTest4:
                buildPushSelf4();
                break;
            case R.id.button_PushTestClear:
                buildPushClear();
                break;
            case R.id.button_dbTest1:
                break;
            case R.id.button_dbTest2:
                replaceFragment(R.id.fr_set_container, new IoTest_2(), true);
                break;
            case R.id.button_dbTest3:
                replaceFragment(R.id.fr_set_container, new IoTest_3(), true);
                break;
            default:
                break;
        }
    }

    /**
     * キー操作時に呼ばれる
     */
    @Override
    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
        return false;
    }

    /**
     * ダイアログクリック時に使用
     */
    @Override
    public void onClick(DialogInterface dialog, int which) {

        if (which == DialogInterface.BUTTON_POSITIVE) {
            if (DialogType.ALERT_TEST_DIALOG1.name().equals(mDialogTag)) {
                mText.setText("DialogTest1 OK");
            } else if (DialogType.SINGLE_CHOICE_TEST_DIALOG1.name().equals(mDialogTag)) {
                mText.setText("DialogTest2 OK");
            } else if (DialogType.SINGLE_CHOICE_TEST_DIALOG2.name().equals(mDialogTag)) {
                SingleChoiceDialogFactory factory = (SingleChoiceDialogFactory) mDialogFactory;
                mText.setText("DialogTest3 " + factory.getCheckedItemString() + " Selected");
            } else if (DialogType.SINGLE_CHOICE_TEST_DIALOG3.name().equals(mDialogTag)) {
                CustomSampleDialogFactory factory = (CustomSampleDialogFactory) mDialogFactory;
                mImage.setBackgroundColor(factory.getBtnColor());
                if (mColor != factory.getBtnColor()) {
                    mColor = factory.getBtnColor();
                    mText.setText("Changed Select Color");
                } else {
                    mText.setText("Please Select Button");
                }
            }
        } else if (which == DialogInterface.BUTTON_NEGATIVE) {
            if (DialogType.SINGLE_CHOICE_TEST_DIALOG3.name().equals(mDialogTag)) {
                mImage.setBackgroundColor(Color.WHITE);
                mColor = Color.WHITE;
                mText.setText("Changed No Color");
            }
        } else if (which == DialogInterface.BUTTON_NEUTRAL) {
            if (DialogType.SINGLE_CHOICE_TEST_DIALOG3.name().equals(mDialogTag)) {
                mImage.setBackgroundColor(Color.GRAY);
                mColor = Color.GRAY;
                mText.setText("Changed Default Color");
            }
        } else {
            return;
        }
    }

    /**
     * アラートダイアログ呼び出し設定
     */
    private void buildTestAlertDialog() {
        mDialogFactory = new AssistAlertDialogFactory(
                jp.softbank.assist.view.dialog.factories.DialogTypeControl.DialogType.ALERT_TEST_DIALOG1);
        mDialogTag = mDialogFactory.getDialogTag();
        new jp.softbank.assist.view.dialog.DialogGenerator(getActivity(), mDialogFactory).show();

    }

    /**
     * 選択ダイアログ呼び出し設定
     */
    private void buildTestSingleChoiceDialog() {
        SingleChoiceDialogFactory dialogFactory = new SingleChoiceDialogFactory(
                DialogType.SINGLE_CHOICE_TEST_DIALOG1);
        dialogFactory.setCheckedPos(0);
        final CharSequence[] tStrList = {"この文章はテストです\n改行できてますか？"};
        dialogFactory.setCharList(tStrList);
        mDialogFactory = dialogFactory;
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(getActivity(), dialogFactory).show();
    }

    /**
     * 選択ダイアログ呼び出し設定(選択ラジオボタン設定)
     */
    private void buildSingleChoiceDialogCustom() {
        SingleChoiceDialogFactory dialogFactory = new SingleChoiceDialogFactory(
                DialogType.SINGLE_CHOICE_TEST_DIALOG2);
        dialogFactory.setCheckedPos(0);
        final CharSequence[] tStrList = {getActivity().getString(R.string.sch_title),
                getActivity().getString(R.string.dic_my_dic),
                getActivity().getString(R.string.set_setting)};
        dialogFactory.setCharList(tStrList);
        mDialogFactory = dialogFactory;
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(getActivity(), dialogFactory).show();
    }

    /**
     * カスタムダイアログ呼び出し設定
     */
    private void buildCustomSampleDialog() {
        CustomSampleDialogFactory dialogFactory = new CustomSampleDialogFactory(
                DialogType.SINGLE_CHOICE_TEST_DIALOG3);
        mDialogFactory = dialogFactory;
        mDialogTag = mDialogFactory.getDialogTag();
        dialogFactory.setBtnColor(mColor);
        new DialogGenerator(getActivity(), dialogFactory).show();
    }

    /**
     * push通知送信テスト
     */
    private void buildPushSelf1() {

        Intent intent = new Intent("assist");
        PendingIntent contentIntent = PendingIntent.getBroadcast(getContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder notification = new NotificationCompat.Builder(getContext(), "testId")
                .setSmallIcon(R.drawable.ic_time)
                .setContentTitle("あと10分で予定時間です")
                .setContentText("××学校に到着")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(contentIntent);
        NotificationChannel notificationChannel = new NotificationChannel("testId", "test", NotificationManager.IMPORTANCE_DEFAULT);
        notificationChannel.enableVibration(true);

        NotificationManager notificationManager =
                (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(notificationChannel);

        notificationManager.notify(1, notification.build());
    }

    /**
     * push通知送信テスト
     */
    private void buildPushSelf2() {

        Intent intent = new Intent("assist");
        PendingIntent contentIntent = PendingIntent.getBroadcast(getContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder notification = new NotificationCompat.Builder(getContext(), "testId")
                .setSmallIcon(R.drawable.ic_time)
                .setContentTitle("予定時間になりました")
                .setContentText("××学校に到着")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(contentIntent);
        NotificationChannel notificationChannel = new NotificationChannel("testId", "test", NotificationManager.IMPORTANCE_DEFAULT);
        notificationChannel.enableVibration(true);

        NotificationManager notificationManager =
                (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(notificationChannel);

        notificationManager.notify(1, notification.build());
    }

    /**
     * push通知送信テスト
     */
    private void buildPushSelf3() {

        Intent intent = new Intent("assist");
        PendingIntent contentIntent = PendingIntent.getBroadcast(getContext(), 1, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        int rem = mPushCount % 3;
        if (rem == 0) {
            String id = String.format("testId%02d",mPushCount);
            NotificationCompat.Builder notification = new NotificationCompat.Builder(getContext(), id)
                    .setSmallIcon(R.drawable.ic_time)
                    .setContentTitle("予定が追加されました")
                    .setContentText("おばあちゃんの家に行く")
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
//                    .setGroup(GROUP_KEY)
//                    .setGroupSummary(true)
                    .setContentIntent(contentIntent);
            NotificationChannel notificationChannel = new NotificationChannel(id, "test", NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.enableVibration(true);

            NotificationManager notificationManager =
                    (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);

            notificationManager.notify(mPushCount, notification.build());
//            notificationManager.notify(100, notification.build());
        } else if (rem == 1) {
            String id = String.format("testId%02d",mPushCount);
            NotificationCompat.Builder notification = new NotificationCompat.Builder(getContext(), id)
                    .setSmallIcon(R.drawable.ic_time)
                    .setContentTitle("予定が追加されました")
                    .setContentText("おかあさんと病院に行く")
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
//                    .setGroup(GROUP_KEY)
//                    .setGroupSummary(true)
                    .setContentIntent(contentIntent);
            NotificationChannel notificationChannel = new NotificationChannel(id, "test", NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.enableVibration(true);

            NotificationManager notificationManager =
                    (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);

            notificationManager.notify(mPushCount, notification.build());
//            notificationManager.notify(100, notification.build());

        } else if (rem == 2) {
            String id = String.format("testId%02d",mPushCount);
            NotificationCompat.Builder notification = new NotificationCompat.Builder(getContext(), id)
                    .setSmallIcon(R.drawable.ic_time)
                    .setContentTitle("予定が追加されました")
                    .setContentText("しゅくだいをする")
//                    .setSound(Uri.parse(Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.raw.test))
//                    .setSound(Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.raw.test2))
                    .setDefaults(0)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
//                    .setGroup(GROUP_KEY)
//                    .setGroupSummary(true)
                    .setContentIntent(contentIntent);
            NotificationChannel notificationChannel = new NotificationChannel(id, "test", NotificationManager.IMPORTANCE_DEFAULT);
//            notificationChannel.setSound(Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.raw.test2),null);
            notificationChannel.enableVibration(true);

            NotificationManager notificationManager =
                    (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);

            notificationManager.notify(mPushCount, notification.build());
//            notificationManager.notify(100, notification.build());

        }
        mPushCount++;
    }
    /**
     * push通知送信テスト
     */
    private void buildPushSelf4() {

        Intent intent = new Intent("assist");
        PendingIntent contentIntent = PendingIntent.getBroadcast(getContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder notification = new NotificationCompat.Builder(getContext(), "testIdgps")
                .setSmallIcon(R.drawable.ic_time)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(contentIntent);
        NotificationChannel notificationChannel = new NotificationChannel("testIdgps", "test", NotificationManager.IMPORTANCE_DEFAULT);
        notificationChannel.enableVibration(true);

        NotificationManager notificationManager =
                (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(notificationChannel);

        notificationManager.notify(999, notification.build());

        try {
            Thread.sleep(5 * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        NotificationManager mNotificationManager = (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.cancel(999);
    }
    /**
     * push通知送信テスト
     */
    private void buildPushClear() {

        NotificationManager mNotificationManager = (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.cancelAll();
    }
}
