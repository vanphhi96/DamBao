/*
 * ファイル：FragmentSelectIcon.java
 * 概要：List all icon schedule
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment.schedule;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import jp.softbank.assist.R;
import jp.softbank.assist.view.activity.schedule.IScheduleSelectIcon;
import jp.softbank.assist.view.adapter.AdapterListSelectIconSchedule;
import jp.softbank.assist.view.fragment.BaseFragment;

import java.util.ArrayList;


/**
 * sch-ed-01.
 *
 * @author Systena
 * @version 1.0
 */

@SuppressLint("ValidFragment")
public class FragmentSelectIcon extends BaseFragment implements ISelectIconSchedule {
    private static final int COLUMNS = 2;
    private ArrayList<String> mListIcon;
    private RecyclerView mRvIcon;
    private AdapterListSelectIconSchedule mAdapterListSelectIconSchedule;
    private IScheduleSelectIcon mIScheduleSelectIcon;
    private String mDrawableSelected;

    /**
     * constructor of fragment
     *
     * @param mIScheduleSelectIcon interface select icon schedule
     * @param listIcon
     */
    public FragmentSelectIcon(IScheduleSelectIcon mIScheduleSelectIcon, ArrayList<String> listIcon, String drawable) {
        this.mIScheduleSelectIcon = mIScheduleSelectIcon;
        this.mListIcon = listIcon;
        this.mDrawableSelected = drawable;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_select_icon, container, false);
        mRvIcon = view.findViewById(R.id.rv_icon);
        mAdapterListSelectIconSchedule = new AdapterListSelectIconSchedule(mListIcon);
        mAdapterListSelectIconSchedule.setInterface(this);
        mAdapterListSelectIconSchedule.setIconSelected(mDrawableSelected);
        mRvIcon.setLayoutManager(new GridLayoutManager(mRvIcon.getContext(), COLUMNS, GridLayoutManager.HORIZONTAL, false));
        mRvIcon.setAdapter(mAdapterListSelectIconSchedule);
        return view;
    }

    @Override
    public void selectedIcon(String drawable) {
        if (mIScheduleSelectIcon == null) {
            return;
        }
        mIScheduleSelectIcon.selectIcon(drawable);
        mAdapterListSelectIconSchedule.setIconSelected(drawable);
        mAdapterListSelectIconSchedule.notifyDataSetChanged();
    }
}
