/*
 * ファイル：SynchronizeDictionaryResultDictionary.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

/**
 * 辞書情報.
 */
public class SynchronizeDictionaryResultDictionary {

    @SerializedName("mId")
    private Long mId = null;
    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("category_id")
    private Long mCategoryId = null;
    @SerializedName("dictionary_type")
    private Long mDictionaryType = null;
    @SerializedName("mName")
    private String mName = null;
    @SerializedName("image_path")
    private String mImagePath = null;
    @SerializedName("is_memorize")
    private Long mIsMemorize = null;
    @SerializedName("version")
    private Long mVersion = null;
    @SerializedName("mNickname")
    private String mNickname = null;
    @SerializedName("icon_id")
    private Long mIconId = null;
    @SerializedName("icon_path")
    private String mIconPath = null;
    @SerializedName("created_at")
    private String mCreatedAt = null;
    @SerializedName("updated_at")
    private String mUpdatedAt = null;
    @SerializedName("created_by")
    private Long mCreatedBy = null;
    @SerializedName("updated_by")
    private Long mUpdatedBy = null;
    @SerializedName("is_deleted")
    private Long mIsDeleted = null;


    /**
     * 辞書ID.
     */
    public Long getId() {
        return mId;
    }
    public void setId(Long id) {
        this.mId = id;
    }

    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * カテゴリID.
     */
    public Long getCategoryId() {
        return mCategoryId;
    }
    public void setCategoryId(Long categoryId) {
        this.mCategoryId = categoryId;
    }

    /**
     * 辞書種別（0：ステップ形式、1：チェック形式）.
     */
    public Long getDictionaryType() {
        return mDictionaryType;
    }
    public void setDictionaryType(Long dictionaryType) {
        this.mDictionaryType = dictionaryType;
    }

    /**
     * 辞書名.
     */
    public String getName() {
        return mName;
    }
    public void setName(String name) {
        this.mName = name;
    }

    /**
     * 画像パス.
     */
    public String getImagePath() {
        return mImagePath;
    }
    public void setImagePath(String imagePath) {
        this.mImagePath = imagePath;
    }

    /**
     * 覚えたフラグ（0：覚えていない、1：覚えた）.
     */
    public Long getIsMemorize() {
        return mIsMemorize;
    }
    public void setIsMemorize(Long isMemorize) {
        this.mIsMemorize = isMemorize;
    }

    /**
     * バージョン.
     */
    public Long getVersion() {
        return mVersion;
    }
    public void setVersion(Long version) {
        this.mVersion = version;
    }

    /**
     * ニックネーム.
     */
    public String getNickname() {
        return mNickname;
    }
    public void setNickname(String nickname) {
        this.mNickname = nickname;
    }

    /**
     * アイコンID.
     */
    public Long getIconId() {
        return mIconId;
    }
    public void setIconId(Long iconId) {
        this.mIconId = iconId;
    }

    /**
     * アイコンパス.
     */
    public String getIconPath() {
        return mIconPath;
    }
    public void setIconPath(String iconPath) {
        this.mIconPath = iconPath;
    }

    /**
     * 作成日時（YYYYMMDDhhmmss形式）.
     */
    public String getCreatedAt() {
        return mCreatedAt;
    }
    public void setCreatedAt(String createdAt) {
        this.mCreatedAt = createdAt;
    }

    /**
     * 更新日時（YYYYMMDDhhmmss形式）.
     */
    public String getUpdatedAt() {
        return mUpdatedAt;
    }
    public void setUpdatedAt(String updatedAt) {
        this.mUpdatedAt = updatedAt;
    }

    /**
     * 作成者ID.
     */
    public Long getCreatedBy() {
        return mCreatedBy;
    }
    public void setCreatedBy(Long createdBy) {
        this.mCreatedBy = createdBy;
    }

    /**
     * 更新者ID.
     */
    public Long getUpdatedBy() {
        return mUpdatedBy;
    }
    public void setUpdatedBy(Long updatedBy) {
        this.mUpdatedBy = updatedBy;
    }

    /**
     * 削除済フラグ.
     */
    public Long getIsDeleted() {
        return mIsDeleted;
    }
    public void setIsDeleted(Long isDeleted) {
        this.mIsDeleted = isDeleted;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SynchronizeDictionaryResultDictionary dictionaryResult = (SynchronizeDictionaryResultDictionary) o;
        return (this.mId == null ? dictionaryResult.mId == null : this.mId.equals(dictionaryResult.mId)) &&
                (this.mUserId == null ? dictionaryResult.mUserId == null : this.mUserId.equals(dictionaryResult.mUserId)) &&
                (this.mCategoryId == null ? dictionaryResult.mCategoryId == null : this.mCategoryId.equals(dictionaryResult.mCategoryId)) &&
                (this.mDictionaryType == null ? dictionaryResult.mDictionaryType == null : this.mDictionaryType.equals(dictionaryResult.mDictionaryType)) &&
                (this.mName == null ? dictionaryResult.mName == null : this.mName.equals(dictionaryResult.mName)) &&
                (this.mImagePath == null ? dictionaryResult.mImagePath == null : this.mImagePath.equals(dictionaryResult.mImagePath)) &&
                (this.mIsMemorize == null ? dictionaryResult.mIsMemorize == null : this.mIsMemorize.equals(dictionaryResult.mIsMemorize)) &&
                (this.mVersion == null ? dictionaryResult.mVersion == null : this.mVersion.equals(dictionaryResult.mVersion)) &&
                (this.mNickname == null ? dictionaryResult.mNickname == null : this.mNickname.equals(dictionaryResult.mNickname)) &&
                (this.mIconId == null ? dictionaryResult.mIconId == null : this.mIconId.equals(dictionaryResult.mIconId)) &&
                (this.mIconPath == null ? dictionaryResult.mIconPath == null : this.mIconPath.equals(dictionaryResult.mIconPath)) &&
                (this.mCreatedAt == null ? dictionaryResult.mCreatedAt == null : this.mCreatedAt.equals(dictionaryResult.mCreatedAt)) &&
                (this.mUpdatedAt == null ? dictionaryResult.mUpdatedAt == null : this.mUpdatedAt.equals(dictionaryResult.mUpdatedAt)) &&
                (this.mCreatedBy == null ? dictionaryResult.mCreatedBy == null : this.mCreatedBy.equals(dictionaryResult.mCreatedBy)) &&
                (this.mUpdatedBy == null ? dictionaryResult.mUpdatedBy == null : this.mUpdatedBy.equals(dictionaryResult.mUpdatedBy)) &&
                (this.mIsDeleted == null ? dictionaryResult.mIsDeleted == null : this.mIsDeleted.equals(dictionaryResult.mIsDeleted));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mId == null ? 0: this.mId.hashCode());
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mCategoryId == null ? 0: this.mCategoryId.hashCode());
        result = 31 * result + (this.mDictionaryType == null ? 0: this.mDictionaryType.hashCode());
        result = 31 * result + (this.mName == null ? 0: this.mName.hashCode());
        result = 31 * result + (this.mImagePath == null ? 0: this.mImagePath.hashCode());
        result = 31 * result + (this.mIsMemorize == null ? 0: this.mIsMemorize.hashCode());
        result = 31 * result + (this.mVersion == null ? 0: this.mVersion.hashCode());
        result = 31 * result + (this.mNickname == null ? 0: this.mNickname.hashCode());
        result = 31 * result + (this.mIconId == null ? 0: this.mIconId.hashCode());
        result = 31 * result + (this.mIconPath == null ? 0: this.mIconPath.hashCode());
        result = 31 * result + (this.mCreatedAt == null ? 0: this.mCreatedAt.hashCode());
        result = 31 * result + (this.mUpdatedAt == null ? 0: this.mUpdatedAt.hashCode());
        result = 31 * result + (this.mCreatedBy == null ? 0: this.mCreatedBy.hashCode());
        result = 31 * result + (this.mUpdatedBy == null ? 0: this.mUpdatedBy.hashCode());
        result = 31 * result + (this.mIsDeleted == null ? 0: this.mIsDeleted.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class SynchronizeDictionaryResultDictionary {\n");

        sb.append("  mId: ").append(mId).append("\n");
        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mCategoryId: ").append(mCategoryId).append("\n");
        sb.append("  mDictionaryType: ").append(mDictionaryType).append("\n");
        sb.append("  mName: ").append(mName).append("\n");
        sb.append("  mImagePath: ").append(mImagePath).append("\n");
        sb.append("  mIsMemorize: ").append(mIsMemorize).append("\n");
        sb.append("  mVersion: ").append(mVersion).append("\n");
        sb.append("  mNickname: ").append(mNickname).append("\n");
        sb.append("  mIconId: ").append(mIconId).append("\n");
        sb.append("  mIconPath: ").append(mIconPath).append("\n");
        sb.append("  mCreatedAt: ").append(mCreatedAt).append("\n");
        sb.append("  mUpdatedAt: ").append(mUpdatedAt).append("\n");
        sb.append("  mCreatedBy: ").append(mCreatedBy).append("\n");
        sb.append("  mUpdatedBy: ").append(mUpdatedBy).append("\n");
        sb.append("  mIsDeleted: ").append(mIsDeleted).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
