/*
 * ファイル：ApiGetSyncDictionaryList.java
 * 概要：リクエスト用オブジェクト
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.api;

import android.os.Handler;

import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.json.dictionary.GetCategoriesResultList;
import jp.softbank.assist.network.json.dictionary.SynchronizeDictionaryParam;
import jp.softbank.assist.network.listener.BaseResultListener;
import jp.softbank.assist.network.listener.GetDictionaryListResultListener;
import jp.softbank.assist.util.AssistLog;

import java.util.Iterator;
import java.util.List;

/**
 * 辞書差分取得リクエスト.
 */
public class ApiGetSyncDictionaryList extends ApiBaseObject {

    private SynchronizeDictionaryParam mParam; // リクエストパラメータ

    private static List<DictionaryInfo> sDictionaryList; // TODO:Instead of DB


    private ApiGetSyncDictionaryList() {
        super();
    }

    public static ApiGetSyncDictionaryList newInstance(Handler handler,
                                                       String token,
                                                       long userId,
                                                       long dictionaryVersion,
                                                       long cardVersion,
                                                       GetDictionaryListResultListener callback) {
        ApiGetSyncDictionaryList data = new ApiGetSyncDictionaryList();

        data.mSeqNo = nextSeqNo();
        data.mHandler = handler;
        data.mAccessToken = token;
        data.mParam = new SynchronizeDictionaryParam(userId, dictionaryVersion, cardVersion);
        data.addCallback(callback);

        return data;
    }

    @Override
    public WebApiInterface.Api getApi() {
        return WebApiInterface.Api.GET_SYNC_DICTIONARY_LIST;
    }

    @Override
    public void asyncProcess(WebApiInterface webApiIf) {
        AssistLog.d("[ASI_DBG] asyncProcess start");

        // TODO:DBチェック
        if (sDictionaryList != null) {
            registPostProcess();
            AssistLog.d("[ASI_DBG] asyncProcess in DB");
            return;
        }

        // 接続開始前通知
        notifyStartConnection();
        // サーバーへ問い合わせ
        webApiIf.getSyncDictionaryList(mAccessToken, mParam, this);

        AssistLog.d("[ASI_DBG] asyncProcess end");
    }

    @Override
    public void resultSuccess(String response) {
        AssistLog.d("[ASI_DBG] resultSuccess start");

        GetCategoriesResultList temp = WebApiUtil.deserializeToObject(response, GetCategoriesResultList.class);

        // TODO:DBへ保存
//        sDictionaryList = WebApiUtil.convertToUiData(temp);

        AssistLog.d("[ASI_DBG] resultSuccess end");
    }

    @Override
    public void resultError(int status, byte[] response) {
        AssistLog.d("[ASI_DBG] resultError start");

        mStatusCode = status;
        mError = WebApiUtil.convertToError(response);

        AssistLog.d("[ASI_DBG] resultError end");
    }

    @Override
    public void postProcess() {
        AssistLog.d("[ASI_DBG] postProcess start");

        // TODO:DBから取得
        List<DictionaryInfo> list = sDictionaryList;

        if (mError != null) {
            // エラーあり
            AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
                    mError.getCode(), mError.getMessage(), mError.getItem());
            Iterator<BaseResultListener> ite = mCallbacks.iterator();
            while (ite.hasNext()) {
                BaseResultListener temp = ite.next();
                if (temp instanceof GetDictionaryListResultListener) {
                    GetDictionaryListResultListener listener = (GetDictionaryListResultListener)temp;
                    listener.onResult(result, list);
                }
            }
        } else {
            // 正常
            AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
            Iterator<BaseResultListener> ite = mCallbacks.iterator();
            while (ite.hasNext()) {
                BaseResultListener temp = ite.next();
                if (temp instanceof GetDictionaryListResultListener) {
                    GetDictionaryListResultListener listener = (GetDictionaryListResultListener)temp;
                    listener.onResult(result, list);
                }
            }
        }

        AssistLog.d("[ASI_DBG] postProcess end");
    }
}
