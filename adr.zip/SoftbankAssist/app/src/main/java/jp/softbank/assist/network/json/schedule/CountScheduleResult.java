/*
 * ファイル：CountScheduleResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.schedule;

import com.google.gson.annotations.SerializedName;

/**
 * スケジュール件数取得結果.
 */
public class CountScheduleResult {

    @SerializedName("mDate")
    private String mDate = null;
    @SerializedName("mCount")
    private Long mCount = null;


    /**
     * 日付（YYYYMMDD）.
     */
    public String getDate() {
        return mDate;
    }
    public void setDate(String date) {
        this.mDate = date;
    }

    /**
     * 件数.
     */
    public Long getCount() {
        return mCount;
    }
    public void setCount(Long count) {
        this.mCount = count;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CountScheduleResult scheduleResult = (CountScheduleResult) o;
        return (this.mDate == null ? scheduleResult.mDate == null : this.mDate.equals(scheduleResult.mDate)) &&
                (this.mCount == null ? scheduleResult.mCount == null : this.mCount.equals(scheduleResult.mCount));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mDate == null ? 0: this.mDate.hashCode());
        result = 31 * result + (this.mCount == null ? 0: this.mCount.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class CountScheduleResult {\n");

        sb.append("  mDate: ").append(mDate).append("\n");
        sb.append("  mCount: ").append(mCount).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
