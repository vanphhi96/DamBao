/*
 * ファイル：BaseWebActivity.java
 * 概要：WebView画面のベースクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;

/**
 * WebView画面のベースクラス
 *
 * @author Systena
 * @version 1.0
 */
public abstract class BaseWebActivity extends BaseActivity implements View.OnClickListener {
    protected String mTitleWeb;
    protected String mTextBack;
    protected String mUrlWebView;
    private WebView mWebView;
    private LinearLayout mLayoutBack;
    private TextView mTvTitleWeb;
    private TextView mTvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_web);
        getDataIntent();
        mLayoutBack = findViewById(R.id.ln_back);
        mTvTitleWeb = findViewById(R.id.tv_title_web);
        mTvBack = findViewById(R.id.tv_back);
        mWebView = findViewById(R.id.web_view);
        mLayoutBack.setOnClickListener(this);
        mTvTitleWeb.setText(mTitleWeb);
        mTvBack.setText(mTextBack);
        initWebView();
    }

    /**
     * init web.
     */
    private void initWebView() {
        if (mUrlWebView != null) {
            WebSettings webSettings = mWebView.getSettings();
            webSettings.setJavaScriptEnabled(true);
            webSettings.setSupportZoom(false);
            mWebView.setWebViewClient(new WebViewClient());
            mWebView.loadUrl(mUrlWebView);
        }
    }

    /**
     * get data from intent
     */
    protected void getDataIntent() {
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ln_back:
                onBackPressed();
                break;
            default:
                break;
        }
    }
}
