/*
 * ファイル：SchCreateUiActivity.java
 * 概要：予定作成画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.schedule;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.adapter.AdapterPagerSelectIcon;
import jp.softbank.assist.view.customview.EditTextLinesLimiter;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;
import jp.softbank.assist.view.dialog.factories.customfactories.DateTimePickerDialogFactory;
import jp.softbank.assist.view.dialog.factories.customfactories.IDateTimePicker;
import jp.softbank.assist.view.dialog.factories.customfactories.ISchSaveDialog;
import jp.softbank.assist.view.dialog.factories.customfactories.SchSaveDialogFactory;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * sch-cr-01
 *
 * @author Systena
 * @version 1.0
 */
public class SchCreateUiActivity extends BaseUiActivity implements View.OnClickListener,
        ISchSaveDialog, IScheduleSelectIcon, IDateTimePicker, NotifyOnlyResultListener {
    private ViewPager mViewPager;
    private TextView mTvStartDate;
    private TextView mTvStartTime;
    private TextView mTvEndDate;
    private TextView mTvEndTime;
    private TextView mTvTypeRepeat;
    private LinearLayout mLayoutKeyBoard;
    private EditText mEdtScheduleTitle;
    private EditText mEdtScheduleNote;
    private EditText mEdtScheduleLocation;
    private DialogFragment mDialogSchSave;
    private ImageView mImgSchedule;
    private View mViewSpaceIcon;
    private RelativeLayout mRlStartDateTime;
    private RelativeLayout mRlEndDateTime;
    private DialogFragment mDialogDateTime;
    private boolean mIsStartDateTime;
    private Switch mSwitchRepeat;
    private DictionaryInfo mDictionaryInfoOne;
    private DictionaryInfo mDictionaryInfoTwo;
    private DictionaryInfo mDictionaryInfoThree;
    private AssistAlertDialogFactory mDialogFactory;
    private String mDialogTag;
    private Date mStartDate;
    private Date mEndDate;
    private Calendar mCalendar = Calendar.getInstance();
    private ScheduleInfo.IntervalType mIntervalType = ScheduleInfo.IntervalType.None;
    private AdapterPagerSelectIcon mAdapterPagerSelectIcon;
    private ScheduleInfo mScheduleInfo;
    private int mSelectDictionary;
    private final int mSelectDictionaryInfoOne = 1;
    private final int mSelectDictionaryInfoTwo = 2;
    private final int mSelectDictionaryInfoThree = 3;
    private TextView mTvDictionaryOne;
    private TextView mTvDictionaryTwo;
    private TextView mTvDictionaryThree;
    private LinearLayout mLnParent;
    private ScrollView mScrollView;
    private String mIconName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_schedule);
        mLnParent = findViewById(R.id.ln_schedule_create);
        mImgSchedule = findViewById(R.id.img_schedule);
        RelativeLayout mRelativeRepeat = findViewById(R.id.rlt_sch_cr_repeat);
        ImageView mImvEditIcon = findViewById(R.id.imv_sch_cr_ic_edit);
        mLayoutKeyBoard = findViewById(R.id.ln_sch_cr_keyboard);
        mViewPager = findViewById(R.id.view_pager_keyboard_select_icon);
        TabLayout tabLayout = findViewById(R.id.tab_dots);
        tabLayout.setupWithViewPager(mViewPager, true);
        TextView mTvSave = findViewById(R.id.tv_sch_cr_save);
        LinearLayout mLnBack = findViewById(R.id.ln_back);
        mTvStartDate = findViewById(R.id.tv_sch_cr_start_date);
        mTvStartTime = findViewById(R.id.tv_sch_cr_start_time);
        mTvEndDate = findViewById(R.id.tv_sch_cr_end_date);
        mTvEndTime = findViewById(R.id.tv_sch_cr_end_time);
        mTvTypeRepeat = findViewById(R.id.tv_sch_cr_type_repeat);
        mEdtScheduleTitle = findViewById(R.id.edt_sch_cr_title);
        mEdtScheduleNote = findViewById(R.id.edt_sch_cr_comment);
        mEdtScheduleLocation = findViewById(R.id.edt_sch_cr_place);
        mViewSpaceIcon = findViewById(R.id.view_space_icon);
        mRlStartDateTime = findViewById(R.id.rlt_sch_cr_date_time_start);
        mRlEndDateTime = findViewById(R.id.rlt_sch_cr_date_time_end);
        mViewSpaceIcon = findViewById(R.id.view_space_icon);
        mSwitchRepeat = findViewById(R.id.switch_repeat);
        mTvDictionaryOne = findViewById(R.id.tv_dictionary_one);
        mTvDictionaryTwo = findViewById(R.id.tv_dictionary_two);
        mTvDictionaryThree = findViewById(R.id.tv_dictionary_three);
        mScrollView = findViewById(R.id.scroll_view_schedule_create);
        RelativeLayout mRlSelectDictionaryOne = findViewById(R.id.rl_select_dictionary_one);
        RelativeLayout mRlSelectDictionaryTwo = findViewById(R.id.rl_select_dictionary_two);
        RelativeLayout mRlSelectDictionaryThree = findViewById(R.id.rl_select_dictionary_three);
        mRlSelectDictionaryOne.setOnClickListener(this);
        mRlSelectDictionaryTwo.setOnClickListener(this);
        mRlSelectDictionaryThree.setOnClickListener(this);
        mLnParent.setOnClickListener(this);
        mLnBack.setOnClickListener(this);
        mTvSave.setOnClickListener(this);
        mImvEditIcon.setOnClickListener(this);
        mRelativeRepeat.setOnClickListener(this);
        mRlStartDateTime.setOnClickListener(this);
        mRlEndDateTime.setOnClickListener(this);
        mViewSpaceIcon.setOnClickListener(this);
        mImgSchedule.setOnClickListener(this);
        //hide keyboard when click out view
        mScrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                clearFocus();
                mLayoutKeyBoard.setVisibility(View.GONE);
                return false;
            }
        });
        mEdtScheduleTitle.addTextChangedListener(new EditTextLinesLimiter(mEdtScheduleTitle, 3));
        mEdtScheduleNote.addTextChangedListener(new EditTextLinesLimiter(mEdtScheduleNote, 2));
        mEdtScheduleLocation.addTextChangedListener(new EditTextLinesLimiter(mEdtScheduleLocation, 2));


        initViewPager();
        fillDataDateTime();
    }

    /**
     * event click edit schedule
     */
    private void editIconSchedule() {
        clearFocus();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mLayoutKeyBoard.setVisibility(View.VISIBLE);
            }
        }, Constants.Schedule.TIME_DELAY_HIDE_KEY_BOARD);
    }

    /**
     * fill data to text date time
     */
    private void fillDataDateTime() {
        Date date = new Date();
        mCalendar.setTime(date);
        int hour = mCalendar.get(Calendar.HOUR_OF_DAY);
        mCalendar.set(Calendar.HOUR_OF_DAY, hour + 1);
        mCalendar.set(Calendar.MINUTE, 0);
        mStartDate = mCalendar.getTime();
        mTvStartDate.setText(DateUtils.convertDateToString(mCalendar.getTime(), DateUtils.DATE_PICKER_FORMAT));
        mTvStartTime.setText(DateUtils.convertValueOneCharacter(mCalendar.get(Calendar.HOUR_OF_DAY)) +
                ":" + DateUtils.convertValueOneCharacter(mCalendar.get(Calendar.MINUTE)));
        mCalendar.set(Calendar.HOUR_OF_DAY, mCalendar.get(Calendar.HOUR_OF_DAY) + 1);
        mEndDate = mCalendar.getTime();
        mTvEndDate.setText(DateUtils.convertDateToString(mCalendar.getTime(), DateUtils.DATE_PICKER_FORMAT));
        mTvEndTime.setText(DateUtils.convertValueOneCharacter(mCalendar.get(Calendar.HOUR_OF_DAY)) +
                ":" + DateUtils.convertValueOneCharacter(mCalendar.get(Calendar.MINUTE)));
    }

    /**
     * hide keyboard
     *
     * @param view view focus
     */
    private void hideKeyboard(View view) {
        InputMethodManager in = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (view == null) {
            view = new View(SchCreateUiActivity.this);
        }
        in.hideSoftInputFromWindow(view.getWindowToken(), Constants.Schedule.FLAG_HIDE_INPUT_FORM);
    }

    /**
     * init viewpager select icon schedule
     */
    private void initViewPager() {
        mAdapterPagerSelectIcon = new AdapterPagerSelectIcon(getSupportFragmentManager(), this);
        mViewPager.setAdapter(mAdapterPagerSelectIcon);
        mViewPager.setOffscreenPageLimit(0);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ln_back:
                onBackPressed();
                break;
            case R.id.tv_sch_cr_save:
                createScheduleInfo();
                break;
            case R.id.img_schedule:
            case R.id.imv_sch_cr_ic_edit:
                editIconSchedule();
                break;
            case R.id.rlt_sch_cr_repeat:
                goToSchRepeatActivity();
                break;
            case R.id.rl_select_dictionary_one:
                mSelectDictionary = mSelectDictionaryInfoOne;
                selectDictionary(mDictionaryInfoOne);
                break;
            case R.id.rl_select_dictionary_two:
                mSelectDictionary = mSelectDictionaryInfoTwo;
                selectDictionary(mDictionaryInfoTwo);
                break;
            case R.id.rl_select_dictionary_three:
                mSelectDictionary = mSelectDictionaryInfoThree;
                selectDictionary(mDictionaryInfoThree);
                break;
            case R.id.view_space_icon:
                mLayoutKeyBoard.setVisibility(View.GONE);
                break;
            case R.id.rlt_sch_cr_date_time_start:
                buildDialogDateTime(true);
                break;
            case R.id.rlt_sch_cr_date_time_end:
                buildDialogDateTime(false);
                break;
            case R.id.ln_schedule_create:
                clearFocus();
                break;
            default:
                break;
        }
    }

    /**
     * create schedule
     */
    private void createScheduleInfo() {
        clearFocus();
        mLayoutKeyBoard.setVisibility(View.GONE);
        String title = mEdtScheduleTitle.getText().toString();
        String note = mEdtScheduleNote.getText().toString();
        String location = mEdtScheduleLocation.getText().toString();
        String error = "";

        if (TextUtils.isEmpty(title)) {
            error = getResources().getString(R.string.sch_validate_title);
        }
        if (mIntervalType == ScheduleInfo.IntervalType.Yearly &&
                (DateUtils.checkSpecialDate(mStartDate) || DateUtils.checkSpecialDate(mEndDate))) {
            error = TextUtils.isEmpty(error) ? getResources().getString(R.string.sch_validate_leapyear)
                    : error + "\n" + getResources().getString(R.string.sch_validate_leapyear);
        }
        if (validateDate()) {
            error = TextUtils.isEmpty(error) ? getResources().getString(R.string.sch_validate_date_reverse)
                    : error + "\n" + getResources().getString(R.string.sch_validate_date_reverse);
        }
        if (!TextUtils.isEmpty(error)) {
            buildDialogError(error);
            return;
        }
        mScheduleInfo = new ScheduleInfo();
        mScheduleInfo.setTitle(title);
        mScheduleInfo.setNote(note);
        mScheduleInfo.setLocation(location);
        mScheduleInfo.setScheduleStartDate(mStartDate);
        mScheduleInfo.setScheduleEndDate(mEndDate);
        mScheduleInfo.setInterval(mIntervalType);
        List<DictionaryInfo> listDictionary = new ArrayList<>();
        if (mDictionaryInfoOne != null) {
            listDictionary.add(mDictionaryInfoOne);
        }
        if (mDictionaryInfoTwo != null) {
            listDictionary.add(mDictionaryInfoTwo);
        }
        if (mDictionaryInfoThree != null) {
            listDictionary.add(mDictionaryInfoThree);
        }
        if (listDictionary.size() > 0) {
            mScheduleInfo.setAttachedDictionaries(listDictionary);
        }
        mScheduleInfo.setIsAllDay(mSwitchRepeat.isChecked());
        if (!TextUtils.isEmpty(mIconName)) {
            mScheduleInfo.setIconName(mIconName);
        }
        AppController.getInstance().getAssistServerInterface().addSchedule(mScheduleInfo, this);
    }

    /**
     * validate date start and end when schedule is all day or not
     *
     * @return true: startDate,endDate < current time or endDate<startDate
     */
    private boolean validateDate() {
        Date startDate = mStartDate;
        Date endDate = mEndDate;
        // if schedule is all day compare time with format yyyy/MM/dd
        if (mSwitchRepeat.isChecked()) {
            mCalendar.setTime(startDate);
            mCalendar.set(Calendar.HOUR_OF_DAY, 0);
            mCalendar.set(Calendar.MINUTE, 0);
            startDate = mCalendar.getTime();
            mCalendar.setTime(endDate);
            mCalendar.set(Calendar.HOUR_OF_DAY, 0);
            mCalendar.set(Calendar.MINUTE, 0);
            endDate = mCalendar.getTime();
        }
        if (DateUtils.compareTo(endDate, startDate) < 0) {
            return true;
        }
        return false;
    }

    /**
     * build dialog confirm
     *
     * @param type type of dialog
     */
    private void buildDialogConfirm(DialogTypeControl.DialogType type) {
        mDialogFactory = new AssistAlertDialogFactory(type);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * dialog create error
     *
     * @return boolean
     */
    private void buildDialogError(String errorMessage) {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIALOG_MESSAGE, errorMessage);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * select dictionary
     *
     * @param dictionaryInfo
     */
    private void selectDictionary(DictionaryInfo dictionaryInfo) {
        clearFocus();
        Bundle bundle = new Bundle();
        bundle.putString(Constants.Schedule.KEY_GO_TO_FROM, getString(R.string.sch_cr));
        if (dictionaryInfo == null) {
            changeScreenResult(ScreenId.START_SCH_DICTIONARY_SELECT, Constants.Schedule.REQUEST_CODE_DICTIONARY, bundle);
        } else {
            bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, dictionaryInfo);
            changeScreenResult(ScreenId.START_SCH_DICTIONARY_EDIT, Constants.Schedule.REQUEST_CODE_DICTIONARY, bundle);
        }
    }

    /**
     * build dialog date time picker
     *
     * @param isStartDateTime true: dialog for start time, false: dialog for end time
     */
    private void buildDialogDateTime(boolean isStartDateTime) {
        mIsStartDateTime = isStartDateTime;
        DateTimePickerDialogFactory dialogFactory = new DateTimePickerDialogFactory(DialogTypeControl.DialogType.SCH_DETAIL_DIALOG, this);
        dialogFactory.isCreateNew(true);
        dialogFactory.isScheduleAllDay(mSwitchRepeat.isChecked());
        if (isStartDateTime) {
            dialogFactory.setDate(mStartDate);

        } else {
            dialogFactory.setDate(mEndDate);
        }
        mDialogDateTime = new DialogGenerator(this, dialogFactory).show();
    }

    /**
     * go to screen select type repeat
     */
    private void goToSchRepeatActivity() {
        clearFocus();
        Bundle mBundle = new Bundle();
        mBundle.putSerializable(Constants.Schedule.KEY_INTERVAL_TYPE, mIntervalType);
        mBundle.putString(Constants.Schedule.KEY_BACK_REPEAT_TITLE, getString(R.string.sch_cr));
        changeScreenResult(ScreenId.START_SCH_REPEAT, Constants.Schedule.REQUEST_CODE_REPEAT, mBundle);
    }

    /**
     * set text type repeat schedule
     *
     * @param intervalType is value of type in ScheduleInfo.IntervalType
     */
    private void setTypeRepeat(ScheduleInfo.IntervalType intervalType) {
        switch (intervalType) {
            case None:
                mTvTypeRepeat.setText(getString(R.string.sch_no));
                break;
            case Daily:
                mTvTypeRepeat.setText(R.string.sch_every_day);
                break;
            case Weekly:
                mTvTypeRepeat.setText(getString(R.string.sch_every_week));
                break;
            case Monthly:
                mTvTypeRepeat.setText(getString(R.string.sch_every_month));
                break;
            case Yearly:
                mTvTypeRepeat.setText(getString(R.string.sch_every_year));
                break;
            default:
                break;
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.Schedule.REQUEST_CODE_REPEAT && resultCode == Constants.Schedule.REQUEST_CODE_REPEAT) {
            ScheduleInfo.IntervalType intervalType = (ScheduleInfo.IntervalType) data.getSerializableExtra(Constants.Schedule.KEY_GO_BACK_REPEAT);
            mIntervalType = intervalType;
            setTypeRepeat(mIntervalType);
        } else if (requestCode == Constants.Schedule.REQUEST_CODE_DICTIONARY && resultCode == Constants.Schedule.REQUEST_CODE_DICTIONARY) {
            DictionaryInfo dictionaryInfo = (DictionaryInfo) data.getSerializableExtra(Constants.Schedule.KEY_DICTIONARY_INFO);
            setDictionary(dictionaryInfo);
        }
    }

    /**
     * show dialog confirm save
     *
     * @param scheduleInfo schedule create
     */
    private void buildSchSaveDialog(ScheduleInfo scheduleInfo) {
        if (scheduleInfo != null) {
            SchSaveDialogFactory dialogFactory = new SchSaveDialogFactory(scheduleInfo, DialogTypeControl.DialogType.SCH_SAVE_DIALOG, this);
            dialogFactory.setTitleDialog(getString(R.string.sch_cr_end));
            mDialogSchSave = new DialogGenerator(this, dialogFactory).show();
        }

    }

    @Override
    public void onClickOkSchSave() {
        if (mDialogSchSave != null) {
            mDialogSchSave.dismiss();
            backScreenResult(this, new Bundle(), Constants.Schedule.REQUEST_CODE_SCHEDULE_CREATE);
        }
    }

    @Override
    public void selectIcon(String iconName) {
        if (TextUtils.isEmpty(mIconName)) {
            mImgSchedule.setBackgroundColor(getColor(R.color.sch_cr_bgr));
            mImgSchedule.setPadding(0, 0, 0, 0);
        }
        mImgSchedule.setImageResource(ResourcesUtils.getScheduleIconResourceFromId(iconName));
        mLayoutKeyBoard.setVisibility(View.GONE);
        mIconName = iconName;
        int currentPosition = mViewPager.getCurrentItem();
        mAdapterPagerSelectIcon.setIconSelected(iconName);
        mViewPager.setAdapter(null);
        mViewPager.setAdapter(mAdapterPagerSelectIcon);
        mViewPager.setCurrentItem(currentPosition);
    }


    @Override
    public void dismissDialogDateTime() {
        mDialogDateTime.dismiss();
    }

    @Override
    public void saveDateTime(Date date) {
        mDialogDateTime.dismiss();
        if (mIsStartDateTime) {
            mStartDate = date;
            mTvStartDate.setText(DateUtils.convertDateToString(date, DateUtils.DATE_PICKER_FORMAT));
            mTvStartTime.setText(DateUtils.convertDateToString(date, DateUtils.TIME_PICKER_FORMAT));
        } else {
            mEndDate = date;
            mTvEndDate.setText(DateUtils.convertDateToString(date, DateUtils.DATE_PICKER_FORMAT));
            mTvEndTime.setText(DateUtils.convertDateToString(date, DateUtils.TIME_PICKER_FORMAT));
        }
    }

    @Override
    public void onBackPressed() {
        clearFocus();
        buildDialogConfirm(DialogTypeControl.DialogType.SCH_CR_QUIT);
    }

    /**
     * event click button positive or negative in dialog
     *
     * @param dialog dialog interface
     * @param which  position button click
     */
    @Override
    public void onClick(DialogInterface dialog, int which) {
        if (which == DialogInterface.BUTTON_POSITIVE && mDialogTag.equals(DialogTypeControl.DialogType.SCH_CR_QUIT.name())) {
            Bundle bundle = new Bundle();
            backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_DICTIONARY);
        } else {
            return;
        }
    }

    @Override
    public void onResult(AssistServerResult result) {
        if (result.mResult == AssistServerResult.Result.Success) {
            buildSchSaveDialog(mScheduleInfo);
        } else {

        }
    }

    @Override
    public void onStartConnection() {
        displayIndicator();
    }

    /**
     * set dictionary info
     *
     * @param dictionaryInfo
     */
    private void setDictionary(DictionaryInfo dictionaryInfo) {
        switch (mSelectDictionary) {
            case mSelectDictionaryInfoOne:
                mDictionaryInfoOne = dictionaryInfo;
                mTvDictionaryOne.setText(dictionaryInfo == null ? getString(R.string.nothing) :
                        dictionaryInfo.getName().length() <= 12 ? dictionaryInfo.getName() : dictionaryInfo.getName().substring(0, 11) + "...");
                break;
            case mSelectDictionaryInfoTwo:
                mDictionaryInfoTwo = dictionaryInfo;
                mTvDictionaryTwo.setText(dictionaryInfo == null ? getString(R.string.nothing) :
                        dictionaryInfo.getName().length() <= 12 ? dictionaryInfo.getName() : dictionaryInfo.getName().substring(0, 11) + "...");
                break;
            case mSelectDictionaryInfoThree:
                mDictionaryInfoThree = dictionaryInfo;
                mTvDictionaryThree.setText(dictionaryInfo == null ? getString(R.string.nothing) :
                        dictionaryInfo.getName().length() <= 12 ? dictionaryInfo.getName() : dictionaryInfo.getName().substring(0, 11) + "...");
                break;
            default:
                break;
        }
    }

    /**
     * clear focus in EditText
     */
    private void clearFocus() {
        if (mEdtScheduleTitle.isFocusable()) {
            mEdtScheduleTitle.clearFocus();
            hideKeyboard(mEdtScheduleTitle);
        } else if (mEdtScheduleLocation.isFocusable()) {
            mEdtScheduleLocation.clearFocus();
            hideKeyboard(mEdtScheduleLocation);
        } else if (mEdtScheduleNote.isFocusable()) {
            mEdtScheduleNote.clearFocus();
            hideKeyboard(mEdtScheduleNote);
        }
    }
}
