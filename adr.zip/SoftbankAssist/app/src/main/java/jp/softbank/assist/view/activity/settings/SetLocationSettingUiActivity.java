/*
 * ファイル：SetLocationSettingUiActivity.java
 * 概要：位置情報取得画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.settings;

import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.LocationSettings;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;

/**
 * set-pos-01
 *
 * @author Systena
 * @version 1.0
 */
public class SetLocationSettingUiActivity extends BaseUiActivity implements
        View.OnClickListener,
        NotifyOnlyResultListener,
        CompoundButton.OnCheckedChangeListener {

    public static final String LOCATION_SETTING_KEY = "LOCATION SETTING KEY";
    private Switch mSwEnableGps;
    private Switch mSwRequest;
    private Switch mSwRegular;
    private Switch mSwFence;
    private TextView mTvTrackTime;
    private LinearLayout mLnBack;
    private LinearLayout mLnBigContainer;
    private FrameLayout mFrTrackTime;
    private LocationSettings mLocationSettings;
    private boolean mIsFirstCreated = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_location);
        mLocationSettings = AppController.getInstance().getAssistServerInterface().getLocationSettings();
        initView();
    }

    private void initView() {
        mSwEnableGps = findViewById(R.id.sw_set_enable_gps);
        mSwRequest = findViewById(R.id.sw_set_request);
        mSwRegular = findViewById(R.id.sw_set_regular);
        mTvTrackTime = findViewById(R.id.tv_set_track_time);
        mSwFence = findViewById(R.id.sw_set_fence);
        mLnBack = findViewById(R.id.ln_back);
        mLnBigContainer = findViewById(R.id.ln_set_big_container);
        mFrTrackTime = findViewById(R.id.fr_set_location_track_time);

        if (!isAllDay()) {
            // Set text for time to display. For example "06:00 ~ 10:00"
            mTvTrackTime.setText(DateUtils.convertToHourDisplaySetting
                    (mLocationSettings.getRegularLocationStartTime()
                            , mLocationSettings.getRegularLocationEndTime()));
        }

        // Check switch
        mSwEnableGps.setChecked(true);
        mSwRequest.setChecked(mLocationSettings.isRequestedLocation());
        mSwRegular.setChecked(mLocationSettings.isRegularLocation());
        mSwFence.setChecked(mLocationSettings.isFence());
        if (mSwRegular.isChecked()) {
            mFrTrackTime.setVisibility(View.VISIBLE);
        } else {
            mFrTrackTime.setVisibility(View.GONE);
        }

        mSwEnableGps.setOnCheckedChangeListener(this);
        mSwRequest.setOnCheckedChangeListener(this);
        mSwRegular.setOnCheckedChangeListener(this);
        mSwFence.setOnCheckedChangeListener(this);
        mLnBack.setOnClickListener(this);
        mFrTrackTime.setOnClickListener(this);
        onCheckedChanged(mSwEnableGps, mSwEnableGps.isChecked());
    }

    /**
     * If 24h is chosen in LocationSettings.
     *
     * @return
     */
    private boolean isAllDay() {
        return (mLocationSettings.getRegularLocationTermKind() == LocationSettings.TermType.AllDay);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ln_back:
                onBackPressed();
                break;
            case R.id.fr_set_location_track_time:
                Bundle bundle = new Bundle();
                bundle.putSerializable(LOCATION_SETTING_KEY, mLocationSettings);
                changeScreen(ScreenId.START_SET_LOCATION_TIME_RECORD, bundle);
                break;
            default:
                break;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        // Prevent onCheckedChanged trigger from the first time activity created.
        if (mIsFirstCreated) {
            mIsFirstCreated = false;
            return;
        }

        switch (buttonView.getId()) {
            case R.id.sw_set_enable_gps:
                if (isChecked) {
                    AppController.getInstance().getLocationRecordingManager().startGetGpsRequest(getApplicationContext());
                    showViewWithAnim(mLnBigContainer);
                } else {
                    AppController.getInstance().getLocationRecordingManager().stopGetGpsRequest(getApplicationContext());
                    AppController.getInstance().getLocationRecordingManager().checkGpsAvailable(true);
                    hideViewWithAnim(mLnBigContainer);
                }
                break;
            case R.id.sw_set_request:
                mLocationSettings.setRequestedLocation(isChecked);
                break;
            case R.id.sw_set_regular:
                if (isChecked) {
                    showViewWithAnim(mFrTrackTime);
                } else {
                    hideViewWithAnim(mFrTrackTime);
                }
                mLocationSettings.setRegularLocation(isChecked);
                break;
            case R.id.sw_set_fence:
                mLocationSettings.setIsFence(isChecked);
                break;
            default:
                break;
        }
        displayIndicator();
        AppController.getInstance().getAssistServerInterface().sendLocationSettings(mLocationSettings, this);

    }

    @Override
    public void onResult(AssistServerResult result) {
        closeIndicator();
        if (result.mResult != AssistServerResult.Result.Success){
            // TODO: 2019/04/19 T.B.D
            return;
        }

    }

    @Override
    public void onStartConnection() {
    }
}
