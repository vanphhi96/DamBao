/*
 * ファイル：DialogTypeControl.java
 * 概要：ダイアログ生成関連定義ファイル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories;

/**
 * カスタムダイアログサンプル
 *
 * @author Systena
 * @version 1.0
 */
public class DialogTypeControl {

    // -------------------------------------------------------------------------------------
    // FactoryのBandleに値を追加する際のKEYをここで定義する
    // -------------------------------------------------------------------------------------
    /**
     * Factory Bundle Key
     */
    public final String BUNDLE_KEY_SELECT_SAMPLE = "BUNDLE_KEY_SELECT_SAMPLE";

    /* -------------------------------------------------------------------------------------
     * ダイアログを追加する際はここにタグを追加する。
     * [簡易命名規約]
     * AssistAlertDialogFactoryを使用する場合  :ALERT_(機能名)_(簡単なダイアログ内容)_XXX
     * SingleChoiceDialogFactoryを使用する場合 :SINGLE_CHOICE__(簡単なダイアログ内容)_XXX
     * CustomFactoryを作成する場合             : CUSTOM_(機能名)_(簡単なダイアログ内容)_XXX
      -------------------------------------------------------------------------------------*/

    /**
     * Dialog Type
     */
    public enum DialogType {
        // AlertDialog
// TODO: 2019/01/30 [ALERT_TEST_DIALOG1]この定義はテストのため、後で消す/ This item is just for test, delete later.
        ALERT_TEST_DIALOG1,

        // SingleChoiceDialog
// TODO: 2019/01/30 [SINGLE_CHOICE_TEST_XXX]この定義はテストのため、後で消す/ This item is just for test, delete later.
        SINGLE_CHOICE_TEST_DIALOG1,
        SINGLE_CHOICE_TEST_DIALOG2,
        SINGLE_CHOICE_TEST_DIALOG3,

        // CustomDialog
// TODO: 2019/01/30 [CUSTOM_IMAGE_CHANGE_TEST_DIALOG1]この定義はテストのため、後で消す/ This item is just for test, delete later.
        CUSTOM_IMAGE_CHANGE_TEST_DIALOG1,

        //Dialog of Schedule
        SCH_DETAIL_DIALOG,
        SCH_SAVE_DIALOG,
        SCH_DELETE_DIALOG,
        SCH_DELETE_END,
        SCH_EDIT_SAVE_DIALOG,
        SCH_DICTIONARY_CHECK,
        SCH_DIC_DEL,
        SCH_DIC_DELETE_END,
        SCH_DETAIL_OFFLINE,
        SCH_CR_QUIT,
        SCH_ED_QUIT,
        SCH_SELECTED_DIC,

        //Dialog of Dictionary
        DIC_CHOOSE_PHOTO,
        DIC_CR_END,
        DIC_DELETE_DIALOG,
        DIC_EDIT_END,
        DIC_DEL_END,
        DIC_EDIT_DEL_ITEM,
        DIC_EDIT_DEL_ITEM_END,
        SCH_DEL_DIC_CONFIRM,
        SCH_DEL_DIC_END,
        DIC_CAN_NOT_SORT,
        DIC_LIST_MAX,
        DIC_CARD_MAX,
        DIC_NO_CARD,
        DIC_VALIDATE_NO_TITLE,
        DIC_VALIDATE_EMPTY_CARD,
        DIC_VALIDATE_NO_TITLE_EMPTY_CARD,

        //Dialog of Setting
        SET_SAVE_DIALOG,
        SET_TIME_PICKER_DIALOG,

        //Dialog of dialog picture
        DETAIL_PICTURE_DIALOG,

        //Dialog indicator loading
        INDICATOR_LOADING_DIALOG,

        //dialog message
        DIALOG_MESSAGE,;
    }

}
