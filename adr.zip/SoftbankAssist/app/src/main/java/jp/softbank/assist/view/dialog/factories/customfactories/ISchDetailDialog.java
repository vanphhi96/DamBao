/*
 * ファイル：ISchDetailDialog.java
 * 概要：Interface Schedule Detail Dialog
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.dialog.factories.customfactories;

import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.model.database.ScheduleInfo;

/**
 * interface for sch-02
 *
 * @author Systena
 * @version 1.0
 */
public interface ISchDetailDialog {
    /**
     * show dictionary detail
     *
     * @param dictionaryInfo DictionaryInfo
     */
    void showDetailDictionary(DictionaryInfo dictionaryInfo);

    /**
     * Dismiss Dialog Schedule Detail Dialog
     */
    void dismissScheduleDetail();

    /**
     * edit schedule
     *
     * @param scheduleInfo
     */
    void editSchedule(ScheduleInfo scheduleInfo);

    /**
     * completed schedule
     *
     * @param mScheduleInfo
     */
    void completedSchedule(ScheduleInfo mScheduleInfo);
}
