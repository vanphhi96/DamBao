/*
 * ファイル：SchDicEditUiActivity.java
 * 概要：dictionary edit.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.activity.schedule;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.adapter.SchDicEditAdapter;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;
import jp.softbank.assist.view.dialog.factories.customfactories.DetailPictureDialogFactory;
import jp.softbank.assist.view.dialog.factories.customfactories.IDetailPicture;

/**
 * sch-ed-dic-01.
 *
 * @author Systena
 * @version 1.0
 */
public class SchDicEditUiActivity extends BaseUiActivity implements ISchDictionaryDetail,
        ISchDictionaryDelete, View.OnClickListener, DialogInterface.OnClickListener, IDetailPicture {
    private RecyclerView mRecycleView;
    private SchDicEditAdapter mAdapter;
    private RelativeLayout mBtnBack;
    private String mDialogTag;
    private TextView mTvSelectDic;
    private DialogFragment mDialogDetailPicture;
    private DictionaryInfo mDictionaryInfo;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sch_dic_edit);
        mDictionaryInfo = getIntentDicInfo();
        mRecycleView = findViewById(R.id.recycle_sch_dic_detail);
        mBtnBack = findViewById(R.id.rlt_sch_dic_detail_back);
        mTvSelectDic = findViewById(R.id.tv_select_sch_dic);
        mBtnBack.setOnClickListener(this);
        mTvSelectDic.setOnClickListener(this);
        if (mDictionaryInfo != null) {
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            linearLayoutManager.setOrientation(LinearLayout.VERTICAL);
            mRecycleView.setLayoutManager(linearLayoutManager);
            initListCard();
        }
    }

    /**
     * init list card
     */
    private void initListCard() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayout.VERTICAL);
        mRecycleView.setLayoutManager(linearLayoutManager);
        mAdapter = new SchDicEditAdapter();
        mAdapter.setData(mDictionaryInfo);
        mAdapter.setColorItem(ResourcesUtils.getColorBackgroundItemDictionary(mDictionaryInfo.getCategoryId()),
                ResourcesUtils.getColorFlagItemDictionary(mDictionaryInfo.getCategoryId()));
        mAdapter.setIOnClickDetailDic(this);
        mAdapter.setShowDelete(true);
        mAdapter.setActivity(this);
        mRecycleView.setAdapter(mAdapter);
    }

    /**
     * get DictionaryInfo
     *
     * @return dictionary info
     */
    private DictionaryInfo getIntentDicInfo() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_DICTIONARY_INFO)) {
            return (DictionaryInfo) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_DICTIONARY_INFO);
        } else {
            return null;
        }
    }

    /**
     * get value text back.
     *
     * @return
     */
    private String getIntentFrom() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_GO_TO_FROM)) {
            return getIntent().getExtras().getString(Constants.Schedule.KEY_GO_TO_FROM);
        } else {
            return "";
        }
    }

    @Override
    public void onClickSeeAgain() {
        mRecycleView.smoothScrollToPosition(0);
    }

    @Override
    public void deleteDictionary() {
        AssistAlertDialogFactory mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.SCH_DEL_DIC_CONFIRM);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();

    }

    @Override
    public void onClickZoomPicture(int position) {
        DetailPictureDialogFactory dialogFactory = new DetailPictureDialogFactory(DialogTypeControl.DialogType.DETAIL_PICTURE_DIALOG,
                this, mDictionaryInfo.getType());
        dialogFactory.setListCardInfo(mDictionaryInfo.getCardList());
        dialogFactory.setActivity(this);
        dialogFactory.setPositionStartPage(position);
        mDialogDetailPicture = new DialogGenerator(this, dialogFactory).show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rlt_sch_dic_detail_back:
                onBackPressed();
                break;
            case R.id.tv_select_sch_dic:
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, mDictionaryInfo);
                bundle.putString(Constants.Schedule.KEY_GO_TO_FROM, getIntentFrom());
                changeScreenResult(ScreenId.START_SCH_DICTIONARY_SELECT, Constants.Schedule.REQUEST_CODE_DICTIONARY, bundle);
                break;
            default:
                break;
        }
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        if (which == DialogInterface.BUTTON_POSITIVE) {
            if (DialogTypeControl.DialogType.SCH_DEL_DIC_CONFIRM.name().equals(mDialogTag)) {
                AssistAlertDialogFactory mDialogFactory = new AssistAlertDialogFactory(
                        DialogTypeControl.DialogType.SCH_DEL_DIC_END);
                mDialogTag = mDialogFactory.getDialogTag();
                new DialogGenerator(this, mDialogFactory).show();
            } else if (DialogTypeControl.DialogType.SCH_DEL_DIC_END.name().equals(mDialogTag)) {
                backScreenResult(this, new Bundle(), Constants.Schedule.REQUEST_CODE_DICTIONARY);
            }
        } else if (which == DialogInterface.BUTTON_NEGATIVE) {
            if (DialogTypeControl.DialogType.SCH_DEL_DIC_CONFIRM.name().equals(mDialogTag)) {

            }
        }
    }

    @Override
    public void dismissDialog() {
        mDialogDetailPicture.dismiss();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.Schedule.REQUEST_CODE_DICTIONARY && resultCode == Constants.Schedule.REQUEST_CODE_DICTIONARY) {
            DictionaryInfo dictionaryInfo = (DictionaryInfo) data.getSerializableExtra(Constants.Schedule.KEY_DICTIONARY_INFO);
            Bundle bundle = new Bundle();
            bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, dictionaryInfo);
            backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_DICTIONARY);
        }
    }

    @Override
    public void onBackPressed() {
        if (mAdapter != null && mDialogDetailPicture != null) {
            mAdapter.notifyFooterChanged();
        }
        super.onBackPressed();

    }
}
