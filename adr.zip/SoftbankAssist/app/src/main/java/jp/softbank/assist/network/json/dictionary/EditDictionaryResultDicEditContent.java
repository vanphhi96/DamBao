/*
 * ファイル：EditDictionaryResultDicEditContent.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

/**
 * 辞書内容結果.
 */
public class EditDictionaryResultDicEditContent {

    @SerializedName("dictionary_id")
    private Long mDictionaryId = null;
    @SerializedName("category_id")
    private Long mCategoryId = null;
    @SerializedName("dictionary_type")
    private Long mDictionaryType = null;
    @SerializedName("mName")
    private String mName = null;
    @SerializedName("version")
    private Long mVersion = null;
    @SerializedName("image")
    private String mImage = null;


    /**
     * 辞書ID.
     */
    public Long getDictionaryId() {
        return mDictionaryId;
    }
    public void setDictionaryId(Long dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }

    /**
     * カテゴリID.
     */
    public Long getCategoryId() {
        return mCategoryId;
    }
    public void setCategoryId(Long categoryId) {
        this.mCategoryId = categoryId;
    }

    /**
     * 辞書種別（0：ステップ形式、1：チェック形式）.
     */
    public Long getDictionaryType() {
        return mDictionaryType;
    }
    public void setDictionaryType(Long dictionaryType) {
        this.mDictionaryType = dictionaryType;
    }

    /**
     * 辞書名.
     */
    public String getName() {
        return mName;
    }
    public void setName(String name) {
        this.mName = name;
    }

    /**
     * 辞書バージョン.
     */
    public Long getVersion() {
        return mVersion;
    }
    public void setVersion(Long version) {
        this.mVersion = version;
    }

    /**
     * 画像パス.
     */
    public String getImage() {
        return mImage;
    }
    public void setImage(String image) {
        this.mImage = image;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EditDictionaryResultDicEditContent dicEditContent = (EditDictionaryResultDicEditContent) o;
        return (this.mDictionaryId == null ? dicEditContent.mDictionaryId == null : this.mDictionaryId.equals(dicEditContent.mDictionaryId)) &&
                (this.mCategoryId == null ? dicEditContent.mCategoryId == null : this.mCategoryId.equals(dicEditContent.mCategoryId)) &&
                (this.mDictionaryType == null ? dicEditContent.mDictionaryType == null : this.mDictionaryType.equals(dicEditContent.mDictionaryType)) &&
                (this.mName == null ? dicEditContent.mName == null : this.mName.equals(dicEditContent.mName)) &&
                (this.mVersion == null ? dicEditContent.mVersion == null : this.mVersion.equals(dicEditContent.mVersion)) &&
                (this.mImage == null ? dicEditContent.mImage == null : this.mImage.equals(dicEditContent.mImage));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mDictionaryId == null ? 0: this.mDictionaryId.hashCode());
        result = 31 * result + (this.mCategoryId == null ? 0: this.mCategoryId.hashCode());
        result = 31 * result + (this.mDictionaryType == null ? 0: this.mDictionaryType.hashCode());
        result = 31 * result + (this.mName == null ? 0: this.mName.hashCode());
        result = 31 * result + (this.mVersion == null ? 0: this.mVersion.hashCode());
        result = 31 * result + (this.mImage == null ? 0: this.mImage.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class EditDictionaryResultDicEditContent {\n");

        sb.append("  mDictionaryId: ").append(mDictionaryId).append("\n");
        sb.append("  mCategoryId: ").append(mCategoryId).append("\n");
        sb.append("  mDictionaryType: ").append(mDictionaryType).append("\n");
        sb.append("  mName: ").append(mName).append("\n");
        sb.append("  mVersion: ").append(mVersion).append("\n");
        sb.append("  mImage: ").append(mImage).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
