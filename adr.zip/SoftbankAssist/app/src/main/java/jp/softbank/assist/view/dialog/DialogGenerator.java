/*
 * ファイル：DialogGenerator.java
 * 概要：ダイアログジェネレータクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog;

import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;

import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;

/**
 * ダイアログジェネレータ
 *
 * @author Systena
 * @version 1.0
 */
public class DialogGenerator {
    /**
     * ダイアログ表示するActivity.
     */
    private FragmentActivity mActivity;

    /**
     * 表示するダイアログファクトリ
     */
    private BaseDialogFactory mDialogFactory;

    /**
     * コンストラクタ.
     *
     * @param activity      ダイアログ表示するActivity
     * @param dialogFactory 表示するダイアログファクトリ
     */
    public DialogGenerator(
            final FragmentActivity activity, final BaseDialogFactory dialogFactory) {
        if ((dialogFactory == null) || (activity == null)) {
            throw new IllegalArgumentException("create dialog instance but param is null.");
        }

        mActivity = activity;
        mDialogFactory = dialogFactory;
    }

    /**
     * /**
     * ダイアログを表示する.
     *
     * @return 表示したダイアログ、ダイアログ生成失敗時はnull
     */
    public DialogFragment show() {
        // 死んでいるActivityではダイアログ表示できないため、フェールセーフとしてチェックしておく。
        if (mActivity.isFinishing()) {
            return null;
        }

        // 同TAG名のダイアログ重複を抑止するため、ダイアログ表示有無をチェック
        try {
            DialogFragment showedDialogFragment =
                    (DialogFragment) mActivity.getSupportFragmentManager().findFragmentByTag(
                            mDialogFactory.getDialogTag());
            if (showedDialogFragment != null) {
                // 同TAG名のダイアログ表示中は表示中ダイアログを継続して利用する。（新規にダイアログ表示しない）
                return showedDialogFragment;
            }
        } catch (ClassCastException e) {
            // 処理無し
        }

        // 表示するダイアログオブジェクト
        DialogFragment dialogFragment = AssistAlertDialog.newInstance(mDialogFactory);

        try {
            // ダイアログ表示後、ダイアログを呼び出し元に返却
            dialogFragment.show(mActivity.getSupportFragmentManager(), mDialogFactory.getDialogTag());
        } catch (IllegalStateException e) {
            // ダイアログ表示前にアプリがバックグラウンドに戻るケースを考慮し、IllegalStateExceptionをcatch
            AssistLog.d("show dialog failed. IllegalStateException.");
        }
        return dialogFragment;
    }
}
