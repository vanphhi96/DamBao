/*
 * ファイル：RecyclerBaseAdapter.java
 * 概要：
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */


package jp.softbank.assist.view.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetImageResultListener;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.activity.dictionary.IOnClickDetailDic;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.RecyclerBaseAdapter;


/**
 * Adapter for dic-03
 *
 * @author Systena
 * @version 1.0
 */
public class DetailDictionaryAdapter extends RecyclerBaseAdapter {
    private DictionaryInfo mDictionaryInfo;
    private IOnClickDetailDic mIOnClickDetailDic;
    private boolean mShowEdit;
    private int mColorBackgroundItem = R.color.white;
    private int mColorFlagItem = R.color.white;
    private Activity mActivity;

    {
        setFooterVisibility(true);
        setHeaderVisibility(true);
    }

    /**
     * set Activity, use when runOnUiThread
     *
     * @param activity
     */
    public void setActivity(Activity activity) {
        this.mActivity = activity;
    }


    /**
     * set data for actionDictionary
     *
     * @param actionDictionary model data
     */
    public void setDictionary(DictionaryInfo actionDictionary) {
        this.mDictionaryInfo = actionDictionary;

    }

    /**
     * set show hide button edit
     *
     * @param showEdit true: show, false: hide button
     */
    public void setShowEdit(boolean showEdit) {
        this.mShowEdit = showEdit;
    }


    /**
     * set IOnClickDetailDic
     *
     * @param mIOnClickDetailDic this class implement
     */
    public void setIOnClickDetailDic(IOnClickDetailDic mIOnClickDetailDic) {
        this.mIOnClickDetailDic = mIOnClickDetailDic;
    }

    /**
     * set color flag and background of item
     *
     * @param colorBackgroundItem color background
     * @param colorFlagItem       color flag
     */
    public void setColorItem(int colorBackgroundItem, int colorFlagItem) {
        this.mColorBackgroundItem = colorBackgroundItem;
        this.mColorFlagItem = colorFlagItem;
    }

    @Override
    public int getContentItemCount() {
        return mDictionaryInfo == null || mDictionaryInfo.getCardList() == null ? 0 : mDictionaryInfo.getCardList().size();
    }

    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_detail_dic_header, parent, false);
        return new HeaderViewHolder(view);
    }

    @Override
    public BaseViewHolder onCreateFooterHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_detail_dic_footer, parent, false);
        return new FooterViewHolder(view);

    }

    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_detail_dic, parent, false);
        return new ItemViewHolder(view);

    }

    /**
     * Class Holder item card dictionary for RecyclerView
     */
    public class ItemViewHolder extends BaseViewHolder implements GetImageResultListener {

        private ImageView mImageView;
        private TextView mTvComment;
        private TextView mTvPosition;
        private ImageView mImgArrowDown;
        private ImageView mImvZoom;
        private CheckBox mCheckBox;
        private FrameLayout mFrameImage;
        private LinearLayout mLayoutItemDicDetail;
        private ProgressBar mProgressBar;

        /**
         * Constructor
         *
         * @param itemView view item
         */
        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.imv_detail_dic);
            mTvComment = itemView.findViewById(R.id.tv_detail_dic_comment);
            mTvPosition = itemView.findViewById(R.id.tv_detail_dic_position);
            mImgArrowDown = itemView.findViewById(R.id.imv_detail_dic_next);
            mImvZoom = itemView.findViewById(R.id.imv_detail_dic_zoom);
            mCheckBox = itemView.findViewById(R.id.checkbox_detail_dic);
            mFrameImage = itemView.findViewById(R.id.frame_image);
            mLayoutItemDicDetail = itemView.findViewById(R.id.ln_item_dic_detail);
            mProgressBar = itemView.findViewById(R.id.progress_load_imv);
        }

        @Override
        public void onBindView(final int position) {
            mProgressBar.setVisibility(View.INVISIBLE);
            final CardInfo cardInfo = mDictionaryInfo.getCardList().get(toContentPosition(position));
            Bitmap bitmap = ResourcesUtils.getImageFromPath(cardInfo.getImageFileAbsolutePath());
            if (bitmap == null && TextUtils.isEmpty(cardInfo.getImageUrl())) {
                mFrameImage.setVisibility(View.GONE);
            } else if (bitmap != null) {
                mFrameImage.setVisibility(View.VISIBLE);
                mImageView.setImageBitmap(bitmap);
                mImageView.setBackground(mImageView.getContext().getDrawable(R.drawable.bgr_imv_item_detail_dic));
                mImageView.setPadding(0, 0, 0, 0);
            } else {
                mFrameImage.setVisibility(View.VISIBLE);
                int padding = convertDpToPx(Constants.Dictionary.PADDING_IMAGE_DEFAULT, mImageView.getContext());
                mImageView.setPadding(padding, padding, padding, padding);
                mImageView.setImageDrawable(mImageView.getContext().getDrawable(R.drawable.ic_create_dic));
                mImageView.setBackground(mImageView.getContext().getDrawable(R.drawable.bgr_imv_item_detail_dic_error));
            }
            if (!cardInfo.isCalledGetImageMethod() && bitmap == null && !TextUtils.isEmpty(cardInfo.getImageUrl())) {
                AppController.getInstance().getAssistServerInterface().getCardImage(cardInfo, this);
                cardInfo.setIsCalledGetImageMethod(true);
            }
            mImageView.setClipToOutline(true);
            mTvComment.setText(cardInfo.getText());
            mTvPosition.setText(String.valueOf(position));
            if (mDictionaryInfo.getType() == DictionaryInfo.DictionaryType.Check) {
                mCheckBox.setChecked(mDictionaryInfo.getCardList().get(toContentPosition(position)).isChecked());
                mTvPosition.setVisibility(View.INVISIBLE);
                mCheckBox.setVisibility(View.VISIBLE);
                mImgArrowDown.setVisibility(View.INVISIBLE);
            } else {
                mTvPosition.setVisibility(View.VISIBLE);
                mCheckBox.setVisibility(View.INVISIBLE);
                mImgArrowDown.setVisibility(View.VISIBLE);
            }
            if (position == mDictionaryInfo.getCardList().size()) {
                mImgArrowDown.setVisibility(View.INVISIBLE);
            }
            mLayoutItemDicDetail.setBackgroundColor(mLayoutItemDicDetail.getContext().getColor(mColorBackgroundItem));
            mCheckBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCheckBox.setChecked(!mDictionaryInfo.getCardList().get(toContentPosition(position)).isChecked());
                    mDictionaryInfo.getCardList().get(toContentPosition(position)).setIsChecked(mCheckBox.isChecked());
                }
            });
            mImvZoom.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickDetailDic != null) {
                        mIOnClickDetailDic.onClickZoomPicture(toContentPosition(position));
                    }
                }
            });
        }

        @Override
        public void onResult(AssistServerResult result, final String filepath) {
            if (mActivity != null && result.mResult == AssistServerResult.Result.Success) {
                mActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (getLayoutPosition() != RecyclerView.NO_POSITION) {
                            mDictionaryInfo.getCardList().get(toContentPosition(getLayoutPosition())).setIsDownloaded(true);
                        }
                        mProgressBar.setVisibility(View.INVISIBLE);
                        Bitmap bitmap = ResourcesUtils.getImageFromPath(filepath);
                        if (bitmap != null) {
                            mImageView.setImageBitmap(bitmap);
                            mImageView.setBackground(mImageView.getContext().getDrawable(R.drawable.bgr_imv_item_detail_dic));
                            mImageView.setPadding(0, 0, 0, 0);
                        }
                    }
                });
            }
        }

        @Override
        public void onStartConnection() {
            mProgressBar.setVisibility(View.VISIBLE);
        }

        /**
         * convert dp to px
         *
         * @param dp
         * @param context
         * @return
         */
        private int convertDpToPx(int dp, Context context) {
            return (int) (dp * context.getResources().getDisplayMetrics().density);
        }
    }

    /**
     * Class Holder for Header RecyclerView
     */
    public class HeaderViewHolder extends BaseViewHolder {
        private TextView mTvTitle;
        private TextView mTvDate;
        private ImageView mImgEdit;
        private TextView mUser;
        private View mViewFlagColor;
        private FrameLayout mFrameBgrIcon;
        private ImageView mImvUser;
        private RelativeLayout mContentItem;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            mTvTitle = itemView.findViewById(R.id.tv_title_dic_detail);
            mTvDate = itemView.findViewById(R.id.tv_time_update_dic_detail);
            mImgEdit = itemView.findViewById(R.id.imv_edit_dic_detail);
            mUser = itemView.findViewById(R.id.tv_user_dic_detail);
            mFrameBgrIcon = itemView.findViewById(R.id.frame_flag_item_detail_dic);
            mViewFlagColor = itemView.findViewById(R.id.view_flag_item_detail_dic);
            mImvUser = itemView.findViewById(R.id.imv_user_dic_detail);
            mContentItem = itemView.findViewById(R.id.rlt_content_item_top_detail_dic);
            mImgEdit.setVisibility(mShowEdit ? View.VISIBLE : View.GONE);
            mViewFlagColor.setClipToOutline(true);
            GradientDrawable drawableFlag = (GradientDrawable) mViewFlagColor.getBackground();
            drawableFlag.setColor(mViewFlagColor.getContext().getColor(mColorFlagItem));
            GradientDrawable drawable = (GradientDrawable) mFrameBgrIcon.getBackground();
            drawable.setColor(mFrameBgrIcon.getContext().getColor(mColorBackgroundItem));
            mContentItem.setBackgroundColor(mContentItem.getContext().getColor(mColorBackgroundItem));
        }

        @Override
        public void onBindView(int position) {
            mUser.setText(mDictionaryInfo.getCreatorNickname());
            mTvTitle.setText(mDictionaryInfo.getName());
            mTvDate.setText(mTvDate.getContext().getString(R.string.update) + DateUtils.convertDateString(mDictionaryInfo.getCreatedDate()));

            mImgEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mIOnClickDetailDic.onClickEdit();
                }
            });
            try {
                mImvUser.setVisibility(View.VISIBLE);
                mImvUser.setImageDrawable(mImvUser.getContext().getDrawable(ResourcesUtils.getUserIconResourceFromId((int) mDictionaryInfo.getCreatorIconId())));
            } catch (Resources.NotFoundException e) {
                mImvUser.setVisibility(View.INVISIBLE);
                AssistLog.e(e.toString());
            }

        }

    }

    /**
     * Class Holder for Footer RecyclerView
     */
    public class FooterViewHolder extends BaseViewHolder {
        private RelativeLayout mRltTopPage;
        private LinearLayout mLayoutItemFooter;

        public FooterViewHolder(@NonNull View itemView) {
            super(itemView);
            mRltTopPage = itemView.findViewById(R.id.rlt_see_again_dic_detail);
            mLayoutItemFooter = itemView.findViewById(R.id.ln_item_footer_dic_detail);
            mLayoutItemFooter.setClipToOutline(true);
            GradientDrawable drawable = (GradientDrawable) mLayoutItemFooter.getBackground();
            drawable.setColor(mLayoutItemFooter.getContext().getColor(mColorBackgroundItem));
        }

        @Override
        public void onBindView(int position) {
            mRltTopPage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickDetailDic != null) {
                        mIOnClickDetailDic.onClickSeeAgain();
                    }
                }
            });
        }
    }
}
