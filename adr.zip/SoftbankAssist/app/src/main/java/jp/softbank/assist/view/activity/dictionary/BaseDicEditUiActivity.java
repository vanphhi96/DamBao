/*
 * ファイル：BaseDicEditUiActivity.java
 * 概要：辞書作成画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.dictionary;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;
import jp.softbank.assist.view.dialog.factories.SingleChoiceDialogFactory;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Base for DicCreateUiActivity and DicEditUiActivity
 *
 * @author Systena
 * @version 1.0
 */
public class BaseDicEditUiActivity extends BaseUiActivity implements DialogInterface.OnClickListener {
    protected SingleChoiceDialogFactory mChoiceDialogFactory;
    protected DialogFragment mDialogFragment;
    protected String mDialogTag;
    protected String mTemporaryPhotoPath;
    protected List<CategoryInfo> mCategoryInfoList = new ArrayList<>();
    protected BaseDialogFactory mDialogFactory;

    /**
     * intent go to gallery
     *
     * @return intent go to gallery
     */
    public Intent galleryIntent() {
        Intent intent = new Intent();
        intent.setType(Constants.Dictionary.PATH_IMAGE);
        intent.setAction(Intent.ACTION_GET_CONTENT);
        return intent;
    }

    /**
     * intent go to camera
     *
     * @return
     */
    public Intent cameraIntent() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        return cameraIntent;
    }

    /**
     * 一時保存用の画像ファイルパス.
     *
     * @return File
     */
    private File createTempImageFilePath() {
        // Create an image file name
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = new File(storageDir, Constants.Dictionary.TAKE_PICTURE_TEMP_FILENAME);
        // Save a file: path for use with ACTION_VIEW intents
        mTemporaryPhotoPath = image.getAbsolutePath();
        return image;
    }

    /**
     * start intent take picture
     */
    protected void dispatchTakePictureIntent() {
        Intent takePictureIntent = cameraIntent();
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = createTempImageFilePath();
            // Continue only if the File was successfully created
            if (photoFile != null) {
                try {
                    Uri photoUri = FileProvider.getUriForFile(this,
                            Constants.Dictionary.FILE_PROVIDER_AUTHORITY,
                            photoFile);
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                } catch (IllegalArgumentException e) {
                    AssistLog.e(e.getMessage());
                }
            }
            startActivityForResult(takePictureIntent, Constants.Dictionary.REQUEST_IMAGE_CAPTURE);
        }
    }

    /**
     * @return Intent go to screen select category
     */
    public void goToDicCategoryActivity(long idCategory, String nameScreen) {
        Bundle mBundle = new Bundle();
        mBundle.putString(Constants.Dictionary.KEY_NAME_SCREEN, nameScreen);
        mBundle.putString(Constants.Dictionary.KEY_CATEGORY_SELECT, String.valueOf(idCategory));
        mBundle.putSerializable(Constants.Dictionary.KEY_LIST_CATEGORY, (Serializable) mCategoryInfoList);
        changeScreenResult(ScreenId.START_DIC_CATEGORY, Constants.Dictionary.REQUEST_CODE_CATEGORY, mBundle);
    }


    /**
     * build dialog choose thumbnail
     */
    public void buildSingleChoiceDialog() {
        mChoiceDialogFactory = new SingleChoiceDialogFactory(
                DialogTypeControl.DialogType.DIC_CHOOSE_PHOTO);
        final CharSequence[] tStrList = {getString(R.string.dic_pict_camera),
                getString(R.string.dic_pict_library)};
        mChoiceDialogFactory.setCharList(tStrList);
        BaseDialogFactory dialogFactory = mChoiceDialogFactory;
        mDialogTag = dialogFactory.getDialogTag();
        mDialogFragment = new DialogGenerator(this, dialogFactory).show();
    }

    /**
     * hide keyboard
     *
     * @param view view focus
     */
    public void hideKeyboard(View view) {
        InputMethodManager in = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        if (view == null) {
            view = new View(this);
        }
        in.hideSoftInputFromWindow(view.getWindowToken(), Constants.Dictionary.FLAG_HIDE_INPUT_FORM);
        if (getCurrentFocus() != null) {
            getCurrentFocus().clearFocus();
        }
    }

    /**
     * check camera permission
     *
     * @return true:granted, false:denied
     */
    protected boolean checkCameraPermissions() {
        return PackageManager.PERMISSION_GRANTED == checkSelfPermission(Manifest.permission.CAMERA);
    }

    /**
     * setOnclick dialog choose thumbnail
     *
     * @param dialog
     * @param which
     */
    @Override
    public void onClick(DialogInterface dialog, int which) {
        if (which == DialogInterface.BUTTON_POSITIVE) {
            if (DialogTypeControl.DialogType.DIC_CHOOSE_PHOTO.name().equals(mDialogTag)) {
                if (mChoiceDialogFactory.getCheckedItemString().equals(getString(R.string.dic_pict_camera))) {
                    if (mDialogFragment != null) {
                        mDialogFragment.dismiss();
                    }
                    if (!checkCameraPermissions()) {
                        // TODO:仕様を確認する / Confirm the specifications.
                        AlertDialog.Builder builder = new AlertDialog.Builder(this);
                        builder.setMessage("カメラへのアクセスが許可されていません");
                        builder.setPositiveButton("OK", null);
                        builder.show();
                        return;
                    } else {
                        dispatchTakePictureIntent();
                    }
                } else if (mChoiceDialogFactory.getCheckedItemString().equals(getString(R.string.dic_pict_library))) {
                    if (mDialogFragment != null) {
                        mDialogFragment.dismiss();
                    }
                    Intent intent = galleryIntent();
                    startActivityForResult(Intent.createChooser(intent, Constants.Dictionary.SELECT_PICTURE),
                            Constants.Dictionary.REQUEST_CODE_GALLERY);
                }
            }
        } else if (which == DialogInterface.BUTTON_NEGATIVE) {
            if (DialogTypeControl.DialogType.DIC_CHOOSE_PHOTO.name().equals(mDialogTag)) {
                if (mDialogFragment != null) {
                    mDialogFragment.dismiss();
                }
            }
        }
    }

    /**
     * dialog delete item dic confirm
     */
    protected void buildDicDelItemDialogConfirm() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_EDIT_DEL_ITEM);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();

    }

    /**
     * dialog delete item dic end
     */
    protected void buildDicDelItemDialogEnd() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_EDIT_DEL_ITEM_END);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();

    }

    /**
     * dialog delete item dic confirm
     */
    protected void buildDialogDicValidateNoTitle() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_VALIDATE_NO_TITLE);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();

    }

    /**
     * dialog delete item dic end
     */
    protected void buildDialogDicValidateEmptyCard() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_VALIDATE_EMPTY_CARD);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * dialog dic card max
     */
    protected void buildDialogDicCardMax() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_CARD_MAX);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * dialog dic no card
     */
    protected void buildDialogDicNoCard() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_NO_CARD);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * dialog validate no title and empty card
     */
    protected void buildDialogDicValidateNoTitleEmptyCard() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_VALIDATE_NO_TITLE_EMPTY_CARD);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();

    }
}
