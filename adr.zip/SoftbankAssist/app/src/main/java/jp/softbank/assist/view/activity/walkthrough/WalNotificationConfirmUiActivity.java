/*
 * ファイル：WalNotificationConfirmUiActivity.java
 * 概要：プッシュ通知受信許諾画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.walkthrough;

import android.os.Bundle;

import jp.softbank.assist.R;
import jp.softbank.assist.view.activity.BaseUiActivity;

/**
 * wal-10
 *
 * @author Systena
 * @version 1.0
 */
public class WalNotificationConfirmUiActivity extends BaseUiActivity {
    // TODO: 2019/02/25
    /* Sua lai theo nhung gi anh noi file ic_schedule_continue
    */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wal_notification_confirm);
    }
}
