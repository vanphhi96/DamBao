/*
 * ファイル：SetContactUsWebActivity.java
 * 概要：お問い合わせ画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.settings;

import jp.softbank.assist.R;
import jp.softbank.assist.view.activity.BaseWebActivity;

/**
 * set-abo-ctt-01.
 *
 * @author Systena
 * @version 1.0
 */
public class SetContactUsWebActivity extends BaseWebActivity {
    @Override
    protected void getDataIntent() {
        super.getDataIntent();
        //TODO[5189] fix data to test
        mTextBack = getString(R.string.set_about_app);
        mTitleWeb = getString(R.string.set_inquiry);
        mUrlWebView = "https://google.com";
    }
}
