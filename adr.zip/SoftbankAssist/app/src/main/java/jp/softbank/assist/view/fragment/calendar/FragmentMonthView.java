/*
 * ファイル：FragmentMonthView.java
 * 概要：Fragment month view calendar
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment.calendar;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.ScheduleCount;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.CountScheduleResultListener;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.view.activity.schedule.SchCalendarUiActivity;
import jp.softbank.assist.view.adapter.AdapterCalendar;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;
import jp.softbank.assist.view.fragment.BaseFragment;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


/**
 * sch-cal.
 *
 * @author Systena
 * @version 1.0
 */
@SuppressLint("ValidFragment")
public class FragmentMonthView extends BaseFragment implements IClickItemCalendar, CountScheduleResultListener {
    private RecyclerView mRvCalendar;
    private AdapterCalendar mAdapterCalendar;
    private int mNumberColumns = 7;
    private int mDaysCount = 35;
    private int mDaysOfWeek = 7;
    private int mWeekInMonth;
    private ArrayList<ScheduleCount> mListScheduleCount = new ArrayList<>();
    private SchCalendarUiActivity mCurrentActivity;
    private Date mDate;
    private String mDialogTag;

    public FragmentMonthView(Date date) {
        this.mDate = date;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCurrentActivity = (SchCalendarUiActivity) getActivity();
        mCurrentActivity.setCurrentFraggment(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(
                R.layout.fragment_month_view, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRvCalendar = view.findViewById(R.id.rv_calendar);
        initRvCalendar(mDate);
        AppController.getInstance().getAssistServerInterface().countSchedule(mDate, this);
    }

    /**
     * create list date follow month year
     *
     * @param date date format yyyy/MM
     * @return array list date
     */
    private void initRvCalendar(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        // determine the cell for current month's beginning

        calendar.set(Calendar.DAY_OF_MONTH, 1);
        int monthBeginningCell = getDayOfWeek(calendar.get(Calendar.DAY_OF_WEEK));
        //size of grid calendar
        mDaysCount = getDayOfWeek(calendar.get(Calendar.DAY_OF_WEEK)) + calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        //columns of gird calendar
        mWeekInMonth = mDaysCount % mDaysOfWeek == 0 ? mDaysCount / mDaysOfWeek : mDaysCount / mDaysOfWeek + 1;

        // move calendar backwards to the beginning of the week
        calendar.add(Calendar.DAY_OF_MONTH, -monthBeginningCell);
        // fill cells
        while (mListScheduleCount.size() < mDaysCount) {
            ScheduleCount scheduleCount = new ScheduleCount();
            scheduleCount.setDate(calendar.getTime());
            mListScheduleCount.add(scheduleCount);
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        mAdapterCalendar = new AdapterCalendar(mListScheduleCount, date, mWeekInMonth);
        mAdapterCalendar.setClickListener(this);
        mRvCalendar.setLayoutManager(new GridLayoutManager(mRvCalendar.getContext(), mNumberColumns));
        mRvCalendar.setAdapter(mAdapterCalendar);

    }

    /**
     * get number day of previous month in grid calendar
     *
     * @param dayOfWeek value of day in Calendar
     * @return number day of previous month in grid calendar
     */
    private int getDayOfWeek(int dayOfWeek) {
        switch (dayOfWeek) {
            case Calendar.TUESDAY:
                return 1;
            case Calendar.WEDNESDAY:
                return 2;
            case Calendar.THURSDAY:
                return 3;
            case Calendar.FRIDAY:
                return 4;
            case Calendar.SATURDAY:
                return 5;
            case Calendar.SUNDAY:
                return 6;
            case Calendar.MONDAY:
            default:
                return 0;

        }
    }

    @Override
    public void onItemClick(ScheduleCount scheduleCount) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Constants.Schedule.KEY_DATE_CALENDAR, scheduleCount.getDate());
        mCurrentActivity.backScreenResult(mCurrentActivity, bundle, Constants.Schedule.RESULT_CALENDAR);
    }

    @Override
    public void onResult(final AssistServerResult result, final List<ScheduleCount> list) {
        mCurrentActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mCurrentActivity.displayIndicator();
                if (result.mResult == AssistServerResult.Result.Success) {
                    if (list.size() > 0) {
                        for (int i = 0; i < list.size(); i++) {
                            ScheduleCount scheduleCount = list.get(i);
                            for (int j = 0; j < mListScheduleCount.size(); j++) {
                                if (DateUtils.compareEqualDate(mListScheduleCount.get(j).getDate(), scheduleCount.getDate())) {
                                    mListScheduleCount.get(j).setCount(scheduleCount.getCount());
                                }
                            }
                        }
                        mAdapterCalendar.notifyDataSetChanged();
                    }
                } else {
                    showDialogMessage(result.mMessage);
                }
            }
        });
    }

    @Override
    public void onStartConnection() {
        mCurrentActivity.displayIndicator();
    }

    /**
     * build dialog message
     *
     * @param message
     */
    public void showDialogMessage(String message) {
        AssistAlertDialogFactory mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIALOG_MESSAGE, message);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(mCurrentActivity, mDialogFactory).show();
    }
}