/*
 * ファイル：IOnClickItemDicCreate.java
 * 概要：Interface On Click Item Dictionary Create
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.dictionary;

/**
 * interface of dic-cr-01
 *
 * @author Systena
 * @version 1.0
 */
public interface IOnClickItemDicCreate {
    /**
     * on click button delete in Item of Dic Create
     *
     * @param position
     */
    void onClickButtonDelete(int position);

    /**
     * on click button create in Item of Dic Create
     *
     * @param position
     */
    void onClickButtonCreate(int position);

    /**
     * on click choose thumbnail
     */
    void onClickChooseThumbnail();

    /**
     * set onclick choose category
     */
    void onClickChooseCategory();

    /**
     * set onclick header
     */
    void onClickHeader();

    /**
     * update avatar item dictionary
     *
     * @param position
     */
    void updateAvatar(int position);

}
