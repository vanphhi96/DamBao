/*
 * ファイル：EditTextLinesLimiter.java
 * 概要：TextWatcher to set limit line and disable enter of EditText.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.customview;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

/**
 * EditText limit line and disable enter.
 *
 * @author Systena
 * @version 1.0
 */
public class EditTextLinesLimiter implements TextWatcher {
    private EditText mEditText;
    private int mMaxLines;
    private String mLastValue = "";

    public EditTextLinesLimiter(EditText editText, int maxLines) {
        this.mEditText = editText;
        this.mMaxLines = maxLines;
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        mLastValue = charSequence.toString();
    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {
        if (mEditText.getLineCount() > mMaxLines || mEditText.getText().toString().contains("\n")) {
            int selectionStart = mEditText.getSelectionStart() - 1;
            mEditText.setText(mLastValue);
            if (selectionStart >= mEditText.length()) {
                selectionStart = mEditText.length();
            }
            mEditText.setSelection(selectionStart);
        }
    }
}
