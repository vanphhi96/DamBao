/*
 * ファイル：BaseDialog.java
 * 概要：ダイアログBaseクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentTransaction;
import android.util.TypedValue;
import android.widget.Button;

import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * ダイアログBaseクラス
 *
 * @author Systena
 * @version 1.0
 */
public class BaseDialog extends DialogFragment
        implements DialogInterface.OnShowListener {
    /**
     * ダイアログ引数キー名
     */
    static final String KEY_DIALOG_ARGUMENT = "key_dialog_argument";

    /**
     * ダイアログファクトリ
     */
    private BaseDialogFactory mDialogFactory;

    /**
     * In the case the dialog is 2 buttons or more, onCancel default is negative button.
     * true if onCancel is negative button, false otherwise
     */
    private boolean mIsCancelToNegative = false;

    /**
     * ダイアログファクトリを取得.
     *
     * @return ダイアログファクトリ
     */
    public BaseDialogFactory getDialogFactory() {
        return mDialogFactory;
    }

    /**
     * 必須パラメータをセットする.
     *
     * @param dialogFactory ダイアログファクトリ
     * @return 必須パラメータがセットされたBundle
     */
    public static Bundle getArgumentsBundle(BaseDialogFactory dialogFactory) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_DIALOG_ARGUMENT, dialogFactory);
        return bundle;
    }

    /**
     * ダイアログ重複表示時のダイアログ消去可否を取得.
     *
     * @return ダイアログ重複表示時、ダイアログ消去可能な場合true.
     */
    public boolean isRemovable() {
        return mDialogFactory.isRemovable();
    }

    /**
     * onCreate
     *
     * @param savedInstanceState Bundle
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 引数からダイアログファクトリを取得
        mDialogFactory =
                (BaseDialogFactory) getArguments().getSerializable(KEY_DIALOG_ARGUMENT);

        if (mDialogFactory == null) {
            // Factoryが存在しない場合ダイアログ表示できないため、異常として扱う
            throw new IllegalArgumentException(
                    "dialog arguments is null.");
        }

        // ダイアログ同士の重複表示を避けるため、ダイアログをcleanする
        cleanActiveDialog();
        BaseDialog.ActiveDialog.getInstance().add(this);
    }

    /**
     * onActivityCreated
     *
     * @param savedInstanceState Bundle
     */
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    /**
     * onPause
     */
    @Override
    public void onPause() {
        super.onPause();
        AssistLog.d("dialog[" + mDialogFactory.getDialogTag() + "] dismiss.");
        dismissAllowingStateLoss();
        BaseDialog.ActiveDialog.getInstance().remove(this);
        BaseDialog.ActiveDialog.getInstance().dump();
    }

    /**
     * onDismiss
     */
    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (mDialogFactory.getOnDismissListener() != null) {
            mDialogFactory.getOnDismissListener().onDismiss(dialog);
        } else if (getActivity() instanceof DialogInterface.OnDismissListener) {
            ((DialogInterface.OnDismissListener) getActivity()).onDismiss(dialog);
        }
    }

    /**
     * onCancel
     *
     * @param dialog ダイアログ
     */
    @Override
    public void onCancel(DialogInterface dialog) {
        super.onCancel(dialog);
        if (mIsCancelToNegative) {
            ((AlertDialog) dialog).getButton(AlertDialog.BUTTON_NEGATIVE).callOnClick();
            AssistLog.d("dialog[" + mDialogFactory.getDialogTag() +
                    "] onCancel >> onClick BUTTON_NEGATIVE.");
        } else if (getDialogFactory().isPositivelyDialog()) {
            ((AlertDialog) dialog).getButton(AlertDialog.BUTTON_POSITIVE).callOnClick();
            AssistLog.d("dialog[" + mDialogFactory.getDialogTag() +
                    "] onCancel >> onClick BUTTON_POSITIVE.");
        } else {
            AssistLog.d("dialog[" + mDialogFactory.getDialogTag() +
                    "] onCancel >> listener: " + mDialogFactory.getOnCancelListener());
            if (mDialogFactory.getOnCancelListener() != null) {
                mDialogFactory.getOnCancelListener().onCancel(dialog);
            } else if (getActivity() instanceof DialogInterface.OnCancelListener) {
                ((DialogInterface.OnCancelListener) getActivity()).onCancel(dialog);
            }
        }
    }

    /**
     * onShow
     *
     * @param dialog ダイアログ
     */
    @Override
    public void onShow(DialogInterface dialog) {
        // ボタンの表示制御
        AlertDialog alertDialog = (AlertDialog) dialog;
        final Button positiveButton = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
        final Button negativeButton = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE);

        // ボタン表示のはボタンサイズを固定
        if (positiveButton != null && positiveButton.isShown()) {
            // ボタンの文字サイズ設定
            positiveButton.setSingleLine(true);
            fittingButtonTextWidth(positiveButton);
        }
        if (negativeButton != null && negativeButton.isShown()) {
            // ボタンの文字サイズ設定
            mIsCancelToNegative = true;
            negativeButton.setSingleLine(true);
            fittingButtonTextWidth(negativeButton);
        }

        if (positiveButton != null) {
            BaseDialogFactory.PositiveButtonClickListener positiveButtonClickListener = mDialogFactory.getPositiveButtonClickListener();
            if (null != positiveButtonClickListener) {
                positiveButton.setOnClickListener(positiveButtonClickListener);
            }
        }

        BaseDialogFactory.CustomOnShowListener customOnShowListener = mDialogFactory.getCustomOnShowListener();
        if (null != customOnShowListener) {
            customOnShowListener.onShow(getActivity(), dialog);
        }
    }

    /**
     * ボタンテキスト幅を改行しないようにリサイズする処理.
     *
     * @param button 表示制御対象のView
     */
    protected void fittingButtonTextWidth(Button button) {
        float textSize = button.getTextSize();
        String text = button.getText().toString();

        float buttonWidth = button.getWidth();
        Paint paint = new Paint();
        paint.setTextSize(textSize);
        float buttonTextWidth = paint.measureText(text)
                + (button.getPaddingLeft() + button.getPaddingRight());

        // 横幅に収まるようにサイズを縮小
        final double weight = 0.9;
        while (buttonTextWidth > buttonWidth * weight) {
            textSize--;
            paint.setTextSize(textSize);
            buttonTextWidth = paint.measureText(text);
            if (textSize < 0) {
                // フェールセーフ
                break;
            }
        }

        // 縮小したサイズをボタンへ再設定し、ボタン名を縮小表示する
        button.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
    }

    /**
     * 重複表示可能なダイアログ以外のダイアログを消去する.
     */
    private void cleanActiveDialog() {
        synchronized (BaseDialog.ActiveDialog.getInstance().getActiveDialogs()) {
            for (BaseDialog dialog : BaseDialog.ActiveDialog.getInstance().getActiveDialogs()) {
                if (dialog.isRemovable()) {
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.remove(dialog);
                    // ダイアログ消去はダイアログ内の情報を保持する必要がないためStateLossでダイアログ消去
                    transaction.commitAllowingStateLoss();
                }
            }
        }
    }

    /**
     * 表示中のダイアログをリスト管理する。表示中のダイアログ情報は本クラスより取得可能。
     *
     * @author Systena
     * @version 1.0
     */
    private static class ActiveDialog {

        /**
         * インスタンス.
         */
        private static ActiveDialog mInstance = new ActiveDialog();

        /**
         * 現在表示中のダイアログリスト.
         */
        private final List<BaseDialog> mActiveDialogs =
                Collections.synchronizedList(new LinkedList<BaseDialog>());

        /**
         * コンストラクタ.
         */
        private ActiveDialog() {
            // Singleton
        }

        /**
         * インスタンスを取得.
         *
         * @return 唯一のActiveDialogインスタンス
         */
        public static ActiveDialog getInstance() {
            return mInstance;
        }

        /**
         * ダイアログを表示中ダイアログとしてリスト登録.
         *
         * @param dialogFragment リスト登録するダイアログ<br/>ダイアログが既にリスト登録済みの場合は新たにリスト登録しない
         */
        public void add(BaseDialog dialogFragment) {
            if (!mActiveDialogs.contains(dialogFragment)) {
                mActiveDialogs.add(dialogFragment);
            }
        }

        /**
         * ダイアログをリストから登録解除.
         *
         * @param dialogFragment 登録解除するダイアログ.<br/>リストに存在しないダイアログを解除しようとした場合は何も処理しない
         */
        public void remove(BaseDialog dialogFragment) {
            if (mActiveDialogs.contains(dialogFragment)) {
                mActiveDialogs.remove(dialogFragment);
            }
        }

        /**
         * 表示中ダイアログリストを取得.
         *
         * @return 表示中ダイアログリスト
         */
        List<BaseDialog> getActiveDialogs() {
            return mActiveDialogs;
        }

        /**
         * リストの中身を出力する.
         */
        public void dump() {
            synchronized (mActiveDialogs) {
                StringBuilder stringBuilder = new StringBuilder();
                int counter = 1;
                stringBuilder.append("ActiveDialog.dump:");
                stringBuilder.append(System.getProperty("line.separator"));
                if (mActiveDialogs.size() > 0) {
                    for (BaseDialog fragment : mActiveDialogs) {
                        stringBuilder.append("ActiveDialog[");
                        stringBuilder.append(counter);
                        stringBuilder.append("]->");
                        stringBuilder.append(fragment.getClass().getSimpleName());
                        stringBuilder.append("(");
                        stringBuilder.append(fragment.getDialogFactory().getClass().getSimpleName());
                        stringBuilder.append(")");
                        stringBuilder.append(System.getProperty("line.separator"));
                        counter++;
                    }
                } else {
                    stringBuilder.append("ActiveDialog is empty.");
                }
                AssistLog.d(stringBuilder.toString());
            }
        }
    }

    private OnOkClickListener mListener;

    /**
     * OnOkClickListener
     */
    public interface OnOkClickListener {
        public void onOkClicked(Bundle args);
    }

}
