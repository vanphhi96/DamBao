/*
 * ファイル：SynchronizeDictionaryParam.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import jp.softbank.assist.network.json.RequestParam;

/**
 * 辞書一覧（差分）取得パラメータ.
 */
public class SynchronizeDictionaryParam extends RequestParam {

    private Long mUserId;
    private Long mDictionaryVersion;
    private Long mCardVersion;

    /**
     * コンストラクタ.
     *
     * @param userId 利用者ID
     * @param dictionaryVersion 辞書バージョン
     * @param cardVersion カードバージョン
     */
    public SynchronizeDictionaryParam(Long userId, Long dictionaryVersion, Long cardVersion) {
        this.mUserId = userId;
        this.mDictionaryVersion = dictionaryVersion;
        this.mCardVersion = cardVersion;
    }

    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * 辞書バージョン.
     */
    public Long getDictionaryVersion() {
        return mDictionaryVersion;
    }
    public void setDictionaryVersion(Long dictionaryVersion) {
        this.mDictionaryVersion = dictionaryVersion;
    }

    /**
     * カードバージョン.
     */
    public Long getCardVersion() {
        return mCardVersion;
    }
    public void setCardVersion(Long cardVersion) {
        this.mCardVersion = cardVersion;
    }
}
