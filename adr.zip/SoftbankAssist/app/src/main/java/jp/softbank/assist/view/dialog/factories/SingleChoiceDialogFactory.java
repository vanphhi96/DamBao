/*
 * ファイル：SingleChoiceDialogFactory.java
 * 概要：選択ダイアログ表示用Factoryベースクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v4.app.FragmentActivity;
import android.widget.ArrayAdapter;

import jp.softbank.assist.R;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl.DialogType;

/**
 * 選択ダイアログ表示用Factoryベースクラス
 *
 * @author Systena
 * @version 1.0
 */
public class SingleChoiceDialogFactory extends BaseDialogFactory {

    ArrayAdapter<CharSequence> mAdapter;
    private DialogType mDialogType;
    private CharSequence[] mCharList;
    private int mCheckedPos;

    /**
     * Constructor create dialog Single Choice
     *
     * @param dialogType type of the dialog.
     */
    public SingleChoiceDialogFactory(DialogType dialogType) {
        this.mDialogType = dialogType;
    }

    public CharSequence[] getCharList() {
        return mCharList;
    }

    public void setCharList(CharSequence[] charList) {
        this.mCharList = charList;
    }

    public int getCheckedPos() {
        return mCheckedPos;
    }

    public void setCheckedPos(int checkedPos) {
        this.mCheckedPos = checkedPos;
    }

    public String getCheckedItemString() {
        return mCharList[mCheckedPos].toString();
    }

    @Override
    public String getDialogTag() {
        return mDialogType.name();
    }

    /**
     * ダイアログ種別判定
     *
     * @param activity ダイアログ表示するActivity
     */
    @Override
    public AlertDialog getReadyAlertDialog(FragmentActivity activity) {
        AlertDialog.Builder builder = createDialogBuilder(activity);
        mAdapter = new ArrayAdapter<CharSequence>(activity, R.layout.assist_custom_singlechoise_dialog,
                mCharList);
        switch (mDialogType) {
            case SINGLE_CHOICE_TEST_DIALOG1:
                buildDiaglogTest1Dialog(activity, builder);
                break;
            case SINGLE_CHOICE_TEST_DIALOG2:
                buildDiaglogTest2Dialog(activity, builder);
                break;
            case DIC_CHOOSE_PHOTO:
                buildChooseThumbnailDialog(activity, builder);
                break;
            default:
                break;
        }
        return builder.create();
    }

    // TODO: 2019/01/30 [buildDiaglogTest1Dialog]このMethodはテストのため、後で消す/ This method is just for test, delete later.

    /**
     * ダイアログ設定(Test1)
     *
     * @param activity ダイアログ表示するActivity
     * @param builder  生成するダイアログBuilder
     */
    private void buildDiaglogTest1Dialog(Activity activity, AlertDialog.Builder builder) {
        setPositivelyDialog(false);
        builder.setTitle(activity.getString(R.string.app_name));
        builder.setMessage(jp.softbank.assist.R.string.app_name);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setNegativeButton(jp.softbank.assist.R.string.cancel,
                    (DialogInterface.OnClickListener) activity);
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    // TODO: 2019/01/30 [buildDiaglogTest2Dialog]このMethodはテストのため、後で消す/ This method is just for test, delete later.

    /**
     * ダイアログ設定(Test2)
     *
     * @param activity ダイアログ表示するActivity
     * @param builder
     */
    private void buildDiaglogTest2Dialog(final Activity activity, AlertDialog.Builder builder) {

        int select = 0;
        setPositivelyDialog(false);
        builder.setTitle(activity.getString(jp.softbank.assist.R.string.app_name));
        builder.setSingleChoiceItems(getCharList(), select,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {
                        //チェックしたものを配列へ
                        setCheckedPos(item);
                    }
                });
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setNegativeButton(jp.softbank.assist.R.string.cancel,
                    (DialogInterface.OnClickListener) activity);
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * build dialog choose thumbnail of dic-cr-01 screen
     *
     * @param activity
     * @param builder
     */
    private void buildChooseThumbnailDialog(final Activity activity, AlertDialog.Builder builder) {
        int select = 0;
        setPositivelyDialog(false);
        builder.setSingleChoiceItems(getCharList(), select,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {
                        setCheckedPos(item);
                    }
                });
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setNegativeButton(R.string.cancel,
                    (DialogInterface.OnClickListener) activity);
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }
}
