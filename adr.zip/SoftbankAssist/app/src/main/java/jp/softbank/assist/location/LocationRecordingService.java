/*
 * ファイル：LocationRecordingService.java
 * 概要：位置測位を行うサービス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.location;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import java.util.Timer;
import java.util.TimerTask;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.view.activity.main.MenuUiActivity;

/**
 * 位置測位用サービス.
 *
 * @author Systena
 * @version 1.0
 */
public class LocationRecordingService extends Service {

    private FusedLocationProviderClient mFusedLocationClient;
    private LocationRequest mLocationRequest;
    private Location mLastLocation;
    private static final long UPDATE_INTERVAL = 5 * 1000, FASTEST_INTERVAL = 5 * 1000; // = 10 seconds
    private final static float CALCULATE_INTERVAL = 5f;

    private LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            if (locationResult == null) {
                return;
            }
            mLastLocation = locationResult.getLastLocation();
            AppController.getInstance().getLocationRecordingManager().setLongitude(String.valueOf(mLastLocation.getLongitude()));
            AppController.getInstance().getLocationRecordingManager().setLatitude(String.valueOf(mLastLocation.getLatitude()));
            // TODO: 2019/02/14 Logテスト用。 後で削除。（タン）
            Log.i("tntan", "onLocationResult: " + mLastLocation);
        }

        @Override
        public void onLocationAvailability(LocationAvailability locationAvailability) {
            super.onLocationAvailability(locationAvailability);
            // TODO: 2019/02/14 Logテスト用。 後で削除。（タン）
            Log.d("tntan", "onLocationAvailability: " + locationAvailability.isLocationAvailable());
            AppController.getInstance().getLocationRecordingManager().checkGpsAvailable(locationAvailability.isLocationAvailable());
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        runAsForeground();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopLocationUpdate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        runAsForeground();
        createLocationRequest();
        startLocationUpdate();
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /*
   * Create Location Request
   */
    private void createLocationRequest() {
        mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(UPDATE_INTERVAL)
                .setFastestInterval(FASTEST_INTERVAL)
//                .setSmallestDisplacement(CALCULATE_INTERVAL)
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

    }

    /*
    * Stop Location Update
    */
    private void stopLocationUpdate() {
        if (mFusedLocationClient!=null){
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
        }
    }

    /*
    * Start Location Update
    */
    private void startLocationUpdate() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, null);
    }

    /*
    * StartForegroundServiceを実装するため、Android8.0以上にはこのメソッドが必要。
    */
    private void runAsForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String CHANNEL_ID = "my_channel_01";
            Intent notificationIntent = new Intent(this, MenuUiActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                    notificationIntent, 0);
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Assist Test Title 1",
                    NotificationManager.IMPORTANCE_DEFAULT);
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);
            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("Assist Test Title 2")
                    .setContentText("Assist Test Title 3")
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentIntent(pendingIntent)
                    .build();
            startForeground(1, notification);
        }
    }
}
