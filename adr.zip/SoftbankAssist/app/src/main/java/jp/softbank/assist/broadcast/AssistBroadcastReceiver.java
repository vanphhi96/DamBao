/*
 * ファイル：AssistBroadcastReceiver.java
 * 概要：BroadcastReceiver受信時時の処理を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.util.AssistLog;


/**
 * BroadcastReceiver受信時用クラス.
 *
 * @author Systena
 * @version 1.0
 */
public class AssistBroadcastReceiver extends BroadcastReceiver {

    /**
     * BroadcastReceiver受信時の処理を行う
     *
     * @param context context
     * @param intent  intent
     */
    @Override
    public void onReceive(Context context, Intent intent) {

        AssistLog.d("AssistBroadcastReceiver Start");
        Context cont = context.createDeviceProtectedStorageContext();

        String intentAction = intent.getAction();
        if (intentAction == null) {
            AssistLog.d("inten Action Error");
            return;
        }

        switch (intentAction) {
            case Intent.ACTION_LOCKED_BOOT_COMPLETED:
                AssistLog.d("ACTION_LOCKED_BOOT_COMPLETED");
                // 端末再起動 タイマ情報クリア、再設定
                AppController.getInstance().getAssistTimerManager().timerReset(cont);
                break;
            case Intent.ACTION_TIME_CHANGED:
                AssistLog.d("ACTION_TIME_CHANGED");
                // 時間変更 タイマ情報クリア、再設定
                AppController.getInstance().getAssistTimerManager().timerReset(context);
                break;
            case Intent.ACTION_TIMEZONE_CHANGED:
                AssistLog.d("ACTION_TIMEZONE_CHANGED");
                // タイムゾーン変更 タイマ情報クリア、再設定
                AppController.getInstance().getAssistTimerManager().timerReset(context);
                break;
            case Intent.ACTION_MY_PACKAGE_REPLACED:
                AssistLog.d("ACTION_MY_PACKAGE_REPLACED");
                // タイムゾーン変更 タイマ情報クリア、再設定
                AppController.getInstance().getAssistTimerManager().timerReset(cont);
                break;
            default:
                AssistLog.i("case default");
                Log.i("AssistBroadcastReceiver", "default");
                break;
        }
    }
}


