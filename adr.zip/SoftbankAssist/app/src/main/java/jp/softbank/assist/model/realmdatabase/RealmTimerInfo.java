/*
 * ファイル：RealmTimerInfo.java
 * 概要：Realmタイマー情報テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Realmタイマー情報テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmTimerInfo extends RealmObject {

    private int mRequestCode; //リクエストコード
    @PrimaryKey
    private String mType; // タイマ設定 Type

    public int getRequestCode() {
        return mRequestCode;
    }

    public void setRequestCode(int requestCode) {
        this.mRequestCode = requestCode;
    }

    public String getType() {
        return mType;
    }

    public void setType(String type) {
        this.mType = type;
    }

}
