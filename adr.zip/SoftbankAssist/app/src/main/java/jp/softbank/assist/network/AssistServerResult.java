/*
 * ファイル：AssistServerResult.java
 * 概要：非同期処理の結果
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network;

/**
 * 非同期処理の結果.
 */
public class AssistServerResult {

    /**
     * 結果.
     */
    public enum Result {
        Success, // 成功
        ResponseError, // レスポンスエラー
        NetworkError, // TODO:T.B.D.
    }


    public final Result mResult; // 結果
    public final int mCode; // エラーコード
    public final String mMessage; // エラーメッセージ
    public final String mItem; // エラー項目


    /**
     * コンストラクタ.
     *
     * @param result 結果
     * @param code エラーコード
     * @param message エラーメッセージ
     * @param item エラー項目
     */
    public AssistServerResult(Result result, int code, String message, String item) {
        this.mResult = result;
        this.mCode = code;
        this.mMessage = message;
        this.mItem = item;
    }

    /**
     * コンストラクタ.
     *
     * @param result 結果
     * @param code エラーコード
     * @param message エラーメッセージ
     * @param item エラー項目
     */
    public AssistServerResult(Result result, String code, String message, String item) {
        int temp = 0;
        try {
            temp = Integer.valueOf(code);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        this.mResult = result;
        this.mCode = temp;
        this.mMessage = message;
        this.mItem = item;
    }

    /**
     * コンストラクタ（結果のみ）.
     *
     * @param result 結果
     */
    public AssistServerResult(Result result) {
        this(result, 0, "", "");
    }
}
