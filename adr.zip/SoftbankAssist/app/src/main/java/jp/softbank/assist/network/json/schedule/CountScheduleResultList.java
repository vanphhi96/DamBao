/*
 * ファイル：CountScheduleResultList.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.schedule;

import java.util.ArrayList;

/**
 * スケジュール件数取得結果リスト.
 */
public class CountScheduleResultList extends ArrayList<CountScheduleResult> {

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CountScheduleResultList scheduleResultList = (CountScheduleResultList) o;
        return true;
    }

    @Override
    public int hashCode() {
        int result = 17;
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class CountScheduleResultList {\n");
        sb.append("  " + super.toString()).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
