/*
 * ファイル：GetNoticeResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.notice;

import com.google.gson.annotations.SerializedName;

/**
 * お知らせ情報.
 */
public class GetNoticeResult {

    @SerializedName("mId")
    private Long mId = null;
    @SerializedName("delivery_on")
    private String mDeliveryOn = null;
    @SerializedName("information_title")
    private String mInformationTitle = null;
    @SerializedName("information_content")
    private String mInformationContent = null;
    @SerializedName("version")
    private Long mVersion = null;
    @SerializedName("is_priority")
    private Long mIsPriority = null;
    @SerializedName("created_at")
    private String mCreatedAt = null;
    @SerializedName("updated_at")
    private String mUpdatedAt = null;


    /**
     * お知らせID.
     */
    public Long getId() {
        return mId;
    }
    public void setId(Long id) {
        this.mId = id;
    }

    /**
     * 配信日時（YYYYMMDDhhmm形式）.
     */
    public String getDeliveryOn() {
        return mDeliveryOn;
    }
    public void setDeliveryOn(String deliveryOn) {
        this.mDeliveryOn = deliveryOn;
    }

    /**
     * お知らせタイトル.
     */
    public String getInformationTitle() {
        return mInformationTitle;
    }
    public void setInformationTitle(String informationTitle) {
        this.mInformationTitle = informationTitle;
    }

    /**
     * お知らせ内容.
     */
    public String getInformationContent() {
        return mInformationContent;
    }
    public void setInformationContent(String informationContent) {
        this.mInformationContent = informationContent;
    }

    /**
     * バージョン.
     */
    public Long getVersion() {
        return mVersion;
    }
    public void setVersion(Long version) {
        this.mVersion = version;
    }

    /**
     * 優先表示フラグ（0:OFF、1:ON）.
     */
    public Long getIsPriority() {
        return mIsPriority;
    }
    public void setIsPriority(Long isPriority) {
        this.mIsPriority = isPriority;
    }

    /**
     * 作成日時（YYYYMMDDhhmmss形式）.
     */
    public String getCreatedAt() {
        return mCreatedAt;
    }
    public void setCreatedAt(String createdAt) {
        this.mCreatedAt = createdAt;
    }

    /**
     * 更新日時（YYYYMMDDhhmmss形式）.
     */
    public String getUpdatedAt() {
        return mUpdatedAt;
    }
    public void setUpdatedAt(String updatedAt) {
        this.mUpdatedAt = updatedAt;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GetNoticeResult noticeResult = (GetNoticeResult) o;
        return (this.mId == null ? noticeResult.mId == null : this.mId.equals(noticeResult.mId)) &&
                (this.mDeliveryOn == null ? noticeResult.mDeliveryOn == null : this.mDeliveryOn.equals(noticeResult.mDeliveryOn)) &&
                (this.mInformationTitle == null ? noticeResult.mInformationTitle == null : this.mInformationTitle.equals(noticeResult.mInformationTitle)) &&
                (this.mInformationContent == null ? noticeResult.mInformationContent == null : this.mInformationContent.equals(noticeResult.mInformationContent)) &&
                (this.mVersion == null ? noticeResult.mVersion == null : this.mVersion.equals(noticeResult.mVersion)) &&
                (this.mIsPriority == null ? noticeResult.mIsPriority == null : this.mIsPriority.equals(noticeResult.mIsPriority)) &&
                (this.mCreatedAt == null ? noticeResult.mCreatedAt == null : this.mCreatedAt.equals(noticeResult.mCreatedAt)) &&
                (this.mUpdatedAt == null ? noticeResult.mUpdatedAt == null : this.mUpdatedAt.equals(noticeResult.mUpdatedAt));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mId == null ? 0: this.mId.hashCode());
        result = 31 * result + (this.mDeliveryOn == null ? 0: this.mDeliveryOn.hashCode());
        result = 31 * result + (this.mInformationTitle == null ? 0: this.mInformationTitle.hashCode());
        result = 31 * result + (this.mInformationContent == null ? 0: this.mInformationContent.hashCode());
        result = 31 * result + (this.mVersion == null ? 0: this.mVersion.hashCode());
        result = 31 * result + (this.mIsPriority == null ? 0: this.mIsPriority.hashCode());
        result = 31 * result + (this.mCreatedAt == null ? 0: this.mCreatedAt.hashCode());
        result = 31 * result + (this.mUpdatedAt == null ? 0: this.mUpdatedAt.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class GetNoticeResult {\n");

        sb.append("  mId: ").append(mId).append("\n");
        sb.append("  mDeliveryOn: ").append(mDeliveryOn).append("\n");
        sb.append("  mInformationTitle: ").append(mInformationTitle).append("\n");
        sb.append("  mInformationContent: ").append(mInformationContent).append("\n");
        sb.append("  mVersion: ").append(mVersion).append("\n");
        sb.append("  mIsPriority: ").append(mIsPriority).append("\n");
        sb.append("  mCreatedAt: ").append(mCreatedAt).append("\n");
        sb.append("  mUpdatedAt: ").append(mUpdatedAt).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
