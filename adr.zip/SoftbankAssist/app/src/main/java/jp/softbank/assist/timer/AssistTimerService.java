/*
 * ファイル：AssistTimerService.java
 * 概要：タイマ満了Broadcast受信時の処理を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.timer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.DateUtils;

/**
 * タイマ制御用クラス.
 *
 * @author Systena
 * @version 1.0
 */
public class AssistTimerService extends BroadcastReceiver {

    /**
     * タイマ満了Broadcast受信
     *
     * @param context   Context
     * @param getIntent 受信時のintent
     */
    @Override
    public void onReceive(Context context, Intent getIntent) {

        AssistLog.d("Start");
        Bundle bundle = getIntent.getBundleExtra(Constants.TimerControl.TIMER_BUNDLE_KEY);
        // 受信時に端末ロックされていた場合に備えて端末暗号化ストレージにアクセスする
        Context cont = context.createDeviceProtectedStorageContext();
        int timerType = bundle.getInt(Constants.TimerControl.TIMER_TYPE,
                Constants.TimerControl.TIMER_SCHEDULE_NONE);

        switch (timerType) {
            case Constants.TimerControl.TIMER_SCHEDULE_10MIN:
                // 予定開始前10分のタイマ満了
                callNotification10min(cont, bundle);
                break;
            case Constants.TimerControl.TIMER_SCHEDULE_ONTIME:
                // 予定開始定刻のタイマ満了
                callNotificationOnTime(cont, bundle);
                break;
            case Constants.TimerControl.TIMER_DATE_CHANGED:
                // 日付変更時タイマ満了(0:05)
                AppController.getInstance().getAssistTimerManager().timerReset(cont);
                break;
            case Constants.TimerControl.TIMER_SCHEDULE_NONE:
            default:
                AssistLog.d("case default");
                break;
        }

    }

    /**
     * 予定開始前10分のタイマ満了受信処理
     *
     * @param context Context
     * @param bundle  Intentから取得したbundle
     */
    private void callNotification10min(Context context, Bundle bundle) {

        AssistLog.i("Start");

        // Notification出力
        AppController.getInstance().getAssistNotificationManager().sendNotificationByTimer(context, bundle);

        // 予定開始定刻のタイマ設定
        long scheduleId = bundle.getLong(Constants.TimerControl.SCHEDULE_ID);
        ScheduleInfo data = AppController.getInstance().getModelInterface().getScheduleInfoById(scheduleId);
        if (data == null) {
            // スケジュールID異常
            AssistLog.i("schedule get error scheduleId[" + scheduleId + ":");
            return;
        }

        String text = bundle.getString(Constants.TimerControl.TIMER_NOTIFICATION_TEXT);
        String title = context.getString(R.string.timer_before_ontime);
        long timerMillis = DateUtils.getTimerSetMillis(data.getScheduleStartDate());
        int requestCode = AppController.getInstance().getAssistTimerManager().timerSetSchedule(context, scheduleId,
                Constants.TimerControl.TIMER_SCHEDULE_ONTIME, text, title, timerMillis, String.valueOf(scheduleId));

        // タイマ情報更新
        AppController.getInstance().getAssistTimerManager().updateTimerInfo(requestCode, String.valueOf(scheduleId));
    }

    /**
     * 予定開始定刻のタイマ満了受信処理
     *
     * @param context Context
     * @param bundle  Intentから取得したbundle
     */
    private void callNotificationOnTime(Context context, Bundle bundle) {
        AssistLog.i("Start");

        // Notification出力
        AppController.getInstance().getAssistNotificationManager().sendNotificationByTimer(context, bundle);
        // タイマ情報クリア
        AppController.getInstance().getModelInterface().deleteTimerInfoByType(bundle.getLong(Constants.TimerControl.SCHEDULE_ID));

    }

}

