/*
 * ファイル：AssistApplication.java
 * 概要：アプリのアプリケーション
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.app;

import android.app.Activity;
import android.app.Application;
import android.arch.lifecycle.DefaultLifecycleObserver;
import android.arch.lifecycle.LifecycleOwner;
import android.arch.lifecycle.ProcessLifecycleOwner;
import android.os.Bundle;
import android.support.annotation.NonNull;

import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.ModelInterface;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.ResourcesUtils;

/**
 * アプリのアプリケーション.
 *
 * @author Systena
 * @version 1.0
 */
public class AssistApplication extends Application
        implements Application.ActivityLifecycleCallbacks {

    @Override
    public void onCreate() {
        AssistLog.i("onCreate");
        super.onCreate();

        initialize();
    }

    /**
     * アプリ初期化処理.
     */
    private void initialize() {
        AssistLog.i("initialize");
        ModelInterface.initDatabase(this);

        AppController.getInstance().init(this);

        registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(new AssistLifecycleEvent());
        ResourcesUtils.initIconResourceMap();
    }

    @Override
    public void onLowMemory() {
        AssistLog.i("onLowMemory");
        super.onLowMemory();
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
        AssistLog.v("onActivityCreated -> " + activity.getClass().getSimpleName());
    }

    @Override
    public void onActivityStarted(Activity activity) {
        AssistLog.v("onActivityStarted -> " + activity.getClass().getSimpleName());
    }

    @Override
    public void onActivityResumed(Activity activity) {
        AssistLog.v("onActivityResumed -> " + activity.getClass().getSimpleName());
    }

    @Override
    public void onActivityPaused(Activity activity) {
        AssistLog.v("onActivityPaused -> " + activity.getClass().getSimpleName());
    }

    @Override
    public void onActivityStopped(Activity activity) {
        AssistLog.v("onActivityStopped -> " + activity.getClass().getSimpleName());
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
        AssistLog.v("onActivitySaveInstanceState -> " + activity.getClass().getSimpleName());
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        AssistLog.v("onActivityDestroyed -> " + activity.getClass().getSimpleName());
    }

    /**
     * ライフサイクルイベント通知用内部クラス.
     */
    private class AssistLifecycleEvent implements DefaultLifecycleObserver {
        @Override
        public void onCreate(@NonNull LifecycleOwner owner) {
            AssistLog.i("Lifecycle -> onCreate");
        }

        @Override
        public void onStart(@NonNull LifecycleOwner owner) {
            AssistLog.i("Lifecycle -> onStart");
            AppController.getInstance().onStartApplication();
        }

        @Override
        public void onResume(@NonNull LifecycleOwner owner) {
            AssistLog.i("Lifecycle -> onResume");
            AppController.getInstance().onResumeApplication();
        }

        @Override
        public void onPause(@NonNull LifecycleOwner owner) {
            AssistLog.i("Lifecycle -> onPause");
            AppController.getInstance().onPauseApplication();
        }

        @Override
        public void onStop(@NonNull LifecycleOwner owner) {
            AssistLog.i("Lifecycle -> onStop");
            AppController.getInstance().onStopApplication();
        }

        @Override
        public void onDestroy(@NonNull LifecycleOwner owner) {
            AssistLog.i("Lifecycle -> onDestroy");
        }
    }
}
