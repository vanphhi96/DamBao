/*
 * ファイル：DateTimePickerDialogFactory.java
 * 概要：Dialog date time picker.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories.customfactories;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import jp.softbank.assist.R;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;

import java.util.Calendar;
import java.util.Date;

/**
 * sch-cr-01, sch-ed-01.
 *
 * @author Systena
 * @version 1.0
 */
public class DateTimePickerDialogFactory extends BaseDialogFactory implements View.OnClickListener {
    private IDateTimePicker mIDateTimePicker;
    private TextView mTvOk;
    private TextView mTvCancel;
    private DatePicker mDatePicker;
    private TimePicker mTimePicker;
    private Date mDate;
    private Enum mDialogType;
    private boolean mIsCreateNew;
    private boolean mIsScheduleAllDay;
    private Date mMinDateEdit;
    Calendar mCalendar = Calendar.getInstance();

    public DateTimePickerDialogFactory(DialogTypeControl.DialogType dialogType, IDateTimePicker iDateTimePicker) {
        this.mDialogType = dialogType;
        this.mIDateTimePicker = iDateTimePicker;
    }

    /**
     * set date start of dialog.
     *
     * @param date
     */
    public void setDate(Date date) {
        this.mDate = date;
    }

    /**
     * is dialog picker for create new schedule.
     *
     * @param isCreateNew true: create schedule, false:edit schedule;
     */
    public void isCreateNew(boolean isCreateNew) {
        this.mIsCreateNew = isCreateNew;
    }

    @Override
    public AlertDialog getReadyAlertDialog(FragmentActivity activity) {
        AlertDialog.Builder builder = createDialogBuilder(activity);
        LayoutInflater inflater = activity.getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_picker, null);
        view.setClipToOutline(true);
        mTvCancel = view.findViewById(R.id.tv_cancel);
        mTvOk = view.findViewById(R.id.tv_ok);
        mDatePicker = view.findViewById(R.id.date_picker);
        mTimePicker = view.findViewById(R.id.time_picker);
        mTimePicker.setEnabled(!mIsScheduleAllDay);
        mTvOk.setOnClickListener(this);
        mTvCancel.setOnClickListener(this);
        setDataDatePicker();
        setDataTimePicker();
        setPositivelyDialog(false);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return alertDialog;
    }


    @Override
    public String getDialogTag() {
        return mDialogType.name();
    }

    @Override
    public void onClick(View v) {
        if (mIDateTimePicker == null) {
            return;
        }
        switch (v.getId()) {
            case R.id.tv_cancel:
                mIDateTimePicker.dismissDialogDateTime();
                break;
            case R.id.tv_ok:
                saveDateTime();
                break;
            default:
                break;
        }
    }


    /**
     * set data for date picker
     */
    public void setDataDatePicker() {
        if (mIsCreateNew) {
            setDataDatePickerCreate();
        } else {
            setDataDatePickerEdit();
        }
    }

    /**
     * set data date picker when create new schedule.
     */
    private void setDataDatePickerCreate() {
        mDatePicker.setMinDate(new Date().getTime());
        mDatePicker.setMaxDate(DateUtils.getMaxDate(new Date()).getTime());
        mCalendar.setTime(mDate);
        mDatePicker.init(mCalendar.get(Calendar.YEAR), mCalendar.get(Calendar.MONTH), mCalendar.get(Calendar.DAY_OF_MONTH), null);
    }

    /**
     * set data date picker when edit schedule.
     */
    private void setDataDatePickerEdit() {
        // start time > current time, set min date picker is current time,
        if (mMinDateEdit.compareTo(new Date()) > 0) {
            mDatePicker.setMinDate(new Date().getTime());
        } else {
            // start time < current time, set min date picker is start time,
            mDatePicker.setMinDate(mMinDateEdit.getTime());
        }
        mDatePicker.setMaxDate(DateUtils.getMaxDate(new Date()).getTime());
        mCalendar.setTime(mDate);
        mDatePicker.init(mCalendar.get(Calendar.YEAR), mCalendar.get(Calendar.MONTH), mCalendar.get(Calendar.DAY_OF_MONTH), null);
    }

    /**
     * set data for time picker
     */
    private void setDataTimePicker() {
        mTimePicker.setIs24HourView(true);
        if (mDate != null) {
            mCalendar.setTime(mDate);
            mTimePicker.setHour(mCalendar.get(Calendar.HOUR_OF_DAY));
            mTimePicker.setMinute(mCalendar.get(Calendar.MINUTE));
        }
    }

    /**
     * set date time when click ok
     */
    private void saveDateTime() {
        mCalendar.set(mDatePicker.getYear(), mDatePicker.getMonth(), mDatePicker.getDayOfMonth(), mTimePicker.getHour(), mTimePicker.getMinute());
        mIDateTimePicker.saveDateTime(mCalendar.getTime());
    }

    /**
     * set schedule is all day
     *
     * @param isScheduleAllDay is schedule all day
     */
    public void isScheduleAllDay(boolean isScheduleAllDay) {
        this.mIsScheduleAllDay = isScheduleAllDay;
    }

    /**
     * set min date picker when edit schedule
     *
     * @param scheduleStartDate
     */
    public void setMinDate(Date scheduleStartDate) {
        this.mMinDateEdit = scheduleStartDate;
    }
}
