/*
 * ファイル：DateUtils.java
 * 概要：DateUtils
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.util;

import android.content.Context;
import android.text.TextUtils;

import jp.softbank.assist.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

/**
 * DateUtils
 *
 * @author Systena
 * @version 1.0
 */
public final class DateUtils {
    public static final String DATE_FORMAT = "dd/MM/yyyy";
    public static final String DATE_PICKER_FORMAT = "yyyy.MM.dd";
    public static final String TIME_PICKER_FORMAT = "HH:mm";
    public static final String DATE_FORMAT_DIC_DETAIL = "yyyy/MM/dd";
    public static final String SCHEDULE_OTHER_DATE_FORMAT = "M/d HH:mm";
    public static final String SCHEDULE_DETAIL_DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm";
    /* Calendar start from the current month of one last year
  until the current month of three years later
  -> TOTAL_MONTH_SHOW = 12 month before + 1 month current + 36 month after = 49 month
  */
    private static final int TOTAL_MONTH_SHOW = 49;
    private static final int PAGE_OF_CURRENT_DAY = 12;
    private static final int MILLISECOND_IN_DAY = 1000 * 60 * 60 * 24;
    // date special 29/2
    public static final int SPECIAL_DAY = 29;
    public static final int SPECIAL_MONTH = Calendar.FEBRUARY;
    // 日時設定要定義
    private static final int SET_TIME_MIN = 0;
    private static final int SET_TIME_HOUR = 23;
    private static final int SET_TIME_MINUTE = 59;

    /**
     * get string of other date
     *
     * @param isNext is after date
     * @param day    day check
     * @return string of date
     */
    public static String getOtherDay(boolean isNext, int day) {
        Calendar calendar = Calendar.getInstance();
        if (isNext) {
            calendar.add(Calendar.DAY_OF_YEAR, +day); // get day after
        } else {
            calendar.add(Calendar.DAY_OF_YEAR, -day); // get day ago
        }
        Date newDate = calendar.getTime();
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        return dateFormat.format(newDate);
    }

    /**
     * create list date
     *
     * @param dateStart date start
     * @param dateEnd   date end
     * @return list Date
     */
    private static ArrayList<Date> getDates(String dateStart, String dateEnd) {
        ArrayList<Date> dates = new ArrayList<Date>();
        DateFormat df1 = new SimpleDateFormat(DATE_FORMAT);

        Date date1;
        Date date2;

        try {
            date1 = df1.parse(dateStart);
            date2 = df1.parse(dateEnd);
            Calendar cal1 = Calendar.getInstance();
            cal1.setTime(date1);
            Calendar cal2 = Calendar.getInstance();
            cal2.setTime(date2);
            while (!cal1.after(cal2)) {
                dates.add(cal1.getTime());
                cal1.add(Calendar.DATE, 1);
            }
        } catch (ParseException e) {
            AssistLog.e(e.toString());
        }
        return dates;
    }

    /**
     * convert day to string japanese
     *
     * @param day     day convert
     * @param context context
     * @return string day of week in japanese
     */
    public static String convertDateToStringJapan(int day, Context context) {
        switch (day) {
            case 1:
                return context.getString(R.string.sch_sat_brackets);
            case 2:
                return context.getString(R.string.sch_mon_brackets);
            case 3:
                return context.getString(R.string.sch_tue_brackets);
            case 4:
                return context.getString(R.string.sch_wed_brackets);
            case 5:
                return context.getString(R.string.sch_thu_brackets);
            case 6:
                return context.getString(R.string.sch_fri_brackets);
            case 7:
                return context.getString(R.string.sch_sat_brackets);
            default:
                return null;
        }
    }

    /**
     * get current time for mat HH:mm
     *
     * @return string date format HH:,,
     */
    public static String getCurrentHour() {
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.HOUR_OF_DAY) + ":" + (calendar.get(Calendar.MINUTE) < 10 ?
                "0" + calendar.get(Calendar.MINUTE) : calendar.get(Calendar.MINUTE));
    }

    /**
     * convert string date to Date.
     *
     * @param strDate string date.
     * @return string date.
     */
    public static Date convertStringToDate(String strDate) {
        if (TextUtils.isEmpty(strDate)) {
            return null;
        }
        SimpleDateFormat formatDate = new SimpleDateFormat(DATE_PICKER_FORMAT);
        try {
            Date date = formatDate.parse(strDate);
            return date;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * convert string time to Time.
     *
     * @param strTime string time.
     * @return string date.
     */
    public static Date convertStringToTime(String strTime) {
        if (TextUtils.isEmpty(strTime)) {
            return null;
        }
        SimpleDateFormat formatDate = new SimpleDateFormat(TIME_PICKER_FORMAT);
        try {
            Date date = formatDate.parse(strTime);
            return date;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * get max date of dialog picker.
     *
     * @param dateStart Date
     * @return max Date
     */
    public static Date getMaxDate(Date dateStart) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dateStart);
        int maxYear = calendar.get(Calendar.YEAR) + 3;
        int maxDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        int maxMonth = calendar.get(calendar.MONTH);
        calendar.set(maxYear, maxMonth, maxDay);
        return calendar.getTime();
    }

    /**
     * compare  start  date and  end date.
     *
     * @param dateStart start date.
     * @param dateEnd   end date.
     * @param startTime start time.
     * @param endTime   end time.
     * @return true: date same, false: not same date
     */
    public static boolean compareDate(String dateStart, String dateEnd, String startTime, String endTime) {
        if (TextUtils.isEmpty(dateStart) || TextUtils.isEmpty(dateEnd)) {
            return false;
        }
        SimpleDateFormat formatDate = new SimpleDateFormat(DATE_PICKER_FORMAT);
        try {
            Calendar calendar = Calendar.getInstance();
            Date date = formatDate.parse(dateStart);
            calendar.setTime(date);
            int startYear = calendar.get(Calendar.YEAR);
            int startMonth = calendar.get(Calendar.MONTH);
            int startDay = calendar.get(Calendar.DAY_OF_MONTH);
            date = formatDate.parse(dateEnd);
            calendar.setTime(date);
            int endYear = calendar.get(Calendar.YEAR);
            int endMonth = calendar.get(Calendar.MONTH);
            int endDay = calendar.get(Calendar.DAY_OF_MONTH);
            if (endYear < startYear || endYear == startYear && endMonth < startMonth ||
                    endYear == startYear && endMonth == startMonth && endDay < startDay
                    || endYear == startYear && endMonth == startMonth && endDay == startDay && compareTime(startTime, endTime)) {
                return true;
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * compare start time and end time.
     *
     * @param startTime start time.
     * @param endTime   end time.
     * @return true: same time, false: not same time.
     */
    public static boolean compareTime(String startTime, String endTime) {
        if (TextUtils.isEmpty(startTime) || TextUtils.isEmpty(endTime)) {
            return false;
        }
        SimpleDateFormat formatDate = new SimpleDateFormat(TIME_PICKER_FORMAT);
        try {
            Calendar calendar = Calendar.getInstance();
            Date date = formatDate.parse(startTime);
            calendar.setTime(date);
            int startHour = calendar.get(Calendar.HOUR_OF_DAY);
            int startMin = calendar.get(Calendar.MINUTE);
            date = formatDate.parse(endTime);
            calendar.setTime(date);
            int endHour = calendar.get(Calendar.HOUR_OF_DAY);
            int endMin = calendar.get(Calendar.MINUTE);
            if (endHour < startHour || endHour == startHour && endMin < startMin) {
                return true;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * add 0 before value datetime < 10.
     *
     * @param value value datetime.
     * @return String with 0 before value <10.
     */
    public static String convertValueOneCharacter(int value) {
        return value < 10 ? "0" + value : String.valueOf(value);
    }

    /**
     * convert date to string format yyyy/MM/dd
     *
     * @param date Date convert.
     * @return String date.
     */
    public static String convertDateString(Date date) {
        if (date == null) {
            return "";
        }
        SimpleDateFormat fm = new SimpleDateFormat(DATE_FORMAT_DIC_DETAIL, Locale.getDefault());
        return fm.format(date);
    }

    /**
     * 現在の日時を取得する
     *
     * @return 現在日付
     */
    public static Date getDateNow() {
        return new Date(System.currentTimeMillis());
    }

    /**
     * 指定のフィールド、指定数だけ日時を変更する
     *
     * @param date   変更する日付の元データ
     * @param field  Calendarフィールド指定
     * @param amount フィールドを加算/減算する値
     * @return 変更した日付
     */
    public static Date getDateAdd(Date date, int field, int amount) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(field, amount);
        return cal.getTime();
    }

    /**
     * 日時を現在からのミリ秒に変換する(タイマ設定用)
     *
     * @param date 変換する日時
     * @return ミリ秒
     */
    public static long getTimerSetMillis(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal.getTimeInMillis();
    }

    /**
     * 日付のみ同一かチェックする
     *
     * @param chkDate  チェック対象日付
     * @param baseDate 基準日付
     * @return true:有効、false:無効
     */
    public static boolean dateCompare(Date chkDate, Date baseDate) {
        return (truncate(chkDate, false).compareTo(truncate(baseDate, false)) == 0);
    }

    /**
     * 日時の「時刻」を変更して返却する
     *
     * @param datetime 日時
     * @param flg      true 00:00に変更/false 23:59に変更
     * @return 時間変更後の日付
     */
    public static Date truncate(Date datetime, boolean flg) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(datetime);

        Date date;
        if (flg) {
            date = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                    cal.get(Calendar.DATE), SET_TIME_MIN, SET_TIME_MIN, SET_TIME_MIN).getTime();
        } else {
            date = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                    cal.get(Calendar.DATE), SET_TIME_HOUR, SET_TIME_MINUTE, SET_TIME_MIN).getTime();
        }
        return date;
    }


    /**
     * get time format HH:mm in date
     *
     * @param date Date
     * @return time in Date
     */
    public static String getTimeInDate(Date date) {
        if (date == null) {
            return "";
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return convertValueOneCharacter(calendar.get(Calendar.HOUR_OF_DAY)) + ":" + convertValueOneCharacter(calendar.get(Calendar.MINUTE));
    }

    /**
     * compare start time and end time of schedule
     *
     * @param endTime   end time.
     * @param startTime start time.
     * @return true: start time < end time, false: start time>= end time
     */
    public static boolean compareTimeSchedule(Date endTime, Date startTime) {
        if (endTime == null || startTime == null) {
            return false;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(endTime);
        int currentHour = calendar.get(Calendar.HOUR_OF_DAY);
        int currentMin = calendar.get(Calendar.MINUTE);
        calendar.setTime(startTime);
        int startHour = calendar.get(Calendar.HOUR_OF_DAY);
        int startMin = calendar.get(Calendar.MINUTE);
        if (currentHour < startHour || currentHour == startHour && currentMin < startMin) {
            return true;
        }
        return false;
    }

    /**
     * compare date yyyy/MM/dd, don't compare HH:mm:ss
     *
     * @param dateOne Date one
     * @param dateTwo Date two
     * @return true: date one same date two.
     */
    public static boolean compareEqualDate(Date dateOne, Date dateTwo) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dateOne);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        Date date1 = calendar.getTime();
        calendar.setTime(dateTwo);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        Date date2 = calendar.getTime();
        return date1.compareTo(date2) == 0;
    }

    /**
     * compare start time and end time.
     *
     * @param date date convert.
     * @return String date.
     */
    public static String convertDateToString(Date date, String format) {
        if (date == null) {
            return "";
        }
        SimpleDateFormat formatDate = new SimpleDateFormat(format);
        return formatDate.format(date);
    }

    /**
     * compare date yyyy/MM/dd HH:mm, don't compare seconds(ss)
     *
     * @param date        Date
     * @param anotherDate another date
     * @return -1: date < another date, 0: date = another date, 1: date > another date.
     */
    public static int compareTo(Date date, Date anotherDate) {
        long thisTime = date.getTime() / Constants.Schedule.MILLISECONDS;
        long anotherTime = anotherDate.getTime() / Constants.Schedule.MILLISECONDS;
        return (thisTime < anotherTime ? -1 : (thisTime == anotherTime ? 0 : 1));
    }

    /**
     * create list date for calendar
     *
     * @return list date
     */
    public static List<Date> createListCalendar() {
        List<Date> list = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MONTH, -PAGE_OF_CURRENT_DAY);
        while (list.size() < TOTAL_MONTH_SHOW) {
            list.add(calendar.getTime());
            calendar.add(Calendar.MONTH, 1);
        }
        return list;
    }

    /**
     * compare date yyyy/MM
     *
     * @param date        Date
     * @param anotherDate another date
     * @return true: date = another date, false: date != another date.
     */
    public static boolean compareEqualMonth(Date date, Date anotherDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        calendar.setTime(anotherDate);
        int currentYear = calendar.get(Calendar.YEAR);
        int currentMonth = calendar.get(Calendar.MONTH);
        return year == currentYear && month == currentMonth;
    }

    /**
     * get total day from first day of the current month in a year ago to last day of the current month in three years later
     *
     * @return total day
     */
    public static int getTotalDay() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, -1);// move calendar to a year ago.
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.set(Calendar.HOUR, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        Date startTime = calendar.getTime();
        calendar.setTime(new Date());
        calendar.add(Calendar.YEAR, 3);// move calendar to three years later.
        int maxDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        calendar.set(Calendar.DAY_OF_MONTH, maxDay);
        calendar.set(Calendar.HOUR, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        Date endTime = calendar.getTime();
        return (int) ((endTime.getTime() - startTime.getTime()) / MILLISECOND_IN_DAY);
    }

    /**
     * create list day in sch-01.
     *
     * @return list days
     */
    public static List<Date> createListDays() {
        List<Date> listDate = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, -1);// move calendar to a year ago.
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        while (listDate.size() <= getTotalDay()) {
            listDate.add(calendar.getTime());
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }
        return listDate;
    }

    /**
     * find position of day in list days.
     *
     * @param date date.
     * @return list date.
     */
    public static int findPositionOfPage(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, -1);// move calendar to a year ago.
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.set(Calendar.HOUR, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        Date startTime = calendar.getTime();
        calendar.setTime(date);
        Date endTime = calendar.getTime();
        calendar.set(Calendar.HOUR, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return (int) ((endTime.getTime() - startTime.getTime()) / MILLISECOND_IN_DAY);
    }

    /**
     * Convert Date to String
     *
     * @param date
     * @return
     */
    public static String convertDateToStringSetting(Date date) {
        return new SimpleDateFormat(TIME_PICKER_FORMAT, Locale.JAPAN).format(date);
    }

    /**
     * For example :
     * Input 1 : Fri Apr 19 13:30:14 GMT+09:00 2019
     * Input 2 : Fri Apr 19 20:30:14 GMT+09:00 2019
     * Output : 13:30 ~ 20:30
     *
     * @param start
     * @param end
     * @return
     */
    public static String convertToHourDisplaySetting(Date start, Date end) {
        return convertDateToStringSetting(start) + " : " + convertDateToStringSetting(end);
    }

    /**
     * Get date from Time Picker
     *
     * @param hour
     * @param minute
     * @return
     */
    public static Date getDateFromTimePicker(int hour, int minute) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        return calendar.getTime();
    }

    /**
     * Get hour(int) from Date
     *
     * @param date
     * @return
     */
    public static int getHourFromDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.HOUR_OF_DAY);
    }

    /**
     * Get minute(int) from Date
     *
     * @param date
     * @return
     */
    public static int getMinFromDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.MINUTE);
    }

    /**
     * check date is special day Feb 29.
     * @param date
     * @return
     */
    public static boolean checkSpecialDate(Date date) {
        if (date == null) {
            return false;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DAY_OF_MONTH) == SPECIAL_DAY && calendar.get(Calendar.MONTH) == SPECIAL_MONTH;
    }
}
