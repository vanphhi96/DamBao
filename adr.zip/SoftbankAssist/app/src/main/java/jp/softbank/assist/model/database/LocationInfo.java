/*
 * ファイル：LocationInfo.java
 * 概要：位置測位結果情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

/**
 * 位置測位結果情報.
 */
public class LocationInfo {

    /**
     * 登録種別.
     */
    public enum RegistType {
        Regularly(0), // 定期登録
        Request(1), // 取得リクエスト
        Fence(2), // みまもるフェンス
        ;

        private final long mValue;

        private RegistType(final long value) {
            this.mValue = value;
        }

        public long getValue() {
            return mValue;
        }

        /**
         * 数値からenumへの変換.
         *
         * @param value 数値
         * @return RegistType
         */
        public static RegistType fromValue(final long value) {
            RegistType[] list = RegistType.values();
            for (RegistType item : list) {
                if (item.getValue() == value) {
                    return item;
                }
            }
            return Regularly;
        }
    }

    /**
     * ステータス.
     */
    public enum Status {
        Success(0), // 正常取得
        Failed(11), // 取得失敗
        MobileSettingOff(21), // 端末設定で位置情報取得OFF
        ApplicationSettingOff(22), // アプリ設定で位置情報取得OFF
        ;

        private final long mValue;

        private Status(final long value) {
            this.mValue = value;
        }

        public long getValue() {
            return mValue;
        }

        /**
         * 数値からenumへの変換.
         *
         * @param value 数値
         * @return Status
         */
        public static Status fromValue(final long value) {
            Status[] list = Status.values();
            for (Status item : list) {
                if (item.getValue() == value) {
                    return item;
                }
            }
            return Failed;
        }
    }


    private RegistType mRegistType; // 登録種別
    private Status mStatus; // ステータス
    private double mLatitude; // 緯度
    private double mLongitude; // 経度
    private double mTolerance; // 誤差(m)


    public RegistType getRegistType() {
        return mRegistType;
    }

    public void setRegistType(RegistType type) {
        this.mRegistType = type;
    }

    public Status getStatus() {
        return mStatus;
    }

    public void setStatus(Status status) {
        this.mStatus = status;
    }

    public double getLatitude() {
        return mLatitude;
    }

    public void setLatitude(double latitude) {
        this.mLatitude = latitude;
    }

    public double getLongitude() {
        return mLongitude;
    }

    public void setLongitude(double longitude) {
        this.mLongitude = longitude;
    }

    public double getTolerance() {
        return mTolerance;
    }

    public void setTolerance(double tolerance) {
        this.mTolerance = mTolerance;
    }
}
