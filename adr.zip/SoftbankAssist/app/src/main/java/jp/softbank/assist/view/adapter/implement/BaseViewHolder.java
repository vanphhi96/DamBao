/*
 * ファイル：BaseViewHolder.java
 * 概要：Base class of view holder
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter.implement;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Base class of view holder
 *
 * @author Systena
 * @version 1.0
 */
public abstract class BaseViewHolder<T extends RecyclerView.ViewHolder>
        extends RecyclerView.ViewHolder {
    /**
     * base view holder
     *
     * @param itemView view item
     */
    public BaseViewHolder(@NonNull View itemView) {
        super(itemView);
    }

    /**
     * fill data to holder
     *
     * @param position
     */
    public abstract void onBindView(int position);
}
