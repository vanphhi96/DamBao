/*
 * ファイル：SetModel.java
 * 概要：Model set top (set-01).
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model;

/**
 * set-01.
 *
 * @author Systena
 * @version 1.0
 */
public class SetModel {
    private String mTitle;
    private String mDescription;
    private int mDrawable;

    public SetModel(String title, String description, int drawable) {
        this.mTitle = title;
        this.mDescription = description;
        this.mDrawable = drawable;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        this.mTitle = title;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        this.mDescription = description;
    }

    public int getDrawable() {
        return mDrawable;
    }

    public void setDrawable(int drawable) {
        this.mDrawable = drawable;
    }
}
