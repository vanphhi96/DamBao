/*
 * ファイル：CheckAppUiActivity.java
 * 概要：アプリ起動時のチェック画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.main;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.ImageView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.AppVersionInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetAppVersionResultListener;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BasePermissionUiActivity;

/**
 * アプリ起動時のチェック画面
 *
 * @author Systena
 * @version 1.0
 */
public class CheckAppUiActivity extends BasePermissionUiActivity implements GetAppVersionResultListener {

    public static final String APP_VERSION_KEY = "APP VERSION KEY";
    private AnimationDrawable mAnim;
    private ImageView mImgLoading;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chk_01);
        mImgLoading = findViewById(R.id.img_anim);
        mAnim = (AnimationDrawable) mImgLoading.getDrawable();
        mAnim.start();
        addPermission();
    }

    @Override
    protected void onDestroy() {
        mAnim.stop();
        super.onDestroy();
    }

    @Override
    public void onResult(AssistServerResult result, AppVersionInfo info) {
        if (info == null) {
            changeScreen(ScreenId.START_MENU);
        } else {
            if (info.isForceUpdate() && !Constants.DBG_DISABLE_UPDATE) {
                // Current version # latest version
                Bundle bundle = new Bundle();
                bundle.putSerializable(APP_VERSION_KEY, info);
                changeScreen(ScreenId.START_UPDATE_NOTICE, bundle);
            } else {
                // TODO: 2019/04/03 まだデザインがありません。一旦 MenuUiActivityに移動.
                // If Current version = latest version
                changeScreen(ScreenId.START_MENU);
            }
        }
        finish();
    }

    @Override
    public void onStartConnection() {
    }
}
