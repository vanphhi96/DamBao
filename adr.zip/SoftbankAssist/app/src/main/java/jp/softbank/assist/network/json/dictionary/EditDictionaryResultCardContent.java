/*
 * ファイル：EditDictionaryResultCardContent.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

/**
 * カード内容結果.
 */
public class EditDictionaryResultCardContent {

    @SerializedName("card_id")
    private String mCardId = null;
    @SerializedName("version")
    private Long mVersion = null;
    @SerializedName("mText")
    private String mText = null;
    @SerializedName("image")
    private String mImage = null;


    /**
     * カードID.
     */
    public String getCardId() {
        return mCardId;
    }
    public void setCardId(String cardId) {
        this.mCardId = cardId;
    }

    /**
     * カードバージョン.
     */
    public Long getVersion() {
        return mVersion;
    }
    public void setVersion(Long version) {
        this.mVersion = version;
    }

    /**
     * カードテキスト.
     */
    public String getText() {
        return mText;
    }
    public void setText(String text) {
        this.mText = text;
    }

    /**
     * カード画像パス.
     */
    public String getImage() {
        return mImage;
    }
    public void setImage(String image) {
        this.mImage = image;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EditDictionaryResultCardContent cardContent = (EditDictionaryResultCardContent) o;
        return (this.mCardId == null ? cardContent.mCardId == null : this.mCardId.equals(cardContent.mCardId)) &&
                (this.mVersion == null ? cardContent.mVersion == null : this.mVersion.equals(cardContent.mVersion)) &&
                (this.mText == null ? cardContent.mText == null : this.mText.equals(cardContent.mText)) &&
                (this.mImage == null ? cardContent.mImage == null : this.mImage.equals(cardContent.mImage));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mCardId == null ? 0: this.mCardId.hashCode());
        result = 31 * result + (this.mVersion == null ? 0: this.mVersion.hashCode());
        result = 31 * result + (this.mText == null ? 0: this.mText.hashCode());
        result = 31 * result + (this.mImage == null ? 0: this.mImage.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class EditDictionaryResultCardContent {\n");

        sb.append("  mCardId: ").append(mCardId).append("\n");
        sb.append("  mVersion: ").append(mVersion).append("\n");
        sb.append("  mText: ").append(mText).append("\n");
        sb.append("  mImage: ").append(mImage).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
