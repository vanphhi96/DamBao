/*
 * ファイル：IGetImageDic.java
 * 概要：
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.activity.dictionary;

/**
 * call back for get image dictionary
 * @author Systena
 * @version 1.0
 */
public interface IGetImageDic {
    /**
     * set onClick item dic of dic-02
     */
    void getImageDictionary(int position);

}
