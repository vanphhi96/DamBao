/*
 * ファイル：GetScheduleResultSchedule.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.schedule;

import com.google.gson.annotations.SerializedName;

/**
 * スケジュール日時情報.
 */
public class GetScheduleResultSchedule {

    @SerializedName("schedule_id")
    private Long mScheduleId = null;
    @SerializedName("schedule_meta_id")
    private Long mScheduleMetaId = null;
    @SerializedName("schedule_from_on")
    private String mScheduleFromOn = null;
    @SerializedName("schedule_to_on")
    private String mScheduleToOn = null;
    @SerializedName("is_completed")
    private Long mIsCompleted = null;
    @SerializedName("is_all_day")
    private Long mIsAllDay = null;


    /**
     * スケジュール日時ID.
     */
    public Long getScheduleId() {
        return mScheduleId;
    }
    public void setScheduleId(Long scheduleId) {
        this.mScheduleId = scheduleId;
    }

    /**
     * スケジュール内容ID.
     */
    public Long getScheduleMetaId() {
        return mScheduleMetaId;
    }
    public void setScheduleMetaId(Long scheduleMetaId) {
        this.mScheduleMetaId = scheduleMetaId;
    }

    /**
     * スケジュール開始日時（YYYYMMDDhhmm形式）.
     */
    public String getScheduleFromOn() {
        return mScheduleFromOn;
    }
    public void setScheduleFromOn(String scheduleFromOn) {
        this.mScheduleFromOn = scheduleFromOn;
    }

    /**
     * スケジュール終了日時（YYYYMMDDhhmm形式）.
     */
    public String getScheduleToOn() {
        return mScheduleToOn;
    }
    public void setScheduleToOn(String scheduleToOn) {
        this.mScheduleToOn = scheduleToOn;
    }

    /**
     * 完了済フラグ（0：未完了、1：完了）.
     */
    public Long getIsCompleted() {
        return mIsCompleted;
    }
    public void setIsCompleted(Long isCompleted) {
        this.mIsCompleted = isCompleted;
    }

    /**
     * 終日フラグ（0：無効、1：有効）.
     */
    public Long getIsAllDay() {
        return mIsAllDay;
    }
    public void setIsAllDay(Long isAllDay) {
        this.mIsAllDay = isAllDay;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GetScheduleResultSchedule schedule = (GetScheduleResultSchedule) o;
        return (this.mScheduleId == null ? schedule.mScheduleId == null : this.mScheduleId.equals(schedule.mScheduleId)) &&
                (this.mScheduleMetaId == null ? schedule.mScheduleMetaId == null : this.mScheduleMetaId.equals(schedule.mScheduleMetaId)) &&
                (this.mScheduleFromOn == null ? schedule.mScheduleFromOn == null : this.mScheduleFromOn.equals(schedule.mScheduleFromOn)) &&
                (this.mScheduleToOn == null ? schedule.mScheduleToOn == null : this.mScheduleToOn.equals(schedule.mScheduleToOn)) &&
                (this.mIsCompleted == null ? schedule.mIsCompleted == null : this.mIsCompleted.equals(schedule.mIsCompleted)) &&
                (this.mIsAllDay == null ? schedule.mIsAllDay == null : this.mIsAllDay.equals(schedule.mIsAllDay));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mScheduleId == null ? 0: this.mScheduleId.hashCode());
        result = 31 * result + (this.mScheduleMetaId == null ? 0: this.mScheduleMetaId.hashCode());
        result = 31 * result + (this.mScheduleFromOn == null ? 0: this.mScheduleFromOn.hashCode());
        result = 31 * result + (this.mScheduleToOn == null ? 0: this.mScheduleToOn.hashCode());
        result = 31 * result + (this.mIsCompleted == null ? 0: this.mIsCompleted.hashCode());
        result = 31 * result + (this.mIsAllDay == null ? 0: this.mIsAllDay.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class GetScheduleResultSchedule {\n");

        sb.append("  mScheduleId: ").append(mScheduleId).append("\n");
        sb.append("  mScheduleMetaId: ").append(mScheduleMetaId).append("\n");
        sb.append("  mScheduleFromOn: ").append(mScheduleFromOn).append("\n");
        sb.append("  mScheduleToOn: ").append(mScheduleToOn).append("\n");
        sb.append("  mIsCompleted: ").append(mIsCompleted).append("\n");
        sb.append("  mIsAllDay: ").append(mIsAllDay).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
