/*
 * ファイル：EditDictionaryInfo.java
 * 概要：辞書情報（編集時）
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import android.graphics.Bitmap;
import android.text.TextUtils;

import jp.softbank.assist.model.ModelInterface;
import jp.softbank.assist.util.Constants;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 辞書情報（編集時）.
 *
 * @author Systena
 * @version 1.0
 */
public class EditDictionaryInfo extends DictionaryInfo {

    private final DictionaryInfo mOrigin;
    private boolean mEdited = false; // TODO:unused


    /**
     * コンストラクタ.
     *
     * @param info 編集元の辞書情報
     */
    public EditDictionaryInfo(DictionaryInfo info) {
        setDictionaryId(info.getDictionaryId());
        setCategoryId(info.getCategoryId());
        setType(info.getType());
        setName(info.getName());
        setImageUrl(info.getImageUrl());
        setImageFileName(info.getImageFileName());
        setIsMemorize(info.isMemorize());
        setCreatorNickname(info.getCreatorNickname());
        setCreatorIconId(info.getCreatorIconId());
        setCreatedDate((Date)info.getCreatedDate().clone());
        setUpdatedDate((Date)info.getUpdatedDate().clone());
        setIsDeleted(info.isDeleted());

        List<CardInfo> listEdit = new ArrayList<CardInfo>();
        List<CardInfo> list = info.getCardList();
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                CardInfo card = list.get(i);
                listEdit.add(new EditCardInfo(card));
            }
        }
        setCardList(listEdit);

        mOrigin = info;
        mEdited = false;
    }

    @Override
    public void setCategoryId(long categoryId) {
        super.setCategoryId(categoryId);
        if (categoryId == Constants.Ids.CATEGORY_ID_PROPERTY) {
            setType(DictionaryType.Check);
        } else {
            setType(DictionaryType.Step);
        }
        mEdited = true;
    }

    @Override
    public void setName(String name) {
        super.setName(name);
        mEdited = true;
    }



    /**
     * 編集済みか確認する.
     *
     * @return true:編集済み、false:未編集
     */
    @Override
    public boolean isEdited() {
        if (mOrigin == null) {
            return false; // あり得ないエラー
        }

        if (getCategoryId() != mOrigin.getCategoryId()) {
            return true;
        }
        if (getType() != mOrigin.getType()) {
            return true;
        }
        if (!TextUtils.equals(getName(), mOrigin.getName())) {
            return true;
        }
        if (!TextUtils.equals(getImageUrl(), mOrigin.getImageUrl())) {
            return true;
        }
        if (!TextUtils.equals(getImageFileName(), mOrigin.getImageFileName())) {
            return true;
        }

        List<CardInfo> list = getCardList();
        List<CardInfo> listOrigin = mOrigin.getCardList();
        if (listOrigin != null && list.size() != listOrigin.size()) {
            return true;
        }
        for (int i = 0; i < list.size(); i++) {
            CardInfo card = list.get(i);
            if (card.isEdited()) {
                return true;
            }
        }

        return false;
    }

    /**
     * 追加・編集時のキャンセル.
     */
    @Override
    public void cancel() {
        getImagePath(Constants.Dictionary.DICTIONARY_TEMP_IMAGE_FILENAME).delete();
        if (getCardList() != null && getCardList().size() > 0) {
            for(CardInfo cardInfo: getCardList()){
                cardInfo.cancel();
            }
        }
    }

    /**
     * 画像ファイルが有効（保存済み）か確認する.
     *
     * @return true:有効、false:無効
     */
    @Override
    public boolean isImageEnabled() {
        return Constants.Dictionary.DICTIONARY_TEMP_IMAGE_FILENAME.equals(getImageFileName()) ||
                Constants.Dictionary.DICTIONARY_IMAGE_FILENAME.equals(getImageFileName());
    }

    /**
     * 画像の保存.
     *
     * @param bitmap ビットマップ
     * @return true:成功、false:失敗
     */
    @Override
    public boolean setImage(Bitmap bitmap) {
        bitmap = ModelInterface.scaleDictionaryImage(bitmap);
        boolean result = ModelInterface.saveDictionaryImage(bitmap,
                getImagePath(Constants.Dictionary.DICTIONARY_TEMP_IMAGE_FILENAME));
        if (result) {
            setImageFileName(Constants.Dictionary.DICTIONARY_TEMP_IMAGE_FILENAME);
            mEdited = true;
        }
        return result;
    }

    /**
     * 画像設定の削除.
     */
    @Override
    public void clearImage() {
        getImagePath(Constants.Dictionary.DICTIONARY_TEMP_IMAGE_FILENAME).delete();
        setImageUrl("");
        setImageFileName("");
        mEdited = true;
    }

    /**
     * 画像ファイルパスの取得.
     *
     * @return ファイルパス
     */
    @Override
    public String getImageFileAbsolutePath() {
        if (isImageEnabled()) {
            File file = getImagePath(getImageFileName());
            if (file.exists()) {
                return file.getAbsolutePath();
            }
        }
        return null;
    }

    /**
     * カードの追加（インデックス指定）.
     *
     * @param index インデックス。範囲外の場合は最後に追加
     * @return CardInfo:成功、null:失敗
     */
    @Override
    public CardInfo addCard(final int index) {
        List<CardInfo> list = getCardList();
        if (list != null) {
            if (list.size() < Constants.Dictionary.MAX_CARD_NUM) {
                TempCardInfo card = TempCardInfo.newInstance(getDictionaryId());
                if (index >= 0 && index < list.size()) {
                    list.add(index, card);
                } else {
                    list.add(card);
                }
                return card;
            }
        }
        return null;
    }
}
