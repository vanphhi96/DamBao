/*
 * ファイル：SchPageFragment.java
 * 概要：Fragment Page Content Schedule
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment.schedule;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetScheduleListResultListener;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.main.MenuUiActivity;
import jp.softbank.assist.view.adapter.ListItemAllDayAdapter;
import jp.softbank.assist.view.adapter.SchListAdapter;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;
import jp.softbank.assist.view.dialog.factories.customfactories.ISchDetailDialog;
import jp.softbank.assist.view.dialog.factories.customfactories.SchDetailDialogFactory;
import jp.softbank.assist.view.fragment.BaseFragment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * sch-01
 *
 * @author Systena
 * @version 1.0
 */
@SuppressLint("ValidFragment")
public class SchPageFragment extends BaseFragment implements ISchPageFragment, ISchDetailDialog,
        View.OnClickListener, GetScheduleListResultListener {
    private Date mDate;
    private SchListAdapter mAdapter;
    private List<ScheduleInfo> mListSchedule = new ArrayList<>();
    private List<ScheduleInfo> mListScheduleAllDay = new ArrayList<>();
    private List<ScheduleInfo> mListScheduleAllDayOneItem = new ArrayList<>();

    private ListItemAllDayAdapter mAdapterScheduleAllDay;
    private LinearLayout mLayoutShowMoreAllDay;
    private ImageView mImgShowMore;
    private TextView mTvShowMore;
    private LinearLayout mLnNoPlans;
    private LinearLayout mLnNotice;
    private RecyclerView mRvScheduleAllDay;
    private RecyclerView mRvSchedule;

    private boolean mFlagShowMoreItemAllDay;
    private DialogFragment mDialogSchDetail;
    private MenuUiActivity mCurrentActivity;
    private String mDialogTag;
    private ScheduleInfo mScheduleEdit;
    private ImageView mImgLoading;
    private AnimationDrawable mAnim;
    private ScheduleInfo mScheduleShowDetail;
    private int mIconUser;
    private FrameLayout mFrameLoading;

    /**
     * init schedule page fragment
     *
     * @param date
     */
    public SchPageFragment(Date date) {
        this.mDate = date;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCurrentActivity = (MenuUiActivity) getActivity();
        mCurrentActivity.setCurrentFraggment(this);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_schedule_page, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRvSchedule = view.findViewById(R.id.recycler_schedule);
        mLayoutShowMoreAllDay = view.findViewById(R.id.ll_show_more_item_all_day);
        mImgShowMore = view.findViewById(R.id.img_show_more);
        mTvShowMore = view.findViewById(R.id.tv_show_more);
        mLnNoPlans = view.findViewById(R.id.ln_no_plans);
        mLnNotice = view.findViewById(R.id.ln_notice);
        mRvScheduleAllDay = view.findViewById(R.id.list_item_all_day);
        mFrameLoading = view.findViewById(R.id.fr_loading);
        mImgLoading = view.findViewById(R.id.img_anim);
        mAnim = (AnimationDrawable) mImgLoading.getDrawable();

        mLayoutShowMoreAllDay.setOnClickListener(this);
        initRvSchedule();
        initRvScheduleAllDay();
        updateRvListSchedule();
        updateRvScheduleAllDay();
        mIconUser = AppController.getInstance().getAssistServerInterface().getMyUserIcon();
        AppController.getInstance().getAssistServerInterface().getScheduleList(mDate, this);

    }

    /**
     * update list schedule
     */
    private void updateRvListSchedule() {
        if (mListSchedule.size() == 0) {
            mLnNoPlans.setVisibility(View.VISIBLE);
            mRvSchedule.setVisibility(View.GONE);
            mRvScheduleAllDay.setVisibility(View.GONE);
            mLnNotice.setVisibility(View.GONE);
        } else {
            mLnNoPlans.setVisibility(View.GONE);
            mRvSchedule.setVisibility(View.VISIBLE);
            updateRvScheduleAllDay();
            mAdapter.setListScheduleModel(mListSchedule);
            mAdapter.notifyFooterChanged();
        }
    }

    /**
     * init list schedule.
     */
    private void initRvSchedule() {
        mListSchedule.clear();
        mAdapter = new SchListAdapter();
        mAdapter.setDate(mDate);
        mAdapter.setListScheduleModel(mListSchedule);
        mAdapter.setInterface(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRvSchedule.setLayoutManager(layoutManager);
        mRvSchedule.setAdapter(mAdapter);
    }

    /**
     * init list schedule all day.
     */
    private void initRvScheduleAllDay() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRvScheduleAllDay.setLayoutManager(layoutManager);
        mAdapterScheduleAllDay = new ListItemAllDayAdapter();
        mAdapterScheduleAllDay.setList(mListScheduleAllDayOneItem);
        mRvScheduleAllDay.setAdapter(mAdapterScheduleAllDay);
    }

    /**
     * update list schedule all day
     */
    private void updateRvScheduleAllDay() {
        mListScheduleAllDay = getListScheduleAllDay(mListSchedule);
        sortListScheduleByStartDate(mListScheduleAllDay);
        if (mListScheduleAllDay.size() <= 0) {
            mLayoutShowMoreAllDay.setVisibility(View.GONE);
            mRvScheduleAllDay.setVisibility(View.GONE);
        } else {
            if (mListScheduleAllDay.size() <= 2) {
                mLayoutShowMoreAllDay.setVisibility(View.GONE);
                mAdapterScheduleAllDay.setList(mListScheduleAllDay);
            } else {
                mListScheduleAllDayOneItem.clear();
                mListScheduleAllDayOneItem.add(mListScheduleAllDay.get(0));
                mLayoutShowMoreAllDay.setVisibility(View.VISIBLE);
                mTvShowMore.setText(String.format(mTvShowMore.getContext().getString(R.string.sch_allday_number), mListScheduleAllDay.size() - 1));
                mImgShowMore.setImageDrawable(mImgShowMore.getContext().getDrawable(R.drawable.ic_schedule_down));
            }
            mRvScheduleAllDay.setVisibility(View.VISIBLE);
            mAdapterScheduleAllDay.notifyFooterChanged();
        }
    }

    /**
     * get list schedule all day from list schedule
     *
     * @param listSchedule
     * @return
     */
    private List<ScheduleInfo> getListScheduleAllDay(List<ScheduleInfo> listSchedule) {
        List<ScheduleInfo> list = new ArrayList<>();
        for (ScheduleInfo ScheduleInfo : listSchedule) {
            if (ScheduleInfo.isAllDay()) {
                list.add(ScheduleInfo);
            }
        }
        return list;
    }


    @Override
    public void onClickSchedule(ScheduleInfo scheduleInfo) {
        mScheduleShowDetail = scheduleInfo;
        buildDialogDetail(scheduleInfo);
    }

    @Override
    public void showDetailDictionary(DictionaryInfo dictionaryInfo) {
        Bundle mBundle = new Bundle();
        mBundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, dictionaryInfo);
        changeScreenResultFragment(ScreenId.START_SCH_DICTIONARY_CHECK, Constants.Schedule.REQUEST_CODE_DICTIONARY, mBundle);
    }


    @Override
    public void dismissScheduleDetail() {
        mDialogSchDetail.dismiss();
    }

    @Override
    public void editSchedule(ScheduleInfo scheduleInfo) {
        Bundle mBundle = new Bundle();
        mBundle.putSerializable(Constants.Schedule.KEY_DATA_SCHEDULE_INFO, scheduleInfo);
        changeScreenResultFragment(ScreenId.START_SCH_EDIT, Constants.Schedule.REQUEST_CODE_SCHEDULE_INFO, mBundle);
    }

    @Override
    public void completedSchedule(ScheduleInfo scheduleInfo) {
        mScheduleEdit = scheduleInfo;
        Bundle bundle = new Bundle();
        bundle.putSerializable(Constants.Schedule.KEY_DATA_SCHEDULE_INFO, mScheduleEdit);
        bundle.putSerializable(Constants.Schedule.KEY_DATA_DATE, mDate);
        changeScreenResultFragment(ScreenId.START_SCH_COMPLETE, Constants.Schedule.REQUEST_CODE_SCHEDULE_COMPLETED, bundle);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_show_more_item_all_day:
                showMoreScheduleAllDay();
                break;
            default:
                break;
        }
    }

    /**
     * click show more schedule all day.
     */
    private void showMoreScheduleAllDay() {
        if (mFlagShowMoreItemAllDay) {
            mFlagShowMoreItemAllDay = false;
            mAdapterScheduleAllDay.setList(mListScheduleAllDayOneItem);
            mTvShowMore.setText(String.format(getString(R.string.sch_allday_number), mListScheduleAllDay.size() - 1));
            mImgShowMore.setImageDrawable(getActivity().getDrawable(R.drawable.ic_schedule_down));
        } else {
            mFlagShowMoreItemAllDay = true;
            mAdapterScheduleAllDay.setList(mListScheduleAllDay);
            mTvShowMore.setText(R.string.sch_close);
            mImgShowMore.setImageDrawable(getActivity().getDrawable(R.drawable.ic_schedule_up));
        }
        mAdapterScheduleAllDay.notifyDataSetChanged();
    }

    @Override
    public void onResult(final AssistServerResult result, final List<ScheduleInfo> list) {
        mCurrentActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (result.mResult == AssistServerResult.Result.Success) {
                    mAnim.stop();
                    mFrameLoading.setVisibility(View.GONE);
                    mListSchedule.clear();
                    mListSchedule.addAll(list);
                    updateRvListSchedule();
                } else {
                    showDialogMessage(result.mMessage);
                }
            }
        });
    }

    @Override
    public void onStartConnection() {
        mFrameLoading.setVisibility(View.VISIBLE);
        mAnim.start();
    }

    /**
     * sort list schedule by date start and end
     *
     * @param listSchedule
     */
    private void sortListScheduleByStartDate(List<ScheduleInfo> listSchedule) {
        Collections.sort(listSchedule, new Comparator<ScheduleInfo>() {
            @Override
            public int compare(ScheduleInfo sch1, ScheduleInfo sch2) {
                Date start1 = sch1.getScheduleStartDate();
                Date start2 = sch2.getScheduleStartDate();
                int startCompare = start1.compareTo(start2);
                if (startCompare != 0) {
                    return startCompare;
                }
                Date end1 = sch1.getScheduleEndDate();
                Date end2 = sch2.getScheduleEndDate();
                return end1.compareTo(end2);
            }
        });
    }

    /**
     * build dialog message
     *
     * @param message
     */
    public void showDialogMessage(String message) {
        AssistAlertDialogFactory mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIALOG_MESSAGE, message);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(mCurrentActivity, mDialogFactory).show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.Schedule.REQUEST_CODE_SCHEDULE_COMPLETED && resultCode == Constants.Schedule.REQUEST_CODE_SCHEDULE_COMPLETED) {
            //dismiss dialog detail and update data list schedule after completed
            mDialogSchDetail.dismiss();
            AppController.getInstance().getAssistServerInterface().getScheduleList(mDate, this);
        } else if (requestCode == Constants.Schedule.REQUEST_CODE_DICTIONARY && resultCode == Constants.Schedule.REQUEST_CODE_DICTIONARY) {
            //when back from dictionary detail
            buildDialogDetail(mScheduleShowDetail);
        } else if (requestCode == Constants.Schedule.REQUEST_CODE_SCHEDULE_INFO && resultCode == Constants.Schedule.REQUEST_CODE_SCHEDULE_INFO) {
            String typeRequest = data.getExtras().getString(Constants.Schedule.KEY_TYPE_BACK_RESULT);
            if (!typeRequest.equals(Constants.Schedule.REQUEST_DELETE)) {
                // show dialog detail schedule again when back or edit, delete schedule not show again
                ScheduleInfo scheduleInfo = (ScheduleInfo) data.getSerializableExtra(Constants.Schedule.KEY_DATA_SCHEDULE_INFO);
                buildDialogDetail(scheduleInfo);
            }
            if (typeRequest.equals(Constants.Schedule.REQUEST_EDIT) || typeRequest.equals(Constants.Schedule.REQUEST_DELETE)) {
                // call reload data when edit or delete
                AppController.getInstance().getAssistServerInterface().getScheduleList(mDate, this);
            }
        }
    }

    /**
     * build dialog schedule info detail
     *
     * @param scheduleInfo
     */
    private void buildDialogDetail(ScheduleInfo scheduleInfo) {
        if (mDialogSchDetail != null) {
            mDialogSchDetail.dismiss();
            mDialogSchDetail = null;
        }
        SchDetailDialogFactory dialogFactory = new SchDetailDialogFactory(this, DialogTypeControl.DialogType.SCH_DETAIL_DIALOG, mIconUser);
        dialogFactory.setSchedule(scheduleInfo);
        dialogFactory.setActivity(mCurrentActivity);
        dialogFactory.setDate(mDate);
        mDialogSchDetail = new DialogGenerator(getActivity(), dialogFactory).show();
    }
}
