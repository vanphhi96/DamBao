/*
 * ファイル：AssistEventLog.java
 * 概要：FirebaseConsoleにイベントを送信
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.util;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;

import com.google.firebase.analytics.FirebaseAnalytics;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.main.MenuUiActivity;
import jp.softbank.assist.view.fragment.dictionary.DicTopUiFragment;
import jp.softbank.assist.view.fragment.schedule.SchTopUiFragment;
import jp.softbank.assist.view.fragment.settings.SetTopUiFragment;

/**
 * @author Systena
 * @version 1.0
 */
public final class AssistEventLog {

    // サーバ通信結果通知
    public static final String INFORMATION_GET = "Information_Get";
    public static final String SCHEDULE_GET = "Schedule_Get";
    public static final String SCHEDULE_EDIT = "Schedule_Edit";
    public static final String SCHEDULE_OTHER = "Schedule_Other";
    public static final String DICTIONARY_GET = "Dictionary_Get";
    public static final String DICTIONARY_EDIT = "Dictionary_Edit";
    public static final String DICTIONARY_OTHER = "Dictionary_Other";
    public static final String SETTING_REGISTER = "Setting_Register";
    public static final String SETTING_LOCATION_REGISTER = "Setting_Location_Register";
    //データ関連処理結果通知
    public static final String SUCCESS_SCHEDULE_GET = "Success_ScheduleGet";
    public static final String SUCCESS_SCHEDULE_CREATE = "Success_ScheduleCreate";
    public static final String SUCCESS_SCHEDULE_EDIT = "Success_ScheduleEdit";
    public static final String SUCCESS_DICTIONARY_GET = "Success_DictionaryGet";
    public static final String SUCCESS_DICTIONARY_CREATE = "Success_DictionaryCreate";
    public static final String SUCCESS_DICTIONARY_EDIT = "Success_DictionaryEdit";
    public static final String SUCCESS_NOTICE_GET = "Success_NoticeGet";
    public static final String SUCCESS_LOCATION_REGISTER = "Success_location_Register";
    public static final String FAILURE_SCHEDULE_CREATE = "Failure_ScheduleCreate";
    public static final String FAILURE_SCHEDULE_EDIT = "Failure_ScheduleEdit";
    public static final String FAILURE_DICTIONARY_CREATE = "Failure_DictionaryCreate";
    public static final String FAILURE_DICTIONARY_EDIT = "Failure_DictionaryEdit";
    // 画面起動
    private static final String EVENT_SCREEN_NAME = "Screen_Start";
    private static final String EVENT_SCREEN_PARAMETER = "a_ScreenName";
    private static final String EVENT_SERVER_PARAMETER_A_RESULT = "a_Result";
    private static final String EVENT_SERVER_PARAMETER_B_REASON = "b_ReasonForError";
    private static final String EVENT_DATA_PARAMETER_A_PROCESSING = "a_ProcessingTime";
    private static final String EVENT_DATA_PARAMETER_B_DATA_COUNT = "b_DataCount";
    private static final String EVENT_DATA_PARAMETER_C_DATA_CAPACITY = "c_DataCapacity";
    private static final String EVENT_DATA_PARAMETER_D_OTHER = "d_Other";

    private static final int SCH_FRAGMENT_POSITION = 0;
    private static final int DIC_FRAGMENT_POSITION = 1;
    private static final int SET_FRAGMENT_POSITION = 2;

    /**
     * 画面起動出力
     *
     * @param context
     */
    public static void sendEventFirebaseScreenId(Context context, ScreenId screenId) {
        Bundle bundle = new Bundle();
        if (screenId != null && screenId.getFirebaseId() != 0) {
            bundle.putString(EVENT_SCREEN_PARAMETER, context.getResources().getString(screenId.getFirebaseId()));
        }
        FirebaseAnalytics.getInstance(context).logEvent(EVENT_SCREEN_NAME, bundle);
    }

    /**
     * サーバ通信結果通知出力
     *
     * @param context
     * @param eventName
     * @param typeName
     * @param result
     * @param errCode
     * @param errMsg
     */
    public static void sendEventFirebaseServer(Context context, String eventName, String typeName, Result result, String errCode, String errMsg) {
        Bundle bundle = new Bundle();
        switch (result) {
            case SUCCESS:
                bundle.putInt(EVENT_SERVER_PARAMETER_A_RESULT, 1); // 成功 : １で表示
                break;
            case FAILED:
                bundle.putInt(EVENT_SERVER_PARAMETER_A_RESULT, 0); // 失敗 : 0で表示
                bundle.putString(EVENT_SERVER_PARAMETER_B_REASON, convertString(typeName, errCode, errMsg));
                break;
            case OTHER:
                break;
            default:
                break;
        }
        FirebaseAnalytics.getInstance(context).logEvent(EVENT_SCREEN_NAME, bundle);
    }

    /**
     * データ関連処理結果通知
     *
     * @param context
     * @param eventName
     * @param processingTime
     * @param dataCount
     * @param dataCapacity
     * @param other
     */
    public static void sendEventFirebaseData(Context context, String eventName, int processingTime, int dataCount, int dataCapacity, int other) {
        Bundle bundle = new Bundle();
        if (processingTime != 0) {
            bundle.putInt(EVENT_DATA_PARAMETER_A_PROCESSING, processingTime);
        }
        if (dataCount != 0) {
            bundle.putInt(EVENT_DATA_PARAMETER_B_DATA_COUNT, dataCount);
        }
        if (dataCapacity != 0) {
            bundle.putInt(EVENT_DATA_PARAMETER_C_DATA_CAPACITY, dataCapacity);
        }
        if (other != 0) {
            bundle.putInt(EVENT_DATA_PARAMETER_D_OTHER, other);
        }
        FirebaseAnalytics.getInstance(context).logEvent(EVENT_SCREEN_NAME, bundle);
    }

    /**
     * String convert
     *
     * @param typeName
     * @param errCode
     * @param errMsg
     */
    private static String convertString(String typeName, String errCode, String errMsg) {
        if (typeName != null && errCode != null && errMsg != null) {
            return new StringBuilder().append(typeName)
                    .append("-")
                    .append(errCode)
                    .append("-")
                    .append(errMsg)
                    .toString();
        }
        return null;
    }

    /**
     * FirebaseAnalyticsEventの送信
     *
     * @param context
     */
    public void handleSendEvent(Context context) {
        if (context instanceof MenuUiActivity) {
            ViewPager viewPager = ((MenuUiActivity) context).findViewById(R.id.view_pager_menu);
            int position = 0;
            if (viewPager != null) {
                position = viewPager.getCurrentItem();
            }
            switch (position) {
                case SCH_FRAGMENT_POSITION:
                    AppController.getInstance().getViewManager().setFragment(SchTopUiFragment.newInstance());
                    break;
                case DIC_FRAGMENT_POSITION:
                    AppController.getInstance().getViewManager().setFragment(DicTopUiFragment.newInstance());
                    break;
                case SET_FRAGMENT_POSITION:
                    AppController.getInstance().getViewManager().setFragment(SetTopUiFragment.newInstance());
                    break;
                default:
                    break;
            }
        }
        sendEventFirebaseScreenId(context, AppController.getInstance().getViewManager().getScreenId());
    }

    /**
     * サーバからのレスポンス
     */
    public enum Result {
        SUCCESS,
        FAILED,
        OTHER
    }
}
