/*
 * ファイル：BaseResultListener.java
 * 概要：アシストサーバI/Fのコールバック
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.listener;

/**
 * コールバックのベースクラス.
 */
public interface BaseResultListener {

    /**
     * サーバへの通信が発生な場合に通知される.
     *   ※この通知はUIスレッドではありません
     */
    public void onStartConnection();
}
