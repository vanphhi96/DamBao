/*
 * ファイル：DictionaryOrderInfo.java
 * 概要：辞書並び順情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

/**
 * 辞書並び順情報.
 *
 * @author Systena
 * @version 1.0
 */
public class DictionaryOrderInfo {

    private long mCategoryId; // カテゴリID
    private long[] mDictionaryIdList; // 辞書IDの配列（最大25）


    public long getCategoryId() {
        return mCategoryId;
    }

    public void setCategoryId(long mCategoryId) {
        this.mCategoryId = mCategoryId;
    }

    public long[] getDictionaryIdList() {
        return mDictionaryIdList;
    }

    public void setDictionaryIdList(long[] mDictionaryIdList) {
        this.mDictionaryIdList = mDictionaryIdList;
    }
}
