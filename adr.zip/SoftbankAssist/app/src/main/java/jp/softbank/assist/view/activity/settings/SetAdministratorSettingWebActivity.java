/*
 * ファイル：SetAdministratorSettingWebActivity.java
 * 概要：管理者設定画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.settings;

import jp.softbank.assist.view.activity.BaseWebActivity;

/**
 * set-adm-01
 * set-adm-02
 * set-adm-cr-01
 * set-adm-cr-02
 * set-adm-de-01
 * set-adm-de-02
 * set-adm-de-03
 *
 * @author Systena
 * @version 1.0
 */
public class SetAdministratorSettingWebActivity extends BaseWebActivity {
}
