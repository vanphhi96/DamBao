/*
 * ファイル：GetScheduleResultMeta.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.schedule;

import com.google.gson.annotations.SerializedName;

/**
 * スケジュール内容情報.
 */
public class GetScheduleResultMeta {

    @SerializedName("schedule_meta_id")
    private Long mScheduleMetaId = null;
    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("schedule_title")
    private String mScheduleTitle = null;
    @SerializedName("schedule_note")
    private String mScheduleNote = null;
    @SerializedName("mLocation")
    private String mLocation = null;
    @SerializedName("icon_name")
    private String mIconName = null;
    @SerializedName("creator_icon_id")
    private Long mCreatorIconId = null;
    @SerializedName("creator_icon_path")
    private String mCreatorIconPath = null;
    @SerializedName("creator_nickname")
    private String mCreatorNickname = null;
    @SerializedName("created_at")
    private String mCreatedAt = null;
    @SerializedName("updated_at")
    private String mUpdatedAt = null;
    @SerializedName("created_by")
    private Long mCreatedBy = null;
    @SerializedName("updated_by")
    private Long mUpdatedBy = null;


    /**
     * スケジュール内容ID.
     */
    public Long getScheduleMetaId() {
        return mScheduleMetaId;
    }
    public void setScheduleMetaId(Long scheduleMetaId) {
        this.mScheduleMetaId = scheduleMetaId;
    }

    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * スケジュールタイトル.
     */
    public String getScheduleTitle() {
        return mScheduleTitle;
    }
    public void setScheduleTitle(String scheduleTitle) {
        this.mScheduleTitle = scheduleTitle;
    }

    /**
     * スケジュールメモ.
     */
    public String getScheduleNote() {
        return mScheduleNote;
    }
    public void setScheduleNote(String scheduleNote) {
        this.mScheduleNote = scheduleNote;
    }

    /**
     * 場所.
     */
    public String getLocation() {
        return mLocation;
    }
    public void setLocation(String location) {
        this.mLocation = location;
    }

    /**
     * アイコン名.
     */
    public String getIconName() {
        return mIconName;
    }
    public void setIconName(String iconName) {
        this.mIconName = iconName;
    }

    /**
     * 作成者アイコンID.
     */
    public Long getCreatorIconId() {
        return mCreatorIconId;
    }
    public void setCreatorIconId(Long creatorIconId) {
        this.mCreatorIconId = creatorIconId;
    }

    /**
     * 作成者アイコンパス.
     */
    public String getCreatorIconPath() {
        return mCreatorIconPath;
    }
    public void setCreatorIconPath(String creatorIconPath) {
        this.mCreatorIconPath = creatorIconPath;
    }

    /**
     * 作成者ニックネーム.
     */
    public String getCreatorNickname() {
        return mCreatorNickname;
    }
    public void setCreatorNickname(String creatorNickname) {
        this.mCreatorNickname = creatorNickname;
    }

    /**
     * 作成日時(YYYYMMDDhhmmss).
     */
    public String getCreatedAt() {
        return mCreatedAt;
    }
    public void setCreatedAt(String createdAt) {
        this.mCreatedAt = createdAt;
    }

    /**
     * 更新日時(YYYYMMDDhhmmss).
     */
    public String getUpdatedAt() {
        return mUpdatedAt;
    }
    public void setUpdatedAt(String updatedAt) {
        this.mUpdatedAt = updatedAt;
    }

    /**
     * 作成者.
     */
    public Long getCreatedBy() {
        return mCreatedBy;
    }
    public void setCreatedBy(Long createdBy) {
        this.mCreatedBy = createdBy;
    }

    /**
     * 更新者.
     */
    public Long getUpdatedBy() {
        return mUpdatedBy;
    }
    public void setUpdatedBy(Long updatedBy) {
        this.mUpdatedBy = updatedBy;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GetScheduleResultMeta scheduleMata = (GetScheduleResultMeta) o;
        return (this.mScheduleMetaId == null ? scheduleMata.mScheduleMetaId == null : this.mScheduleMetaId.equals(scheduleMata.mScheduleMetaId)) &&
                (this.mUserId == null ? scheduleMata.mUserId == null : this.mUserId.equals(scheduleMata.mUserId)) &&
                (this.mScheduleTitle == null ? scheduleMata.mScheduleTitle == null : this.mScheduleTitle.equals(scheduleMata.mScheduleTitle)) &&
                (this.mScheduleNote == null ? scheduleMata.mScheduleNote == null : this.mScheduleNote.equals(scheduleMata.mScheduleNote)) &&
                (this.mLocation == null ? scheduleMata.mLocation == null : this.mLocation.equals(scheduleMata.mLocation)) &&
                (this.mIconName == null ? scheduleMata.mIconName == null : this.mIconName.equals(scheduleMata.mIconName)) &&
                (this.mCreatorIconId == null ? scheduleMata.mCreatorIconId == null : this.mCreatorIconId.equals(scheduleMata.mCreatorIconId)) &&
                (this.mCreatorIconPath == null ? scheduleMata.mCreatorIconPath == null : this.mCreatorIconPath.equals(scheduleMata.mCreatorIconPath)) &&
                (this.mCreatorNickname == null ? scheduleMata.mCreatorNickname == null : this.mCreatorNickname.equals(scheduleMata.mCreatorNickname)) &&
                (this.mCreatedAt == null ? scheduleMata.mCreatedAt == null : this.mCreatedAt.equals(scheduleMata.mCreatedAt)) &&
                (this.mUpdatedAt == null ? scheduleMata.mUpdatedAt == null : this.mUpdatedAt.equals(scheduleMata.mUpdatedAt)) &&
                (this.mCreatedBy == null ? scheduleMata.mCreatedBy == null : this.mCreatedBy.equals(scheduleMata.mCreatedBy)) &&
                (this.mUpdatedBy == null ? scheduleMata.mUpdatedBy == null : this.mUpdatedBy.equals(scheduleMata.mUpdatedBy));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mScheduleMetaId == null ? 0: this.mScheduleMetaId.hashCode());
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mScheduleTitle == null ? 0: this.mScheduleTitle.hashCode());
        result = 31 * result + (this.mScheduleNote == null ? 0: this.mScheduleNote.hashCode());
        result = 31 * result + (this.mLocation == null ? 0: this.mLocation.hashCode());
        result = 31 * result + (this.mIconName == null ? 0: this.mIconName.hashCode());
        result = 31 * result + (this.mCreatorIconId == null ? 0: this.mCreatorIconId.hashCode());
        result = 31 * result + (this.mCreatorIconPath == null ? 0: this.mCreatorIconPath.hashCode());
        result = 31 * result + (this.mCreatorNickname == null ? 0: this.mCreatorNickname.hashCode());
        result = 31 * result + (this.mCreatedAt == null ? 0: this.mCreatedAt.hashCode());
        result = 31 * result + (this.mUpdatedAt == null ? 0: this.mUpdatedAt.hashCode());
        result = 31 * result + (this.mCreatedBy == null ? 0: this.mCreatedBy.hashCode());
        result = 31 * result + (this.mUpdatedBy == null ? 0: this.mUpdatedBy.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class GetScheduleResultMeta {\n");

        sb.append("  mScheduleMetaId: ").append(mScheduleMetaId).append("\n");
        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mScheduleTitle: ").append(mScheduleTitle).append("\n");
        sb.append("  mScheduleNote: ").append(mScheduleNote).append("\n");
        sb.append("  mLocation: ").append(mLocation).append("\n");
        sb.append("  mIconName: ").append(mIconName).append("\n");
        sb.append("  mCreatorIconId: ").append(mCreatorIconId).append("\n");
        sb.append("  mCreatorIconPath: ").append(mCreatorIconPath).append("\n");
        sb.append("  mCreatorNickname: ").append(mCreatorNickname).append("\n");
        sb.append("  mCreatedAt: ").append(mCreatedAt).append("\n");
        sb.append("  mUpdatedAt: ").append(mUpdatedAt).append("\n");
        sb.append("  mCreatedBy: ").append(mCreatedBy).append("\n");
        sb.append("  mUpdatedBy: ").append(mUpdatedBy).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
