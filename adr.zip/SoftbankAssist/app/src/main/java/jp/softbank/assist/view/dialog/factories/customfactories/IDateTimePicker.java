/*
 * ファイル：IDateTimePicker.java
 * 概要：interface of dialog date time picker.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories.customfactories;

import java.util.Date;

/**
 * sch-cr-01, sch-ed-01.
 *
 * @author Systena
 * @version 1.0
 */
public interface IDateTimePicker {
    /**
     * dismiss dialog
     */
    void dismissDialogDateTime();

    /**
     * save date time
     *
     * @param date date time picker
     */
    void saveDateTime(Date date);
}
