/*
 * ファイル：AdapterDicTop.java
 * 概要：Adapter list category dictionary
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.RecyclerBaseAdapter;
import jp.softbank.assist.view.fragment.dictionary.IDicTopFragment;

import java.util.ArrayList;
import java.util.List;


/**
 * Adapter dic-01
 *
 * @author Systena
 * @version 1.0
 */
public class AdapterDicTop extends RecyclerBaseAdapter {
    private List<CategoryInfo> mCategoryInfoList = new ArrayList<>();
    private IDicTopFragment mIDicTopFragment;

    public AdapterDicTop() {

    }

    /**
     * set category list
     *
     * @param categoryInfoList
     */
    public void setCategoryInfoList(List<CategoryInfo> categoryInfoList) {
        this.mCategoryInfoList = categoryInfoList;
    }

    /**
     * set interface
     *
     * @param iDicTopFragment IDicTopFragment
     */
    public void setIDicTopFragment(IDicTopFragment iDicTopFragment) {
        this.mIDicTopFragment = iDicTopFragment;
    }

    @Override
    public int getContentItemCount() {
        return mCategoryInfoList.size();
    }

    /**
     * create header view holder
     *
     * @param parent view parent
     * @return header view holder
     */
    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        return null;
    }

    /**
     * create footer view holder
     *
     * @param parent view parent
     * @return footer view holder
     */
    @Override
    public BaseViewHolder onCreateFooterHolder(ViewGroup parent) {
        return null;
    }

    /**
     * create content view holder
     *
     * @param parent   view parent
     * @param viewType view type
     * @return
     */
    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category_dic, parent, false);
        return new CategoryHolder(view);
    }


    /**
     * category view holder
     */
    private class CategoryHolder extends BaseViewHolder {
        private TextView mTvName;
        private TextView mTvCount;
        private View mViewFlag;
        private CardView mCardView;
        private int mColorBackgroundItem;
        private int mColorFlagItem;
        private int mThumbnail;
        private ImageView mImvThumbnail;

        CategoryHolder(@NonNull View itemView) {
            super(itemView);
            mTvName = itemView.findViewById(R.id.tv_dic_category_name);
            mTvCount = itemView.findViewById(R.id.tv_count_dic_category);
            mViewFlag = itemView.findViewById(R.id.view_flag);
            mCardView = itemView.findViewById(R.id.card_dic_category);
            mImvThumbnail = itemView.findViewById(R.id.imv_dic_category);
            mCardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIDicTopFragment != null) {
                        mIDicTopFragment.onClickCategory(mCategoryInfoList.get(getLayoutPosition()));
                    }
                }
            });
        }

        @Override
        public void onBindView(final int position) {
            if (position != RecyclerView.NO_POSITION) {
                CategoryInfo categoryInfo = mCategoryInfoList.get(position);
                getThumbnailItemDictionary(categoryInfo.getName(), mTvName.getContext());
                if (!TextUtils.isEmpty(categoryInfo.getName())) {
                    mTvName.setText(categoryInfo.getName());
                }
                if (!TextUtils.isEmpty(Integer.toString(mCategoryInfoList.get(position).getCount()))) {
                    mTvCount.setText(Integer.toString(categoryInfo.getCount()));
                }
                mColorFlagItem = ResourcesUtils.getColorFlagItemDictionary(categoryInfo.getCategoryId());
                mColorBackgroundItem = ResourcesUtils.getColorBackgroundItemDictionary(categoryInfo.getCategoryId());
                mViewFlag.setBackgroundColor(mTvName.getContext().getColor(mColorFlagItem));
                mCardView.setCardBackgroundColor(mTvName.getContext().getColor(mColorBackgroundItem));
                mImvThumbnail.setImageResource(mThumbnail);
            }
        }

        /**
         * get color for item dictionary
         *
         * @param categoryName category name
         */
        private void getThumbnailItemDictionary(String categoryName, Context context) {
            if (categoryName.equals(context.getString(R.string.how_to_go))) {
                mThumbnail = R.drawable.ic_category_how_to_go;
            } else if (categoryName.equals(context.getString(R.string.how_to_do))) {
                mThumbnail = R.drawable.ic_category_how_to_do;
            } else if (categoryName.equals(context.getString(R.string.belongings))) {
                mThumbnail = R.drawable.ic_category_belongings;
            }
        }

    }

}
