/*
 * ファイル：AdapterPagerCalendar.java
 * 概要：Adapter pager month view calendar
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import jp.softbank.assist.view.fragment.calendar.FragmentMonthView;

import java.util.Date;
import java.util.List;

/**
 * sch-cal
 *
 * @author Systena
 * @version 1.0
 */
public class AdapterPagerCalendar extends FragmentPagerAdapter {
    private static final int FIRST_PAGE_POSITION = 0;
    private List<Date> mListDate;

    /**
     * constructor adapter pager calendar
     *
     * @param fragmentManager FragmentManager
     * @param list            list Date
     */
    public AdapterPagerCalendar(FragmentManager fragmentManager, List<Date> list) {
        super(fragmentManager);
        this.mListDate = list;
    }

    @Override
    public int getCount() {
        return mListDate.isEmpty() ? 0 : mListDate.size();
    }

    @Override
    public Fragment getItem(int position) {
        return new FragmentMonthView(mListDate.get(position));
    }

    /**
     * position of last pager.
     *
     * @return position last pager
     */
    public int getLastPagePosition() {
        return mListDate.isEmpty() && mListDate.size() > 0 ? 0 : mListDate.size() - 1;
    }

    /**
     * position of fist pager.
     *
     * @return position fist pager
     */
    public int getFistPagePosition() {
        return FIRST_PAGE_POSITION;
    }
}
