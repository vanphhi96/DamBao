/*
 * ファイル：RequestBody.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json;

/**
 * リクエスト用ボディデータベースクラス.
 */
public abstract class RequestBody {
}
