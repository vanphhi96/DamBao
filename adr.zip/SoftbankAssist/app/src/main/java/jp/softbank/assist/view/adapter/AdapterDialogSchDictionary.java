/*
 * ファイル：AdapterDialogSchDictionary.java
 * 概要：Adapter recycler view in dialog schedule dictionary check.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.RecyclerBaseAdapter;

/**
 * sch-dic-01.
 *
 * @author Systena
 * @version 1.0
 */
public class AdapterDialogSchDictionary extends RecyclerBaseAdapter {
    //TODO:[#3368] fix total item to test
    private static final Integer TOTAL_ITEM = 10;
    private static final Integer POSITION_LAST_ITEM = 12;

    /**
     * set show footer view
     */ {
        setFooterVisibility(true);
        setHeaderVisibility(true);
    }

    /**
     * get total content item
     *
     * @return
     */
    @Override
    public int getContentItemCount() {
        return TOTAL_ITEM + 2;
    }

    /**
     * create header view holder
     *
     * @param parent view parent
     * @return header view holder
     */
    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sch_dic_header, parent, false);
        return new DicItemHeader(view);
    }

    /**
     * create footer view holder
     *
     * @param parent view parent
     * @return footer view holder
     */
    @Override
    public BaseViewHolder onCreateFooterHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sch_dic_fotter, parent, false);
        return new DicItemFooter(view);
    }

    /**
     * create content view holder
     *
     * @param parent   view parent
     * @param viewType view type
     * @return
     */
    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sch_dic, parent, false);
        return new SchDictionaryHolder(view);
    }

    /**
     * schedule dictionary view holder
     */
    private class SchDictionaryHolder extends BaseViewHolder {
        private FrameLayout mFrImage;
        private ImageView mImgDown;
        private LinearLayout mLnParentItem;

        SchDictionaryHolder(@NonNull View itemView) {
            super(itemView);
            mLnParentItem = itemView.findViewById(R.id.ln_parent_item);
            mFrImage = itemView.findViewById(R.id.fr_img);
            mImgDown = itemView.findViewById(R.id.img_down);
            mFrImage.setClipToOutline(true);
        }

        @Override
        public void onBindView(int position) {
            if (position == POSITION_LAST_ITEM) {
                mLnParentItem.setBackground(mLnParentItem.getContext().getDrawable(R.drawable.bgr_item_sch_dic_footer));
                mImgDown.setVisibility(View.INVISIBLE);
            }
        }
    }

    /**
     * schedule dictionary header view holder
     */
    private class DicItemHeader extends BaseViewHolder {
        private TextView mTvTime;

        DicItemHeader(@NonNull View itemView) {
            super(itemView);
            mTvTime = itemView.findViewById(R.id.tv_time);
        }

        @Override
        public void onBindView(int position) {
            //TODO[#3368] fix data to test
            mTvTime.setText(mTvTime.getContext().getString(R.string.update) + "2018/11/03");
        }
    }

    /**
     * schedule dictionary footer view holder
     */
    private class DicItemFooter extends BaseViewHolder {
        DicItemFooter(@NonNull View itemView) {
            super(itemView);
        }

        @Override
        public void onBindView(int position) {
        }
    }

}
