/*
 * ファイル：NoticeInfo.java
 * 概要：お知らせ情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import java.util.Date;

/**
 * お知らせ情報.
 *
 * @author Systena
 * @version 1.0
 */
public class NoticeInfo {

    private long mId;  // お知らせID
    private Date mDeliveredDate; // 配信日時
    private String mTitle; // タイトル
    private String mContents; // 内容
    private long mVersion; // バージョン
    private boolean mPriority; // 優先表示フラグ
    private Date mCreatedDate; // 作成日時
    private Date mUpdatedDate; // 更新日時


    public long getId() {
        return mId;
    }

    public void setId(long id) {
        this.mId = id;
    }

    public Date getDeliveredDate() {
        return mDeliveredDate;
    }

    public void setDeliveredDate(Date deliveredDate) {
        this.mDeliveredDate = deliveredDate;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        this.mTitle = title;
    }

    public String getContents() {
        return mContents;
    }

    public void setContents(String contents) {
        this.mContents = contents;
    }

    public long getVersion() {
        return mVersion;
    }

    public void setVersion(long version) {
        this.mVersion = version;
    }

    public boolean isPriority() {
        return mPriority;
    }

    public void setIsPriority(boolean priority) {
        this.mPriority = priority;
    }

    public Date getCreatedDate() {
        return mCreatedDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.mCreatedDate = createdDate;
    }

    public Date getUpdatedDate() {
        return mUpdatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.mUpdatedDate = updatedDate;
    }
}
