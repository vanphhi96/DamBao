/*
 * ファイル：AssistFirebaseMessagingService.java
 * 概要：FCMからの受信を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.notification;

import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import jp.softbank.assist.controller.AppController;

/**
 * FCM通知用サービス.
 *
 * @author Systena
 * @version 1.0
 */
public class AssistFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        AppController.getInstance().getAssistNotificationManager().initNotification(this, remoteMessage);
        AppController.getInstance().getAssistNotificationManager().sendGpsToServer();
        if (remoteMessage.getData().size() > 0) {
            // TODO: 2019/02/15 Delete later (タン)
            Log.i("tntan", "Message data: " + remoteMessage.getData());
        }

        if (remoteMessage.getNotification() != null) {
            // TODO: 2019/02/15 Delete later (タン)
            Log.i("tntan", "Message Notification: " + remoteMessage.getNotification());
        }
    }

}
