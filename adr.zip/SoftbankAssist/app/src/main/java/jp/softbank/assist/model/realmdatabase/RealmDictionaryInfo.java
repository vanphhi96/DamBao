/*
 * ファイル：RealmCategoryInfo.java
 * 概要：Realm用辞書一覧テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

import java.util.Date;

/**
 * Realm用辞書一覧テーブル
 *
 * @author Systena
 * @version 1.0
 */
public class RealmDictionaryInfo extends RealmObject {

    @PrimaryKey
    private long mDictionaryId; // 辞書ID
    private long mCategoryId; // カテゴリID
    private long mType; // 辞書種別
    private String mName; // 辞書名
    private String mImageUrl; // 画像URL
    private String mImageFileName; // 画像ファイル名
    private boolean mIsMemorize; // 覚えたフラグ
    private long mVersion; // バージョン
    private String mCreatorNickname; // 作成者ニックネーム
    private long mCreatorIconId; // 作成者アイコンID
    private Date mCreatedDate; // 作成日時
    private Date mUpdatedDate; // 更新日時
    private boolean mIsDeleted; // 削除済みフラグ


    public long getDictionaryId() {
        return mDictionaryId;
    }

    public void setDictionaryId(long dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }

    public long getCategoryId() {
        return mCategoryId;
    }

    public void setCategoryId(long categoryId) {
        this.mCategoryId = categoryId;
    }

    public long getType() {
        return mType;
    }

    public void setType(long type) {
        this.mType = type;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.mImageUrl = imageUrl;
    }

    public String getImageFileName() {
        return mImageFileName;
    }

    public void setImageFileName(String imageFileName) {
        this.mImageFileName = imageFileName;
    }

    public boolean isMemorize() {
        return mIsMemorize;
    }

    public void setIsMemorize(boolean memorize) {
        mIsMemorize = memorize;
    }

    public long getVersion() {
        return mVersion;
    }

    public void setVersion(long version) {
        this.mVersion = version;
    }

    public String getCreatorNickname() {
        return mCreatorNickname;
    }

    public void setCreatorNickname(String creatorNickname) {
        this.mCreatorNickname = creatorNickname;
    }

    public long getCreatorIconId() {
        return mCreatorIconId;
    }

    public void setCreatorIconId(long creatorIconId) {
        this.mCreatorIconId = creatorIconId;
    }

    public Date getCreatedDate() {
        return mCreatedDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.mCreatedDate = createdDate;
    }

    public Date getUpdatedDate() {
        return mUpdatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.mUpdatedDate = updatedDate;
    }

    public boolean isDeleted() {
        return mIsDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        mIsDeleted = deleted;
    }
}
