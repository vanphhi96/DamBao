/*
 * ファイル：RealmConstants.java
 * 概要：Realmの定数定義
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

/**
 * 定数定義.
 *
 * @author Systena
 * @version 1.0
 */
public final class RealmConstants {

    public static int REALM_VERSION = 1;
    public static final String DATE_FORMAT_LOCATION_TIME = "hhmm";

    public static final class UserInfo {
        public static final String USER_INFO_TABLE = "user_info.realm";
        public static final int USER_INFO_DATA_CNT = 1;
        public static final int USER_INFO_ID = 1;
        // KEY情報
        public static final String PRIMARY_ID = "mId"; // ユーザー情報ID
    }

    public static final class ScheduleInfo {
        public static final String SCHEDULE_INFO_TABLE = "schedule_info.realm";
        public static final int SCHEDULE_INFO_DATA_CNT_BYID = 1;
        // KEY情報
        public static final String PRIMARY_SCHEDULE_ID = "mScheduleId"; // スケジュール日時ID
        public static final String KEY_SCHEDULE_START_DATE = "mScheduleStartDate"; // スケジュール開始日時
        public static final String KEY_SCHEDULE_END_DATE = "mScheduleEndDate"; // スケジュール終了日時
    }

    public static final class ScheduleGetHistory {
        public static final String SCHEDULE_GET_HISTORY_TABLE = "sch_get_history.realm";
        // KEY情報
        public static final String PRIMARY_ID = "mId"; // お知らせID
    }

    public static final class NoticeInfo {
        public static final String NOTICE_INFO_TABLE = "notice_info.realm";
        // KEY情報
        public static final String PRIMARY_NOTICE_ID = "mNoticeId"; // お知らせID
    }

    public static final class LocationSettings {
        public static final String LOCATION_SETTING_TABLE = "location_setting.realm";
        public static final int LOCATION_SETTING_DATA_CNT = 1;
        public static final int LOCATION_SETTING_ID = 1;
        // KEY情報
        public static final String PRIMARY_ID = "mId"; // 位置更新可否設定ID
    }

    public static final class DictionaryOrderInfo {
        public static final String DICTIONARY_ORDER_INFO_TABLE = "dictionary_order_info.realm";
        // 保存しているKEY情報
        public static final String PRIMARY_CATEGORY_ID = "mCategoryId"; // カテゴリID
    }

    public static final class DictionaryInfo {
        public static final String DICTIONARY_INFO_TABLE = "dictionary_info.realm";
        // 保存しているKEY情報
        public static final String PRIMARY_DICTIONARY_ID = "mDictionaryId"; // 辞書ID
        public static final String KEY_CATEGORY_ID = "mCategoryId"; // カテゴリID
        public static final String KEY_DELETE_FLG = "mIsDeleted"; // 削除済みフラグ
        public static final String KEY_UPDATE_DATE = "mUpdatedDate"; // 更新日時
    }

    public static final class CategoryInfo {
        public static final String CATEGORY_INFO_TABLE = "category_info.realm";
        // 保存しているKEY情報
        public static final String PRIMARY_CATEGORY_ID = "mCategoryId"; // お知らせID
    }

    public static final class CardInfo {
        public static final String CARD_INFO_TABLE = "card_info.realm";
        // 保存しているKEY情報
        public static final String KEY_DICTIONARY_ID = "mDictionaryId"; // 辞書ID
        public static final String KEY_DELETE_FLG = "mIsDeleted"; // 削除フラグ
        public static final String SORTKEY_NEXTCARD_ID = "mNextCardId"; // 次カードID
        public static final String KEY_UPDATE_DATE = "mUpdatedDate"; // 更新日時
    }

    public static final class AuthInfo {
        public static final String AUTH_INFO_TABLE = "auth_info.realm";
        public static final int AUTH_INFO_DATA_CNT = 1;
        public static final int AUTH_INFO_ID = 1;
        // KEY情報
        public static final String PRIMARY_ID = "mId"; // 認証情報ID
    }

    public static final class DeviceInfo {
        public static final String DEVICE_INFO_TABLE = "device_info.realm";
        public static final int DEVICE_INFO_DATA_CNT = 1;
        public static final int DEVICE_INFO_ID = 1;
        // KEY情報
        public static final String PRIMARY_ID = "mId"; // デバイス情報ID
    }

    public static final class LocationInfo {
        public static final String LOCATION_INFO_TABLE = "location_info.realm";
        public static final int LOCATION_INFO_DATA_CNT = 1;
        public static final int LOCATION_INFO_ID = 1;
        // KEY情報
        public static final String PRIMARY_ID = "mId"; // 位置情報ID
    }

    public static final class AppVersionInfo {
        public static final String APP_VERSION_INFO_TABLE = "app_version_info.realm";
        public static final int APP_VERSION_INFO_DATA_CNT = 1;
        public static final int APP_VERSION_INFO_ID = 1;
        // KEY情報
        public static final String PRIMARY_ID = "mId"; // デバイス情報ID
    }

    public static final class TimerInfo {
        public static final String TIMER_INFO_TABLE = "timer_info.realm";
        // KEY情報
        public static final String PRIMARY_ID = "mType";
        public static final String KEY_REQUEST_CODE = "mRequestCode";
    }
}