/*
 * ファイル：WalUserAccountEditUiActivity.java
 * 概要：アカウント情報入力画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.walkthrough;

import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.adapter.AccountInfoAdapter;

/**
 * wal-08
 *
 * @author Systena
 * @version 1.0
 */
public class WalUserAccountEditUiActivity extends BaseUiActivity implements
        AccountInfoAdapter.ItemSelectedListener, View.OnClickListener {

    private View mRlContainer;
    private View mFrBackContainer;
    private RecyclerView mRVAccountInfor;
    private AccountInfoAdapter mAccountInfoAdapter;
    private TextView mTvOk;
    private static final int FLAG_HIDE_INPUT = 0;
    private TextView mTvMan;
    private TextView mTvWoman;
    // TODO: #3393 テスト用
    private static final int SPAN_COUNT = 3;
    private static final int DATA_NUMBER_MAN = 3;
    private static final int DATA_NUMBER_WOMAN = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wal_user_account_edit);
        mRlContainer = findViewById(R.id.rl_wal_container);
        mFrBackContainer = findViewById(R.id.fr_wal08_container_back);
        mAccountInfoAdapter = new AccountInfoAdapter(this, this);
        mRVAccountInfor = findViewById(R.id.recyclerView_wal08);
        mTvOk = findViewById(R.id.tv_wal08_OK);
        mTvMan = findViewById(R.id.tv_man);
        mTvMan.setSelected(true);
        mTvWoman = findViewById(R.id.tv_woman);
        mTvMan.setOnClickListener(this);
        mTvWoman.setOnClickListener(this);
        mTvOk.setOnClickListener(this);
        mRlContainer.setOnClickListener(this);
        mFrBackContainer.setOnClickListener(this);
        mRVAccountInfor.setAdapter(mAccountInfoAdapter);

        GridLayoutManager manager = new GridLayoutManager(this, SPAN_COUNT, GridLayoutManager.VERTICAL, false);
        mRVAccountInfor.setLayoutManager(manager);
    }

    @Override
    public void onItemClick() {
        // TODO:[#3393] Handle when click item in RecyclerView Account User
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_wal08_OK:
                changeScreen(ScreenId.START_WAL_LOCATION_CONFIRM);
                break;
            case R.id.tv_man:
                mAccountInfoAdapter.changeData(DATA_NUMBER_MAN);
                mAccountInfoAdapter.notifyDataSetChanged();
                mTvWoman.setSelected(false);
                mTvMan.setSelected(true);
                break;
            case R.id.tv_woman:
                mAccountInfoAdapter.changeData(DATA_NUMBER_WOMAN);
                mAccountInfoAdapter.notifyDataSetChanged();
                mTvMan.setSelected(false);
                mTvWoman.setSelected(true);
                break;
            case R.id.rl_wal_container:
                hideKeyboard(view);
                break;
            case R.id.fr_wal08_container_back:
                onBackPressed();
                break;
            default:
                break;
        }
    }

    /**
     * hide keyboard
     *
     * @param view view focus
     */
    private void hideKeyboard(View view) {
        InputMethodManager in = (InputMethodManager) getSystemService(WalUserAccountEditUiActivity.INPUT_METHOD_SERVICE);
        if (view == null) {
            view = new View(WalUserAccountEditUiActivity.this);
        }
        if (in != null) {
            in.hideSoftInputFromWindow(view.getWindowToken(), FLAG_HIDE_INPUT);
        }
    }
}

