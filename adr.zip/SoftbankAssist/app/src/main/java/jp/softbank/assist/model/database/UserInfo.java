/*
 * ファイル：UserInfo.java
 * 概要：ユーザー情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

/**
 * ユーザー情報.
 *
 * @author Systena
 * @version 1.0
 */
public class UserInfo {

    private long mUserId; // 利用者ID
    private String mCuid; // CUID
    private String mNickname; // 利用者ニックネーム
    private long mIconId; // 利用者アイコンID


    public long getUserId() {
        return mUserId;
    }

    public void setUserId(long userId) {
        this.mUserId = userId;
    }

    public String getCuid() {
        return mCuid;
    }

    public void setCuid(String cuid) {
        this.mCuid = cuid;
    }

    public String getNickname() {
        return mNickname;
    }

    public void setNickname(String nickname) {
        this.mNickname = nickname;
    }

    public long getIconId() {
        return mIconId;
    }

    public void setIconId(long iconId) {
        this.mIconId = iconId;
    }
}
