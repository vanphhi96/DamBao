package jp.softbank.assist.view.fragmenttemp;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.Index;
import io.realm.annotations.PrimaryKey;

public class RealmTestData extends RealmObject {

    @PrimaryKey
    private long mId;
    private String mName;

    private long mVertion;

// マイグレーション対応
//    public String getmAddStr() {
//        return mAddStr;
//    }
//
//    public void setmAddStr(String mAddStr) {
//        this.mAddStr = mAddStr;
//    }
//
//    public String getmAdd2Str() {
//        return mAdd2Str;
//    }
//
//    public void setmAdd2Str(String mAdd2Str) {
//        this.mAdd2Str = mAdd2Str;
//    }
//
//    private String mAddStr;
//    private String mAdd2Str;
// マイグレーション対応

    public long getmId() {
        return mId;
    }

    public void setmId(long mId) {
        this.mId = mId;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public long getmVertion() {
        return mVertion;
    }

    public void setmVertion(long mVertion) {
        this.mVertion = mVertion;
    }

}

