/*
 * ファイル：IndicatorDialogFactory.java
 * 概要：Indicator dialog loading.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories.customfactories;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import jp.softbank.assist.R;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl.DialogType;

/**
 * indicator loading.
 *
 * @author Systena
 * @version 1.0
 */
@SuppressLint("ValidFragment")
public class IndicatorDialogFactory extends BaseDialogFactory {

    private DialogType mDialogType;
    private ImageView mImgLoading;
    private AnimationDrawable mAnimationDrawable;

    public IndicatorDialogFactory(DialogType dialogType) {
        this.mDialogType = dialogType;
    }

    @Override
    public AlertDialog getReadyAlertDialog(FragmentActivity activity) {
        AlertDialog.Builder builder = createDialogBuilder(activity, R.style.DialogFullWidth);
        LayoutInflater inflater = activity.getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_indicator, null);

        setPositivelyDialog(false);
        setCancelable(false);
        builder.setView(view);
        mImgLoading = view.findViewById(R.id.img_loading);
        mAnimationDrawable = (AnimationDrawable) mImgLoading.getDrawable();
        mAnimationDrawable.start();
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        alertDialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        return alertDialog;
    }

    @Override
    public String getDialogTag() {
        return mDialogType.name();
    }
}
