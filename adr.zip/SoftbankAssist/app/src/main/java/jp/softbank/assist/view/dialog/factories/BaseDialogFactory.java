/*
 * ファイル：BaseDialogFactory.java
 * 概要：ダイアログFactoryベースクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.FragmentActivity;
import android.view.View;

import java.io.Serializable;

/**
 * ダイアログFactoryベースクラス
 *
 * @author Systena
 * @version 1.0
 */
public abstract class BaseDialogFactory implements Serializable {
    /**
     * ダイアログキャンセルがOKボタン押下同等の動作にする場合true.
     */
    private boolean mIsPositivelyDialog = true;
    /**
     * ダイアログ重複表示時、ダイアログ消去可能な場合true.
     */
    private boolean mIsRemovable = true;

    /**
     * ダイアログのキャンセル操作が有効の場合true.
     */
    private boolean mIsCancelable = true;

    /**
     * ダイアログを取得.
     *
     * @param activity ダイアログを表示するActivity
     * @return ダイアログ
     */
    public AlertDialog getReadyAlertDialog(final FragmentActivity activity) {
        return null;
    }

    /**
     * ダイアログのPositiveButtonタップ時の通知に使用されるインターフェイス.<br>
     * 自動でダイアログを非表示する処理を抑止する際に使用する.<br>
     *
     * @author Systena
     * @version 1.0
     */
    public interface PositiveButtonClickListener extends View.OnClickListener, Serializable {
        @Override
        void onClick(View view);
    }

    /**
     * ダイアログのPositiveButtonタップ時の通知に使用するインターフェイスを保持する変数.<br>
     */
    private PositiveButtonClickListener mPositiveButtonClickListener = null;

    /**
     * BaseDialog#onShowがコールされた際に通知する関数を定義したインターフェイス.<br>
     * ダイアログ表示時に処理が必要な場合に使用する.<br>
     *
     * @author Systena
     * @version 1.0
     */
    public interface CustomOnShowListener extends Serializable {
        void onShow(Context context, DialogInterface dialog);
    }

    /**
     * CustomOnShowListenerのインスタンスを保持する変数.<br>
     */
    private CustomOnShowListener mCustomOnShowListener = null;
    /**
     * OnCancelListenerのインスタンスを保持する変数.<br>
     * transient指定することでダイアログ再利用時にOnCancelListenerがnullになるが、
     * システム動作としてダイアログを再利用するケースが無い（BaseDialog#onPauseで必ず自身のダイアログを閉じる）ため、
     * OnCancelListenerのnull化を許容する.
     */
    private transient DialogInterface.OnCancelListener mOnCancelListener;

    /**
     * OnDismissListenerのインスタンスを保持する変数.<br>
     * transient指定することでダイアログ再利用時にOnCancelListenerがnullになるが、
     * システム動作としてダイアログを再利用するケースが無い（BaseDialog#onPauseで必ず自身のダイアログを閉じる）ため、
     * OnCancelListenerのnull化を許容する.
     */
    private transient DialogInterface.OnDismissListener mOnDismissListener;

    /**
     * ダイアログタグを取得.
     *
     * @return ダイアログタグ名
     */
    public abstract String getDialogTag();

    /**
     * ダイアログビルダーを生成.
     *
     * @param activity ダイアログ表示するActivity
     * @return 生成された空のダイアログビルダー
     */
    protected AlertDialog.Builder createDialogBuilder(final FragmentActivity activity) {
        return new AlertDialog.Builder(activity);
    }

    /**
     * create alert dialog with theme.
     *
     * @param activity activity show dialog.
     * @param theme    theme of dialog.
     * @return Empty alert dialog.
     */
    protected AlertDialog.Builder createDialogBuilder(final FragmentActivity activity, int theme) {
        return new AlertDialog.Builder(activity, theme);
    }

    /**
     * ダイアログキャンセル時の動作指定を返す.
     *
     * @return OKボタン押下同等にする場合true、キャンセル処理する場合false
     */
    public boolean isPositivelyDialog() {
        return mIsPositivelyDialog;
    }

    /**
     * ダイアログキャンセル時の動作制御.
     *
     * @param isPositive OKボタン押下同等にする場合true、キャンセル処理する場合false
     */
    protected void setPositivelyDialog(boolean isPositive) {
        mIsPositivelyDialog = isPositive;
    }

    /**
     * ダイアログ重複表示時のダイアログ消去可否を取得.
     *
     * @return ダイアログ重複表示時、ダイアログ消去可能な場合true.
     */
    public boolean isRemovable() {
        return mIsRemovable;
    }

    /**
     * ダイアログ重複表示時の消去可能制御.
     *
     * @param isRemovable ダイアログ重複表示時、ダイアログ消去可能とする場合true、消去不可能とする場合false
     */
    protected void setRemovable(boolean isRemovable) {
        mIsRemovable = isRemovable;
    }

    /**
     * ダイアログのキャンセル操作の有効・無効を取得
     *
     * @return ダイアログのキャンセル操作が有効な場合true.
     */
    public boolean isCancelable() {
        return mIsCancelable;
    }

    /**
     * ダイアログのキャンセル操作の有効・無効を設定.
     *
     * @param isCancelable ダイアログのキャンセル操作が有効な場合true、無効の場合false
     */
    protected void setCancelable(boolean isCancelable) {
        mIsCancelable = isCancelable;
    }

    /**
     * 設定されているPositiveButtonClickListenerを取得.<br>
     *
     * @return PositiveButtonClickListenerのインスタンス
     */
    public PositiveButtonClickListener getPositiveButtonClickListener() {
        return mPositiveButtonClickListener;
    }

    /**
     * PositiveButtonClickListenerを設定.<br>
     *
     * @param positiveButtonClickListener 処理を実装したPositiveButtonClickListenerのインスタンス
     */
    protected void setPositiveButtonClickListener(PositiveButtonClickListener positiveButtonClickListener) {
        mPositiveButtonClickListener = positiveButtonClickListener;
    }

    /**
     * 設定されているCustomOnShowListenerを取得.<br>
     *
     * @return CustomOnShowListenerのインスタンス
     */
    public CustomOnShowListener getCustomOnShowListener() {
        return mCustomOnShowListener;
    }

    /**
     * CustomOnShowListenerを設定.<br>
     *
     * @param customOnShowListener 処理を実装したCustomOnShowListenerのインスタンス
     */
    protected void setCustomOnShowListener(CustomOnShowListener customOnShowListener) {
        mCustomOnShowListener = customOnShowListener;
    }

    /**
     * OnCancelListenerを設定.<br>
     *
     * @param listener 処理を実装したOnCancelListenerのインスタンス
     */
    public void setOnCancelListener(DialogInterface.OnCancelListener listener) {
        mOnCancelListener = listener;
    }

    /**
     * 設定されているOnCancelListenerを取得.<br>
     *
     * @return OnCancelListenerのインスタンス
     */
    public DialogInterface.OnCancelListener getOnCancelListener() {
        return mOnCancelListener;
    }

    /**
     * OnDismissListenerを設定.<br>
     *
     * @param listener 処理を実装したOnDismissListenerのインスタンス
     */
    public void setOnDismissListener(DialogInterface.OnDismissListener listener) {
        mOnDismissListener = listener;
    }

    /**
     * 設定されているOnDismissListenerを取得.<br>
     *
     * @return OnDismissListenerのインスタンス
     */
    public DialogInterface.OnDismissListener getOnDismissListener() {
        return mOnDismissListener;
    }
}
