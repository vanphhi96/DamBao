/*
 * ファイル：DicListItemCallback.java
 * 概要：
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.activity.dictionary;

import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;

import jp.softbank.assist.view.adapter.AdapterDicList;


/**
 * @author Systena
 * @version 1.0
 */
public class DicListItemCallback extends ItemTouchHelper.Callback {
    private final AdapterDicList mAdapterDicList;

    public DicListItemCallback(AdapterDicList adapterDicList) {
        mAdapterDicList = adapterDicList;
    }

    @Override
    public int getMovementFlags(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
        final int dragFlags = ItemTouchHelper.UP | ItemTouchHelper.DOWN;
        final int swipeFlags = ItemTouchHelper.START | ItemTouchHelper.END;
        return makeMovementFlags(dragFlags, swipeFlags);
    }

    @Override
    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
        if(!viewHolder.equals(AdapterDicList.DicCategoryItemHolder.class)){
            mAdapterDicList.onItemMove(viewHolder.getAdapterPosition(), target.getAdapterPosition());
            return true;
        }
        else {
            return false;
        }

    }

    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {

    }
    @Override
    public boolean isLongPressDragEnabled() {
        return mAdapterDicList.getEnableButtonDrag();
    }

    @Override
    public boolean isItemViewSwipeEnabled() {
        return false;
    }
}
