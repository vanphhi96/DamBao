/*
 * ファイル：RealmCategoryInfo.java
 * 概要：Realm用辞書カテゴリ一覧テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;


import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Realm用辞書カテゴリ一覧テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */

public class RealmCategoryInfo extends RealmObject {

    @PrimaryKey
    private long mCategoryId; // カテゴリID
    private String mName; // カテゴリ名
    private long mIconId; // アイコンID


    public long getCategoryId() {
        return mCategoryId;
    }

    public void setCategoryId(long categoryId) {
        this.mCategoryId = categoryId;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public long getIconId() {
        return mIconId;
    }

    public void setIconId(long iconId) {
        this.mIconId = iconId;
    }
}
