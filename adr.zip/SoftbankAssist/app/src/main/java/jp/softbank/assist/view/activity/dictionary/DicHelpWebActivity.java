/*
 * ファイル：DicHelpWebActivity.java
 * 概要：辞書のヘルプ画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.dictionary;

import jp.softbank.assist.view.activity.BaseWebActivity;

/**
 * dic-help01 ... dic-help10
 *
 * @author Systena
 * @version 1.0
 */
public class DicHelpWebActivity extends BaseWebActivity {
    private static final String URL_DICTIONARY_HELP = "file:///android_asset/help/dictionary/dictionaryhelp.html";

    @Override
    protected void getDataIntent() {
        super.getDataIntent();
        //TODO[3387] fix data to test
        mTitleWeb = "辞書のヘルプ画面";
        mUrlWebView = URL_DICTIONARY_HELP;
    }
}
