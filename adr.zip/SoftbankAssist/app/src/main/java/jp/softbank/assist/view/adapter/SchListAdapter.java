/*
 * ファイル：SchListAdapter.java
 * 概要：Schedule list adapter (sch-01)
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.annotation.SuppressLint;
import android.content.res.Resources;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.FooterSpaceAdapter;
import jp.softbank.assist.view.fragment.schedule.ISchPageFragment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * Schedule list adapter (sch-01)
 *
 * @author Systena
 * @version 1.0
 */
public class SchListAdapter extends FooterSpaceAdapter {
    private List<ScheduleInfo> mListSchedule = new ArrayList<>();
    private Date mDate;
    private ISchPageFragment mISchPageFragment;
    private Date mCurrentTime = new Date();
    private int mPositionCurrentTime = -1;
    private Handler mHandler = new Handler();
    private boolean mRunningHandler;
    private Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            Date newTime = new Date();
            if (DateUtils.compareTo(newTime, mCurrentTime) != 0) {
                mListSchedule = sortListScheduleToday(mListSchedule, newTime);
                notifyDataSetChanged();
            }
            mHandler.postDelayed(mRunnable, 1000);
        }
    };

    /**
     * setter data for mList ScheduleInfo
     *
     * @param listScheduleModel
     */
    public void setListScheduleModel(List<ScheduleInfo> listScheduleModel) {
        if (android.text.format.DateUtils.isToday(mDate.getTime())) {
            this.mListSchedule = sortListScheduleToday(listScheduleModel, mCurrentTime);
        } else {
            this.mListSchedule = sortListScheduleOtherDay(listScheduleModel);
        }

    }

    /**
     * set date show schedule list
     *
     * @param date Date
     */
    public void setDate(Date date) {
        this.mDate = date;
    }


    @Override
    public int getContentItemCount() {
        return mListSchedule.size();
    }

    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_schedule, parent, false);
        return new ItemScheduleViewHolder(view);
    }

    /**
     * set interface for adapter
     *
     * @param iSchPageFragment ISchPageFragment
     */
    public void setInterface(ISchPageFragment iSchPageFragment) {
        this.mISchPageFragment = iSchPageFragment;
    }

    private class ItemScheduleViewHolder extends BaseViewHolder {
        private LinearLayout mLnContent;
        private FrameLayout mFrCurrentTime;
        private FrameLayout mFrCurrentTimeBottom;
        private ImageView mImgCheck;
        private TextView mTvTime;
        private TextView mTvTitle;
        private TextView mTvComment;
        private TextView mTvAddress;
        private ImageView mImgSchedule;
        private TextView mTvCurrentTime;
        private TextView mTvCurrentTimeBottom;
        private ImageView mImgCard;
        private ImageView mImgUser;

        ItemScheduleViewHolder(@NonNull View itemView) {
            super(itemView);
            itemView.setClipToOutline(true);
            mLnContent = itemView.findViewById(R.id.ln_content);
            mFrCurrentTime = itemView.findViewById(R.id.fr_current_time);
            mFrCurrentTimeBottom = itemView.findViewById(R.id.fr_current_time_bottom);
            mImgCheck = itemView.findViewById(R.id.img_check);
            mLnContent.setClipToOutline(true);
            mTvTime = itemView.findViewById(R.id.tv_time);
            mTvTitle = itemView.findViewById(R.id.tv_title);
            mTvComment = itemView.findViewById(R.id.tv_comment);
            mTvAddress = itemView.findViewById(R.id.tv_address);
            mImgSchedule = itemView.findViewById(R.id.img_schedule);
            mImgCard = itemView.findViewById(R.id.img_card);
            mImgUser = itemView.findViewById(R.id.img_user);
            mTvCurrentTime = itemView.findViewById(R.id.tv_current_time_schedule);
            mTvCurrentTimeBottom = itemView.findViewById(R.id.tv_current_time_schedule_bottom);
            mLnContent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mISchPageFragment == null || getLayoutPosition() == RecyclerView.NO_POSITION) {
                        return;
                    }
                    mISchPageFragment.onClickSchedule(mListSchedule.get(getLayoutPosition()));
                }
            });
        }

        @SuppressLint("StringFormatMatches")
        @Override
        public void onBindView(int position) {
            ScheduleInfo model = mListSchedule.get(position);
            mCurrentTime = new Date();
            mTvAddress.setVisibility(View.GONE);
            mImgCheck.setVisibility(View.GONE);
            if (model.isCompleted()) {
                mImgCheck.setAlpha((float) 0.5);
                mTvTime.setAlpha((float) 0.5);
                mTvTitle.setAlpha((float) 0.5);
                mTvComment.setAlpha((float) 0.5);
                mTvAddress.setAlpha((float) 0.5);
                mImgSchedule.setAlpha((float) 0.5);
                mImgCard.setAlpha((float) 0.5);
                mImgUser.setAlpha((float) 0.5);
                mImgCheck.setVisibility(View.VISIBLE);
            } else {
                mImgCheck.setAlpha((float) 1);
                mTvTime.setAlpha((float) 1);
                mTvTitle.setAlpha((float) 1);
                mTvComment.setAlpha((float) 1);
                mTvAddress.setAlpha((float) 1);
                mImgSchedule.setAlpha((float) 1);
                mImgCard.setAlpha((float) 1);
                mImgUser.setAlpha((float) 1);
                mImgCheck.setVisibility(View.GONE);
            }
            if (model.isAllDay()) {
                mTvTime.setText(mTvTime.getContext().getString(R.string.sch_allday));
                mTvTime.setTextColor(mTvTime.getContext().getResources().getColor(R.color.sch_detail_layout_done, null));
            } else {
                String strTime;
                if (DateUtils.compareEqualDate(mDate, model.getScheduleStartDate())) {
                    strTime = DateUtils.getTimeInDate(model.getScheduleStartDate());
                } else {
                    strTime = DateUtils.convertDateToString(model.getScheduleStartDate(), DateUtils.SCHEDULE_OTHER_DATE_FORMAT);
                }
                if (DateUtils.compareEqualDate(mDate, model.getScheduleEndDate())) {
                    strTime = strTime + "-" + DateUtils.getTimeInDate(model.getScheduleEndDate());
                } else {
                    strTime = strTime + "-" + DateUtils.convertDateToString(model.getScheduleEndDate(), DateUtils.SCHEDULE_OTHER_DATE_FORMAT);
                }
                mTvTime.setText(strTime);
                mTvTime.setTextColor(mTvTime.getContext().getResources().getColor(R.color.sch_detail_time, null));
            }
            mTvTitle.setText(model.getTitle());
            mTvComment.setText(model.getNote());
            String address = mTvAddress.getContext().getString(R.string.sch_location) + model.getLocation();
            mTvAddress.setText(address);
            mImgCard.setVisibility(model.getAttachedDictionaries().isEmpty() ? View.INVISIBLE : View.VISIBLE);
            mImgSchedule.setImageResource(ResourcesUtils.getScheduleIconResourceFromId(model.getIconName()));
            try {
                mImgUser.setVisibility(View.VISIBLE);
                mImgUser.setImageDrawable(mImgUser.getContext().getDrawable(ResourcesUtils.getUserIconResourceFromId((int) model.getCreatorIconId())));
            } catch (Resources.NotFoundException e) {
                mImgUser.setVisibility(View.INVISIBLE);
                AssistLog.e(e.toString());
            }
            if (model.isAllDay() && !model.isCompleted()) {
                mLnContent.setBackgroundResource(R.drawable.bgr_item_all_day);
                mImgSchedule.setBackground(mImgSchedule.getContext().getDrawable(R.drawable.bgr_sch_item_all_day_icon));
            } else if (model.isAllDay() && model.isCompleted()) {
                mLnContent.setBackgroundResource(R.drawable.bgr_item_all_day);
                mImgSchedule.setBackground(mImgSchedule.getContext().getDrawable(R.drawable.bgr_sch_item_all_day_icon));

            } else if (!model.isAllDay() && model.isCompleted()) {
                mImgSchedule.setBackground(mImgSchedule.getContext().getDrawable(R.drawable.sch_icon_current_time));
                mLnContent.setBackgroundResource(R.drawable.bgr_item_schedule_current_time);
            } else {
                mLnContent.setBackgroundResource(R.drawable.bgr_item_schedule);
                mImgSchedule.setBackground(mImgSchedule.getContext().getDrawable(R.drawable.bgr_sch_item_icon));
            }
            if (android.text.format.DateUtils.isToday(mDate.getTime())) {
                if (position == getContentItemCount() - 1 && mPositionCurrentTime >= getContentItemCount()) {
                    mFrCurrentTime.setVisibility(View.GONE);
                    mFrCurrentTimeBottom.setVisibility(View.VISIBLE);
                    mTvCurrentTimeBottom.setText(DateUtils.getTimeInDate(mCurrentTime));
                } else if (position == mPositionCurrentTime) {
                    mFrCurrentTime.setVisibility(View.VISIBLE);
                    mFrCurrentTimeBottom.setVisibility(View.GONE);
                    mTvCurrentTime.setText(DateUtils.getTimeInDate(mCurrentTime));
                } else {
                    mFrCurrentTime.setVisibility(View.GONE);
                    mFrCurrentTimeBottom.setVisibility(View.GONE);
                }
            }
            if (android.text.format.DateUtils.isToday(mDate.getTime())) {
                mHandler.postDelayed(mRunnable, 1000);
                mRunningHandler = true;
            } else if (mRunningHandler) {
                mHandler.removeCallbacks(mRunnable);
            }

        }
    }

    /**
     * sort list schedule
     *
     * @param listSchedule list schedule
     * @return
     */
    private List<ScheduleInfo> sortListScheduleOtherDay(List<ScheduleInfo> listSchedule) {
        List<ScheduleInfo> listSort = new ArrayList<>();
        List<ScheduleInfo> listAllDay = new ArrayList<>();
        for (ScheduleInfo scheduleInfo : listSchedule) {
            if (scheduleInfo.isAllDay()) {
                listAllDay.add(scheduleInfo);
            }
        }
        listSchedule.removeAll(listAllDay);
        sortListScheduleByStartDate(listAllDay);
        sortListScheduleByStartDate(listSchedule);
        listSort.addAll(listAllDay);
        listSort.addAll(listSchedule);
        return listSort;
    }

    /**
     * sort list schedule
     *
     * @param listSchedule list schedule
     * @return List Schedule
     */
    private List<ScheduleInfo> sortListScheduleToday(List<ScheduleInfo> listSchedule, final Date currentTime) {
        List<ScheduleInfo> listSort = new ArrayList<>();
        List<ScheduleInfo> listAllDay = new ArrayList<>();
        List<ScheduleInfo> listBigger = new ArrayList<>();
        List<ScheduleInfo> listSmall = new ArrayList<>();
        for (ScheduleInfo scheduleInfo : listSchedule) {
            if (scheduleInfo.isAllDay()) {
                listAllDay.add(scheduleInfo);
            } else if (DateUtils.compareTo(scheduleInfo.getScheduleEndDate(), currentTime) < 0) {
                listSmall.add(scheduleInfo);
            } else {
                listBigger.add(scheduleInfo);
            }
        }

        mPositionCurrentTime = listAllDay.size() + listSmall.size() + (listBigger.isEmpty() ? 1 : 0);
        sortListScheduleByStartDate(listAllDay);
        listSort.addAll(listAllDay);
        sortListScheduleByEndDate(listSmall);
        listSort.addAll(listSmall);
        sortListScheduleByStartDate(listBigger);
        listSort.addAll(listBigger);
        return listSort;
    }

    /**
     * sort list schedule by date start and end
     *
     * @param listSchedule
     */

    private void sortListScheduleByEndDate(List<ScheduleInfo> listSchedule) {
        Collections.sort(listSchedule, new Comparator<ScheduleInfo>() {
            public int compare(ScheduleInfo sch1, ScheduleInfo sch2) {
                return DateUtils.compareTo(sch1.getScheduleEndDate(), sch2.getScheduleEndDate());
            }
        });
    }

    /**
     * sort list schedule by date start and end
     *
     * @param listSchedule
     */
    private void sortListScheduleByStartDate(List<ScheduleInfo> listSchedule) {
        Collections.sort(listSchedule, new Comparator<ScheduleInfo>() {
            @Override
            public int compare(ScheduleInfo sch1, ScheduleInfo sch2) {
                Date start1 = sch1.getScheduleStartDate();
                Date start2 = sch2.getScheduleStartDate();
                int startCompare = start1.compareTo(start2);
                if (startCompare != 0) {
                    return startCompare;
                }
                Date end1 = sch1.getScheduleEndDate();
                Date end2 = sch2.getScheduleEndDate();
                return end1.compareTo(end2);
            }
        });

    }
}
