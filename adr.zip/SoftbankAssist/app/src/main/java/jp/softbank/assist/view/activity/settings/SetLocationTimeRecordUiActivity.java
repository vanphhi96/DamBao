/*
 * ファイル：SetLocationTimeRecordUiActivity.java
 * 概要：位置情報取得画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.settings;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.LocationSettings;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;
import jp.softbank.assist.view.dialog.factories.customfactories.ISetTimePicker;
import jp.softbank.assist.view.dialog.factories.customfactories.SetTimePickerDialogFactory;

import java.util.Calendar;
import java.util.Date;

/**
 * set-pos-02
 *
 * @author Systena
 * @version 1.0
 */
public class SetLocationTimeRecordUiActivity extends BaseUiActivity implements
        View.OnClickListener,
        ISetTimePicker,
        CompoundButton.OnCheckedChangeListener,
        NotifyOnlyResultListener {
    private TextView mTvStartTime;
    private TextView mTvEndTime;
    private TextView mTvSave;
    private View mViewBack;
    private Date mDateStart;
    private Date mDateEnd;
    private Calendar mCalendarForMin = Calendar.getInstance();
    private Calendar mCalendarForMax = Calendar.getInstance();
    private DialogFragment mDialogFragment;
    private Switch mSw24h;
    private View mLnAboveContainer;
    private LocationSettings mLocationSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_location_time_record);
        getLocationSettings();
        initView();
    }

    /**
     * View初期化
     */
    private void initView() {
        mTvStartTime = findViewById(R.id.tv_start_time);
        mTvEndTime = findViewById(R.id.tv_end_time);
        mSw24h = findViewById(R.id.sw_set_24h);
        mLnAboveContainer = findViewById(R.id.ln_set_above_container);
        mTvSave = findViewById(R.id.tv_save);
        mViewBack = findViewById(R.id.ln_back);
        mTvSave.setOnClickListener(this);
        mSw24h.setOnCheckedChangeListener(this);
        mTvStartTime.setOnClickListener(this);
        mTvEndTime.setOnClickListener(this);
        mViewBack.setOnClickListener(this);

        mDateStart = mLocationSettings.getRegularLocationStartTime();
        mDateEnd = mLocationSettings.getRegularLocationEndTime();

        if (isAllDay()) {
            mLnAboveContainer.setVisibility(View.GONE);
            mSw24h.setChecked(true);
        }
        mTvStartTime.setText(DateUtils.convertDateToStringSetting(mDateStart));
        mTvEndTime.setText(DateUtils.convertDateToStringSetting(mDateEnd));
    }

    /**
     * If 24h is chosen in LocationSettings.
     *
     * @return
     */
    private boolean isAllDay() {
        return (mLocationSettings.getRegularLocationTermKind() == LocationSettings.TermType.AllDay);
    }

    /**
     * BundleでLocation Settings取得
     *
     * @return LocationSettings
     */
    private void getLocationSettings() {
        Bundle bundle = getIntent().getExtras();
        mLocationSettings = getIntent().hasExtra(SetLocationSettingUiActivity.LOCATION_SETTING_KEY)
                ? (LocationSettings) (bundle.getSerializable(SetLocationSettingUiActivity.LOCATION_SETTING_KEY))
                : null;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_start_time:
                showTimeDialog(view.getId());
                break;
            case R.id.tv_end_time:
                showTimeDialog(view.getId());
                break;
            case R.id.tv_save:
                mLocationSettings.setRegularLocationStartTime(mDateStart);
                mLocationSettings.setRegularLocationEndTime(mDateEnd);
                AppController.getInstance().getAssistServerInterface().sendLocationSettings(mLocationSettings, this);
                break;
            case R.id.ln_back:
                onBackPressed();
            default:
                break;
        }
    }

    /**
     * TimeDialogを表示
     *
     * @param viewId
     */
    private void showTimeDialog(int viewId) {
        SetTimePickerDialogFactory mDialogFactory =
                new SetTimePickerDialogFactory
                        (DialogTypeControl.DialogType.SET_TIME_PICKER_DIALOG, this, viewId);
        if (viewId == R.id.tv_end_time) {
            // Because Start and End time cannot be the same --> + 1
            mDialogFactory.setRangeMin(mCalendarForMin.get(Calendar.HOUR_OF_DAY), mCalendarForMin.get(Calendar.MINUTE) + 1);
            mDialogFactory.setDisplayDate(mDateEnd);
        } else {
            mDialogFactory.setDisplayDate(mDateStart);
            mDialogFactory.setRangeMax(mCalendarForMax.get(Calendar.HOUR_OF_DAY), mCalendarForMax.get(Calendar.MINUTE) -1);
        }
        mDialogFragment = new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * ISetTimePicker Interface
     *
     * @param viewId
     * @param date
     */
    @Override
    public void onOkClick(int viewId, Date date) {
        mDialogFragment.dismiss();
        switch (viewId) {
            case R.id.tv_start_time:
                mCalendarForMin.setTime(date);
                mDateStart = date;
                mTvStartTime.setText(DateUtils.convertDateToStringSetting(date));
                break;
            case R.id.tv_end_time:
                mCalendarForMax.setTime(date);
                mDateEnd = date;
                mTvEndTime.setText(DateUtils.convertDateToStringSetting(date));
                break;
        }
    }

    /**
     * ISetTimePicker Interface
     */
    @Override
    public void onCancelClick() {
        mDialogFragment.dismiss();
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.sw_set_24h:
                if (isChecked) {
                    mLocationSettings.setRegularLocationTermKind(LocationSettings.TermType.AllDay);
                    hideViewWithAnim(mLnAboveContainer);
                } else {
                    mLocationSettings.setRegularLocationTermKind(LocationSettings.TermType.Times);
                    showViewWithAnim(mLnAboveContainer);
                }
                break;
            default:
                break;
        }
    }

    /**
     * @param result 処理結果
     */
    @Override
    public void onResult(AssistServerResult result) {
        closeIndicator();
        if (result.mResult != AssistServerResult.Result.Success) {
            // TODO: 2019/04/19  T.B.D
        } else {
            finish();
        }

    }

    @Override
    public void onStartConnection() {
        displayIndicator();
    }
}
