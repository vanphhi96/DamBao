/*
 * ファイル：DeviceInfo.java
 * 概要：デバイス情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

/**
 * デバイス情報
 *
 * @author Systena
 * @version 1.0
 */
public class DeviceInfo {

    private boolean mSendToken; // トークン送信状態
    private String mFcmToken; // FCM端末登録トークン
    private String mOsVersion; // OSバージョン
    private String mAppVersion; // アプリバージョン

    public boolean isSendToken() {
        return mSendToken;
    }

    public void setSendToken(boolean sendToken) {
        this.mSendToken = sendToken;
    }

    public String getFcmToken() {
        return mFcmToken;
    }

    public void setFcmToken(String fcmToken) {
        this.mFcmToken = fcmToken;
    }

    public String getOsVersion() {
        return mOsVersion;
    }

    public void setOsVersion(String osVersion) {
        this.mOsVersion = osVersion;
    }

    public String getAppVersion() {
        return mAppVersion;
    }

    public void setAppVersion(String appVersion) {
        this.mAppVersion = appVersion;
    }

}
