/*
 * ファイル：SynchronizeDictionaryResultCard.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

/**
 * カード情報.
 */
public class SynchronizeDictionaryResultCard {

    @SerializedName("mId")
    private Long mId = null;
    @SerializedName("dictionary_id")
    private Long mDictionaryId = null;
    @SerializedName("next_card_id")
    private Long mNextCardId = null;
    @SerializedName("image_path")
    private String mImagePath = null;
    @SerializedName("mText")
    private String mText = null;
    @SerializedName("version")
    private Long mVersion = null;
    @SerializedName("created_at")
    private String mCreatedAt = null;
    @SerializedName("updated_at")
    private String mUpdatedAt = null;
    @SerializedName("created_by")
    private Long mCreatedBy = null;
    @SerializedName("updated_by")
    private Long mUpdatedBy = null;
    @SerializedName("is_deleted")
    private Long mIsDeleted = null;


    /**
     * カードID.
     */
    public Long getId() {
        return mId;
    }
    public void setId(Long id) {
        this.mId = id;
    }

    /**
     * 辞書ID.
     */
    public Long getDictionaryId() {
        return mDictionaryId;
    }
    public void setDictionaryId(Long dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }

    /**
     * 次カードID.
     */
    public Long getNextCardId() {
        return mNextCardId;
    }
    public void setNextCardId(Long nextCardId) {
        this.mNextCardId = nextCardId;
    }

    /**
     * カード画像パス.
     */
    public String getImagePath() {
        return mImagePath;
    }
    public void setImagePath(String imagePath) {
        this.mImagePath = imagePath;
    }

    /**
     * カード内容.
     */
    public String getText() {
        return mText;
    }
    public void setText(String text) {
        this.mText = text;
    }

    /**
     * バージョン.
     */
    public Long getVersion() {
        return mVersion;
    }
    public void setVersion(Long version) {
        this.mVersion = version;
    }

    /**
     * 作成日時（YYYYMMDDhhmmss形式）.
     */
    public String getCreatedAt() {
        return mCreatedAt;
    }
    public void setCreatedAt(String createdAt) {
        this.mCreatedAt = createdAt;
    }

    /**
     * 更新日時（YYYYMMDDhhmmss形式）.
     */
    public String getUpdatedAt() {
        return mUpdatedAt;
    }
    public void setUpdatedAt(String updatedAt) {
        this.mUpdatedAt = updatedAt;
    }

    /**
     * 作成者.
     */
    public Long getCreatedBy() {
        return mCreatedBy;
    }
    public void setCreatedBy(Long createdBy) {
        this.mCreatedBy = createdBy;
    }

    /**
     * 更新者.
     */
    public Long getUpdatedBy() {
        return mUpdatedBy;
    }
    public void setUpdatedBy(Long updatedBy) {
        this.mUpdatedBy = updatedBy;
    }

    /**
     * 削除済フラグ.
     */
    public Long getIsDeleted() {
        return mIsDeleted;
    }
    public void setIsDeleted(Long isDeleted) {
        this.mIsDeleted = isDeleted;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SynchronizeDictionaryResultCard resultCard = (SynchronizeDictionaryResultCard) o;
        return (this.mId == null ? resultCard.mId == null : this.mId.equals(resultCard.mId)) &&
                (this.mDictionaryId == null ? resultCard.mDictionaryId == null : this.mDictionaryId.equals(resultCard.mDictionaryId)) &&
                (this.mNextCardId == null ? resultCard.mNextCardId == null : this.mNextCardId.equals(resultCard.mNextCardId)) &&
                (this.mImagePath == null ? resultCard.mImagePath == null : this.mImagePath.equals(resultCard.mImagePath)) &&
                (this.mText == null ? resultCard.mText == null : this.mText.equals(resultCard.mText)) &&
                (this.mVersion == null ? resultCard.mVersion == null : this.mVersion.equals(resultCard.mVersion)) &&
                (this.mCreatedAt == null ? resultCard.mCreatedAt == null : this.mCreatedAt.equals(resultCard.mCreatedAt)) &&
                (this.mUpdatedAt == null ? resultCard.mUpdatedAt == null : this.mUpdatedAt.equals(resultCard.mUpdatedAt)) &&
                (this.mCreatedBy == null ? resultCard.mCreatedBy == null : this.mCreatedBy.equals(resultCard.mCreatedBy)) &&
                (this.mUpdatedBy == null ? resultCard.mUpdatedBy == null : this.mUpdatedBy.equals(resultCard.mUpdatedBy)) &&
                (this.mIsDeleted == null ? resultCard.mIsDeleted == null : this.mIsDeleted.equals(resultCard.mIsDeleted));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mId == null ? 0: this.mId.hashCode());
        result = 31 * result + (this.mDictionaryId == null ? 0: this.mDictionaryId.hashCode());
        result = 31 * result + (this.mNextCardId == null ? 0: this.mNextCardId.hashCode());
        result = 31 * result + (this.mImagePath == null ? 0: this.mImagePath.hashCode());
        result = 31 * result + (this.mText == null ? 0: this.mText.hashCode());
        result = 31 * result + (this.mVersion == null ? 0: this.mVersion.hashCode());
        result = 31 * result + (this.mCreatedAt == null ? 0: this.mCreatedAt.hashCode());
        result = 31 * result + (this.mUpdatedAt == null ? 0: this.mUpdatedAt.hashCode());
        result = 31 * result + (this.mCreatedBy == null ? 0: this.mCreatedBy.hashCode());
        result = 31 * result + (this.mUpdatedBy == null ? 0: this.mUpdatedBy.hashCode());
        result = 31 * result + (this.mIsDeleted == null ? 0: this.mIsDeleted.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class SynchronizeDictionaryResultCard {\n");

        sb.append("  mId: ").append(mId).append("\n");
        sb.append("  mDictionaryId: ").append(mDictionaryId).append("\n");
        sb.append("  mNextCardId: ").append(mNextCardId).append("\n");
        sb.append("  mImagePath: ").append(mImagePath).append("\n");
        sb.append("  mText: ").append(mText).append("\n");
        sb.append("  mVersion: ").append(mVersion).append("\n");
        sb.append("  mCreatedAt: ").append(mCreatedAt).append("\n");
        sb.append("  mUpdatedAt: ").append(mUpdatedAt).append("\n");
        sb.append("  mCreatedBy: ").append(mCreatedBy).append("\n");
        sb.append("  mUpdatedBy: ").append(mUpdatedBy).append("\n");
        sb.append("  mIsDeleted: ").append(mIsDeleted).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
