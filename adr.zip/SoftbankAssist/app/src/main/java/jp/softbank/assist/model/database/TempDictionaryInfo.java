/*
 * ファイル：TempDictionaryInfo.java
 * 概要：辞書情報（作成時）
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import android.graphics.Bitmap;

import jp.softbank.assist.model.ModelInterface;
import jp.softbank.assist.util.Constants;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 辞書情報（作成時）.
 *
 * @author Systena
 * @version 1.0
 */
public class TempDictionaryInfo extends DictionaryInfo {

    /**
     * コンストラクタ.
     *
     * @param categoryId 辞書カテゴリ
     */
    public TempDictionaryInfo(long categoryId) {
        setCategoryId(categoryId);
        List<CardInfo> list = new ArrayList<CardInfo>();
        setCardList(list);
        addCard();
    }

    @Override
    public void setCategoryId(long categoryId) {
        super.setCategoryId(categoryId);
        if (categoryId == Constants.Ids.CATEGORY_ID_PROPERTY) {
            setType(DictionaryType.Check);
        } else {
            setType(DictionaryType.Step);
        }
    }

    /**
     * 編集済みか確認する.
     *
     * @return true:編集済み、false:未編集
     */
    @Override
    public boolean isEdited() {
        return true;
    }

    /**
     * 追加・編集時のキャンセル.
     */
    @Override
    public void cancel() {
        getImagePath(Constants.Dictionary.DICTIONARY_TEMP_IMAGE_FILENAME).delete();
        if (getCardList() != null && getCardList().size() > 0) {
            for(CardInfo cardInfo: getCardList()){
                cardInfo.cancel();
            }
        }
    }

    /**
     * 辞書画像のパス.
     *
     * @param fileName ファイル名
     * @return File
     */
    @Override
    protected File getImagePath(final String fileName) {
        File file = ModelInterface.getDictionaryTempDir();
        return new File(file, fileName);
    }

    /**
     * 画像ファイルが有効（保存済み）か確認する.
     *
     * @return true:有効、false:無効
     */
    @Override
    public boolean isImageEnabled() {
        return Constants.Dictionary.DICTIONARY_TEMP_IMAGE_FILENAME.equals(getImageFileName());
    }

    /**
     * 画像の保存.
     *
     * @param bitmap ビットマップ
     * @return true:成功、false:失敗
     */
    @Override
    public boolean setImage(Bitmap bitmap) {
        bitmap = ModelInterface.scaleDictionaryImage(bitmap);
        boolean result = ModelInterface.saveDictionaryImage(bitmap,
                getImagePath(Constants.Dictionary.DICTIONARY_TEMP_IMAGE_FILENAME));
        if (result) {
            setImageFileName(Constants.Dictionary.DICTIONARY_TEMP_IMAGE_FILENAME);
        }
        return result;
    }

    /**
     * 画像設定の削除.
     */
    @Override
    public void clearImage() {
        getImagePath(Constants.Dictionary.DICTIONARY_TEMP_IMAGE_FILENAME).delete();
        setImageFileName("");
    }

    /**
     * 画像ファイルパスの取得.
     *
     * @return ファイルパス
     */
    @Override
    public String getImageFileAbsolutePath() {
        if (isImageEnabled()) {
            File file = getImagePath(getImageFileName());
            if (file.exists()) {
                return file.getAbsolutePath();
            }
        }
        return null;
    }

    /**
     * カードの追加（インデックス指定）.
     *
     * @param index インデックス。範囲外の場合は最後に追加
     * @return CardInfo:成功、null:失敗
     */
    @Override
    public CardInfo addCard(final int index) {
        List<CardInfo> list = getCardList();
        if (list != null) {
            if (list.size() < Constants.Dictionary.MAX_CARD_NUM) {
                TempCardInfo card = TempCardInfo.newInstance();
                if (index >= 0 && index < list.size()) {
                    list.add(index, card);
                } else {
                    list.add(card);
                }
                return card;
            }
        }
        return null;
    }
}
