/*
 * ファイル：SetTopAdapter.java
 * 概要：Adapter list set top (set-01).
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.SetModel;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.FooterSpaceAdapter;
import jp.softbank.assist.view.fragment.settings.ISetTopFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * set-01
 *
 * @author Systena
 * @version 1.0
 */
public class SetTopAdapter extends FooterSpaceAdapter {
    private List<SetModel> mListSet = new ArrayList<>();
    private ISetTopFragment mISetTopFragment;

    /**
     * setter data for adapter
     *
     * @param mListScheduleModel
     */
    public void setData(List<SetModel> mListScheduleModel) {
        this.mListSet = mListScheduleModel;
    }

    /**
     * set interface for adapter
     *
     * @param iSetTopFragment
     */
    public void setInterface(ISetTopFragment iSetTopFragment) {
        this.mISetTopFragment = iSetTopFragment;
    }

    @Override
    public int getContentItemCount() {
        return mListSet.size();
    }

    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_set, parent, false);
        return new ItemScheduleViewHolder(view);
    }

    private class ItemScheduleViewHolder extends BaseViewHolder {
        private TextView mTvTitle;
        private TextView mTvDescription;
        private ImageView mImgSet;


        ItemScheduleViewHolder(@NonNull View itemView) {
            super(itemView);
            mTvTitle = itemView.findViewById(R.id.tv_title);
            mTvDescription = itemView.findViewById(R.id.tv_description);
            mImgSet = itemView.findViewById(R.id.img_set);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (getLayoutPosition() == RecyclerView.NO_POSITION || mISetTopFragment == null) {
                        return;
                    }
                    mISetTopFragment.clickItem(mListSet.get(getLayoutPosition()));
                }
            });
        }

        @Override
        public void onBindView(int position) {
            SetModel model = mListSet.get(position);
            mTvTitle.setText(model.getTitle());
            mTvDescription.setText(model.getDescription());
            mImgSet.setImageResource(model.getDrawable());
        }
    }
}
