/*
 * ファイル：ModelInterface.java
 * 概要：アプリで保持するデータの管理を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model;

import android.content.Context;
import android.graphics.Bitmap;

import io.realm.Realm;
import io.realm.RealmConfiguration;
import io.realm.RealmList;
import io.realm.RealmResults;
import io.realm.Sort;

import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.AppVersionInfo;
import jp.softbank.assist.model.database.AuthInfo;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DeviceInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.model.database.DictionaryOrderInfo;
import jp.softbank.assist.model.database.LocationSettings;
import jp.softbank.assist.model.database.NoticeInfo;
import jp.softbank.assist.model.database.ScheduleCount;
import jp.softbank.assist.model.database.ScheduleGetHistory;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.model.database.TimerInfo;
import jp.softbank.assist.model.database.UserInfo;
import jp.softbank.assist.model.realmdatabase.AssistMigration;
import jp.softbank.assist.model.realmdatabase.RealmAppVersionInfo;
import jp.softbank.assist.model.realmdatabase.RealmAuthInfo;
import jp.softbank.assist.model.realmdatabase.RealmCardInfo;
import jp.softbank.assist.model.realmdatabase.RealmCategoryInfo;
import jp.softbank.assist.model.realmdatabase.RealmConstants;
import jp.softbank.assist.model.realmdatabase.RealmDeviceInfo;
import jp.softbank.assist.model.realmdatabase.RealmDicOrderInfo;
import jp.softbank.assist.model.realmdatabase.RealmDictionaryInfo;
import jp.softbank.assist.model.realmdatabase.RealmLocationSetting;
import jp.softbank.assist.model.realmdatabase.RealmNoticeInfo;
import jp.softbank.assist.model.realmdatabase.RealmScheduleGetHistory;
import jp.softbank.assist.model.realmdatabase.RealmScheduleInfo;
import jp.softbank.assist.model.realmdatabase.RealmTimerInfo;
import jp.softbank.assist.model.realmdatabase.RealmUserInfo;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.DateUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

/**
 * データ管理クラス.
 *
 * @author Systena
 * @version 1.0
 */
public class ModelInterface {

    private Realm mRealm;

    /**
     * Realm開始
     */
    private void realmStart() {

        mRealm = Realm.getDefaultInstance();
        mRealm.beginTransaction();
    }

    /**
     * Realm完了
     */
    private void realmEnd() {
        mRealm.close();
    }

    /**
     * Realmとテーブル初期化
     * <p>
     * (UserInfo, AuthInfo, DeviceInfo, LocationSetting,
     * LocationInfo, AppVersionInfo, NoticeInfo, CategoryInfo,
     * DicInfo, CardInfo, SchInfo, DicOrderInfo, SchGetHistory,
     * TimerInfo)
     */
    public static void initDatabase(Context context) {
        Realm.init(context);

        initTable(RealmConstants.UserInfo.USER_INFO_TABLE);
        initTable(RealmConstants.AuthInfo.AUTH_INFO_TABLE);
        initTable(RealmConstants.DeviceInfo.DEVICE_INFO_TABLE);
        initTable(RealmConstants.LocationSettings.LOCATION_SETTING_TABLE);
        initTable(RealmConstants.LocationInfo.LOCATION_INFO_TABLE);
        initTable(RealmConstants.AppVersionInfo.APP_VERSION_INFO_TABLE);
        initTable(RealmConstants.NoticeInfo.NOTICE_INFO_TABLE);
        initTable(RealmConstants.CategoryInfo.CATEGORY_INFO_TABLE);
        initTable(RealmConstants.DictionaryInfo.DICTIONARY_INFO_TABLE);
        initTable(RealmConstants.CardInfo.CARD_INFO_TABLE);
        initTable(RealmConstants.ScheduleInfo.SCHEDULE_INFO_TABLE);
        initTable(RealmConstants.DictionaryOrderInfo.DICTIONARY_ORDER_INFO_TABLE);
        initTable(RealmConstants.ScheduleGetHistory.SCHEDULE_GET_HISTORY_TABLE);
        initTable(RealmConstants.TimerInfo.TIMER_INFO_TABLE);
    }

    /**
     * テーブル初期化
     *
     * @param tableName テーブル名
     */
    private static void initTable(String tableName) {
        // TODO: Migration発生時実装箇所
        /* Migration実施時、AssistMigration.java migrate()を呼び出す
         name:DB名(データを保存しているファイル実名)
         schemaVersion:バージョンアップ後のバージョン(数値)
        */
        RealmConfiguration realmConfiguration = new RealmConfiguration.Builder()
                .name(tableName)
                .schemaVersion(RealmConstants.REALM_VERSION)
                .migration(new AssistMigration()).build();
        Realm.getInstance(realmConfiguration);
    }

    // ---------------------------------------------------------------------------------------------
    // 認証情報
    // AuthInfo
    // ---------------------------------------------------------------------------------------------

    /**
     * 認証情報取得処理
     *
     * @return 認証情報
     */
    public AuthInfo getAuthInfo() {
        AuthInfo data = null;
        realmStart();
        RealmResults<RealmAuthInfo> getData = mRealm.where(RealmAuthInfo.class)
                .equalTo(RealmConstants.AuthInfo.PRIMARY_ID, RealmConstants.AuthInfo.AUTH_INFO_ID)
                .findAll();
        if (getData != null && getData.size() == RealmConstants.AuthInfo.AUTH_INFO_DATA_CNT) {
            data = new AuthInfo();
            RealmAuthInfo item = getData.get(0);
            data.setLineCertified(item.isCertified());
            data.setAccessToken(item.getAccessToken());
        }
        realmEnd();
        return data;
    }

    /**
     * 認証情報更新処理
     *
     * @param saveData 保存データ
     */
    public void updateAuthInfo(AuthInfo saveData) {
        realmStart();
        RealmAuthInfo realmAuthInfo = new RealmAuthInfo();
        realmAuthInfo.setId(RealmConstants.AuthInfo.AUTH_INFO_ID);
        realmAuthInfo.setCertified(saveData.isLineCertified());
        realmAuthInfo.setAccessToken(saveData.getAccessToken());
        mRealm.copyToRealmOrUpdate(realmAuthInfo);
        mRealm.commitTransaction();
        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // ユーザー情報テーブル
    // UserInfo
    // ---------------------------------------------------------------------------------------------

    /**
     * ユーザー情報取得処理
     *
     * @return ユーザー情報
     */
    public UserInfo getUserInfo() {
        UserInfo data = null;
        realmStart();
        RealmResults<RealmUserInfo> getData = mRealm.where(RealmUserInfo.class)
                .equalTo(RealmConstants.UserInfo.PRIMARY_ID, RealmConstants.UserInfo.USER_INFO_ID)
                .findAll();
        if (getData != null && getData.size() == RealmConstants.UserInfo.USER_INFO_DATA_CNT) {
            data = new UserInfo();
            RealmUserInfo item = getData.get(0);
            data.setUserId(item.getUserId());
            data.setCuid(item.getCuid());
            data.setNickname(item.getNickName());
            data.setIconId(item.getIconId());
        }
        realmEnd();
        return data;
    }

    /**
     * ユーザー情報更新処理
     *
     * @param saveData 保存データ
     */
    public void updateUserInfo(UserInfo saveData) {
        realmStart();
        RealmUserInfo realmUserInfo = new RealmUserInfo();
        realmUserInfo.setId(RealmConstants.UserInfo.USER_INFO_ID);
        realmUserInfo.setUserId(saveData.getUserId());
        realmUserInfo.setCuid(saveData.getCuid());
        realmUserInfo.setNickName(saveData.getNickname());
        realmUserInfo.setIconId(saveData.getIconId());
        mRealm.copyToRealmOrUpdate(realmUserInfo);
        mRealm.commitTransaction();
        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // デバイス情報
    // DeviceInfo
    // ---------------------------------------------------------------------------------------------

    /**
     * デバイス情報取得処理
     *
     * @return デバイス情報
     */
    public DeviceInfo getDeviceInfo() {
        DeviceInfo data = null;
        realmStart();
        RealmResults<RealmDeviceInfo> getData = mRealm.where(RealmDeviceInfo.class)
                .equalTo(RealmConstants.DeviceInfo.PRIMARY_ID, RealmConstants.DeviceInfo.DEVICE_INFO_ID)
                .findAll();
        if (getData != null && getData.size() == RealmConstants.DeviceInfo.DEVICE_INFO_DATA_CNT) {
            data = new DeviceInfo();
            RealmDeviceInfo item = getData.get(0);
            data.setSendToken(item.isSendToken());
            data.setFcmToken(item.getFcmToken());
            data.setOsVersion(item.getOsVersion());
            data.setAppVersion(item.getAppVersion());
        }
        realmEnd();
        return data;
    }

    /**
     * デバイス情報更新処理
     *
     * @param saveData 保存データ
     */
    public void updateDeviceInfo(DeviceInfo saveData) {
        realmStart();
        RealmDeviceInfo realmDeviceInfo = new RealmDeviceInfo();
        realmDeviceInfo.setId(RealmConstants.DeviceInfo.DEVICE_INFO_ID);
        realmDeviceInfo.setIsSendToken(saveData.isSendToken());
        realmDeviceInfo.setFcmToken(saveData.getFcmToken());
        realmDeviceInfo.setOsVersion(saveData.getOsVersion());
        realmDeviceInfo.setAppVersion(saveData.getAppVersion());

        mRealm.copyToRealmOrUpdate(realmDeviceInfo);
        mRealm.commitTransaction();
        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // 位置情報設定テーブル
    // LocationSettings
    // ---------------------------------------------------------------------------------------------

    /**
     * 位置情報設定取得処理
     *
     * @return 位置情報設定
     */
    public LocationSettings getLocationSettings() {
        LocationSettings data = null;
        realmStart();
        RealmResults<RealmLocationSetting> getData = mRealm.where(RealmLocationSetting.class)
                .equalTo(RealmConstants.LocationSettings.PRIMARY_ID, RealmConstants.LocationSettings.LOCATION_SETTING_ID)
                .findAll();
        if (getData != null && getData.size() == RealmConstants.LocationSettings.LOCATION_SETTING_DATA_CNT) {
            data = new LocationSettings();
            RealmLocationSetting item = getData.get(0);
            data.setRequestedLocation(item.isRequestLocation());
            data.setRegularLocation(item.isRegularLocation());
            data.setRegularLocationTermKind(LocationSettings.TermType.fromValue(item.getType()));
            data.setRegularLocationStartTime(item.getRegularStartTime());
            data.setRegularLocationEndTime(item.getRegularEndTime());
            data.setIsFence(item.isFenceLocation());
        }
        realmEnd();
        return data;
    }

    /**
     * 位置情報設定-設定送信状態取得処理
     *
     * @return 設定送信状態
     */
    public boolean getLocationSendSetting() {
        boolean flg = false;
        realmStart();
        RealmResults<RealmLocationSetting> getData = mRealm.where(RealmLocationSetting.class)
                .equalTo(RealmConstants.LocationSettings.PRIMARY_ID, RealmConstants.LocationSettings.LOCATION_SETTING_ID)
                .findAll();
        if (getData != null && getData.size() == RealmConstants.LocationSettings.LOCATION_SETTING_DATA_CNT) {
            RealmLocationSetting item = getData.get(0);
            flg = item.isSendSetting();
        }
        realmEnd();
        return flg;
    }

    /**
     * 位置情報設定更新処理
     *
     * @param saveData 保存データ
     */
    public void updateLocationSettings(LocationSettings saveData) {
        realmStart();
        RealmLocationSetting realmLocationSetting = new RealmLocationSetting();
        realmLocationSetting.setId(RealmConstants.LocationSettings.LOCATION_SETTING_ID);
        realmLocationSetting.setIsSendSetting(false);
        realmLocationSetting.setIsRequestLocation(saveData.isRequestedLocation());
        realmLocationSetting.setIsRegularLocation(saveData.isRegularLocation());
        realmLocationSetting.setType(saveData.getRegularLocationTermKind().getValue());
        realmLocationSetting.setRegularStartTime(saveData.getRegularLocationStartTime());
        realmLocationSetting.setRegularEndTime(saveData.getRegularLocationEndTime());
        realmLocationSetting.setIsFenceLocation(saveData.isFence());
        mRealm.copyToRealmOrUpdate(realmLocationSetting);
        mRealm.commitTransaction();
        realmEnd();
    }

    /**
     * 位置情報設定-設定送信状態更新処理
     *
     * @param flg 設定送信状態更新データ
     */
    public void updateLocationSendSetting(boolean flg) {

        realmStart();
        RealmResults<RealmLocationSetting> getData = mRealm.where(RealmLocationSetting.class)
                .equalTo(RealmConstants.LocationSettings.PRIMARY_ID, RealmConstants.LocationSettings.LOCATION_SETTING_ID)
                .findAll();
        if (getData != null && getData.size() == RealmConstants.LocationSettings.LOCATION_SETTING_DATA_CNT) {
            RealmLocationSetting item = getData.get(0);
            RealmLocationSetting realmLocationSetting = new RealmLocationSetting();

            realmLocationSetting.setId(RealmConstants.LocationSettings.LOCATION_SETTING_ID);
            realmLocationSetting.setIsSendSetting(flg);
            realmLocationSetting.setIsRequestLocation(item.isRequestLocation());
            realmLocationSetting.setIsRegularLocation(item.isRegularLocation());
            realmLocationSetting.setType(item.getType());
            realmLocationSetting.setRegularStartTime(item.getRegularStartTime());
            realmLocationSetting.setRegularEndTime(item.getRegularEndTime());
            realmLocationSetting.setIsFenceLocation(item.isFenceLocation());
            mRealm.copyToRealmOrUpdate(realmLocationSetting);
            mRealm.commitTransaction();
        }
        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // 最新アプリバージョン情報
    // AppVersionInfo
    // ---------------------------------------------------------------------------------------------

    /**
     * 最新アプリバージョン情報取得処理
     *
     * @return 最新アプリバージョン情報
     */
    public AppVersionInfo getAppVersionInfo() {
        AppVersionInfo data = null;
        realmStart();
        RealmResults<RealmAppVersionInfo> getData = mRealm.where(RealmAppVersionInfo.class)
                .equalTo(RealmConstants.AppVersionInfo.PRIMARY_ID, RealmConstants.AppVersionInfo.APP_VERSION_INFO_ID)
                .findAll();
        if (getData != null && getData.size() == RealmConstants.AppVersionInfo.APP_VERSION_INFO_DATA_CNT) {
            data = new AppVersionInfo();
            RealmAppVersionInfo item = getData.get(0);
            data.setMustUpdate(item.isMustUpdate());
            data.setMessage(item.getMessageText());
            data.setUrl(item.getUrl());
            data.setVersion(item.getLatestVersion());
        }
        realmEnd();
        return data;
    }

    /**
     * 最新アプリバージョン情報更新処理
     *
     * @param saveData 保存データ
     */
    public void updateAppVersionInfo(AppVersionInfo saveData) {
        realmStart();
        RealmAppVersionInfo realmAppVersionInfo = new RealmAppVersionInfo();
        realmAppVersionInfo.setId(RealmConstants.AppVersionInfo.APP_VERSION_INFO_ID);
        realmAppVersionInfo.setMustUpdate(saveData.isMustUpdate());
        realmAppVersionInfo.setMessageText(saveData.getMessage());
        realmAppVersionInfo.setUrl(saveData.getUrl());
        realmAppVersionInfo.setLatestVersion(saveData.getVersion());

        mRealm.copyToRealmOrUpdate(realmAppVersionInfo);
        mRealm.commitTransaction();
        realmEnd();
    }


    // ---------------------------------------------------------------------------------------------
    // お知らせ一覧テーブル
    // NoticeInfo
    // ---------------------------------------------------------------------------------------------

    /**
     * お知らせ一覧情報取得処理
     *
     * @return お知らせ一覧情報
     */
    public List<NoticeInfo> getNoticeInfo() {
        List<NoticeInfo> list = null;
        realmStart();
        RealmResults<RealmNoticeInfo> getData = mRealm.where(RealmNoticeInfo.class)
                .findAll()
                .sort(RealmConstants.NoticeInfo.PRIMARY_NOTICE_ID, Sort.DESCENDING);

        if (getData != null && !getData.isEmpty()) {
            list = new ArrayList<>();
            for (RealmNoticeInfo item : getData) {
                NoticeInfo data = new NoticeInfo();
                data.setId(item.getNoticeId());
                data.setDeliveredDate(item.getDeliveredDate());
                data.setTitle(item.getTitle());
                data.setContents(item.getContents());
                data.setVersion(item.getVersion());
                data.setIsPriority(item.isPriority());
                data.setCreatedDate(item.getCreatedDate());
                data.setUpdatedDate(item.getUpdatedDate());
                list.add(data);
            }
            realmEnd();
        }
        return list;
    }

    /**
     * お知らせ一覧情報更新処理
     *
     * @param saveData 保存データ
     */
    public void updateNoticeInfo(NoticeInfo saveData) {
        realmStart();
        RealmNoticeInfo tmpData = new RealmNoticeInfo();
        tmpData.setNoticeId(saveData.getId());
        tmpData.setDeliveredDate(saveData.getDeliveredDate());
        tmpData.setTitle(saveData.getTitle());
        tmpData.setContents(saveData.getContents());
        tmpData.setVersion(saveData.getVersion());
        tmpData.setIsPriority(saveData.isPriority());
        tmpData.setCreatedDate(saveData.getCreatedDate());
        tmpData.setUpdatedDate(saveData.getUpdatedDate());
        mRealm.copyToRealmOrUpdate(tmpData);
        mRealm.commitTransaction();
        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // 辞書カテゴリ一覧テーブル
    // CategoryInfo
    // ---------------------------------------------------------------------------------------------

    /**
     * 辞書カテゴリ一覧情報取得処理
     *
     * @return 辞書カテゴリ一覧情報
     */
    public List<CategoryInfo> getCategoryInfo() {
        List<CategoryInfo> list = null;
        realmStart();
        RealmResults<RealmCategoryInfo> getData = mRealm.where(RealmCategoryInfo.class)
                .findAll()
                .sort(RealmConstants.CategoryInfo.PRIMARY_CATEGORY_ID);
        if (getData != null && !getData.isEmpty()) {
            list = new ArrayList<>();
            for (RealmCategoryInfo item : getData) {
                CategoryInfo data = new CategoryInfo();
                data.setCategoryId(item.getCategoryId());
                data.setName(item.getName());
                data.setIconId(item.getIconId());
                list.add(data);
            }
            realmEnd();
        }
        return list;
    }

    /**
     * 辞書カテゴリ一覧情報更新処理
     *
     * @param saveData 保存データ
     */
    public void updateCategoryInfo(CategoryInfo saveData) {
        realmStart();
        RealmCategoryInfo tmpData = new RealmCategoryInfo();
        tmpData.setCategoryId(saveData.getCategoryId());
        tmpData.setName(saveData.getName());
        tmpData.setIconId(saveData.getIconId());
        mRealm.copyToRealmOrUpdate(tmpData);
        mRealm.commitTransaction();
        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // 辞書カード一覧テーブル
    // CardInfo
    // ---------------------------------------------------------------------------------------------

    /**
     * 辞書カード一覧取得処理
     *
     * @param dictionaryId 辞書ID
     * @return 辞書カード一覧情報
     */
    private List<CardInfo> getCardInfo(long dictionaryId) {
        List<CardInfo> list = null;
        RealmResults<RealmCardInfo> getData = mRealm.where(RealmCardInfo.class)
                .equalTo(RealmConstants.CardInfo.KEY_DICTIONARY_ID, dictionaryId)
                .equalTo(RealmConstants.CardInfo.KEY_DELETE_FLG, false)
                .findAll()
                .sort(RealmConstants.CardInfo.SORTKEY_NEXTCARD_ID);
        // 次カードIDでソートした場合、最後のカードが先頭になってしまう(0固定のため)
        // 先頭のデータを保持、最後にADDする
        CardInfo lastData = null;
        if (getData != null && !getData.isEmpty()) {
            list = new ArrayList<>();
            int cnt = 0;
            for (RealmCardInfo item : getData) {
                CardInfo data = new CardInfo();
                data.setCardId(item.getCardId());
                data.setDictionaryId(item.getDictionaryId());
                data.setNextCardId(item.getNextCardId());
                data.setImageUrl(item.getImageUrl());
                data.setImageFileName(item.getImageFileName());
                data.setText(item.getText());
                data.setVersion(item.getVersion());
                data.setCreatedDate(item.getCreatedDate());
                data.setUpdatedDate(item.getUpdatedDate());
                data.setIsDeleted(item.isDeleted());
                if (cnt > 0) {
                    list.add(data);
                } else {
                    lastData = data;
                }
                cnt++;
            }
            list.add(lastData);
        }
        return list;
    }

    /**
     * カード情報最終更新日取得処理
     *
     * @return 最終更新日
     */
    public Date getCardLastUpdateDate() {

        realmStart();
        Date updateDate = mRealm.where(RealmCardInfo.class)
                .maximumDate(RealmConstants.CardInfo.KEY_UPDATE_DATE);

        realmEnd();
        return updateDate;
    }


    /**
     * 辞書カード一覧情報更新処理
     *
     * @param saveData 保存データ
     */
    private void updateCardInfo(CardInfo saveData) {
        realmStart();
        RealmCardInfo tmpData = new RealmCardInfo();
        tmpData.setCardId(saveData.getCardId());
        tmpData.setDictionaryId(saveData.getDictionaryId());
        tmpData.setNextCardId(saveData.getNextCardId());
        tmpData.setImageUrl(saveData.getImageUrl());
        tmpData.setImageFileName(saveData.getImageFileName());
        tmpData.setText(saveData.getText());
        tmpData.setVersion(saveData.getVersion());
        tmpData.setCreatedDate(saveData.getCreatedDate());
        tmpData.setUpdatedDate(saveData.getUpdatedDate());
        tmpData.setIsDeleted(saveData.isDeleted());
        mRealm.copyToRealmOrUpdate(tmpData); // 登録
        mRealm.commitTransaction();
        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // 辞書一覧テーブル
    // DictionaryInfo
    // ---------------------------------------------------------------------------------------------

    /**
     * 辞書一覧情報取得処理(カテゴリ指定)
     *
     * @param categoryId 指定カテゴリID
     * @return 辞書一覧
     */
    public List<DictionaryInfo> getDicInfoByCategory(long categoryId) {
        realmStart();
        List<DictionaryInfo> dicList = getDicInfoByCategoryImpl(categoryId);
        realmEnd();
        return dicList;
    }

    /**
     * 辞書一覧情報取得処理(カテゴリ指定)※トランザクション以外の処理
     *
     * @param categoryId 指定カテゴリID
     * @return 辞書一覧
     */
    private List<DictionaryInfo> getDicInfoByCategoryImpl(long categoryId) {

        List<DictionaryInfo> sortDataList = new ArrayList<>();
        RealmResults<RealmDictionaryInfo> getData = mRealm.where(RealmDictionaryInfo.class)
                .equalTo(RealmConstants.DictionaryInfo.KEY_CATEGORY_ID, categoryId)
                .equalTo(RealmConstants.DictionaryInfo.KEY_DELETE_FLG, false)
                .findAll()
                .sort(RealmConstants.DictionaryInfo.PRIMARY_DICTIONARY_ID);
        if (getData != null && !getData.isEmpty()) {
            List<DictionaryInfo> list = new ArrayList<>();
            for (RealmDictionaryInfo item : getData) {
                DictionaryInfo data = new DictionaryInfo();
                data.setDictionaryId(item.getDictionaryId());
                data.setCategoryId(item.getCategoryId());
                data.setType(DictionaryInfo.DictionaryType.fromValue(item.getType()));
                data.setName(item.getName());
                data.setImageUrl(item.getImageUrl());
                data.setImageFileName(item.getImageFileName());
                data.setIsMemorize(item.isMemorize());
                data.setVersion(item.getVersion());
                data.setCreatorNickname(item.getCreatorNickname());
                data.setCreatorIconId(item.getCreatorIconId());
                data.setCreatedDate(item.getCreatedDate());
                data.setUpdatedDate(item.getUpdatedDate());
                data.setIsDeleted(item.isDeleted());
                data.setCardList(getCardInfo(item.getDictionaryId()));
                list.add(data);
            }
            DictionaryOrderInfo sortSetData = getDictionaryOrderInfo(categoryId);
            if (sortSetData == null || list.size() != sortSetData.getDictionaryIdList().length) {
                // 並べ替えデータ取得失敗、または辞書の数と並び替え辞書数が不一致の場合、ソートせず返却
                sortDataList = list;
            } else {
                for (long number : sortSetData.getDictionaryIdList()) {
                    for (int cnt = 0; cnt < list.size(); cnt++) {
                        if (number == list.get(cnt).getDictionaryId()) {
                            sortDataList.add(list.get(cnt));
                        }
                    }
                }
                if (sortDataList.size() != list.size()) {
                    // 取得データと並び替えデータの数が一致しない場合、並び替え失敗のためソートせず返却
                    sortDataList = list;
                }
            }
        }
        return sortDataList;
    }

    /**
     * カテゴリ別辞書件数一覧取得処理
     *
     * @return カテゴリ別辞書件数一覧
     * [0] やりかた
     * [1] 行きかた
     * [2] 持ちもの
     */
    public List<Long> getDicCntByCategory() {

        List<Long> list = new ArrayList<>();
        realmStart();

        list.add((long) getDicInfoByCategoryImpl(Constants.Ids.CATEGORY_ID_HOW_TO_DO).size());
        list.add((long) getDicInfoByCategoryImpl(Constants.Ids.CATEGORY_ID_HOW_TO_GO).size());
        list.add((long) getDicInfoByCategoryImpl(Constants.Ids.CATEGORY_ID_PROPERTY).size());

        realmEnd();
        return list;
    }

    /**
     * 辞書情報取得処理(辞書ID指定)
     *
     * @param dictionaryId 辞書ID
     * @return 辞書情報（無い場合はnull）
     */
    public DictionaryInfo getDicInfoByDicId(long dictionaryId) {
        realmStart();
        DictionaryInfo dicData = getDicInfoByDicIdImpl(dictionaryId);
        realmEnd();
        return dicData;
    }

    /**
     * 辞書情報取得(辞書ID指定)※トランザクション以外の処理
     *
     * @param dictionaryId 辞書ID
     * @return 辞書情報（無い場合はnull）
     */
    private DictionaryInfo getDicInfoByDicIdImpl(long dictionaryId) {
        DictionaryInfo dicData = null;
        RealmResults<RealmDictionaryInfo> getData = mRealm.where(RealmDictionaryInfo.class)
                .equalTo(RealmConstants.DictionaryInfo.PRIMARY_DICTIONARY_ID, dictionaryId)
                .equalTo(RealmConstants.DictionaryInfo.KEY_DELETE_FLG, false).findAll();
        if (getData != null && !getData.isEmpty()) {
            dicData = new DictionaryInfo();
            RealmDictionaryInfo item = getData.get(0);
            dicData.setDictionaryId(item.getDictionaryId());
            dicData.setCategoryId(item.getCategoryId());
            dicData.setType(DictionaryInfo.DictionaryType.fromValue(item.getType()));
            dicData.setName(item.getName());
            dicData.setImageUrl(item.getImageUrl());
            dicData.setImageFileName(item.getImageFileName());
            dicData.setIsMemorize(item.isMemorize());
            dicData.setVersion(item.getVersion());
            dicData.setCreatorNickname(item.getCreatorNickname());
            dicData.setCreatorIconId(item.getCreatorIconId());
            dicData.setCreatedDate(item.getCreatedDate());
            dicData.setUpdatedDate(item.getUpdatedDate());
            dicData.setIsDeleted(item.isDeleted());
            dicData.setCardList(getCardInfo(item.getDictionaryId()));
        }
        return dicData;
    }

    /**
     * 辞書情報最終更新日取得処理
     *
     * @return 最終更新日
     */
    public Date getDicLastUpdateDate() {

        realmStart();

        Date updateDate = mRealm.where(RealmDictionaryInfo.class)
                .maximumDate(RealmConstants.DictionaryInfo.KEY_UPDATE_DATE);

        realmEnd();
        return updateDate;
    }

    /**
     * 辞書一覧情報更新処理
     *
     * @param saveData 保存データ
     */
    public void updateDictionaryInfo(DictionaryInfo saveData) {
        RealmDictionaryInfo tmpData = new RealmDictionaryInfo();
        tmpData.setDictionaryId(saveData.getDictionaryId());
        tmpData.setCategoryId(saveData.getCategoryId());
        tmpData.setType(saveData.getType().getValue());
        tmpData.setName(saveData.getName());
        tmpData.setImageUrl(saveData.getImageUrl());
        tmpData.setImageFileName(saveData.getImageFileName());
        tmpData.setIsMemorize(saveData.isMemorize());
        tmpData.setVersion(saveData.getVersion());
        tmpData.setCreatorNickname(saveData.getCreatorNickname());
        tmpData.setCreatorIconId(saveData.getCreatorIconId());
        tmpData.setUpdatedDate(saveData.getUpdatedDate());
        tmpData.setIsDeleted(saveData.isDeleted());
        realmStart();
        mRealm.copyToRealmOrUpdate(tmpData); // 登録
        mRealm.commitTransaction();
        // カード情報の更新
        for (CardInfo data : saveData.getCardList()) {
            updateCardInfo(data);
        }
        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // スケジュール情報一覧
    // ScheduleInfo
    // ---------------------------------------------------------------------------------------------

    /**
     * スケジュール情報一覧取得処理(日付指定)
     *
     * @param checkDate スケジュール開始日
     * @return スケジュール情報一覧情報
     */
    public List<ScheduleInfo> getScheduleInfo(Date checkDate) {

        List<ScheduleInfo> list = null;
        realmStart();

        Date startDate = DateUtils.truncate(checkDate, false);
        Date endDate = DateUtils.truncate(checkDate, true);
        RealmResults<RealmScheduleInfo> getData = mRealm.where(RealmScheduleInfo.class)
                .lessThanOrEqualTo(RealmConstants.ScheduleInfo.KEY_SCHEDULE_START_DATE,startDate)
                .greaterThanOrEqualTo(RealmConstants.ScheduleInfo.KEY_SCHEDULE_END_DATE, endDate)
                .findAll()
                .sort(RealmConstants.ScheduleInfo.KEY_SCHEDULE_START_DATE);
        if (getData != null && !getData.isEmpty()) {
            list = new ArrayList<>();
            for (RealmScheduleInfo item : getData) {
                ScheduleInfo data = setScheduleInfo(item);
                list.add(data);
            }
        }
        realmEnd();
        return list;
    }

    /**
     * スケジュール情報一覧取得処理(日付範囲指定)
     *
     * @param scheduleStartDate スケジュール開始日
     * @param scheduleEndDate   スケジュール終了日
     * @return スケジュール情報一覧情報
     */
    public List<ScheduleInfo> getScheduleInfoByStrEnd(Date scheduleStartDate, Date scheduleEndDate) {

        List<ScheduleInfo> list = null;
        Date startDate = DateUtils.truncate(scheduleStartDate, true);
        Date endDate = DateUtils.truncate(scheduleEndDate, false);

        realmStart();
        RealmResults<RealmScheduleInfo> getData = mRealm.where(RealmScheduleInfo.class)
                .between(RealmConstants.ScheduleInfo.KEY_SCHEDULE_START_DATE, startDate, endDate)
                .or().between(RealmConstants.ScheduleInfo.KEY_SCHEDULE_END_DATE, startDate, endDate)
                .findAll()
                .sort(RealmConstants.ScheduleInfo.KEY_SCHEDULE_START_DATE)
                .sort(RealmConstants.ScheduleInfo.KEY_SCHEDULE_END_DATE);
        if (getData != null && !getData.isEmpty()) {
            list = new ArrayList<>();
            for (RealmScheduleInfo item : getData) {
                ScheduleInfo data = setScheduleInfo(item);
                list.add(data);
            }
        }
        realmEnd();
        return list;
    }


    /**
     * スケジュール情報一覧取得処理(タイマ設定用、現在時刻以降の当日と翌日の予定を取得)
     *
     * @return スケジュール情報一覧情報
     */
    public List<ScheduleInfo> getScheduleInfoForTimer() {

        List<ScheduleInfo> list = null;
        Date nowDate = DateUtils.getDateNow();
        Date endDate = DateUtils.truncate(DateUtils.getDateAdd(nowDate,Calendar.DATE,1), false);

        realmStart();
        RealmResults<RealmScheduleInfo> getData = mRealm.where(RealmScheduleInfo.class)
                .between(RealmConstants.ScheduleInfo.KEY_SCHEDULE_START_DATE, nowDate, endDate)
                .findAll()
                .sort(RealmConstants.ScheduleInfo.KEY_SCHEDULE_START_DATE);
        if (getData != null && !getData.isEmpty()) {
            list = new ArrayList<>();
            for (RealmScheduleInfo item : getData) {
                ScheduleInfo data = setScheduleInfo(item);
                list.add(data);
            }
        }
        realmEnd();
        return list;
    }

    /**
     * スケジュール情報取得処理(スケジュール日時ID指定)
     *
     * @param scheduleId スケジュール日時ID
     * @return スケジュール情報一覧情報
     */
    public ScheduleInfo getScheduleInfoById(long scheduleId) {

        ScheduleInfo data = null;
        realmStart();
        RealmResults<RealmScheduleInfo> getData = mRealm.where(RealmScheduleInfo.class)
                .equalTo(RealmConstants.ScheduleInfo.PRIMARY_SCHEDULE_ID, scheduleId)
                .findAll()
                .sort(RealmConstants.ScheduleInfo.KEY_SCHEDULE_START_DATE);
        if (getData != null && getData.size() == RealmConstants.ScheduleInfo.SCHEDULE_INFO_DATA_CNT_BYID) {
            data = setScheduleInfo(getData.get(0));
        }
        realmEnd();
        return data;
    }

    /**
     * スケジュール情報日別件数取得処理(日付範囲指定)
     *
     * @param scheduleStartDate スケジュール開始日
     * @param scheduleEndDate   スケジュール終了日
     * @return スケジュール情報一覧情報
     */
    public List<ScheduleCount> getScheduleCntByStrEnd(Date scheduleStartDate, Date scheduleEndDate) {

        List<ScheduleCount> list = null;
        Date startDate = DateUtils.truncate(scheduleStartDate, true);
        Date endDate = DateUtils.truncate(scheduleEndDate, false);
        realmStart();

        RealmResults<RealmScheduleInfo> getData = mRealm.where(RealmScheduleInfo.class)
                .between(RealmConstants.ScheduleInfo.KEY_SCHEDULE_START_DATE, startDate, endDate)
                .or().between(RealmConstants.ScheduleInfo.KEY_SCHEDULE_END_DATE, startDate, endDate)
                .findAll()
                .sort(RealmConstants.ScheduleInfo.KEY_SCHEDULE_START_DATE);
        if (getData != null && !getData.isEmpty()) {

            list = new ArrayList<>();
            Date chkDate = DateUtils.truncate(scheduleStartDate, true);
            Date chkEndDate = DateUtils.truncate(scheduleEndDate, false);

            // チェック対象日が範囲
            // チェック対象日>チェック範囲最終日になれば終了
            for (; DateUtils.truncate(chkDate, true).after(chkEndDate); ) {
                int cnt = 0;
                ScheduleCount data = new ScheduleCount();
                for (RealmScheduleInfo item : getData) {
                    // スケジュール開始日時<チェック対象日<スケジュール終了日時
                    // またはスケジュール開始日=チェック対象日
                    // またはスケジュール終了日=チェック対象日
                    if ((chkDate.after(item.getScheduleStartDate())
                            && chkDate.before(item.getScheduleEndDate()))
                            || DateUtils.dateCompare(chkDate, item.getScheduleStartDate())
                            || DateUtils.dateCompare(chkDate, item.getScheduleEndDate())) {
                        cnt++;
                    }
                }
                data.setDate(startDate);
                data.setCount(cnt);
                list.add(data);
                Calendar cal = Calendar.getInstance();
                cal.setTime(chkDate);
                cal.add(Calendar.DATE,1);
                chkDate = cal.getTime();
            }
        }
        realmEnd();
        return list;
    }


    /**
     * スケジュール情報一覧更新処理
     *
     * @param saveData 保存データ
     */
    public void updateScheduleInfo(ScheduleInfo saveData) {
        realmStart();
        RealmScheduleInfo tmpData = new RealmScheduleInfo();
        tmpData.setScheduleId(saveData.getScheduleId());
        tmpData.setScheduleStartDate(saveData.getScheduleStartDate());
        tmpData.setScheduleEndDate(saveData.getScheduleEndDate());
        if (saveData.isAllDay()) {
            // 終日がONの場合、0:00～23:59に変更する
            tmpData.setScheduleStartDate(DateUtils.truncate(saveData.getScheduleStartDate(),true));
            tmpData.setScheduleEndDate((DateUtils.truncate(saveData.getScheduleEndDate(),false)));
        }
        tmpData.setCompleted(saveData.isCompleted());
        tmpData.setAllDay(saveData.isAllDay());
        tmpData.setTitle(saveData.getTitle());
        tmpData.setNote(saveData.getNote());
        tmpData.setLocation(saveData.getLocation());
        tmpData.setIconName(saveData.getIconName());
        tmpData.setCreatorIconId(saveData.getCreatorIconId());
        tmpData.setCreatorNickname(saveData.getCreatorNickname());
        tmpData.setCreatedDate(saveData.getCreatedDate());
        tmpData.setUpdatedDate(saveData.getUpdatedDate());
        tmpData.setDictionaryId1(saveData.getAttachedDictionaryId(0));
        tmpData.setDictionaryId2(saveData.getAttachedDictionaryId(1));
        tmpData.setDictionaryId3(saveData.getAttachedDictionaryId(2));
        tmpData.setRepeatStartDate(saveData.getRepeatStartDate());
        tmpData.setRepeatEndDate(saveData.getRepeatEndDate());
        tmpData.setInterval(saveData.getInterval().getValue());
        tmpData.setIsRepeatSunday(saveData.isRepeatSunday());
        tmpData.setIsRepeatMonday(saveData.isRepeatMonday());
        tmpData.setIsRepeatTuesday(saveData.isRepeatTuesday());
        tmpData.setIsRepeatWednesday(saveData.isRepeatWednesday());
        tmpData.setIsRepeatThursday(saveData.isRepeatThursday());
        tmpData.setIsRepeatFriday(saveData.isRepeatFriday());
        tmpData.setIsRepeatSaturday(saveData.isRepeatSaturday());
        mRealm.copyToRealmOrUpdate(tmpData); // 登録
        mRealm.commitTransaction();
        realmEnd();
    }

    /**
     * スケジュール情報全件削除処理
     */
    public void deleteScheduleInfoAll() {
        realmStart();
        RealmResults<RealmScheduleInfo> getData = mRealm.where(RealmScheduleInfo.class).findAll();
        getData.deleteAllFromRealm();

        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // スケジュール取得履歴テーブル
    // ScheduleGetHistory
    // ---------------------------------------------------------------------------------------------

    /**
     * スケジュール取得履歴情報取得処理
     *
     * @return スケジュール取得履歴
     */
    public ScheduleGetHistory getScheduleGetHistory() {

        ScheduleGetHistory data = null;
        realmStart();
        RealmResults<RealmScheduleGetHistory> getData = mRealm.where(RealmScheduleGetHistory.class).findAll()
                .sort(RealmConstants.ScheduleGetHistory.PRIMARY_ID, Sort.DESCENDING);
        RealmScheduleGetHistory laseData = getData.first();

        data.setScheduleFrom(laseData.getScheduleFromOn());
        data.setScheduleTo(laseData.getScheduleToOn());
        realmEnd();
        return data;
    }

    /**
     * スケジュール取得履歴情報更新処理
     *
     * @param saveData 保存データ
     */
    public void updateScheduleGetHistory(ScheduleGetHistory saveData) {
        realmStart();
        RealmScheduleGetHistory tmpData = new RealmScheduleGetHistory();
        RealmResults<RealmScheduleGetHistory> getData = mRealm.where(RealmScheduleGetHistory.class)
                .findAll()
                .sort(RealmConstants.ScheduleGetHistory.PRIMARY_ID, Sort.DESCENDING);
        RealmScheduleGetHistory laseData = getData.first();
        // 最大値インクリメント
        long idGet = laseData.getId();
        idGet++;
        tmpData.setId(idGet);
        tmpData.setScheduleFromOn(saveData.getScheduleFrom());
        tmpData.setScheduleToOn(saveData.getScheduleTo());
        mRealm.copyToRealm(tmpData); // 登録
        mRealm.commitTransaction();

        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // 辞書の並び順テーブル
    // DictionaryOrderInfo
    // ---------------------------------------------------------------------------------------------

    /**
     * 辞書の並び順情報取得処理
     *
     * @return 辞書の並び順情報
     */
    private DictionaryOrderInfo getDictionaryOrderInfo(long categoryId) {

        DictionaryOrderInfo data = null;
        RealmResults<RealmDicOrderInfo> getData = mRealm.where(RealmDicOrderInfo.class)
                .equalTo(RealmConstants.DictionaryOrderInfo.PRIMARY_CATEGORY_ID, categoryId).findAll();

        if (getData != null && !getData.isEmpty()) {
            RealmDicOrderInfo realmData = getData.first();
            data = new DictionaryOrderInfo();
            data.setCategoryId(realmData.getCategoryId());
            long[] diclist = new long[realmData.getDictionaryId().size()];
            for (int i = 0; i < realmData.getDictionaryId().size(); i++) {
                diclist[i] = realmData.getDictionaryId().get(i);
            }
            data.setDictionaryIdList(diclist);
        }
        return data;
    }

    /**
     * 辞書の並び順情報更新処理
     *
     * @param saveData 保存データ
     */
    public void updateDictionaryOrderInfo(DictionaryOrderInfo saveData) {
        realmStart();
        RealmDicOrderInfo tmpData = new RealmDicOrderInfo();
        tmpData.setCategoryId(saveData.getCategoryId());
        RealmList<Long> dicIdList = new RealmList<Long>();
        for (long id : saveData.getDictionaryIdList()) {
            dicIdList.add(id);
        }
        tmpData.setDictionaryId(dicIdList);
        mRealm.copyToRealmOrUpdate(tmpData); // 登録
        mRealm.commitTransaction();

        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // タイマ情報テーブル
    // TimerInfo
    // ---------------------------------------------------------------------------------------------
    /**
     * タイマ情報取得処理
     *
     * @return タイマ設定情報リスト
     */
    public List<TimerInfo> getTimerInfo() {

        List<TimerInfo> list = null;
        realmStart();

        RealmResults<RealmTimerInfo> getData = mRealm.where(RealmTimerInfo.class).findAll()
                .sort(RealmConstants.TimerInfo.KEY_REQUEST_CODE);
        if (getData != null && !getData.isEmpty()) {
            list = new ArrayList<>();
            for (RealmTimerInfo item : getData) {
                TimerInfo data = new TimerInfo();
                data.setRequestCode(item.getRequestCode());
                data.setType(item.getType());
                list.add(data);
            }
        }
        realmEnd();
        return list;
    }

    /**
     * タイマ情報取得処理
     *
     * @return タイマ設定情報
     */
    public int getTimerInfoNumber() {

        realmStart();
        int number = Constants.TimerControl.TIMER_CODE_DATE_CHANGED + 1;
        Number num = mRealm.where(RealmTimerInfo.class).max(RealmConstants.TimerInfo.KEY_REQUEST_CODE);
        if (num != null) {
            number = num.intValue();
            number++;
        }
        realmEnd();
        return number;
    }

    /**
     * タイマ情報登録処理
     *
     * @param saveData 保存データ
     */
    public void insUpdTimerInfo(TimerInfo saveData) {
        realmStart();

        RealmTimerInfo tmpData = new RealmTimerInfo();
        tmpData.setRequestCode(saveData.getRequestCode());
        tmpData.setType(saveData.getType());
        mRealm.copyToRealmOrUpdate(tmpData); // 登録
        mRealm.commitTransaction();

        realmEnd();
    }

    /**
     * タイマ情報削除処理(type指定)
     *
     */
    public void deleteTimerInfoByType(long type) {

        realmStart();
        RealmResults<RealmTimerInfo> getData = mRealm.where(RealmTimerInfo.class)
                .equalTo(RealmConstants.TimerInfo.PRIMARY_ID,String.valueOf(type))
                .findAll();
        getData.deleteAllFromRealm();
        mRealm.commitTransaction();

        realmEnd();
    }

    /**
     * タイマ情報全件削除処理
     *
     */
    public void deleteTimerInfoAll() {

        realmStart();

        RealmResults<RealmTimerInfo> getData = mRealm.where(RealmTimerInfo.class).findAll();
        getData.deleteAllFromRealm();
        mRealm.commitTransaction();

        realmEnd();
    }

    // ---------------------------------------------------------------------------------------------
    // 内部クラス
    // ---------------------------------------------------------------------------------------------

    /**
     * スケジュール情報設定
     *
     * @param item スケージュール情報(Realm)
     * @return スケジュール情報(UI)
     */
    private ScheduleInfo setScheduleInfo(RealmScheduleInfo item) {

        ScheduleInfo data = new ScheduleInfo();

        data.setScheduleId(item.getScheduleId());
        data.setScheduleStartDate(item.getScheduleStartDate());
        data.setScheduleEndDate(item.getScheduleEndDate());
        data.setIsCompleted(item.isCompleted());
        data.setScheduleMetaId(item.getScheduleMetaId());
        data.setTitle(item.getTitle());
        data.setNote(item.getNote());
        data.setLocation(item.getLocation());
        data.setIconName(item.getIconName());
        data.setCreatorIconId(item.getCreatorIconId());
        data.setCreatorNickname(item.getCreatorNickname());
        data.setCreatedDate(item.getCreatedDate());
        data.setUpdatedDate(item.getUpdatedDate());

        List<DictionaryInfo> dicList = new ArrayList<DictionaryInfo>();
        long[] dictionary = {
                item.getDictionaryId1(),
                item.getDictionaryId2(),
                item.getDictionaryId3(),
        };
        for (long id : dictionary) {
            DictionaryInfo dicInfo = getDicInfoByDicIdImpl(id);
            if (dicInfo != null) {
                dicList.add(dicInfo);
            } else if (verifyId(id)) {
                // TODO:DBには無い、しかしIDが設定されている状態
                AssistLog.e("Not found attached dictionary in DB -> " + id);
            }
        }
        data.setAttachedDictionaries(dicList);

        data.setRepeatStartDate(item.getRepeatStartDate());
        data.setRepeatEndDate(item.getRepeatEndDate());
        data.setInterval(ScheduleInfo.IntervalType.fromValue(item.getInterval()));
        data.setIsRepeatSunday(item.isRepeatSunday());
        data.setIsRepeatMonday(item.isRepeatMonday());
        data.setIsRepeatTuesday(item.isRepeatTuesday());
        data.setIsRepeatWednesday(item.isRepeatWednesday());
        data.setIsRepeatThursday(item.isRepeatThursday());
        data.setIsRepeatFriday(item.isRepeatFriday());
        data.setIsRepeatSaturday(item.isRepeatSaturday());
        return data;
    }

    /**
     * IDの検証.
     *
     * @param id ID
     * @return true:有効、false:無効
     */
    private boolean verifyId(long id) {
        return (id > Constants.Ids.ID_NONE);
    }


    // ---------------------------------------------------------------------------------------------
    // 辞書の画像保存関連
    // ---------------------------------------------------------------------------------------------

    /**
     * 辞書のディレクトリ取得.
     *
     * @param dictionaryId 辞書ID
     * @return File:Success,null:Error
     */
    public static File getDictionaryDir(final long dictionaryId) {
        File file = AppController.getInstance().getDocumentPath();
        if (file != null) {
            String path = String.format(Locale.ENGLISH, Constants.Dictionary.DICTIONARY_DIR, dictionaryId);
            file = new File(file, path);
            file.mkdirs();
        }
        return file;
    }

    /**
     * 辞書作成時のディレクトリ取得.
     *
     * @return File:Success,null:Error
     */
    public static File getDictionaryTempDir() {
        File file = AppController.getInstance().getDocumentPath();
        if (file != null) {
            file = new File(file, Constants.Dictionary.DICTIONARY_TEMP_DIR);
            file.mkdirs();
        }
        return file;
    }

    /**
     * 辞書（カード）画像のリサイズ.
     *
     * @param bitmap ビットマップ
     * @return Bitmap:Success,null:Error
     */
    public static Bitmap scaleDictionaryImage(Bitmap bitmap) {
        AssistLog.d("scaleDictionaryImage()");
        try {
            final int size = Constants.Dictionary.MAX_IMAGE_WH;
            AssistLog.d("bitmap width = " + bitmap.getWidth() + " height = " + bitmap.getHeight());
            if (size < bitmap.getWidth() && bitmap.getWidth() >= bitmap.getHeight()) {
                AssistLog.d("width over!");
                double ratio = (double) bitmap.getWidth() / size;
                return Bitmap.createScaledBitmap(bitmap, size, (int)(bitmap.getHeight() / ratio), false);
            } else if (size < bitmap.getHeight() && bitmap.getHeight() >= bitmap.getWidth()) {
                AssistLog.d("height over!");
                double ratio = (double) bitmap.getHeight() / size;
                return Bitmap.createScaledBitmap(bitmap, (int)(bitmap.getWidth() / ratio), size, false);
            } else {
                AssistLog.d("no scale");
                return bitmap;
            }
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 辞書（カード）画像の保存.
     *
     * @param bitmap ビットマップ
     * @param file 保存先ファイルパス
     * @return true:Success,false:Error
     */
    public static boolean saveDictionaryImage(final Bitmap bitmap, final File file) {
        AssistLog.d("saveDictionaryImage()");

        if (bitmap == null || file == null) {
            AssistLog.w("invalid argument bitmap = " + bitmap + " file = " + file);
            return false;
        }

        final int[] qualityList = {100, 75, 50, 25};

        for (int i = 0; i < qualityList.length; i++) {
            FileOutputStream fos = null;
            try {
                // ファイル削除
                file.delete();
                // ファイルへ書き出し
                fos = new FileOutputStream(file);
                boolean result = bitmap.compress(Bitmap.CompressFormat.PNG, qualityList[i], fos);
                float sizeMB = file.length() / (float)(1024 * 1024);
                // ファイルサイズの確認
                if (file.length() < Constants.Dictionary.MAX_IMAGE_FILE_SIZE) {
                    AssistLog.i("saved! size = " + file.length() + "(" + sizeMB + ")");
                    return true;
                }
                AssistLog.d("over! size = " + file.length() + "(" + sizeMB + ")");

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (fos != null) {
                        fos.close();
                    }
                } catch (IOException e) {
                    // do nothing
                }
            }
        }

        AssistLog.w("could not save.");
        return false;
    }
}
