/*
 * ファイル：DicRememberedUiActivity.java
 * 概要：
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.dictionary;

/**
 * Interface set onclick of detail dictionary screen
 *
 * @author Systena
 * @version 1.0
 */
public interface IOnClickDetailDic {
    /**
     * Set Onclick button see again for DetailDic screen
     */
    void onClickSeeAgain();

    /**
     * set Onclick button edit dictionary
     */
    void onClickEdit();

    /**
     * set onclick icon zoom picture;
     * @param position: position item of list
     */
    void onClickZoomPicture(int position);

}
