/*
 * ファイル：DictionaryInfo.java
 * 概要：辞書情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import android.graphics.Bitmap;
import android.text.TextUtils;

import jp.softbank.assist.model.ModelInterface;
import jp.softbank.assist.util.Constants;

import java.io.File;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 辞書情報.
 *
 * @author Systena
 * @version 1.0
 */
public class DictionaryInfo implements Serializable {

    /**
     * 辞書種別.
     */
    public enum DictionaryType implements Serializable {
        Step(0), // ステップ形式
        Check(1), // チェック形式
        ;

        private final long mValue;

        private DictionaryType(long value) {
            this.mValue = value;
        }

        public long getValue() {
            return this.mValue;
        }

        /**
         * 数値からenumへの変換.
         *
         * @param value 数値
         * @return DictionaryType
         */
        public static DictionaryType fromValue(final long value) {
            DictionaryType[] list = DictionaryType.values();
            for (DictionaryType item : list) {
                if (item.getValue() == value) {
                    return item;
                }
            }
            return Step;
        }
    }

    private long mDictionaryId; // 辞書ID
    private long mCategoryId; // カテゴリID
    private DictionaryType mType; // 辞書種別
    private String mName; // 辞書名
    private String mImageUrl; // 画像URL
    private String mImageFileName; // 画像ファイル名
    private boolean mIsMemorize; // 覚えたフラグ
    private long mVersion; // バージョン
    private String mCreatorNickname; // 作成者ニックネーム
    private long mCreatorIconId; // 作成者アイコンID
    private Date mCreatedDate; // 作成日時
    private Date mUpdatedDate; // 更新日時
    private boolean mIsDeleted; // 削除済みフラグ
    private List<CardInfo> mCardList; // カード一覧
    private boolean mIsCalledGetImageMethod = false;//status downloaded, use check and call getDictionaryImage one times


    public long getDictionaryId() {
        return mDictionaryId;
    }

    public void setDictionaryId(long dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }

    public long getCategoryId() {
        return mCategoryId;
    }

    public void setCategoryId(long categoryId) {
        this.mCategoryId = categoryId;
    }

    public DictionaryType getType() {
        return mType;
    }

    public void setType(DictionaryType type) {
        this.mType = type;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.mImageUrl = imageUrl;
    }

    public String getImageFileName() {
        return mImageFileName;
    }

    public void setImageFileName(String imageFileName) {
        this.mImageFileName = imageFileName;
    }

    public boolean isMemorize() {
        return mIsMemorize;
    }

    public void setIsMemorize(boolean memorize) {
        mIsMemorize = memorize;
    }

    public long getVersion() {
        return mVersion;
    }

    public void setVersion(long version) {
        this.mVersion = version;
    }

    public String getCreatorNickname() {
        return mCreatorNickname;
    }

    public void setCreatorNickname(String creatorNickname) {
        this.mCreatorNickname = creatorNickname;
    }

    public long getCreatorIconId() {
        return mCreatorIconId;
    }

    public void setCreatorIconId(long creatorIconId) {
        this.mCreatorIconId = creatorIconId;
    }

    public Date getCreatedDate() {
        return mCreatedDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.mCreatedDate = createdDate;
    }

    public Date getUpdatedDate() {
        return mUpdatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.mUpdatedDate = updatedDate;
    }

    public boolean isDeleted() {
        return mIsDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        mIsDeleted = deleted;
    }

    public List<CardInfo> getCardList() {
        return mCardList;
    }

    public void setCardList(List<CardInfo> cardList) {
        this.mCardList = cardList;
    }


    /**
     * set status downloaded
     * @param isCalledGetImageMethod
     */
    public void setIsCalledGetImageMethod(boolean isCalledGetImageMethod) {
        this.mIsCalledGetImageMethod = isCalledGetImageMethod;
    }


    /**
     *status downloaded image
     * @return
     */
    public boolean isCalledGetImageMethod() {
        return mIsCalledGetImageMethod;
    }


    /**
     * 編集済みか確認する.
     *
     * @return true:編集済み、false:未編集
     */
    public boolean isEdited() {
        return false;
    }

    /**
     * 追加・編集時のキャンセル.
     */
    public void cancel() {
        // do nothing
    }

    /**
     * 辞書画像のパス.
     *
     * @param fileName ファイル名
     * @return File
     */
    protected File getImagePath(final String fileName) {
        File file = ModelInterface.getDictionaryDir(getDictionaryId());
        return new File(file, fileName);
    }

    /**
     * 画像未設定か確認する.
     *
     * @return true:未設定、false:設定済み
     */
    public boolean isImageNotSet() {
        return TextUtils.isEmpty(getImageUrl()) && TextUtils.isEmpty(getImageFileName());
    }

    /**
     * 画像取得が必要か確認する.
     *
     * @return true:必要、false:不要
     */
    public boolean isImageNeedDownload() {
        return !TextUtils.isEmpty(getImageUrl()) && TextUtils.isEmpty(getImageFileName());
    }

    /**
     * 画像ファイルが有効（保存済み）か確認する.
     *
     * @return true:有効、false:無効
     */
    public boolean isImageEnabled() {
        return Constants.Dictionary.DICTIONARY_IMAGE_FILENAME.equals(getImageFileName());
    }

    /**
     * 画像の保存.
     *
     * @param bitmap ビットマップ
     * @return true:成功、false:失敗
     */
    public boolean setImage(Bitmap bitmap) {
        bitmap = ModelInterface.scaleDictionaryImage(bitmap);
        boolean result = ModelInterface.saveDictionaryImage(bitmap,
                getImagePath(Constants.Dictionary.DICTIONARY_IMAGE_FILENAME));
        if (result) {
            setImageFileName(Constants.Dictionary.DICTIONARY_IMAGE_FILENAME);
        }
        return result;
    }

    /**
     * 画像設定の削除.
     */
    public void clearImage() {
        // do nothing
    }

    /**
     * 画像ファイルパスの取得.
     *
     * @return ファイルパス
     */
    public String getImageFileAbsolutePath() {
        if (isImageEnabled()) {
            File file = getImagePath(getImageFileName());
            if (file.exists()) {
                return file.getAbsolutePath();
            }
        }
        return null;
    }

    /**
     * カードの追加.
     * @see EditDictionaryInfo,TempDictionaryInfoでのみ使用する
     *
     * @return CardInfo:成功、null:失敗
     */
    public CardInfo addCard() {
        return addCard(-1);
    }

    /**
     * カードの追加（インデックス指定）.
     * @see EditDictionaryInfo,TempDictionaryInfoでのみ使用する
     *
     * @param index インデックス。範囲外の場合は最後に追加
     * @return CardInfo:成功、null:失敗
     */
    public CardInfo addCard(final int index) {
        return null;
    }

    /**
     * カードの削除.
     * カードが１件の場合は削除できない.
     * @see EditDictionaryInfo,TempDictionaryInfoでのみ使用する
     *
     * @param index インデックス
     * @return true:成功、false:失敗
     */
    public boolean removeCard(final int index) {
        List<CardInfo> list = getCardList();
        if (list != null && list.size() > 1) {
            if (index >= 0 && index < list.size()) {
                CardInfo card = list.remove(index);
                card.cancel();
                return true;
            }
        }
        return false;
    }
}
