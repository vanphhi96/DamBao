/*
 * ファイル：GetNoticeResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.notice;

import java.util.ArrayList;

/**
 * お知らせ一覧取得結果.
 */
public class GetNoticeResultList extends ArrayList<GetNoticeResult> {

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GetNoticeResultList noticeResult = (GetNoticeResultList) o;
        return true;
    }

    @Override
    public int hashCode() {
        int result = 17;
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class GetNoticeResultList {\n");
        sb.append("  " + super.toString()).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
