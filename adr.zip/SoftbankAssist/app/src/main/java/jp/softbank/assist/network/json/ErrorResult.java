/*
 * ファイル：ErrorResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source mCode including any modifications.
 */

package jp.softbank.assist.network.json;

import com.google.gson.annotations.SerializedName;

/**
 * エラー情報.
 */
public class ErrorResult {

    @SerializedName("mCode")
    private String mCode = null;
    @SerializedName("mMessage")
    private String mMessage = null;
    @SerializedName("mItem")
    private String mItem = null;


    /**
     * エラーコード.
     */
    public String getCode() {
        return mCode;
    }
    public void setCode(String code) {
        this.mCode = code;
    }

    /**
     * エラーメッセージ.
     */
    public String getMessage() {
        return mMessage;
    }
    public void setMessage(String message) {
        this.mMessage = message;
    }

    /**
     * エラー項目（パラメータ物理名）.
     */
    public String getItem() {
        return mItem;
    }
    public void setItem(String item) {
        this.mItem = item;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ErrorResult errors = (ErrorResult) o;
        return (this.mCode == null ? errors.mCode == null : this.mCode.equals(errors.mCode)) &&
                (this.mMessage == null ? errors.mMessage == null : this.mMessage.equals(errors.mMessage)) &&
                (this.mItem == null ? errors.mItem == null : this.mItem.equals(errors.mItem));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mCode == null ? 0: this.mCode.hashCode());
        result = 31 * result + (this.mMessage == null ? 0: this.mMessage.hashCode());
        result = 31 * result + (this.mItem == null ? 0: this.mItem.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class ErrorResult {\n");

        sb.append("  mCode: ").append(mCode).append("\n");
        sb.append("  mMessage: ").append(mMessage).append("\n");
        sb.append("  mItem: ").append(mItem).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
