/*
 * ファイル：RegistUserLocationRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.location;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

/**
 * ユーザ位置登録リクエスト.
 */
public class RegistUserLocationRequest extends RequestBody {

    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("mLatitude")
    private Double mLatitude = null;
    @SerializedName("mLongitude")
    private Double mLongitude = null;
    @SerializedName("mTolerance")
    private Double mTolerance = null;
    @SerializedName("status_code")
    private Long mStatusCode = null;
    @SerializedName("regist_type")
    private Long mRegistType = null;


    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * 緯度.
     */
    public Double getLatitude() {
        return mLatitude;
    }
    public void setLatitude(Double latitude) {
        this.mLatitude = latitude;
    }

    /**
     * 経度.
     */
    public Double getLongitude() {
        return mLongitude;
    }
    public void setLongitude(Double longitude) {
        this.mLongitude = longitude;
    }

    /**
     * 誤差(m).
     */
    public Double getTolerance() {
        return mTolerance;
    }
    public void setTolerance(Double tolerance) {
        this.mTolerance = tolerance;
    }

    /**
     * ステータスコード.
     */
    public Long getStatusCode() {
        return mStatusCode;
    }
    public void setStatusCode(Long statusCode) {
        this.mStatusCode = statusCode;
    }

    /**
     * 登録種別.
     */
    public Long getRegistType() {
        return mRegistType;
    }
    public void setRegistType(Long registType) {
        this.mRegistType = registType;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RegistUserLocationRequest requestLocation = (RegistUserLocationRequest) o;
        return (this.mUserId == null ? requestLocation.mUserId == null : this.mUserId.equals(requestLocation.mUserId)) &&
                (this.mLatitude == null ? requestLocation.mLatitude == null : this.mLatitude.equals(requestLocation.mLatitude)) &&
                (this.mLongitude == null ? requestLocation.mLongitude == null : this.mLongitude.equals(requestLocation.mLongitude)) &&
                (this.mTolerance == null ? requestLocation.mTolerance == null : this.mTolerance.equals(requestLocation.mTolerance)) &&
                (this.mStatusCode == null ? requestLocation.mStatusCode == null : this.mStatusCode.equals(requestLocation.mStatusCode)) &&
                (this.mRegistType == null ? requestLocation.mRegistType == null : this.mRegistType.equals(requestLocation.mRegistType));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mLatitude == null ? 0: this.mLatitude.hashCode());
        result = 31 * result + (this.mLongitude == null ? 0: this.mLongitude.hashCode());
        result = 31 * result + (this.mTolerance == null ? 0: this.mTolerance.hashCode());
        result = 31 * result + (this.mStatusCode == null ? 0: this.mStatusCode.hashCode());
        result = 31 * result + (this.mRegistType == null ? 0: this.mRegistType.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class RegistUserLocationRequest {\n");

        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mLatitude: ").append(mLatitude).append("\n");
        sb.append("  mLongitude: ").append(mLongitude).append("\n");
        sb.append("  mTolerance: ").append(mTolerance).append("\n");
        sb.append("  mStatusCode: ").append(mStatusCode).append("\n");
        sb.append("  mRegistType: ").append(mRegistType).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
