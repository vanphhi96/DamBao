/*
 * ファイル：ResourcesUtils.java
 * 概要：Class get data from resource
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */


package jp.softbank.assist.util;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.support.annotation.ColorRes;
import android.support.annotation.DimenRes;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.v4.content.res.ResourcesCompat;
import android.text.TextUtils;

import jp.softbank.assist.R;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

/**
 * Base class get data from src folder.
 *
 * @author Systena
 * @version 1.0
 */
public final class ResourcesUtils {
    private static HashMap<Integer, Integer> sUserIconResourceMap = new HashMap<>();
    private static LinkedHashMap<String, Integer> sScheduleIconResourceMap = new LinkedHashMap<>();


    private ResourcesUtils() {
    }

    /**
     * get value dimen from dimens.xml
     *
     * @param context
     * @param resId   dimen ID
     * @return
     */
    public static int getDimens(@NonNull Context context, @DimenRes int resId) {
        return context.getResources().getDimensionPixelSize(resId);
    }

    /**
     * get value color from colors.xml
     *
     * @param context
     * @param colorResId color ID
     * @return
     */
    public static int getColor(@NonNull Context context, @ColorRes int colorResId) {
        return ResourcesCompat.getColor(context.getResources(), colorResId, null);
    }

    /**
     * get drawable from drawable folder
     *
     * @param context
     * @param drawableID drawable ID
     * @return
     */
    public static Drawable getDrawable(@NonNull Context context, @DrawableRes int drawableID) {
        return context.getResources().getDrawable(drawableID);
    }

    /**
     * parse string to color value
     *
     * @param color string color
     * @return color value
     */
    public static int parseColor(String color) {
        try {
            return Color.parseColor(color);
        } catch (IllegalArgumentException e) {
            AssistLog.e(color + " " + e.getMessage());
        }
        return Color.TRANSPARENT;
    }

    /**
     * get color flag in dictionary
     *
     * @param categoryId
     * @return
     */
    public static int getColorFlagItemDictionary(long categoryId) {
        if (categoryId == Constants.Ids.CATEGORY_ID_HOW_TO_DO) {
            return R.color.dic_card_how_to_do;
        } else if (categoryId == Constants.Ids.CATEGORY_ID_HOW_TO_GO) {
            return R.color.dic_card_how_to_go;
        } else if (categoryId == Constants.Ids.CATEGORY_ID_PROPERTY) {
            return R.color.dic_card_belongings;
        } else {
            return R.color.white;
        }

    }

    /**
     * get color background in dictionary
     *
     * @param categoryId
     * @return
     */
    public static int getColorBackgroundItemDictionary(long categoryId) {
        if (categoryId == Constants.Ids.CATEGORY_ID_HOW_TO_DO) {
            return R.color.dic_bgr_how_to_do;
        } else if (categoryId == Constants.Ids.CATEGORY_ID_HOW_TO_GO) {
            return R.color.dic_bgr_how_to_go;
        } else if (categoryId == Constants.Ids.CATEGORY_ID_PROPERTY) {
            return R.color.dic_bgr_belongings;
        } else {
            return R.color.white;
        }

    }

    /**
     * get image from path
     *
     * @param path: path image
     * @return bitmap
     */
    public static Bitmap getImageFromPath(String path) {
        if (TextUtils.isEmpty(path)) {
            return null;
        }
        File file = new File(path);
        if (file.exists()) {
            return BitmapFactory.decodeFile(file.getAbsolutePath());
        }
        return null;
    }

    /**
     * get image from path
     *
     * @param path: path image
     * @return bitmap
     */
    public static Bitmap getImageFromPath(Context context, String path) {
        if (TextUtils.isEmpty(path)) {
            return null;
        }
        File file = new File(path);
        if (file.exists()) {
            return scaleImage(context, BitmapFactory.decodeFile(file.getAbsolutePath()));
        }
        return null;
    }

    /**
     * get drawable image by name
     *
     * @param context  context
     * @param iconName name of image
     * @return drawable image in drawable folder
     */
    public static Drawable getDrawableByName(Context context, String iconName) {
        if (TextUtils.isEmpty(iconName)) {
            return null;
        }
        Resources resources = context.getResources();
        int resourceId = resources.getIdentifier(iconName, "drawable",
                context.getPackageName());
        return resourceId == 0 ? null : resources.getDrawable(resourceId, null);
    }

    /**
     * resize image after choose
     *
     * @param bitmap is image choose
     * @return image scaled
     */
    public static Bitmap scaleImage(Context context, Bitmap bitmap) {
        if (bitmap != null) {
            try {
                int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
                if (screenWidth < bitmap.getWidth()) {
                    double ratio = (double) bitmap.getWidth() / screenWidth;
                    Bitmap image = bitmap.createScaledBitmap(bitmap, screenWidth, (int) (bitmap.getHeight() / ratio), false);
                    return image;
                } else {
                    return bitmap;
                }
            } catch (IllegalArgumentException e) {
                AssistLog.e(e.getMessage());
                return null;
            }
        }
        return null;
    }

    /**
     * rotate image
     *
     * @param pathImage
     * @return
     */
    public static Bitmap rotateImage(String pathImage) {
        Bitmap bitmap = getImageFromPath(pathImage);
        if (bitmap == null) {
            return null;
        }
        float angle = getAngleRotateImage(pathImage);
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
                matrix, true);
    }

    /**
     * get angle rotate image
     *
     * @param pathImage
     * @return float
     */
    public static float getAngleRotateImage(String pathImage) {
        ExifInterface ei = null;
        try {
            ei = new ExifInterface(pathImage);
            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_UNDEFINED);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    return 90;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    return 180;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    return 270;
                case ExifInterface.ORIENTATION_NORMAL:
                default:
                    return 0;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Icon Resource HashMap 初期化
     */
    public static void initIconResourceMap() {
        int i = 1;
        sUserIconResourceMap.clear();
        sUserIconResourceMap.put(i++, R.drawable.user_f_semilong_l_part);
        sUserIconResourceMap.put(i++, R.drawable.user_m_bozu);
        sUserIconResourceMap.put(i++, R.drawable.user_f_long);
        sUserIconResourceMap.put(i++, R.drawable.user_m_c_part);
        sUserIconResourceMap.put(i++, R.drawable.user_f_long_wave);
        sUserIconResourceMap.put(i++, R.drawable.user_m_fuwastyling);
        sUserIconResourceMap.put(i++, R.drawable.user_f_matome);
        sUserIconResourceMap.put(i++, R.drawable.user_m_l_part);
        sUserIconResourceMap.put(i++, R.drawable.user_f_megane_1);
        sUserIconResourceMap.put(i++, R.drawable.user_m_megane_1);
        sUserIconResourceMap.put(i++, R.drawable.user_f_megane_2);
        sUserIconResourceMap.put(i++, R.drawable.user_m_megane_2);
        sUserIconResourceMap.put(i++, R.drawable.user_f_osage);
        sUserIconResourceMap.put(i++, R.drawable.user_m_perm);
        sUserIconResourceMap.put(i++, R.drawable.user_f_semilong_r_part);
        sUserIconResourceMap.put(i++, R.drawable.user_m_r_part);
        sUserIconResourceMap.put(i++, R.drawable.user_f_short);
        sUserIconResourceMap.put(i++, R.drawable.user_m_styling);
        sUserIconResourceMap.put(i++, R.drawable.user_f_okappa);
        sUserIconResourceMap.put(i++, R.drawable.user_m_techno_cut);
        sUserIconResourceMap.put(i++, R.drawable.user_f_shortbob);
        sUserIconResourceMap.put(i++, R.drawable.user_m_veryshort);
        sUserIconResourceMap.put(i++, R.drawable.user_dog_1);
        sUserIconResourceMap.put(i++, R.drawable.user_cat);
        sUserIconResourceMap.put(i++, R.drawable.user_dog_2);
        sUserIconResourceMap.put(i++, R.drawable.user_penguin);
        sUserIconResourceMap.put(i++, R.drawable.user_bear);
        sUserIconResourceMap.put(i++, R.drawable.user_piyo);
        sUserIconResourceMap.put(i++, R.drawable.user_rabbit);
        sUserIconResourceMap.put(i++, R.drawable.user_shikaku);
        sUserIconResourceMap.put(i++, R.drawable.user_maru);

        sScheduleIconResourceMap.clear();
        sScheduleIconResourceMap.put("default", R.drawable.sch_default);
        sScheduleIconResourceMap.put("move_bicycle", R.drawable.sch_move_bicycle);
        sScheduleIconResourceMap.put("move_bus", R.drawable.sch_move_bus);
        sScheduleIconResourceMap.put("move_car", R.drawable.sch_move_car);
        sScheduleIconResourceMap.put("move_train", R.drawable.sch_move_train);
        sScheduleIconResourceMap.put("move_walk", R.drawable.sch_move_walk);
        sScheduleIconResourceMap.put("work_bag", R.drawable.sch_work_bag);
        sScheduleIconResourceMap.put("work_factory", R.drawable.sch_work_factory);
        sScheduleIconResourceMap.put("work_memo", R.drawable.sch_work_memo);
        sScheduleIconResourceMap.put("work_note", R.drawable.sch_work_note);
        sScheduleIconResourceMap.put("work_office", R.drawable.sch_work_office);
        sScheduleIconResourceMap.put("work_pc", R.drawable.sch_work_pc);
        sScheduleIconResourceMap.put("work_pencil", R.drawable.sch_work_pencil);
        sScheduleIconResourceMap.put("work_school", R.drawable.sch_work_school);
        sScheduleIconResourceMap.put("work_shoe", R.drawable.sch_work_shoe);
        sScheduleIconResourceMap.put("work_shop", R.drawable.sch_work_shop);
        sScheduleIconResourceMap.put("work_sptalk", R.drawable.sch_work_sptalk);
        sScheduleIconResourceMap.put("life_bath", R.drawable.sch_life_bath);
        sScheduleIconResourceMap.put("life_cake", R.drawable.sch_life_cake);
        sScheduleIconResourceMap.put("life_donut", R.drawable.sch_life_donut);
        sScheduleIconResourceMap.put("life_friend", R.drawable.sch_life_friend);
        sScheduleIconResourceMap.put("life_game", R.drawable.sch_life_game);
        sScheduleIconResourceMap.put("life_home", R.drawable.sch_life_home);
        sScheduleIconResourceMap.put("life_hospital", R.drawable.sch_life_hospital);
        sScheduleIconResourceMap.put("life_meal", R.drawable.sch_life_meal);
        sScheduleIconResourceMap.put("life_medicine", R.drawable.sch_life_medicine);
        sScheduleIconResourceMap.put("life_restroom", R.drawable.sch_life_restroom);
        sScheduleIconResourceMap.put("life_toothbrush", R.drawable.sch_life_toothbrush);
        sScheduleIconResourceMap.put("life_trashcan", R.drawable.sch_life_trashcan);
        sScheduleIconResourceMap.put("life_tshirt", R.drawable.sch_life_tshirt);
        sScheduleIconResourceMap.put("life_tv", R.drawable.sch_life_tv);
        sScheduleIconResourceMap.put("life_wallet", R.drawable.sch_life_wallet);
        sScheduleIconResourceMap.put("fun_medal", R.drawable.sch_fun_medal);
        sScheduleIconResourceMap.put("fun_music", R.drawable.sch_fun_music);
        sScheduleIconResourceMap.put("fun_star", R.drawable.sch_fun_star);
        sScheduleIconResourceMap.put("fun_sun", R.drawable.sch_fun_sun);
        sScheduleIconResourceMap.put("fun_trumpet", R.drawable.sch_fun_trumpet);
    }

    /**
     * UserIconIdからResourceを取得.
     *
     * @param userIconId ユーザアイコンID
     * @return アイコンリソース
     */
    public static int getUserIconResourceFromId(int userIconId) {
        if (sUserIconResourceMap.containsKey(userIconId)) {
            return sUserIconResourceMap.get(userIconId);
        }
        AssistLog.e("There is no resource match with this ID ");
        return 0;
    }

    /**
     * User Icon Resource一覧を取得.
     *
     * @return アイコンリソース一覧
     */
    public static ArrayList<Integer> getUserIconResourceList() {
        return new ArrayList<>(sUserIconResourceMap.values());
    }

    /**
     * 予定アイコン名からアイコンリソースを取得.
     *
     * @param scheduleIconName 予定アイコン名
     * @return アイコンリソース
     */
    public static int getScheduleIconResourceFromId(String scheduleIconName) {
        if (scheduleIconName != null && sScheduleIconResourceMap.containsKey(scheduleIconName)) {
            return sScheduleIconResourceMap.get(scheduleIconName);
        }
        return R.drawable.sch_default;
    }

    /**
     * 予定アイコンResource一覧を取得.
     *
     * @return アイコンリソースマップ
     */
    public static LinkedHashMap<String, Integer> getScheduleIconResourceMap() {
        return new LinkedHashMap<>(sScheduleIconResourceMap);
    }
}
