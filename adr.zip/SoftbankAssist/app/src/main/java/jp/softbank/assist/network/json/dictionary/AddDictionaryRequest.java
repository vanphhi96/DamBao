/*
 * ファイル：AddDictionaryRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

import java.util.ArrayList;
import java.util.List;

/**
 * 辞書登録リクエスト.
 */
public class AddDictionaryRequest extends RequestBody {

    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("category_id")
    private Long mCategoryId = null;
    @SerializedName("dictionary_type")
    private Long mDictionaryType = null;
    @SerializedName("image")
    private String mImage = null;
    @SerializedName("mName")
    private String mName = null;
    @SerializedName("mCard")
    private List<AddDictionaryRequestCard> mCard = null;


    /**
     * 値初期化.
     */
    public void initializeValues() {
        mUserId = 0L;
        mCategoryId = 0L;
        mDictionaryType = 0L;
        mImage = "";
        mName = "";
        mCard = new ArrayList<AddDictionaryRequestCard>();
    }

    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * カテゴリID.
     */
    public Long getCategoryId() {
        return mCategoryId;
    }
    public void setCategoryId(Long categoryId) {
        this.mCategoryId = categoryId;
    }

    /**
     * 辞書種別（0：ステップ形式、1：チェック形式）.
     */
    public Long getDictionaryType() {
        return mDictionaryType;
    }
    public void setDictionaryType(Long dictionaryType) {
        this.mDictionaryType = dictionaryType;
    }

    /**
     * 画像（base64形式　ファイル拡張子：jpg、jpeg、png　最大ファイルサイズ：2.5MB）.
     */
    public String getImage() {
        return mImage;
    }
    public void setImage(String image) {
        this.mImage = image;
    }

    /**
     * 辞書名.
     */
    public String getName() {
        return mName;
    }
    public void setName(String name) {
        this.mName = name;
    }

    /**
     * カード情報.
     */
    public List<AddDictionaryRequestCard> getCard() {
        return mCard;
    }
    public void setCard(List<AddDictionaryRequestCard> card) {
        this.mCard = card;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AddDictionaryRequest dictionaryRequest = (AddDictionaryRequest) o;
        return (this.mUserId == null ? dictionaryRequest.mUserId == null : this.mUserId.equals(dictionaryRequest.mUserId)) &&
                (this.mCategoryId == null ? dictionaryRequest.mCategoryId == null : this.mCategoryId.equals(dictionaryRequest.mCategoryId)) &&
                (this.mDictionaryType == null ? dictionaryRequest.mDictionaryType == null : this.mDictionaryType.equals(dictionaryRequest.mDictionaryType)) &&
                (this.mImage == null ? dictionaryRequest.mImage == null : this.mImage.equals(dictionaryRequest.mImage)) &&
                (this.mName == null ? dictionaryRequest.mName == null : this.mName.equals(dictionaryRequest.mName)) &&
                (this.mCard == null ? dictionaryRequest.mCard == null : this.mCard.equals(dictionaryRequest.mCard));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mCategoryId == null ? 0: this.mCategoryId.hashCode());
        result = 31 * result + (this.mDictionaryType == null ? 0: this.mDictionaryType.hashCode());
        result = 31 * result + (this.mImage == null ? 0: this.mImage.hashCode());
        result = 31 * result + (this.mName == null ? 0: this.mName.hashCode());
        result = 31 * result + (this.mCard == null ? 0: this.mCard.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class AddDictionaryRequest {\n");

        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mCategoryId: ").append(mCategoryId).append("\n");
        sb.append("  mDictionaryType: ").append(mDictionaryType).append("\n");
        sb.append("  mImage: ").append(mImage).append("\n");
        sb.append("  mName: ").append(mName).append("\n");
        sb.append("  mCard: ").append(mCard).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
