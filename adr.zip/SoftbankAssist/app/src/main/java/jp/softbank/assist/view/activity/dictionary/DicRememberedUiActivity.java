/*
 * ファイル：DicRememberedUiActivity.java
 * 概要：覚えた画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.dictionary;

import jp.softbank.assist.view.activity.BaseUiActivity;

/**
 * dic-04
 *
 * @author Systena
 * @version 1.0
 */
public class DicRememberedUiActivity extends BaseUiActivity {
}
