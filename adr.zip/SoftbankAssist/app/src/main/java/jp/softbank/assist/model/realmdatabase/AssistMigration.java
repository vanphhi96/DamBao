/*
 * ファイル：AssistMigration.java
 * 概要：Realm Migration作成
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.DynamicRealm;
import io.realm.RealmMigration;
import io.realm.RealmSchema;

/**
 * RealmMigration作成 .
 *
 * @author Systena
 * @version 1.0
 */
public class AssistMigration implements RealmMigration {
    private String mTableName;

    @Override
    public void migrate(final DynamicRealm realm, long oldVersion, long newVersion) {

        // Access the Realm schema in order to create, modify or delete classes and their fields.
        RealmSchema mSchema = realm.getSchema();
        mTableName = realm.getConfiguration().getRealmFileName();

        switch (mTableName) {
            case RealmConstants.UserInfo.USER_INFO_TABLE:
                // TODO: Migration発生時実装箇所
                // DBにて保存済みのデータに対してフィールドの追加、値の設定等を行う
                /***************************************************
                 - バージョンアップする時、データ更新の修理
                 例として、Id>5のRealmUserInfoの場合、Ageを追加して、Age->30にセットする
                 ************************************************/
//                if (newVersion >= 2) {
//                    RealmObjectSchema userInfoSchema = mSchema.get("RealmUserInfo");
//                    if (!userInfoSchema.hasField("age")) {
//                        userInfoSchema.addField("age", int.class)
//                                .transform(new RealmObjectSchema.Function() {
//                                    @Override
//                                    public void apply(DynamicRealmObject obj) {
//                                        if (obj.getInt("id") > 5) {
//                                            obj.setInt("age", 30);
//                                        }
//                                    }
//                                });
//                    }
//                }
                break;
            case RealmConstants.AuthInfo.AUTH_INFO_TABLE:
                break;
            case RealmConstants.DeviceInfo.DEVICE_INFO_TABLE:
                break;
            case RealmConstants.LocationSettings.LOCATION_SETTING_TABLE:
                break;
            case RealmConstants.LocationInfo.LOCATION_INFO_TABLE:
                break;
            case RealmConstants.AppVersionInfo.APP_VERSION_INFO_TABLE:
                break;
            case RealmConstants.NoticeInfo.NOTICE_INFO_TABLE:
                break;
            case RealmConstants.CategoryInfo.CATEGORY_INFO_TABLE:
                break;
            case RealmConstants.DictionaryInfo.DICTIONARY_INFO_TABLE:
                break;
            case RealmConstants.CardInfo.CARD_INFO_TABLE:
                break;
            case RealmConstants.ScheduleInfo.SCHEDULE_INFO_TABLE:
                break;
            case RealmConstants.DictionaryOrderInfo.DICTIONARY_ORDER_INFO_TABLE:
                break;
            case RealmConstants.ScheduleGetHistory.SCHEDULE_GET_HISTORY_TABLE:
                break;
            default:
                break;

        }
    }
}
