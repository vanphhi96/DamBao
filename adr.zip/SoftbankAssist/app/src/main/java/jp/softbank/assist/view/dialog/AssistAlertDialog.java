/*
 * ファイル：AssistAlertDialog.java
 * 概要：アラートダイアログ生成クラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;

/**
 * アラートダイアログ生成クラス
 *
 * @author Systena
 * @version 1.0
 */
public class AssistAlertDialog extends BaseDialog {

    /**
     * ダイアログ生成
     *
     * @param dialogFactory ダイアログファクトリ
     * @return show可能な状態のダイアログ
     */
    public static AssistAlertDialog newInstance(BaseDialogFactory dialogFactory) {
        Bundle bundle = getArgumentsBundle(dialogFactory);
        AssistAlertDialog dialog = new AssistAlertDialog();
        dialog.setArguments(bundle);
        return dialog;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        super.onCreateDialog(savedInstanceState);
        AlertDialog alertDialog = getDialogFactory().getReadyAlertDialog(getActivity());
        alertDialog.setOnShowListener(this);
        // ダイアログのキャンセル操作の有効無効を設定する
        setCancelable(getDialogFactory().isCancelable());
        return alertDialog;
    }

    /**
     * ダイアログ終了
     *
     * @param dialog 終了させるダイアログ
     */
    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
    }
}
