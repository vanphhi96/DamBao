/*
 * ファイル：RealmDicOrderInfo.java
 * 概要：Realm用辞書並び順設定テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;


import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Realm用辞書並び順設定テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */public class RealmDicOrderInfo  extends RealmObject {

    @PrimaryKey
    private long mCategoryId; // カテゴリID
    private RealmList<Long> mDictionaryId; // 辞書IDの配列（最大25）

    public long getCategoryId() {
        return mCategoryId;
    }

    public void setCategoryId(long mCategoryId) {
        this.mCategoryId = mCategoryId;
    }

    public RealmList<Long> getDictionaryId() {
        return mDictionaryId;
    }

    public void setDictionaryId(RealmList<Long> dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }

}
