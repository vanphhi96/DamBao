/*
 * ファイル：AssistAlertDialogFactory.java
 * 概要：アラートダイアログ表示用Factoryベースクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v4.app.FragmentActivity;

import jp.softbank.assist.R;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl.DialogType;

/**
 * アラートダイアログ表示用Factoryベースクラス
 *
 * @author Systena
 * @version 1.0
 */
public class AssistAlertDialogFactory extends BaseDialogFactory {

    /**
     * ダイアログ種別.
     */
    private DialogType mDialogType;
    /**
     * message of dialog
     */
    private String mMessage;

    /**
     * コンストラクタ.
     *
     * @param dialogType ダイアログ表示種別
     */
    public AssistAlertDialogFactory(final DialogType dialogType) {
        mDialogType = dialogType;
    }

    /**
     * コンストラクタ.
     *
     * @param dialogType ダイアログ表示種別
     */
    public AssistAlertDialogFactory(final DialogType dialogType, final String message) {
        mDialogType = dialogType;
        mMessage = message;
    }

    @Override
    public String getDialogTag() {
        return mDialogType.name();
    }

    /**
     * ダイアログ設定
     *
     * @param activity ダイアログ表示するActivity
     */
    @Override
    public AlertDialog getReadyAlertDialog(final FragmentActivity activity) {
        // ダイアログ生成のためのビルダー取得
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);

        // ダイアログ種別によりそれぞれのビルダーパラメータ作成処理を実行
        switch (mDialogType) {
            case ALERT_TEST_DIALOG1:
                buildDialogTest(activity, builder);
                break;
            case SCH_DELETE_DIALOG:
                buildDialogDeleteSchedule(activity, builder);
                break;
            case SCH_DELETE_END:
                buildDialogDeleteEnd(activity, builder);
                break;
            case DIC_CR_END:
                buildDialogDicCrEnd(activity, builder);
                break;
            case DIC_EDIT_END:
                buildDialogDicEditEnd(activity, builder);
                break;
            case SCH_DIC_DEL:
                buildDialogSchDicDelete(activity, builder);
                break;
            case SCH_DIC_DELETE_END:
                buildDialogSchDicDelEnd(activity, builder);
                break;
            case DIC_DELETE_DIALOG:
                buildDialogDicDelete(activity, builder);
                break;
            case DIC_DEL_END:
                buildDialogDicDelEnd(activity, builder);
                break;
            case SET_SAVE_DIALOG:
                buildDialogSetSave(activity, builder);
                break;
            case DIC_EDIT_DEL_ITEM:
                buildDialogDelItemDic(activity, builder);
                break;
            case DIC_EDIT_DEL_ITEM_END:
                buildDialogDelItemDicEnd(activity, builder);
                break;
            case SCH_DEL_DIC_CONFIRM:
                buildDialogDelDicSchEdDicConfirm(activity, builder);
                break;
            case SCH_DEL_DIC_END:
                buildDialogDelDicSchEdDicEnd(activity, builder);
                break;
            case DIC_CAN_NOT_SORT:
                buildDialogCanNotSortDic(activity, builder);
                break;
            case DIALOG_MESSAGE:
                buildDialogMessage(activity, builder);
                break;
            case SCH_DETAIL_OFFLINE:
                buildDialogOffline(activity, builder);
                break;
            case DIC_CARD_MAX:
                buildDialogDicCardMax(activity, builder);
                break;
            case DIC_NO_CARD:
                buildDialogDicNoCard(activity, builder);
                break;
            case DIC_VALIDATE_EMPTY_CARD:
                buildDialogDicValidateEmptyCard(activity, builder);
                break;
            case DIC_VALIDATE_NO_TITLE:
                buildDialogDicValidateNoTitle(activity, builder);
                break;
            case DIC_VALIDATE_NO_TITLE_EMPTY_CARD:
                buildDialogDicValidateNotitleEmptyCard(activity, builder);
                break;
            case SCH_CR_QUIT:
                buildDialogQuitCreateSchedule(activity, builder);
                break;
            case SCH_ED_QUIT:
                buildDialogQuitEditSchedule(activity, builder);
                break;
            case SCH_SELECTED_DIC:
                buildDialogSelectedDictionary(activity, builder);
                break;
            default:
                // 到達しないコード
                break;
        }
        return builder.create();
    }

// TODO: 2019/01/30 [buildDialogTest]このMethodはテストのため、後で消す/ This file is just for test, delete later.

    /**
     * ダイアログ設定(Test)
     *
     * @param builder パラメータ設定するAlertDialog.Builder
     */
    private void buildDialogTest(final FragmentActivity activity,
                                 AlertDialog.Builder builder) {
        builder.setTitle(jp.softbank.assist.R.string.sch_title);
        builder.setMessage(R.string.app_name);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog delete schedule
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDeleteSchedule(final FragmentActivity activity,
                                           AlertDialog.Builder builder) {
        builder.setMessage(R.string.sch_del_confirm);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setNegativeButton(jp.softbank.assist.R.string.cancel,
                    (DialogInterface.OnClickListener) activity);
            builder.setPositiveButton(R.string.delete,
                    (DialogInterface.OnClickListener) activity);
        }

    }

    /**
     * dialog delete end schedule
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDeleteEnd(final FragmentActivity activity,
                                      AlertDialog.Builder builder) {
        setCancelable(false);
        builder.setMessage(R.string.sch_del_end);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog dictionary create end
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDicCrEnd(final FragmentActivity activity,
                                     AlertDialog.Builder builder) {
        setCancelable(false);
        builder.setMessage(activity.getString(R.string.dic_cr_dic_end));
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog dictionary edit end
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDicEditEnd(final FragmentActivity activity,
                                       AlertDialog.Builder builder) {
        setCancelable(false);
        builder.setMessage(activity.getString(R.string.dic_save_dic));
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog sch-dic-del-01
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogSchDicDelete(final FragmentActivity activity,
                                         AlertDialog.Builder builder) {
        builder.setTitle(activity.getString(R.string.app_name));
        builder.setMessage(R.string.sch_dic_link_del_confirm);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setNegativeButton(R.string.cancel,
                    (DialogInterface.OnClickListener) activity);
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog sch-dic-del-02
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogSchDicDelEnd(final FragmentActivity activity,
                                         AlertDialog.Builder builder) {
        setCancelable(false);
        builder.setTitle(activity.getString(R.string.app_name));
        builder.setMessage(R.string.sch_dic_link_del);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog confirm delete dictionary
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDicDelete(final FragmentActivity activity,
                                      AlertDialog.Builder builder) {
        builder.setMessage(R.string.dic_del_confirm);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setNegativeButton(R.string.cancel, (DialogInterface.OnClickListener) activity);
            builder.setPositiveButton(R.string.delete,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog delete end dictionary
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDicDelEnd(final FragmentActivity activity,
                                      AlertDialog.Builder builder) {
        setCancelable(false);
        builder.setMessage(R.string.dic_del_end);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * Setting Save User Dialog
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogSetSave(final FragmentActivity activity,
                                    AlertDialog.Builder builder) {
        builder.setMessage(R.string.set_save_user);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog delete item dic confirm
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDelItemDic(final FragmentActivity activity,
                                       AlertDialog.Builder builder) {
        builder.setMessage(R.string.dic_card_del_confirm);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setNegativeButton(R.string.cancel, (DialogInterface.OnClickListener) activity);
            builder.setPositiveButton(R.string.delete,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog delete item dic end
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDelItemDicEnd(final FragmentActivity activity,
                                          AlertDialog.Builder builder) {
        builder.setMessage(R.string.dic_card_del);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(jp.softbank.assist.R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog sch-dic-del-01
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDelDicSchEdDicConfirm(final FragmentActivity activity,
                                                  AlertDialog.Builder builder) {
        builder.setMessage(R.string.sch_dic_link_del_confirm);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.delete,
                    (DialogInterface.OnClickListener) activity);
            builder.setNegativeButton(R.string.cancel,
                    (DialogInterface.OnClickListener) activity);
        }
    }

    /**
     * dialog  sch-dic-del-02
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDelDicSchEdDicEnd(final FragmentActivity activity,
                                              AlertDialog.Builder builder) {
        setCancelable(false);
        builder.setMessage(R.string.sch_dic_link_del);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog can not sort dic-02
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogCanNotSortDic(final FragmentActivity activity,
                                          AlertDialog.Builder builder) {
        builder.setMessage(R.string.dic_sort_err);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog message
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogMessage(final FragmentActivity activity,
                                    AlertDialog.Builder builder) {
        builder.setMessage(mMessage);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog  click complete when device disconnection
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogOffline(final FragmentActivity activity,
                                    AlertDialog.Builder builder) {
        builder.setMessage(R.string.sch_offline);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog can not add dictionary because category full item
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDicListMax(final FragmentActivity activity,
                                       AlertDialog.Builder builder) {
        builder.setMessage(R.string.dic_list_max);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog can not add dictionary because dictionary no card
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDicNoCard(final FragmentActivity activity,
                                      AlertDialog.Builder builder) {
        builder.setMessage(R.string.dic_no_card);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog can not add dictionary because size card max
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDicCardMax(final FragmentActivity activity,
                                       AlertDialog.Builder builder) {
        builder.setMessage(String.format(activity.getString(R.string.dic_card_max),
                Constants.Dictionary.MAX_CARD_DICTIONARY));
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog can not add dictionary because size card max
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDicValidateNoTitle(final FragmentActivity activity,
                                               AlertDialog.Builder builder) {
        builder.setMessage(R.string.dic_validate_notitle);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog can not add dictionary because size card max
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDicValidateEmptyCard(final FragmentActivity activity,
                                                 AlertDialog.Builder builder) {
        builder.setMessage(R.string.dic_validate_emptycard);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog can not add dictionary because size card max
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogDicValidateNotitleEmptyCard(final FragmentActivity activity,
                                                        AlertDialog.Builder builder) {
        String msg = activity.getString(R.string.dic_validate_notitle)
                + activity.getString(R.string.new_line)
                + activity.getString(R.string.dic_validate_emptycard);
        builder.setMessage(msg);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog quit create schedule
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogQuitCreateSchedule(final FragmentActivity activity,
                                               AlertDialog.Builder builder) {
        setCancelable(false);
        builder.setMessage(R.string.sch_cr_confirm);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);
            builder.setNegativeButton(R.string.cancel,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog quit edit schedule
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogQuitEditSchedule(final FragmentActivity activity,
                                             AlertDialog.Builder builder) {
        builder.setMessage(R.string.sch_ed_confirm);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);
            builder.setNegativeButton(R.string.cancel,
                    (DialogInterface.OnClickListener) activity);

        }
    }

    /**
     * dialog quit edit schedule
     *
     * @param activity Activity to display dialog
     * @param builder  Generate dialog builder
     */
    private void buildDialogSelectedDictionary(final FragmentActivity activity,
                                               AlertDialog.Builder builder) {
        builder.setMessage(R.string.sch_dic_link);
        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
    }
}
