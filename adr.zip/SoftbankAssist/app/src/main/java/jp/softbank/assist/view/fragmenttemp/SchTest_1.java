package jp.softbank.assist.view.fragmenttemp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import jp.softbank.assist.R;
import jp.softbank.assist.util.AssistEventLog;
import jp.softbank.assist.view.fragment.BaseFragment;
import jp.softbank.assist.view.ScreenId;

/**
 * Created by Tan N. Truong on 2019/01/09.
 */

// TODO: 2019/01/09 Just an example Fragment, can be deleted later
public class SchTest_1 extends BaseFragment implements View.OnClickListener {

    private Button mButton;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AssistEventLog.sendEventFirebaseScreenId(getActivity(), ScreenId.START_SCH_TOP);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_temp_sch_one, container, false);
        mButton = view.findViewById(R.id.button_SCHEDULE_ONE_FRAGMENT);
        mButton.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View view) {
        changeFragment(ScreenId.START_FRAGMENT_SCHEDULE_TWO);
//        setView(VIEW_KEY.START_SUB1);

    }


}
