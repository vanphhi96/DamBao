/*
 * ファイル：GetUserResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.user;

import com.google.gson.annotations.SerializedName;

/**
 * ユーザ情報取得結果.
 */
public class GetUserResult {

    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("mCuid")
    private String mCuid = null;
    @SerializedName("mNickname")
    private String mNickname = null;
    @SerializedName("icon_id")
    private Long mIconId = null;


    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * CUID.
     */
    public String getCuid() {
        return mCuid;
    }
    public void setCuid(String cuid) {
        this.mCuid = cuid;
    }

    /**
     * ニックネーム.
     */
    public String getNickname() {
        return mNickname;
    }
    public void setNickname(String nickname) {
        this.mNickname = nickname;
    }

    /**
     * アイコンID.
     */
    public Long getIconId() {
        return mIconId;
    }
    public void setIconId(Long iconId) {
        this.mIconId = iconId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GetUserResult resultUserInfo = (GetUserResult) o;
        return (this.mUserId == null ? resultUserInfo.mUserId == null : this.mUserId.equals(resultUserInfo.mUserId)) &&
                (this.mCuid == null ? resultUserInfo.mCuid == null : this.mCuid.equals(resultUserInfo.mCuid)) &&
                (this.mNickname == null ? resultUserInfo.mNickname == null : this.mNickname.equals(resultUserInfo.mNickname)) &&
                (this.mIconId == null ? resultUserInfo.mIconId == null : this.mIconId.equals(resultUserInfo.mIconId));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mCuid == null ? 0: this.mCuid.hashCode());
        result = 31 * result + (this.mNickname == null ? 0: this.mNickname.hashCode());
        result = 31 * result + (this.mIconId == null ? 0: this.mIconId.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class GetUserResult {\n");

        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mCuid: ").append(mCuid).append("\n");
        sb.append("  mNickname: ").append(mNickname).append("\n");
        sb.append("  mIconId: ").append(mIconId).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
