/*
 * ファイル：ScheduleGetHistory.java
 * 概要：スケジュール取得履歴
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import java.util.Date;

/**
 * スケジュール取得履歴.
 *
 * @author Systena
 * @version 1.0
 */
public class ScheduleGetHistory {

    private Date mScheduleFrom; // 開始日
    private Date mScheduleTo; // 終了日


    public Date getScheduleFrom() {
        return mScheduleFrom;
    }

    public void setScheduleFrom(Date mScheduleFromOn) {
        this.mScheduleFrom = mScheduleFromOn;
    }

    public Date getScheduleTo() {
        return mScheduleTo;
    }

    public void setScheduleTo(Date mScheduleToOn) {
        this.mScheduleTo = mScheduleToOn;
    }
}
