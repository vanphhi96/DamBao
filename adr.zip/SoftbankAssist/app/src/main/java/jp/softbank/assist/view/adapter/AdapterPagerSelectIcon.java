/*
 * ファイル：AdapterPagerSelectIcon.java
 * 概要：Adapter pager select icon schedule.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.activity.schedule.IScheduleSelectIcon;
import jp.softbank.assist.view.fragment.schedule.FragmentSelectIcon;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * sch-ed-01.
 *
 * @author Systena
 * @version 1.0
 */
public class AdapterPagerSelectIcon extends FragmentStatePagerAdapter {
    private IScheduleSelectIcon mIScheduleSelectIcon;
    private List<String> mListIcon = getListIconName();
    private static final int TOTAL_ITEM_IN_A_PAGE = 10;
    private String mDrawableSelected;

    public AdapterPagerSelectIcon(FragmentManager fragmentManager, IScheduleSelectIcon iScheduleSelectIcon) {
        super(fragmentManager);
        this.mIScheduleSelectIcon = iScheduleSelectIcon;
    }

    @Override
    public Fragment getItem(int i) {
        return new FragmentSelectIcon(mIScheduleSelectIcon, getListIcon(i), mDrawableSelected);
    }

    @Override
    public int getCount() {
        return getTotalPage();
    }

    /**
     * get total page
     *
     * @return total page
     */
    public int getTotalPage() {
        if (mListIcon == null || mListIcon.size() == 0) {
            return 0;
        }
        if (mListIcon.size() % TOTAL_ITEM_IN_A_PAGE > 0) {
            return mListIcon.size() / TOTAL_ITEM_IN_A_PAGE + 1;
        }
        return mListIcon.size() / TOTAL_ITEM_IN_A_PAGE;
    }

    /**
     * get list icon for each page
     *
     * @param position
     * @return
     */
    private ArrayList<String> getListIcon(int position) {
        ArrayList<String> listIcon = new ArrayList<>();
        if (mListIcon.size() > 0) {
            for (int i = 0; i < TOTAL_ITEM_IN_A_PAGE; i++) {
                if (TOTAL_ITEM_IN_A_PAGE * position + i < mListIcon.size()) {
                    listIcon.add(mListIcon.get(TOTAL_ITEM_IN_A_PAGE * position + i));
                }
            }
        }
        return listIcon;
    }

    /**
     * set icon selected
     *
     * @param drawable
     */
    public void setIconSelected(String drawable) {
        this.mDrawableSelected = drawable;
    }

    /**
     * get list name from HashMap icon schedule;
     *
     * @return
     */
    private List<String> getListIconName() {
        List<String> listIconName = new ArrayList<>();
        LinkedHashMap<String, Integer> listIcon = ResourcesUtils.getScheduleIconResourceMap();
        for (String key : listIcon.keySet()) {
            listIconName.add(key);
        }
        return listIconName;
    }
}
