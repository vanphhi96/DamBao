/*
 * ファイル：UpdateNoticeUiActivity.java
 * 強制アップデートStore誘導画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.AppVersionInfo;
import jp.softbank.assist.view.activity.BaseUiActivity;

/**
 * 強制アップデートStore誘導画面
 *
 * @author Systena
 * @version 1.0
 */
public class UpdateNoticeUiActivity extends BaseUiActivity implements View.OnClickListener {

    private Button mUpdateBtn;
    private TextView mTvTitle;
    private TextView mTvContent;
    private AppVersionInfo mAppVersionInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upd_01);
        initView();
        mAppVersionInfo = getAppVersionInfo();
    }

    /**
     * BundleでAppVersionInfo取得
     *
     * @return AppVersionInfo
     */
    private AppVersionInfo getAppVersionInfo() {
        Bundle bundle = getIntent().getExtras();
        return getIntent().hasExtra(CheckAppUiActivity.APP_VERSION_KEY)
                ? (AppVersionInfo) (bundle.getSerializable(CheckAppUiActivity.APP_VERSION_KEY))
                : null;
    }


    /**
     * View初期化
     */
    private void initView() {
        mUpdateBtn = findViewById(R.id.btn_update);
        mTvTitle = findViewById(R.id.tv_title);
        mTvContent = findViewById(R.id.tv_content);
        mUpdateBtn.setText(R.string.update_btn);
        mTvTitle.setText(R.string.update_title);
        mTvContent.setText(R.string.update_note);
        mUpdateBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_update:
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(mAppVersionInfo.getUrl())));
                finish();
                break;
            default:
                break;
        }
    }
}
