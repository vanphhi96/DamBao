/*
 * ファイル：UserInfo.java
 * 概要：ユーザー情報テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragmenttemp;

import java.util.List;

/**
 * ユーザー情報テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */

public class TestData {

    private long mId;
    private String mName;

    private long mVertion;

    // マイグレーション対応
//    public String getmAddStr() {
//        return mAddStr;
//    }
//
//    public void setmAddStr(String mAddStr) {
//        this.mAddStr = mAddStr;
//    }
//
//    public String getmAdd2Str() {
//        return mAdd2Str;
//    }
//
//    public void setmAdd2Str(String mAdd2Str) {
//        this.mAdd2Str = mAdd2Str;
//    }
//
//    private String mAddStr;
//    private String mAdd2Str;
// マイグレーション対応

    public long getmId() {
        return mId;
    }

    public void setmId(long mId) {
        this.mId = mId;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public long getmVertion() {
        return mVertion;
    }

    public void setmVertion(long mVertion) {
        this.mVertion = mVertion;
    }

    // 保存しているKEY情報
    public static final String PRIMARY_KEY_ID = "mId"; // 利用者（ユーザ）ID

}
