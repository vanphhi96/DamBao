/*
 * ファイル：GetScheduleResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.schedule;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * スケジュール情報取得結果.
 */
public class GetScheduleResult {

    @SerializedName("mSchedule")
    private GetScheduleResultSchedule mSchedule = null;
    @SerializedName("schedule_meta")
    private GetScheduleResultMeta mScheduleMeta = null;
    @SerializedName("mReminder")
    private List<GetScheduleResultReminder> mReminder = null;
    @SerializedName("mDictionary")
    private List<ScheduleDictionary> mDictionary = null;
    @SerializedName("schedule_repeat")
    private GetScheduleResultRepeat mScheduleRepeat = null;


    public GetScheduleResultSchedule getSchedule() {
        return mSchedule;
    }
    public void setSchedule(GetScheduleResultSchedule schedule) {
        this.mSchedule = schedule;
    }

    public GetScheduleResultMeta getScheduleMeta() {
        return mScheduleMeta;
    }
    public void setScheduleMeta(GetScheduleResultMeta scheduleMeta) {
        this.mScheduleMeta = scheduleMeta;
    }

    public List<GetScheduleResultReminder> getReminder() {
        return mReminder;
    }
    public void setReminder(List<GetScheduleResultReminder> reminder) {
        this.mReminder = reminder;
    }

    public List<ScheduleDictionary> getDictionary() {
        return mDictionary;
    }
    public void setDictionary(List<ScheduleDictionary> dictionary) {
        this.mDictionary = dictionary;
    }

    public GetScheduleResultRepeat getScheduleRepeat() {
        return mScheduleRepeat;
    }
    public void setScheduleRepeat(GetScheduleResultRepeat scheduleRepeat) {
        this.mScheduleRepeat = scheduleRepeat;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GetScheduleResult scheduleResult = (GetScheduleResult) o;
        return (this.mSchedule == null ? scheduleResult.mSchedule == null : this.mSchedule.equals(scheduleResult.mSchedule)) &&
                (this.mScheduleMeta == null ? scheduleResult.mScheduleMeta == null : this.mScheduleMeta.equals(scheduleResult.mScheduleMeta)) &&
                (this.mReminder == null ? scheduleResult.mReminder == null : this.mReminder.equals(scheduleResult.mReminder)) &&
                (this.mDictionary == null ? scheduleResult.mDictionary == null : this.mDictionary.equals(scheduleResult.mDictionary)) &&
                (this.mScheduleRepeat == null ? scheduleResult.mScheduleRepeat == null : this.mScheduleRepeat.equals(scheduleResult.mScheduleRepeat));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mSchedule == null ? 0: this.mSchedule.hashCode());
        result = 31 * result + (this.mScheduleMeta == null ? 0: this.mScheduleMeta.hashCode());
        result = 31 * result + (this.mReminder == null ? 0: this.mReminder.hashCode());
        result = 31 * result + (this.mDictionary == null ? 0: this.mDictionary.hashCode());
        result = 31 * result + (this.mScheduleRepeat == null ? 0: this.mScheduleRepeat.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class GetScheduleResult {\n");

        sb.append("  mSchedule: ").append(mSchedule).append("\n");
        sb.append("  mScheduleMeta: ").append(mScheduleMeta).append("\n");
        sb.append("  mReminder: ").append(mReminder).append("\n");
        sb.append("  mDictionary: ").append(mDictionary).append("\n");
        sb.append("  mScheduleRepeat: ").append(mScheduleRepeat).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
