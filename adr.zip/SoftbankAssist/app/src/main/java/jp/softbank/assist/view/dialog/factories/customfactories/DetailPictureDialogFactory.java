/*
 * ファイル：DetailPictureDialogFactory.java
 * 概要：写真の拡大表示
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
// TODO: 2019/01/30 このファイルはテストのため、後で消す/ This file is just for test, delete later.

package jp.softbank.assist.view.dialog.factories.customfactories;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.view.activity.schedule.ISchDictionaryDetailPicturePageAdapter;
import jp.softbank.assist.view.adapter.DetailPicturePageAdapter;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;

import java.util.List;

/**
 * sch-dic-02, dic-05.
 *
 * @author Systena
 * @version 1.0
 */
public class DetailPictureDialogFactory extends BaseDialogFactory implements View.OnClickListener,
        ISchDictionaryDetailPicturePageAdapter {

    private DialogTypeControl.DialogType mDialogType;
    private IDetailPicture mIDetailPicture;
    private DetailPicturePageAdapter mSchDictionaryChangePageAdapter;
    private List<CardInfo> mListCardInfo;
    private ViewPager mVpPhoto;
    private ImageView mImgBack;
    private int mPositionStartPage;
    private DictionaryInfo.DictionaryType mDictionaryType;
    private Activity mActivity;

    public DetailPictureDialogFactory(DialogTypeControl.DialogType dialogType, IDetailPicture iDetailPicture,
                                      DictionaryInfo.DictionaryType dictionaryType) {
        this.mDialogType = dialogType;
        this.mIDetailPicture = iDetailPicture;
        this.mDictionaryType = dictionaryType;
    }

    @Override
    public AlertDialog getReadyAlertDialog(FragmentActivity activity) {
        AlertDialog.Builder builder = createDialogBuilder(activity, R.style.DialogFullWidth);
        LayoutInflater inflater = activity.getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_detail_picture, null);

        mImgBack = view.findViewById(R.id.img_back);
        mVpPhoto = view.findViewById(R.id.vp_photo);
        mSchDictionaryChangePageAdapter = new DetailPicturePageAdapter(this, mListCardInfo);
        mSchDictionaryChangePageAdapter.setActivity(mActivity);
        mSchDictionaryChangePageAdapter.setDictionaryType(mDictionaryType);
        mVpPhoto.setAdapter(mSchDictionaryChangePageAdapter);
        mVpPhoto.setCurrentItem(mPositionStartPage);
        mImgBack.setOnClickListener(this);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return alertDialog;
    }

    /**
     * set Activity, use when runOnUiThread
     *
     * @param activity
     */
    public void setActivity(Activity activity) {
        this.mActivity = activity;
    }


    /**
     * set List card info
     *
     * @param listCardInfo
     */
    public void setListCardInfo(List<CardInfo> listCardInfo) {
        this.mListCardInfo = listCardInfo;
    }

    /**
     * set position start of pager
     *
     * @param positionPage
     */
    public void setPositionStartPage(int positionPage) {
        this.mPositionStartPage = positionPage;
    }

    @Override
    public String getDialogTag() {
        return mDialogType.name();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_back:
                mIDetailPicture.dismissDialog();
                break;
            default:
                break;
        }
    }

    @Override
    public void nextPage() {
        if (mVpPhoto.getCurrentItem() >= mSchDictionaryChangePageAdapter.getLastPagePosition()) {
            return;
        }
        mVpPhoto.setCurrentItem(mVpPhoto.getCurrentItem() + 1);
    }

    @Override
    public void previousPage() {
        if (mVpPhoto.getCurrentItem() <= mSchDictionaryChangePageAdapter.getFistPagePosition()) {
            return;
        }
        mVpPhoto.setCurrentItem(mVpPhoto.getCurrentItem() - 1);
    }
}
