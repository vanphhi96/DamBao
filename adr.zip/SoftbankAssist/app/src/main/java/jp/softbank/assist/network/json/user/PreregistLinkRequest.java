/*
 * ファイル：PreregistLinkRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.user;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

/**
 * 紐づけ情報仮登録（利用者から管理者）リクエスト.
 */
public class PreregistLinkRequest extends RequestBody {

    @SerializedName("mCfid")
    private String mCfid = null;
    @SerializedName("mNickname")
    private String mNickname = null;


    /**
     * キャリアフリーID.
     */
    public String getCfid() {
        return mCfid;
    }
    public void setCfid(String cfid) {
        this.mCfid = cfid;
    }

    /**
     * ニックネーム.
     */
    public String getNickname() {
        return mNickname;
    }
    public void setNickname(String nickname) {
        this.mNickname = nickname;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PreregistLinkRequest requestPreregistLink = (PreregistLinkRequest) o;
        return (this.mCfid == null ? requestPreregistLink.mCfid == null : this.mCfid.equals(requestPreregistLink.mCfid)) &&
                (this.mNickname == null ? requestPreregistLink.mNickname == null : this.mNickname.equals(requestPreregistLink.mNickname));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mCfid == null ? 0: this.mCfid.hashCode());
        result = 31 * result + (this.mNickname == null ? 0: this.mNickname.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class PreregistLinkRequest {\n");

        sb.append("  mCfid: ").append(mCfid).append("\n");
        sb.append("  mNickname: ").append(mNickname).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
