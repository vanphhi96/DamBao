/*
 * ファイル：TimerInfo.java
 * 概要：タイマー情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

/**
 * タイマー情報.
 *
 * @author Systena
 * @version 1.0
 */
public class TimerInfo {

    private int mRequestCode; //リクエストコード
    private String mType; // タイマ設定 Settype

    public int getRequestCode() {
        return mRequestCode;
    }

    public void setRequestCode(int requestCode) {
        this.mRequestCode = requestCode;
    }

    public String getType() {
        return mType;
    }

    public void setType(String type) {
        this.mType = type;
    }

}
