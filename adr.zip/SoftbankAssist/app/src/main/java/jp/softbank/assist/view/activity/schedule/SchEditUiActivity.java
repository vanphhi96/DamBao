/*
 * ファイル：SchEditUiActivity.java
 * 概要：予定の編集画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.schedule;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.adapter.AdapterPagerSelectIcon;
import jp.softbank.assist.view.customview.EditTextLinesLimiter;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;
import jp.softbank.assist.view.dialog.factories.customfactories.DateTimePickerDialogFactory;
import jp.softbank.assist.view.dialog.factories.customfactories.IDateTimePicker;
import jp.softbank.assist.view.dialog.factories.customfactories.ISchSaveDialog;
import jp.softbank.assist.view.dialog.factories.customfactories.SchSaveDialogFactory;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * sch-ed-01
 *
 * @author Systena
 * @version 1.0
 */
public class SchEditUiActivity extends BaseUiActivity implements View.OnClickListener,
        ISchSaveDialog, IScheduleSelectIcon, IDateTimePicker, NotifyOnlyResultListener {

    private ViewPager mViewPager;
    private TextView mTvSave;
    private TextView mTvStartDate;
    private TextView mTvStartTime;
    private TextView mTvEndDate;
    private TextView mTvEndTime;
    private TextView mTvTypeRepeat;
    private TextView mTvDeleteSchedule;
    private LinearLayout mLayoutBack;
    private ImageView mImvEditIcon;
    private LinearLayout mLayoutKeyboard;
    private RelativeLayout mRelativeRepeat;
    private ScrollView mScrollView;
    private EditText mEdtScheduleTitle;
    private EditText mEdtScheduleNote;
    private EditText mEdtScheduleLocation;
    private Switch mSwitchRepeat;
    private AdapterPagerSelectIcon mAdapterPagerSelectIcon;
    private DialogFragment mDialogSchSave;
    private View mViewSpaceIcon;
    private AssistAlertDialogFactory mDialogFactory;
    private String mDialogTag;
    private RelativeLayout mRlStartDateTime;
    private RelativeLayout mRlEndDateTime;
    private boolean mIsStartDateTime;
    private DialogFragment mDialogDateTime;
    private ScheduleInfo mScheduleInfo;
    private Date mStartDate;
    private Date mEndDate;
    private Calendar mCalendar = Calendar.getInstance();
    private ImageView mImgSchedule;
    private ScheduleInfo.IntervalType mIntervalType;
    private DictionaryInfo mDictionaryInfoOne;
    private DictionaryInfo mDictionaryInfoTwo;
    private DictionaryInfo mDictionaryInfoThree;
    private int mSelectDictionary;
    private final int mSelectDictionaryInfoOne = 1;
    private final int mSelectDictionaryInfoTwo = 2;
    private final int mSelectDictionaryInfoThree = 3;
    private TextView mTvDictionaryOne;
    private TextView mTvDictionaryTwo;
    private TextView mTvDictionaryThree;
    private String mRequestApi;
    private String mIconName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_schedule);
        mScheduleInfo = getDataSchedule();

        mRelativeRepeat = findViewById(R.id.rlt_sch_cr_repeat);
        mImgSchedule = findViewById(R.id.img_schedule);
        mImvEditIcon = findViewById(R.id.imv_sch_cr_ic_edit);
        mLayoutKeyboard = findViewById(R.id.ln_sch_cr_keyboard);
        mViewPager = findViewById(R.id.view_pager_keyboard_select_icon);
        TabLayout tabLayout = findViewById(R.id.tab_dots);
        tabLayout.setupWithViewPager(mViewPager, true);
        mTvSave = findViewById(R.id.tv_sch_cr_save);
        mLayoutBack = findViewById(R.id.ln_back);
        mTvStartDate = findViewById(R.id.tv_sch_cr_start_date);
        mTvStartTime = findViewById(R.id.tv_sch_cr_start_time);
        mTvEndDate = findViewById(R.id.tv_sch_cr_end_date);
        mTvEndTime = findViewById(R.id.tv_sch_cr_end_time);
        mTvTypeRepeat = findViewById(R.id.tv_sch_cr_type_repeat);
        mTvDeleteSchedule = findViewById(R.id.tv_delete_schedule);
        mScrollView = findViewById(R.id.scroll_view_schedule_create);
        mEdtScheduleTitle = findViewById(R.id.edt_sch_cr_title);
        mEdtScheduleNote = findViewById(R.id.edt_sch_cr_comment);
        mEdtScheduleLocation = findViewById(R.id.edt_sch_cr_place);
        mSwitchRepeat = findViewById(R.id.switch_repeat);
        mViewSpaceIcon = findViewById(R.id.view_space_icon);
        mRlStartDateTime = findViewById(R.id.rlt_sch_cr_date_time_start);
        mRlEndDateTime = findViewById(R.id.rlt_sch_cr_date_time_end);
        mTvDictionaryOne = findViewById(R.id.tv_dictionary_one);
        mTvDictionaryTwo = findViewById(R.id.tv_dictionary_two);
        mTvDictionaryThree = findViewById(R.id.tv_dictionary_three);

        RelativeLayout mRlSelectDictionaryOne = findViewById(R.id.rl_select_dictionary_one);
        RelativeLayout mRlSelectDictionaryTwo = findViewById(R.id.rl_select_dictionary_two);
        RelativeLayout mRlSelectDictionaryThree = findViewById(R.id.rl_select_dictionary_three);
        mRlSelectDictionaryOne.setOnClickListener(this);
        mRlSelectDictionaryTwo.setOnClickListener(this);
        mRlSelectDictionaryThree.setOnClickListener(this);
        mLayoutBack.setOnClickListener(this);
        mTvSave.setOnClickListener(this);
        mImvEditIcon.setOnClickListener(this);
        mImgSchedule.setOnClickListener(this);
        mRelativeRepeat.setOnClickListener(this);
        mTvDeleteSchedule.setOnClickListener(this);
        mViewSpaceIcon.setOnClickListener(this);
        mRlStartDateTime.setOnClickListener(this);
        mRlEndDateTime.setOnClickListener(this);

        //hide keyboard when click out view
        mScrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                clearFocus();
                mLayoutKeyboard.setVisibility(View.GONE);
                return false;
            }
        });

        mEdtScheduleTitle.addTextChangedListener(new EditTextLinesLimiter(mEdtScheduleTitle, 3));
        mEdtScheduleNote.addTextChangedListener(new EditTextLinesLimiter(mEdtScheduleNote, 2));
        mEdtScheduleLocation.addTextChangedListener(new EditTextLinesLimiter(mEdtScheduleLocation, 2));
        initViewPager();
        fillData();
    }

    /**
     * get data schedule
     */
    private ScheduleInfo getDataSchedule() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_DATA_SCHEDULE_INFO)) {
            return (ScheduleInfo) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_DATA_SCHEDULE_INFO);
        } else {
            return null;
        }
    }

    /**
     * event click edit schedule
     */
    private void editIconSchedule() {
        clearFocus();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mLayoutKeyboard.setVisibility(View.VISIBLE);
            }
        }, Constants.Schedule.TIME_DELAY_HIDE_KEY_BOARD);
    }


    /**
     * fill data to date time
     */
    private void fillData() {
        if (mScheduleInfo != null) {
            mIconName = mScheduleInfo.getIconName();
            mImgSchedule.setImageResource(ResourcesUtils.getScheduleIconResourceFromId(mScheduleInfo.getIconName()));
            mEdtScheduleTitle.setText(mScheduleInfo.getTitle());
            mEdtScheduleNote.setText(mScheduleInfo.getNote());
            mEdtScheduleLocation.setText(mScheduleInfo.getLocation());
            mCalendar.setTime(mScheduleInfo.getScheduleStartDate());
            mStartDate = mCalendar.getTime();
            mTvStartDate.setText(DateUtils.convertDateToString(mCalendar.getTime(), DateUtils.DATE_PICKER_FORMAT));
            mTvStartTime.setText(DateUtils.convertDateToString(mCalendar.getTime(), DateUtils.TIME_PICKER_FORMAT));
            mCalendar.setTime(mScheduleInfo.getScheduleEndDate());
            mEndDate = mCalendar.getTime();
            mTvEndDate.setText(DateUtils.convertDateToString(mCalendar.getTime(), DateUtils.DATE_PICKER_FORMAT));
            mTvEndTime.setText(DateUtils.convertDateToString(mCalendar.getTime(), DateUtils.TIME_PICKER_FORMAT));
            mSwitchRepeat.setChecked(mScheduleInfo.isAllDay());
            mIntervalType = mScheduleInfo.getInterval() == null ? ScheduleInfo.IntervalType.None : mScheduleInfo.getInterval();
            setTypeRepeat(mIntervalType);
            if (mScheduleInfo.getAttachedDictionaries().size() >= 1) {
                mDictionaryInfoOne = mScheduleInfo.getAttachedDictionaries().get(0);
            }
            if (mScheduleInfo.getAttachedDictionaries().size() >= 1) {
                mDictionaryInfoTwo = mScheduleInfo.getAttachedDictionaries().get(1);
            }
            if (mScheduleInfo.getAttachedDictionaries().size() >= 1) {
                mDictionaryInfoThree = mScheduleInfo.getAttachedDictionaries().get(2);
            }
            setTextDictionary(mTvDictionaryOne, mDictionaryInfoOne);
            setTextDictionary(mTvDictionaryTwo, mDictionaryInfoTwo);
            setTextDictionary(mTvDictionaryThree, mDictionaryInfoThree);
        }
    }

    /**
     * hide keyboard
     *
     * @param view view focus
     */
    private void hideKeyboard(View view) {
        InputMethodManager in = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        if (view == null) {
            view = new View(SchEditUiActivity.this);
        }
        in.hideSoftInputFromWindow(view.getWindowToken(), Constants.Schedule.FLAG_HIDE_INPUT_FORM);
    }

    /**
     * init viewpager select icon schedule
     */
    private void initViewPager() {
        mAdapterPagerSelectIcon = new AdapterPagerSelectIcon(getSupportFragmentManager(), this);
        if (mScheduleInfo != null) {
            mAdapterPagerSelectIcon.setIconSelected(mScheduleInfo.getIconName());
        }
        mViewPager.setAdapter(mAdapterPagerSelectIcon);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_sch_cr_save:
                editScheduleInfo();
                break;
            case R.id.img_schedule:
            case R.id.imv_sch_cr_ic_edit:
                editIconSchedule();
                break;
            case R.id.rlt_sch_cr_repeat:
                goToSchRepeatActivity();
                break;
            case R.id.ln_back:
                onBackPressed();
                break;
            case R.id.rl_select_dictionary_one:
                mSelectDictionary = mSelectDictionaryInfoOne;
                selectDictionary(mDictionaryInfoOne);
                break;
            case R.id.rl_select_dictionary_two:
                mSelectDictionary = mSelectDictionaryInfoTwo;
                selectDictionary(mDictionaryInfoTwo);
                break;
            case R.id.rl_select_dictionary_three:
                mSelectDictionary = mSelectDictionaryInfoThree;
                selectDictionary(mDictionaryInfoThree);
                break;
            case R.id.tv_delete_schedule:
                buildDeleteScheduleDialog();
                break;
            case R.id.view_space_icon:
                mLayoutKeyboard.setVisibility(View.GONE);
                break;
            case R.id.rlt_sch_cr_date_time_end:
                buildDialogDateTime(false);
                break;
            case R.id.rlt_sch_cr_date_time_start:
                buildDialogDateTime(true);
                break;
            default:
                break;
        }
    }

    /**
     * edit schedule
     */
    private void editScheduleInfo() {
        clearFocus();
        mLayoutKeyboard.setVisibility(View.GONE);
        String title = mEdtScheduleTitle.getText().toString();
        String note = mEdtScheduleNote.getText().toString();
        String location = mEdtScheduleLocation.getText().toString();
        String error = "";

        if (TextUtils.isEmpty(title)) {
            error = getResources().getString(R.string.sch_validate_title);
        }
        if (mIntervalType == ScheduleInfo.IntervalType.Yearly &&
                (DateUtils.checkSpecialDate(mStartDate) || DateUtils.checkSpecialDate(mEndDate))) {
            error = TextUtils.isEmpty(error) ? getResources().getString(R.string.sch_validate_leapyear)
                    : error + "\n" + getResources().getString(R.string.sch_validate_leapyear);
        }
        if (validateDate()) {
            error = TextUtils.isEmpty(error) ? getResources().getString(R.string.sch_validate_date_reverse)
                    : error + "\n" + getResources().getString(R.string.sch_validate_date_reverse);
        }
        if (!TextUtils.isEmpty(error)) {
            buildDialogError(error);
            return;
        }
        mScheduleInfo.setTitle(title);
        mScheduleInfo.setNote(note);
        mScheduleInfo.setLocation(location);
        mScheduleInfo.setScheduleStartDate(mStartDate);
        mScheduleInfo.setScheduleEndDate(mEndDate);
        mScheduleInfo.setInterval(mIntervalType);
        List<DictionaryInfo> listDictionary = new ArrayList<>();
        if (mDictionaryInfoOne != null) {
            listDictionary.add(mDictionaryInfoOne);
        }
        if (mDictionaryInfoTwo != null) {
            listDictionary.add(mDictionaryInfoTwo);
        }
        if (mDictionaryInfoThree != null) {
            listDictionary.add(mDictionaryInfoThree);
        }
        if (listDictionary.size() > 0) {
            mScheduleInfo.setAttachedDictionaries(listDictionary);
        }
        mScheduleInfo.setIsAllDay(mSwitchRepeat.isChecked());
        if (!TextUtils.isEmpty(mIconName)) {
            mScheduleInfo.setIconName(mIconName);
        }
        mRequestApi = Constants.Schedule.REQUEST_EDIT;
        AppController.getInstance().getAssistServerInterface().editSchedule(mScheduleInfo, this);
    }

    /**
     * validate date start and end when schedule is all day or not
     *
     * @return true: startDate,endDate < current time or endDate<startDate
     */
    private boolean validateDate() {
        Date startDate = mStartDate;
        Date endDate = mEndDate;
        // if schedule is all day compare time with format yyyy/MM/dd
        if (mSwitchRepeat.isChecked()) {
            mCalendar.setTime(startDate);
            mCalendar.set(Calendar.HOUR_OF_DAY, 0);
            mCalendar.set(Calendar.MINUTE, 0);
            startDate = mCalendar.getTime();
            mCalendar.setTime(endDate);
            mCalendar.set(Calendar.HOUR_OF_DAY, 0);
            mCalendar.set(Calendar.MINUTE, 0);
            endDate = mCalendar.getTime();
        }
        if (DateUtils.compareTo(endDate, startDate) < 0) {
            return true;
        }
        return false;
    }

    /**
     * build dialog date time picker
     *
     * @param isStartDateTime true: dialog for start time, false: dialog for end time
     */
    private void buildDialogDateTime(boolean isStartDateTime) {
        mIsStartDateTime = isStartDateTime;
        DateTimePickerDialogFactory dialogFactory = new DateTimePickerDialogFactory(DialogTypeControl.DialogType.SCH_DETAIL_DIALOG, this);
        dialogFactory.isCreateNew(false);
        dialogFactory.setMinDate(mScheduleInfo.getScheduleStartDate());
        dialogFactory.isScheduleAllDay(mSwitchRepeat.isChecked());
        if (isStartDateTime) {
            dialogFactory.setDate(mStartDate);

        } else {
            dialogFactory.setDate(mEndDate);
        }
        mDialogDateTime = new DialogGenerator(this, dialogFactory).show();
    }

    /**
     * Intent go to screen select type repeat
     */
    private void goToSchRepeatActivity() {
        clearFocus();
        Bundle mBundle = new Bundle();
        mBundle.putSerializable(Constants.Schedule.KEY_INTERVAL_TYPE, mIntervalType);
        mBundle.putString(Constants.Schedule.KEY_BACK_REPEAT_TITLE, getString(R.string.sch_ed));
        changeScreenResult(ScreenId.START_SCH_REPEAT, Constants.Schedule.REQUEST_CODE_REPEAT, mBundle);
    }

    /**
     * set text type repeat schedule
     *
     * @param intervalType is value of type in ScheduleInfo.IntervalType
     */
    private void setTypeRepeat(ScheduleInfo.IntervalType intervalType) {
        switch (intervalType) {
            case None:
                mTvTypeRepeat.setText(getString(R.string.nothing));
                break;
            case Daily:
                mTvTypeRepeat.setText(R.string.sch_every_day);
                break;
            case Weekly:
                mTvTypeRepeat.setText(getString(R.string.sch_every_week));
                break;
            case Monthly:
                mTvTypeRepeat.setText(getString(R.string.sch_every_month));
                break;
            case Yearly:
                mTvTypeRepeat.setText(getString(R.string.sch_every_year));
                break;
            default:
                break;
        }

    }

    /**
     * build delete schedule dialog
     */
    private void buildDeleteScheduleDialog() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.SCH_DELETE_DIALOG);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * build delete schedule end dialog
     */
    private void buildDeleteEndDialog() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.SCH_DELETE_END);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.Schedule.REQUEST_CODE_REPEAT && resultCode == Constants.Schedule.REQUEST_CODE_REPEAT) {
            ScheduleInfo.IntervalType intervalType = (ScheduleInfo.IntervalType) data.getSerializableExtra(Constants.Schedule.KEY_GO_BACK_REPEAT);
            mIntervalType = intervalType;
            setTypeRepeat(mIntervalType);
        } else if (requestCode == Constants.Schedule.REQUEST_CODE_DICTIONARY && resultCode == Constants.Schedule.REQUEST_CODE_DICTIONARY) {
            DictionaryInfo dictionaryInfo = (DictionaryInfo) data.getSerializableExtra(Constants.Schedule.KEY_DICTIONARY_INFO);
            setDictionary(dictionaryInfo);
        }
    }

    /**
     * delete schedule
     */
    private void deleteSchedule() {
        mRequestApi = Constants.Schedule.REQUEST_DELETE;
        AppController.getInstance().getAssistServerInterface().deleteSchedule(mScheduleInfo, this);
    }

    /**
     * show dialog confirm save
     *
     * @param scheduleInfo schedule info
     */
    private void buildSchSaveDialog(ScheduleInfo scheduleInfo) {
        if (scheduleInfo != null) {
            SchSaveDialogFactory dialogFactory = new SchSaveDialogFactory(scheduleInfo, DialogTypeControl.DialogType.SCH_SAVE_DIALOG, this);
            dialogFactory.setTitleDialog(getString(R.string.sch_ed_end));
            mDialogSchSave = new DialogGenerator(this, dialogFactory).show();
        }
    }

    @Override
    public void onClickOkSchSave() {
        if (mDialogSchSave != null) {
            mDialogSchSave.dismiss();
            Bundle bundle = new Bundle();
            bundle.putSerializable(Constants.Schedule.KEY_DATA_SCHEDULE_INFO, mScheduleInfo);
            bundle.putSerializable(Constants.Schedule.KEY_TYPE_BACK_RESULT, Constants.Schedule.REQUEST_EDIT);
            backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_SCHEDULE_INFO);
        }
    }

    @Override
    public void selectIcon(String iconName) {
        mImgSchedule.setImageResource(ResourcesUtils.getScheduleIconResourceFromId(iconName));
        mIconName = iconName;
        mLayoutKeyboard.setVisibility(View.GONE);
        int currentPosition = mViewPager.getCurrentItem();
        mAdapterPagerSelectIcon.setIconSelected(iconName);
        mViewPager.setAdapter(null);
        mViewPager.setAdapter(mAdapterPagerSelectIcon);
        mViewPager.setCurrentItem(currentPosition);
    }

    @Override
    public void dismissDialogDateTime() {
        mDialogDateTime.dismiss();
    }

    @Override
    public void saveDateTime(Date date) {
        mDialogDateTime.dismiss();
        if (mIsStartDateTime) {
            mStartDate = date;
            mTvStartDate.setText(DateUtils.convertDateToString(date, DateUtils.DATE_PICKER_FORMAT));
            mTvStartTime.setText(DateUtils.convertDateToString(date, DateUtils.TIME_PICKER_FORMAT));
        } else {
            mEndDate = date;
            mTvEndDate.setText(DateUtils.convertDateToString(date, DateUtils.DATE_PICKER_FORMAT));
            mTvEndTime.setText(DateUtils.convertDateToString(date, DateUtils.TIME_PICKER_FORMAT));
        }
    }

    /**
     * build dialog confirm
     *
     * @param type
     */
    private void buildDialogConfirm(DialogTypeControl.DialogType type) {
        mDialogFactory = new AssistAlertDialogFactory(type);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * dialog create error
     *
     * @return boolean
     */
    private void buildDialogError(String errorMessage) {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIALOG_MESSAGE, errorMessage);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    @Override
    public void onResult(AssistServerResult result) {
        if (result.mResult == AssistServerResult.Result.Success) {
            if (mRequestApi.equals(Constants.Schedule.REQUEST_EDIT)) {
                buildSchSaveDialog(mScheduleInfo);
            } else if (mRequestApi.equals(Constants.Schedule.REQUEST_DELETE)) {
                buildDeleteEndDialog();
            }
        } else {

        }
    }

    @Override
    public void onStartConnection() {
        displayIndicator();
    }

    /**
     * event click button positive or negative in dialog
     *
     * @param dialog dialog interface
     * @param which  position button click
     */
    @Override
    public void onClick(DialogInterface dialog, int which) {
        if (which == DialogInterface.BUTTON_POSITIVE) {
            if (mDialogTag.equals(DialogTypeControl.DialogType.SCH_ED_QUIT.name())) {
                // back when quit edit
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.Schedule.KEY_DATA_SCHEDULE_INFO, mScheduleInfo);
                bundle.putSerializable(Constants.Schedule.KEY_TYPE_BACK_RESULT, Constants.Schedule.BACK_EDIT);
                backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_SCHEDULE_INFO);
            } else if (mDialogTag.equals(DialogTypeControl.DialogType.SCH_DELETE_DIALOG.name())) {
                // click ok in dialog confirm delete schedule
                deleteSchedule();
            } else if (mDialogTag.equals(DialogTypeControl.DialogType.SCH_DELETE_END.name())) {
                // click ok in dialog confirm delete end
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.Schedule.KEY_DATA_SCHEDULE_INFO, mScheduleInfo);
                bundle.putSerializable(Constants.Schedule.KEY_TYPE_BACK_RESULT, Constants.Schedule.REQUEST_DELETE);
                backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_SCHEDULE_INFO);
            }
        }
    }

    /**
     * select dictionary
     *
     * @param dictionaryInfo
     */
    private void selectDictionary(DictionaryInfo dictionaryInfo) {
        clearFocus();
        Bundle bundle = new Bundle();
        bundle.putString(Constants.Schedule.KEY_GO_TO_FROM, getString(R.string.sch_ed));
        if (dictionaryInfo == null) {
            changeScreenResult(ScreenId.START_SCH_DICTIONARY_SELECT, Constants.Schedule.REQUEST_CODE_DICTIONARY, bundle);
        } else {
            bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, dictionaryInfo);
            changeScreenResult(ScreenId.START_SCH_DICTIONARY_EDIT, Constants.Schedule.REQUEST_CODE_DICTIONARY, bundle);
        }
    }

    /**
     * set dictionary info
     *
     * @param dictionaryInfo
     */
    private void setDictionary(DictionaryInfo dictionaryInfo) {
        switch (mSelectDictionary) {
            case mSelectDictionaryInfoOne:
                mDictionaryInfoOne = dictionaryInfo;
                setTextDictionary(mTvDictionaryOne, dictionaryInfo);
                break;
            case mSelectDictionaryInfoTwo:
                mDictionaryInfoTwo = dictionaryInfo;
                setTextDictionary(mTvDictionaryTwo, dictionaryInfo);
                break;
            case mSelectDictionaryInfoThree:
                mDictionaryInfoThree = dictionaryInfo;
                setTextDictionary(mTvDictionaryThree, dictionaryInfo);
                break;
            default:
                break;
        }
    }

    @Override
    public void onBackPressed() {
        clearFocus();
        buildDialogConfirm(DialogTypeControl.DialogType.SCH_ED_QUIT);
    }

    /**
     * clear focus in EditText
     */
    private void clearFocus() {
        if (mEdtScheduleTitle.isFocusable()) {
            mEdtScheduleTitle.clearFocus();
            hideKeyboard(mEdtScheduleTitle);
        } else if (mEdtScheduleLocation.isFocusable()) {
            mEdtScheduleLocation.clearFocus();
            hideKeyboard(mEdtScheduleLocation);
        } else if (mEdtScheduleNote.isFocusable()) {
            mEdtScheduleNote.clearFocus();
            hideKeyboard(mEdtScheduleNote);
        }
    }

    /**
     * set text to dictionary with max length =12
     *
     * @param text
     * @param dictionaryInfo
     */
    private void setTextDictionary(TextView text, DictionaryInfo dictionaryInfo) {
        text.setText(dictionaryInfo == null ? getString(R.string.nothing) :
                dictionaryInfo.getName().length() <= 12 ? dictionaryInfo.getName() : dictionaryInfo.getName().substring(0, 11) + "...");
    }
}
