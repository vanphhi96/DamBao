/*
 * ファイル：DicEditUiActivity.java
 * 概要：辞書を編集画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.dictionary;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.model.database.EditDictionaryInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.adapter.DicCreateAdapter;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * dic-ed-01
 *
 * @author Systena
 * @version 1.0
 */
public class DicEditUiActivity extends BaseDicEditUiActivity implements IOnClickItemDicCreate,
        IOnClickDeleteDic, View.OnClickListener, DialogInterface.OnClickListener, NotifyOnlyResultListener {
    private RecyclerView mRecyclerView;
    private DicCreateAdapter mDicEditAdapter;
    private TextView mTvSave;
    private BaseDialogFactory mDialogFactory;
    private RelativeLayout mLayoutBack;
    private boolean mChooseThumbnailCard = false;
    private int mPositionCardUpdate;
    private CategoryInfo mCategoryInfo;
    private boolean mOnClickSaveEdit = true;
    private EditDictionaryInfo mEditDictionaryInfo;
    private int mPositionCardDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_dic_edit);
        mLayoutBack = findViewById(R.id.rlt_dic_edit_back);
        mLayoutBack.setOnClickListener(this);
        mTvSave = findViewById(R.id.tv_save_dic_edit_action_bar);
        mTvSave.setOnClickListener(this);
        mRecyclerView = findViewById(R.id.recycle_view_dic_create);
        mEditDictionaryInfo = new EditDictionaryInfo(getIntentDicInfo());

        mTvSave.setOnClickListener(this);
        mRecyclerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                hideKeyboard(view);
                return false;
            }
        });
        mCategoryInfoList = getIntentListCategory();
        if (mEditDictionaryInfo != null) {
            mCategoryInfo = getCategoryById(mEditDictionaryInfo.getCategoryId());
            initListCard();
        }
    }

    /**
     * init list card
     */
    private void initListCard() {
        mDicEditAdapter = new DicCreateAdapter();
        mDicEditAdapter.setActivity(this);
        mDicEditAdapter.setInterface(this);
        mDicEditAdapter.setIOnClickDeleteDic(this);
        mDicEditAdapter.setDictionaryInfo(mEditDictionaryInfo);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayout.VERTICAL);
        mDicEditAdapter.setShowButtonDelete(true);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setAdapter(mDicEditAdapter);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.rlt_dic_edit_back:
                onBackPressed();
                break;
            case R.id.tv_save_dic_edit_action_bar:
                mOnClickSaveEdit = true;
                setOnClickSave();
                break;
            default:
                break;
        }
    }

    @Override
    public void onBackPressed() {
        hideKeyboard(getCurrentFocus());
        mEditDictionaryInfo.cancel();
        super.onBackPressed();

    }

    /**
     * set thumbnail card dictionary
     *
     * @param imageBitmap is image bitmap
     */
    private void setImage(Bitmap imageBitmap) {
        if (imageBitmap != null) {
            if (mChooseThumbnailCard) {
                mEditDictionaryInfo.getCardList().get(mPositionCardUpdate).clearImage();
                if (mEditDictionaryInfo.getCardList().get(mPositionCardUpdate).setImage(imageBitmap)) {
                    mDicEditAdapter.notifyItemChanged(mPositionCardUpdate + 1);
                }
            } else {
                mEditDictionaryInfo.clearImage();
                if (mEditDictionaryInfo.setImage(imageBitmap)) {
                    mDicEditAdapter.notifyItemChanged(0);
                }

            }
        }
    }


    @Override
    public void onClick(DialogInterface dialog, int which) {
        super.onClick(dialog, which);
        if (which == DialogInterface.BUTTON_POSITIVE) {
            if (DialogTypeControl.DialogType.DIC_DELETE_DIALOG.name().equals(mDialogTag)) {
                mOnClickSaveEdit = false;
                AppController.getInstance().getAssistServerInterface().deleteDictionary(mEditDictionaryInfo.getDictionaryId(), this);
            } else if (DialogTypeControl.DialogType.DIC_EDIT_DEL_ITEM.name().equals(mDialogTag)) {
                if (mEditDictionaryInfo.getCardList().size() > mPositionCardDelete) {
                    mEditDictionaryInfo.removeCard(mPositionCardDelete);
                    buildDicDelItemDialogEnd();
                }
            } else if (DialogTypeControl.DialogType.DIC_EDIT_DEL_ITEM_END.name().equals(mDialogTag)) {
                mDicEditAdapter.notifyDataSetChanged();
            } else if (DialogTypeControl.DialogType.DIC_EDIT_END.name().equals(mDialogTag)) {
                goBackScreen();
            } else if (DialogTypeControl.DialogType.DIC_DEL_END.name().equals(mDialogTag)) {
                goBackScreen();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constants.Dictionary.REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bitmap imageBitmap = null;
            if (!TextUtils.isEmpty(mTemporaryPhotoPath)) {
                // get full data and rotate image
                imageBitmap = ResourcesUtils.rotateImage(mTemporaryPhotoPath);
                // delete temporary file
                File file = new File(mTemporaryPhotoPath);
                file.delete();
            }
            // get thumbnail
            if (imageBitmap == null) {
                Bundle extras = data.getExtras();
                imageBitmap = (Bitmap) extras.get(Constants.Dictionary.KEY_GET_PICTURE);
            }
            setImage(imageBitmap);
        } else if (requestCode == Constants.Dictionary.REQUEST_CODE_GALLERY && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            try {
                Bitmap imageBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);

                // Set (save) the dictionary or card image here.
                setImage(imageBitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }

        } else if (requestCode == Constants.Dictionary.REQUEST_CODE_CATEGORY
                && resultCode == Constants.Dictionary.REQUEST_CODE_CATEGORY) {
            mCategoryInfo = getCategoryById(Long.valueOf(data.getStringExtra(Constants.Dictionary.KEY_GO_BACK_CATEGORY)));
            if (mCategoryInfo != null) {
                mEditDictionaryInfo.setCategoryId(mCategoryInfo.getCategoryId());
                mDicEditAdapter.notifyDataSetChanged();
            }
        }
    }

    /**
     * event click button delete in Item Dic Create
     *
     * @param position is position item
     */
    @Override
    public void onClickButtonDelete(int position) {
        mPositionCardDelete = position;
        buildDicDelItemDialogConfirm();
    }

    /**
     * event click button create in Item Dic Create
     *
     * @param position is position item onclick
     */
    @Override
    public void onClickButtonCreate(int position) {
        hideKeyboard(getCurrentFocus());
        if (mEditDictionaryInfo.getCardList().size() == Constants.Dictionary.MAX_CARD_DICTIONARY) {
            buildDialogDicCardMax();
        } else {
            mEditDictionaryInfo.addCard(position);
            mDicEditAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClickChooseThumbnail() {
        mChooseThumbnailCard = false;
        buildSingleChoiceDialog();
    }

    @Override
    public void onClickChooseCategory() {
        goToDicCategoryActivity(mEditDictionaryInfo.getCategoryId(), getString(R.string.dic_ed_dic));
    }

    @Override
    public void onClickHeader() {
        hideKeyboard(getCurrentFocus());
    }

    @Override
    public void updateAvatar(int position) {
        mPositionCardUpdate = position;
        mChooseThumbnailCard = true;
        buildSingleChoiceDialog();
    }

    @Override
    public void onClickDelete() {
        buildDicDeleteDialog();
    }

    /**
     * get category by id
     *
     * @param idCategory
     * @return CategoryInfo
     */
    private CategoryInfo getCategoryById(long idCategory) {
        CategoryInfo categoryDefault = null;
        for (CategoryInfo categoryInfo : mCategoryInfoList) {
            if (idCategory == categoryInfo.getCategoryId()) {
                return categoryInfo;
            }
        }
        return categoryDefault;
    }

    /**
     * dialog dic-del-01
     */
    private void buildDicDeleteDialog() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_DELETE_DIALOG);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();

    }

    /**
     * dialog dic-del-02
     */
    private void buildDicDeleteEndDialog() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_DEL_END);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();

    }

    /**
     * show dialog dic-ed-02
     */
    private void buildDicEditEndDialog() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_EDIT_END);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }


    /**
     * check card info is empty
     *
     * @return boolean
     */
    private boolean checkCardEmpty() {
        for (CardInfo cardInfo : mEditDictionaryInfo.getCardList()) {
            if (TextUtils.isEmpty(cardInfo.getText().trim())
                    && TextUtils.isEmpty(cardInfo.getImageFileAbsolutePath())) {
                return true;
            }
        }
        return false;
    }

    /**
     * set onclick save
     */
    private void setOnClickSave() {
        hideKeyboard(getCurrentFocus());
        if ((TextUtils.isEmpty(mEditDictionaryInfo.getName()) ||
                TextUtils.isEmpty(mEditDictionaryInfo.getName().trim())) && checkCardEmpty()) {
            buildDialogDicValidateNoTitleEmptyCard();
        } else if (TextUtils.isEmpty(mEditDictionaryInfo.getName().trim())) {
            buildDialogDicValidateNoTitle();
        } else if (checkCardEmpty()) {
            buildDialogDicValidateEmptyCard();
        } else if (mEditDictionaryInfo.getCardList().size() == 0) {
            buildDialogDicNoCard();
        } else {
            AppController.getInstance().getAssistServerInterface().editDictionary(mEditDictionaryInfo, this);
        }
    }

    @Override
    public void onResult(AssistServerResult result) {
        closeIndicator();
        if (result.mResult == AssistServerResult.Result.Success) {
            if (mOnClickSaveEdit) {
                buildDicEditEndDialog();
            } else {
                buildDicDeleteEndDialog();
            }

        } else {
            buildDialogError(result.mMessage);
        }
    }

    @Override
    public void onStartConnection() {
        displayIndicator();
    }

    /**
     * get intent list category
     *
     * @return List<CategoryInfo>
     */
    private List<CategoryInfo> getIntentListCategory() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_LIST_CATEGORY)) {
            return (List<CategoryInfo>) getIntent().getExtras().getSerializable(Constants.Dictionary.KEY_LIST_CATEGORY);
        }
        return new ArrayList<>();
    }

    /**
     * get DictionaryInfo
     *
     * @return
     */
    private DictionaryInfo getIntentDicInfo() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_DICTIONARY_INFO)) {
            return (DictionaryInfo) getIntent().getExtras().getSerializable(Constants.Dictionary.KEY_DICTIONARY_INFO);
        } else {
            return null;
        }
    }

    /**
     * go back dic-03
     */
    private void goBackScreen() {
        Bundle bundle = new Bundle();
        backScreenResult(this, bundle, Constants.Dictionary.REQUEST_CODE_DIC_EDIT);
    }

    /**
     * dialog create error
     *
     * @return boolean
     */
    private void buildDialogError(String errorMessage) {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIALOG_MESSAGE, errorMessage);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }
}
