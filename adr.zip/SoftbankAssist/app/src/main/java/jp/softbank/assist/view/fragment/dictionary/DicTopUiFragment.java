/*
 * ファイル：DicTopUiFragment.java
 * 概要：辞書トップ画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment.dictionary;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.main.MenuUiActivity;
import jp.softbank.assist.view.adapter.AdapterDicTop;
import jp.softbank.assist.view.fragment.BaseFragment;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * dic-01
 *
 * @author Systena
 * @version 1.0
 */
public class DicTopUiFragment extends BaseFragment implements View.OnClickListener, IDicTopFragment {
    private RecyclerView mRecyclerView;
    private ImageView mImvAddDic;
    private ImageView mImvHelp;
    private MenuUiActivity mCurrentActivity;
    private AdapterDicTop mAdapterDicTop;
    private List<CategoryInfo> mCategoryInfoList = new ArrayList<>();

    /**
     * インスタンスを初期化.
     *
     * @return DicTopUiFragment
     */
    public static DicTopUiFragment newInstance() {
        Bundle args = new Bundle();
        DicTopUiFragment fragment = new DicTopUiFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCurrentActivity = (MenuUiActivity) getActivity();
        mCurrentActivity.setCurrentFraggment(this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dic_top, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRecyclerView = view.findViewById(R.id.recycle_dic_category);
        mImvAddDic = view.findViewById(R.id.imv_dic_add);
        mImvHelp = view.findViewById(R.id.imv_dic_help);
        mImvAddDic.setOnClickListener(this);
        mImvHelp.setOnClickListener(this);
        mCategoryInfoList = AppController.getInstance().getAssistServerInterface().getCategoryList();
        initRecycleCategory();
    }

    /**
     * init recycle view
     */
    private void initRecycleCategory() {
        mAdapterDicTop = new AdapterDicTop();
        mAdapterDicTop.setCategoryInfoList(mCategoryInfoList);
        mAdapterDicTop.setIDicTopFragment(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mAdapterDicTop);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imv_dic_add:
                goToScreenDicCreate();
                break;
            case R.id.imv_dic_help:
                break;
            default:
                break;
        }
    }

    @Override
    public void onClickCategory(CategoryInfo categoryInfo) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Constants.Dictionary.KEY_TYPE_CATEGORY, categoryInfo);
        bundle.putSerializable(Constants.Dictionary.KEY_LIST_CATEGORY, (Serializable) mCategoryInfoList);
        mCurrentActivity.changeScreen(ScreenId.START_DIC_LIST, bundle);
    }

    /**
     * go to dic-cr-01
     */
    private void goToScreenDicCreate() {
        Bundle bundle = new Bundle();
        bundle.putString(Constants.Dictionary.KEY_TYPE_CATEGORY, String.valueOf(Constants.Ids.ID_NONE));
        bundle.putSerializable(Constants.Dictionary.KEY_LIST_CATEGORY, (Serializable) mCategoryInfoList);
        mCurrentActivity.changeScreen(ScreenId.START_DIC_CREATE, bundle);
    }


    @Override
    public void onResume() {
        super.onResume();
        mCategoryInfoList = AppController.getInstance().getAssistServerInterface().getCategoryList();
        mAdapterDicTop.notifyDataSetChanged();
    }
}
