/*
 * ファイル：WalUserAccountEditEndUiActivity.java
 * 概要：アカウント情報入力完了画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.walkthrough;

import jp.softbank.assist.view.activity.BaseUiActivity;

/**
 * wal-09
 *
 * @author Systena
 * @version 1.0
 */
public class WalUserAccountEditEndUiActivity extends BaseUiActivity {
}
