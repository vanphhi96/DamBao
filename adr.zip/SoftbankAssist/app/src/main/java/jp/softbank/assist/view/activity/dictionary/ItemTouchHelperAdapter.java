/*
 * ファイル：ItemTouchHelperAdapter.java
 * 概要：
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.dictionary;

/**
 * Interface callback drag item recyclerview
 * @author Systena
 * @version 1.0
 */
public interface ItemTouchHelperAdapter {
    /**
     * Called when an item has been dragged far enough to trigger a move. This is called every time
     * @param fromPosition  The start position of the moved item.
     * @param toPosition Then end position of the moved item.
     */
    void onItemMove(int fromPosition, int toPosition);

}
