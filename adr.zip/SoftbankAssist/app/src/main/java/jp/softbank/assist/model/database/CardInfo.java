/*
 * ファイル：CardInfo.java
 * 概要：辞書カード情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import android.graphics.Bitmap;
import android.text.TextUtils;

import jp.softbank.assist.model.ModelInterface;
import jp.softbank.assist.util.Constants;

import java.io.File;
import java.io.Serializable;
import java.util.Date;

/**
 * 辞書カード情報.
 *
 * @author Systena
 * @version 1.0
 */
public class CardInfo implements Serializable {

    private long mCardId; // カードID
    private long mDictionaryId; // 辞書ID
    private long mNextCardId; // 次のカードID
    private String mImageUrl; // 画像URL
    private String mImageFileName; // 画像ファイル名
    private String mText; // テキスト
    private long mVersion; // バージョン
    private Date mCreatedDate; // 作成日時
    private Date mUpdatedDate; // 更新日時
    private boolean mIsDeleted; // 削除済みフラグ
    private boolean mIsChecked; // is checked in checkbox
    private boolean mIsCalledGetImageMethod = false;//status call method getImage, use check and call getDictionaryImage one times
    private boolean mIsDownloaded = false;// status downloaded image card

    public long getCardId() {
        return mCardId;
    }

    public void setCardId(long cardId) {
        this.mCardId = cardId;
    }

    public long getDictionaryId() {
        return mDictionaryId;
    }

    public void setDictionaryId(long dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }

    public long getNextCardId() {
        return mNextCardId;
    }

    public void setNextCardId(long nextCardId) {
        this.mNextCardId = nextCardId;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.mImageUrl = imageUrl;
    }

    public String getImageFileName() {
        return mImageFileName;
    }

    public void setImageFileName(String imageFileName) {
        this.mImageFileName = imageFileName;
    }

    public String getText() {
        return mText;
    }

    public void setText(String text) {
        this.mText = text;
    }

    public long getVersion() {
        return mVersion;
    }

    public void setVersion(long version) {
        this.mVersion = version;
    }

    public Date getCreatedDate() {
        return mCreatedDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.mCreatedDate = createdDate;
    }

    public Date getUpdatedDate() {
        return mUpdatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.mUpdatedDate = updatedDate;
    }

    public boolean isDeleted() {
        return mIsDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        mIsDeleted = deleted;
    }

    /**
     * set status downloaded image
     *
     * @param isDownloaded
     */
    public void setIsDownloaded(boolean isDownloaded) {
        this.mIsDownloaded = isDownloaded;
    }

    /**
     * status downloaded image
     *
     * @return boolean
     */
    public boolean isDownloaded() {
        return mIsDownloaded;
    }


    /**
     * set status downloaded
     *
     * @param isCalledGetImageMethod
     */
    public void setIsCalledGetImageMethod(boolean isCalledGetImageMethod) {
        this.mIsCalledGetImageMethod = isCalledGetImageMethod;
    }


    /**
     * status downloaded image
     *
     * @return
     */
    public boolean isCalledGetImageMethod() {
        return mIsCalledGetImageMethod;
    }


    /**
     * 編集済みか確認する.
     *
     * @return true:編集済み、false:未編集
     */
    public boolean isEdited() {
        return false;
    }

    /**
     * 追加・編集時のキャンセル.
     */
    public void cancel() {
        // do nothing
    }

    /**
     * 辞書画像のパス.
     *
     * @param fileName ファイル名
     * @return File
     */
    protected File getImagePath(final String fileName) {
        File file = ModelInterface.getDictionaryDir(getDictionaryId());
        return new File(file, fileName);
    }

    /**
     * 画像未設定か確認する.
     *
     * @return true:未設定、false:設定済み
     */
    public boolean isImageNotSet() {
        return TextUtils.isEmpty(getImageUrl()) && TextUtils.isEmpty(getImageFileName());
    }

    /**
     * 画像取得が必要か確認する.
     *
     * @return true:必要、false:不要
     */
    public boolean isImageNeedDownload() {
        return !TextUtils.isEmpty(getImageUrl()) && TextUtils.isEmpty(getImageFileName());
    }

    /**
     * 画像ファイルが有効（保存済み）か確認する.
     *
     * @return true:有効、false:無効
     */
    public boolean isImageEnabled() {
        return Constants.Dictionary.getCardFileName(getCardId()).equals(getImageFileName());
    }

    /**
     * 画像の保存.
     *
     * @param bitmap ビットマップ
     * @return true:成功、false:失敗
     */
    public boolean setImage(Bitmap bitmap) {
        bitmap = ModelInterface.scaleDictionaryImage(bitmap);
        boolean result = ModelInterface.saveDictionaryImage(bitmap,
                getImagePath(Constants.Dictionary.getCardFileName(getCardId())));
        if (result) {
            setImageFileName(Constants.Dictionary.getCardFileName(getCardId()));
        }
        return result;
    }

    /**
     * 画像設定の削除.
     */
    public void clearImage() {
        // do nothing
    }

    /**
     * 画像ファイルパスの取得.
     *
     * @return ファイルパス
     */
    public String getImageFileAbsolutePath() {
        if (isImageEnabled()) {
            File file = getImagePath(getImageFileName());
            if (file.exists()) {
                return file.getAbsolutePath();
            }
        }
        return null;
    }

    public boolean isChecked() {
        return mIsChecked;
    }

    public void setIsChecked(boolean checked) {
        this.mIsChecked = checked;
    }
}
