/*
 * ファイル：AdapterDicList.java
 * 概要：Adapter list dictionary detail
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.app.Activity;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetImageResultListener;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.activity.dictionary.IOnClickItemDicList;
import jp.softbank.assist.view.activity.dictionary.ItemTouchHelperAdapter;
import jp.softbank.assist.view.activity.dictionary.OnDicListChangedListener;
import jp.softbank.assist.view.activity.dictionary.OnStartDragListener;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.RecyclerBaseAdapter;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Adapter list dictionary detail
 *
 * @author Systena
 * @version 1.0
 */
public class AdapterDicList extends RecyclerBaseAdapter implements ItemTouchHelperAdapter {
    private static final int MARGIN_ITEM = 20;
    private List<DictionaryInfo> mListDictionary = new ArrayList<>();
    private List<CategoryInfo> mListOtherCategory = new ArrayList<>();
    private IOnClickItemDicList mOnClickItemDicList;
    private boolean mSort = false;
    private OnStartDragListener mDragStartListener;
    private OnDicListChangedListener mListChangedListener;
    private int mColorBackgroundItem;
    private int mColorFlagItem;
    private Activity mActivity;

    /**
     * set show footer view
     */ {
        setFooterVisibility(true);
    }

    public AdapterDicList(OnDicListChangedListener onListChangedListener,
                          OnStartDragListener dragStartListener,
                          IOnClickItemDicList iOnClickItemDicList) {
        this.mListChangedListener = onListChangedListener;
        this.mDragStartListener = dragStartListener;
        this.mOnClickItemDicList = iOnClickItemDicList;
    }

    /**
     * set activity, use when runOnUiThread
     *
     * @param activity
     */
    public void setActivity(Activity activity) {
        this.mActivity = activity;
    }

    /**
     * set color background item dictionary.
     *
     * @param colorBackgroundItem
     * @param colorFlagItem
     */
    public void setColorItem(int colorBackgroundItem, int colorFlagItem) {
        this.mColorBackgroundItem = colorBackgroundItem;
        this.mColorFlagItem = colorFlagItem;
    }

    /**
     * add data to list model
     *
     * @param listModels list DictionaryMode model
     */
    public void setListDictionary(List<DictionaryInfo> listModels) {
        this.mListDictionary = listModels;
    }

    /**
     * add data to list model
     *
     * @param listOtherDictionary list DictionaryOtherModel model
     */
    public void setListOtherDictionary(List<CategoryInfo> listOtherDictionary) {
        this.mListOtherCategory = listOtherDictionary;
    }

    /**
     * get status icon menu drag item
     *
     * @return status
     */
    public boolean getEnableButtonDrag() {
        return mSort;
    }

    /**
     * get status icon menu drag item
     *
     * @param sort status sort
     */
    public void setEnableButtonDrag(boolean sort) {
        this.mSort = sort;
        notifyDataSetChanged();
    }

    /**
     * get total content item
     *
     * @return
     */
    @Override
    public int getContentItemCount() {
        return mListDictionary.size();
    }

    /**
     * create header view holder
     *
     * @param parent view parent
     * @return header view holder
     */
    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        return null;
    }

    /**
     * create footer view holder
     *
     * @param parent view parent
     * @return footer view holder
     */
    @Override
    public BaseViewHolder onCreateFooterHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_footer_dic_category_other, parent, false);
        return new DicCategoryItemHolder(view);
    }

    /**
     * create content view holder
     *
     * @param parent   view parent
     * @param viewType view type
     * @return
     */
    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_dic_detail, parent, false);
        return new DictionaryHolder(view);
    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        if (fromPosition < toPosition && toPosition < getItemCount() - 1) {
            for (int i = fromPosition; i < toPosition; i++) {
                Collections.swap(mListDictionary, i, i + 1);
            }
            notifyItemMoved(fromPosition, toPosition);
            mListChangedListener.onNoteListChanged(mListDictionary);
        } else if (fromPosition != getItemCount() - 1) {
            for (int i = fromPosition; i > toPosition; i--) {
                Collections.swap(mListDictionary, i, i - 1);
            }
            notifyItemMoved(fromPosition, toPosition);
            mListChangedListener.onNoteListChanged(mListDictionary);
        }


    }

    /**
     * convert dp to px
     *
     * @param dp is dp
     * @return
     */
    public int dpToPx(int dp) {
        return (int) (dp * Resources.getSystem().getDisplayMetrics().density);
    }

    /**
     * category view holder
     */
    private class DictionaryHolder extends BaseViewHolder implements GetImageResultListener {
        private TextView mTvComment;
        private ImageView mImgThumbnail;
        private FrameLayout mFrameFlag;
        private CardView mCardView;
        private ImageView mIconDrag;
        private RelativeLayout mLayoutItem;
        private ImageView mImvCreatorIcon;
        private ProgressBar mProgressBar;

        DictionaryHolder(@NonNull View itemView) {
            super(itemView);
            mLayoutItem = itemView.findViewById(R.id.rlt_item_dic_list);
            mIconDrag = itemView.findViewById(R.id.imv_sort_item_dic);
            mFrameFlag = itemView.findViewById(R.id.frame_flag_dic_item);
            mCardView = itemView.findViewById(R.id.card_dic_item);
            mTvComment = itemView.findViewById(R.id.tv_comment_dic_item);
            mImgThumbnail = itemView.findViewById(R.id.imv_thumbnail_dic_item);
            mImvCreatorIcon = itemView.findViewById(R.id.imv_user_card_dic);
            mProgressBar = itemView.findViewById(R.id.progress_card);
        }

        @Override
        public void onBindView(final int position) {
            DictionaryInfo mModel = mListDictionary.get(toContentPosition(position));
            mProgressBar.setVisibility(View.INVISIBLE);
            Bitmap bitmap = ResourcesUtils.getImageFromPath(mModel.getImageFileAbsolutePath());
            if (bitmap != null) {
                mImgThumbnail.setImageBitmap(bitmap);
            } else {
                mImgThumbnail.setImageDrawable(mImgThumbnail.getContext().getDrawable(R.drawable.ic_card_default));
            }
            if (!mModel.isCalledGetImageMethod() && bitmap == null) {
                AppController.getInstance().getAssistServerInterface().getDictionaryImage(mListDictionary.get(position).getDictionaryId(), this);
                mModel.setIsCalledGetImageMethod(true);
            }
            mImgThumbnail.setClipToOutline(true);
            mTvComment.setText(mModel.getName());
            mFrameFlag.setBackgroundColor(mFrameFlag.getContext().getColor(mColorFlagItem));
            mCardView.setCardBackgroundColor(mFrameFlag.getContext().getColor(mColorBackgroundItem));
            if (mSort) {
                mIconDrag.setVisibility(View.VISIBLE);
                ViewGroup.MarginLayoutParams lpLayoutItem =
                        (ViewGroup.MarginLayoutParams) mLayoutItem.getLayoutParams();
                lpLayoutItem.setMarginStart(dpToPx(MARGIN_ITEM));
                lpLayoutItem.setMarginEnd(-dpToPx(2 * MARGIN_ITEM));
                mLayoutItem.requestLayout();
            } else {
                mIconDrag.setVisibility(View.GONE);
                ViewGroup.MarginLayoutParams lpLayoutItem =
                        (ViewGroup.MarginLayoutParams) mLayoutItem.getLayoutParams();
                lpLayoutItem.setMarginStart(dpToPx(0));
                lpLayoutItem.setMarginEnd(0);
                mLayoutItem.requestLayout();
            }
            mIconDrag.setOnDragListener(new View.OnDragListener() {
                @Override
                public boolean onDrag(View view, DragEvent dragEvent) {
                    if (dragEvent.getAction() == DragEvent.ACTION_DRAG_STARTED && position != mListDictionary.size()) {
                        mDragStartListener.onStartDrag(DictionaryHolder.this);
                    }
                    return false;
                }
            });
            mCardView.setFocusableInTouchMode(false);
            mCardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!mSort && mOnClickItemDicList != null) {
                        mOnClickItemDicList.onClickItemDic(mListDictionary.get(toContentPosition(position)));
                    }

                }
            });
            try {
                mImvCreatorIcon.setVisibility(View.VISIBLE);
                mImvCreatorIcon.setImageDrawable(mImvCreatorIcon.getContext().getDrawable(ResourcesUtils.getUserIconResourceFromId((int) mModel.getCreatorIconId())));
            } catch (Resources.NotFoundException e) {
                mImvCreatorIcon.setVisibility(View.INVISIBLE);
                AssistLog.e(e.getMessage());
            }
        }


        @Override
        public void onResult(AssistServerResult result, final String filepath) {
            if (mActivity != null && result.mResult == AssistServerResult.Result.Success) {
                mActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mProgressBar.setVisibility(View.GONE);
                        if (getLayoutPosition() != RecyclerView.NO_POSITION) {
                            File file = new File(filepath);
                            mListDictionary.get(getLayoutPosition()).setImageFileName(file.getName());
                            Bitmap bitmap = ResourcesUtils.getImageFromPath(filepath);
                            if (bitmap != null) {
                                mImgThumbnail.setImageBitmap(bitmap);
                            }
                        }
                    }
                });
            }
        }

        @Override
        public void onStartConnection() {
            mProgressBar.setVisibility(View.VISIBLE);
        }
    }

    /**
     * dictionary view holder
     */
    public class DicCategoryItemHolder extends BaseViewHolder {
        private RecyclerView mRecyclerView;
        private AdapterDicListOther mAdapter;

        DicCategoryItemHolder(@NonNull View itemView) {
            super(itemView);
            mRecyclerView = itemView.findViewById(R.id.recycler_category_other);
            mAdapter = new AdapterDicListOther(mOnClickItemDicList);
            LinearLayoutManager layoutManager = new LinearLayoutManager(itemView.getContext().getApplicationContext());
            layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            mRecyclerView.setLayoutManager(layoutManager);
            mAdapter.setListCategory(mListOtherCategory);
            mRecyclerView.setAdapter(mAdapter);
        }

        @Override
        public void onBindView(int position) {
            if (mSort) {
                itemView.setVisibility(View.GONE);
            } else {
                itemView.setVisibility(View.VISIBLE);
            }
        }
    }
}
