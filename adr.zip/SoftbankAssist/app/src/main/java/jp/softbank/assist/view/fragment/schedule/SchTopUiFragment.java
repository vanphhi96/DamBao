/*
 * ファイル：SchTopUiFragment.java
 * 概要：スケジュールトップ画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment.schedule;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.main.MenuUiActivity;
import jp.softbank.assist.view.adapter.SchPagerAdapter;
import jp.softbank.assist.view.fragment.BaseFragment;

import java.util.Calendar;
import java.util.Date;

/**
 * sch-01
 *
 * @author Systena
 * @version 1.0
 */
public class SchTopUiFragment extends BaseFragment implements ViewPager.OnPageChangeListener, View.OnClickListener {
    private ViewPager mViewPager;
    private SchPagerAdapter mSchPagerAdapter;
    private TextView mTvMonth;
    private TextView mTvDay;
    private TextView mTvDayOfWeek;
    private ImageView mImgAddSchedule;
    private LinearLayout mLnCalendar;
    private LinearLayout mLnHelp;
    private MenuUiActivity mCurrentActivity;
    private Date mDate;

    /**
     * インスタンスを初期化.
     *
     * @return SchTopUiFragment
     */
    public static SchTopUiFragment newInstance() {
        Bundle args = new Bundle();
        SchTopUiFragment fragment = new SchTopUiFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCurrentActivity = (MenuUiActivity) getActivity();
        mCurrentActivity.setCurrentFraggment(this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sch_top, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mViewPager = view.findViewById(R.id.view_pager_schedule);
        mTvMonth = view.findViewById(R.id.tv_month);
        mTvDay = view.findViewById(R.id.tv_day);
        mTvDayOfWeek = view.findViewById(R.id.tv_day_of_week);
        mLnCalendar = view.findViewById(R.id.ln_calendar);
        mLnHelp = view.findViewById(R.id.ln_help);
        mImgAddSchedule = view.findViewById(R.id.img_add_schedule);
        mImgAddSchedule.setOnClickListener(this);
        mLnCalendar.setOnClickListener(this);
        mLnHelp.setOnClickListener(this);
        initPage(new Date());
    }

    /**
     * init page data schedule info
     */
    private void initPage(Date date) {
        mSchPagerAdapter = new SchPagerAdapter(getFragmentManager());
        mSchPagerAdapter.setListDate(DateUtils.createListDays());
        mViewPager.setAdapter(mSchPagerAdapter);
        mViewPager.setCurrentItem(DateUtils.findPositionOfPage(date));
        mViewPager.addOnPageChangeListener(this);
        onPageSelected(DateUtils.findPositionOfPage(date));
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        mDate = mSchPagerAdapter.getDate(position);
        if (mDate != null) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(mDate);
            mTvDay.setText(String.valueOf(cal.get(Calendar.DAY_OF_MONTH)));
            mTvMonth.setText(String.valueOf(cal.get(Calendar.MONTH) + 1));
            mTvDayOfWeek.setText(DateUtils.convertDateToStringJapan(cal.get(Calendar.DAY_OF_WEEK), getContext()));
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_add_schedule:
                changeScreenResultFragment(ScreenId.START_SCH_CREATE, Constants.Schedule.REQUEST_CODE_SCHEDULE_CREATE, new Bundle());
                break;
            case R.id.ln_calendar:
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.Schedule.KEY_DATA_DATE, mDate);
                changeScreenResultFragment(ScreenId.START_SCH_CALENDAR, Constants.Schedule.RESULT_CALENDAR, bundle);
                break;
            case R.id.ln_help:
                mCurrentActivity.changeScreen(ScreenId.START_SCH_HELP);
                break;
            default:
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.Schedule.RESULT_CALENDAR && resultCode == Constants.Schedule.RESULT_CALENDAR) {
            Date date = (Date) data.getSerializableExtra(Constants.Schedule.KEY_DATE_CALENDAR);
            mViewPager.setCurrentItem(DateUtils.findPositionOfPage(date), false);
        } else if (requestCode == Constants.Schedule.REQUEST_CODE_SCHEDULE_CREATE && resultCode == Constants.Schedule.REQUEST_CODE_SCHEDULE_CREATE) {
            //reload data after create schedule
            reloadData();
        }
    }

    /**
     * reload data page
     */
    private void reloadData() {
        Date dateShowing = mSchPagerAdapter.getDate(mViewPager.getCurrentItem());
        mViewPager.setAdapter(null);
        mViewPager.clearOnPageChangeListeners();
        initPage(dateShowing);
    }
}
