/*
 * ファイル：ISchSaveDialog.java
 * 概要：Interface Schedule Save Dialog
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.dialog.factories.customfactories;

/**
 * @author Systena
 * @version 1.0
 */
public interface ISchSaveDialog {
    /**
     * set event when click button ok of dialog sch-cr-02
     */
    void onClickOkSchSave();
}
