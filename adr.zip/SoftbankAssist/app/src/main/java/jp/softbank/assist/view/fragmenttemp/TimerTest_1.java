package jp.softbank.assist.view.fragmenttemp;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.view.activity.main.MenuUiActivity;
import jp.softbank.assist.view.fragment.BaseFragment;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Tan N. Truong on 2019/01/09.
 */

// TODO: 2019/01/09 Just an example Fragment, can be deleted later

public class TimerTest_1 extends BaseFragment implements View.OnClickListener {

    Button mBtnTimerStart = null;
    Button mBtnTimerStop = null;
    Button mBtnTimerClear = null;

    TextView mText = null;

    private Timer mTimer = null;
    private MyTimerTask1 mTimerTask1 = null;
    private MyTimerTask2 mTimerTask2 = null;
    private Handler mHandler = new Handler();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_temp_timer, container, false);

        mBtnTimerStart = view.findViewById(R.id.button_TimerStart);
        mBtnTimerStart.setOnClickListener(this);
        mBtnTimerStop = view.findViewById(R.id.button_TimerStop);
        mBtnTimerStop.setOnClickListener(this);
        mBtnTimerClear = view.findViewById(R.id.button_TimerClear);
        mBtnTimerClear.setOnClickListener(this);

        mText = view.findViewById(R.id.timerText);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_TimerStart:
                timerSet1();
                break;
            case R.id.button_TimerStop:
                timerCancel();
                break;
            case R.id.button_TimerClear:

                break;
            default:
                break;

        }
    }

    private void timerSet1() {
        // 稼働中の場合は止める
        if (null != mTimer) {
            mTimer.cancel();
            mTimer = null;
        }

        Date now = new Date(System.currentTimeMillis());
        Date timerDate = null;
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(Calendar.MINUTE,1);
        timerDate = cal.getTime();

        // タイマーインスタンスを作成
        mTimer = new Timer();

        // タイマータスクインスタンスを作成
        mTimerTask1 = new MyTimerTask1();

        // タイマースケジュールを設定
        mTimer.schedule(mTimerTask1, timerDate);

        DateFormat df = new SimpleDateFormat("MM/dd HH:mm:ss");
        mText.setText("Timer Set1 [" + df.format(timerDate) + "]");
    }


    private void timerSet2() {
        // 稼働中の場合は止める
        if (null != mTimer) {
            mTimer.cancel();
            mTimer = null;
        }

        Date now = new Date(System.currentTimeMillis());
        Date timerDate = null;
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(Calendar.MINUTE,1);
        timerDate = cal.getTime();

        // タイマーインスタンスを作成
        mTimer = new Timer();

        // タイマータスクインスタンスを作成
        mTimerTask2 = new MyTimerTask2();

        // タイマースケジュールを設定
        mTimer.schedule(mTimerTask2, timerDate);

        DateFormat df = new SimpleDateFormat("MM/dd HH:mm:ss");
        mText.setText("Timer Set2 [" + df.format(timerDate) + "]");
    }

    /**
     * push通知送信テスト
     */
    private void buildPushSelf1() {

        Intent intent = new Intent("assist");
        PendingIntent contentIntent = PendingIntent.getBroadcast(getContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder notification = new NotificationCompat.Builder(getContext(), "testId")
                .setSmallIcon(R.drawable.ic_time)
                .setContentTitle("あと10分で予定時間です")
                .setContentText("××学校に到着")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(contentIntent);
        NotificationChannel notificationChannel = new NotificationChannel("testId", "test", NotificationManager.IMPORTANCE_DEFAULT);
        notificationChannel.enableVibration(true);

        NotificationManager notificationManager =
                (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(notificationChannel);

        notificationManager.notify(1, notification.build());
    }

    /**
     * push通知送信テスト
     */
    private void buildPushSelf2() {

        Intent intent = new Intent("assist");
        PendingIntent contentIntent = PendingIntent.getBroadcast(getContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder notification = new NotificationCompat.Builder(getContext(), "testId")
                .setSmallIcon(R.drawable.ic_time)
                .setContentTitle("予定時間になりました")
                .setContentText("××学校に到着")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(contentIntent);
        NotificationChannel notificationChannel = new NotificationChannel("testId", "test", NotificationManager.IMPORTANCE_DEFAULT);
        notificationChannel.enableVibration(true);

        NotificationManager notificationManager =
                (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(notificationChannel);

        notificationManager.notify(1, notification.build());
    }


    private void timerCancel() {
        if (null != mTimer) {
            // タイマーをキャンセル
            mTimer.cancel();
            mTimer = null;
            mText.setText("Timer No Set");
        }
    }

    // タイマータスク用のクラス
    class MyTimerTask1 extends TimerTask {

        @Override
        public void run() {
            mHandler.post(new Runnable() {
                public void run() {
//                    mText.setText("時間になりました!!");
                    buildPushSelf1();
                    timerSet2();
                }
            });
        }
    }

    // タイマータスク用のクラス
    class MyTimerTask2 extends TimerTask {

        @Override
        public void run() {
            mHandler.post(new Runnable() {
                public void run() {
//                    mText.setText("時間になりました!!");
                    buildPushSelf2();

                }
            });
        }
    }

}