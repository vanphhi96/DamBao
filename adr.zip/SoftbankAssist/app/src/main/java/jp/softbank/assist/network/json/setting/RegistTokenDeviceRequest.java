/*
 * ファイル：RegistTokenDeviceRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.setting;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

/**
 * 端末トークン登録リクエスト.
 */
public class RegistTokenDeviceRequest extends RequestBody {

    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("fb_token")
    private String mToken = null;
    @SerializedName("os_kind")
    private Long mOsKind = null;
    @SerializedName("os_version")
    private String mOsVersion = null;
    @SerializedName("app_version")
    private String mAppVersion = null;
    @SerializedName("device_name")
    private String mDeviceName = null;


    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * FB端末登録トークン.
     */
    public String getFbToken() {
        return mToken;
    }
    public void setFbToken(String fbToken) {
        this.mToken = fbToken;
    }

    /**
     * 端末OS種別（0：iOS、1：Android）.
     */
    public Long getOsKind() {
        return mOsKind;
    }
    public void setOsKind(Long osKind) {
        this.mOsKind = osKind;
    }

    /**
     * 端末OSバージョン.
     */
    public String getOsVersion() {
        return mOsVersion;
    }
    public void setOsVersion(String osVersion) {
        this.mOsVersion = osVersion;
    }

    /**
     * アプリバージョン.
     */
    public String getAppVersion() {
        return mAppVersion;
    }
    public void setAppVersion(String appVersion) {
        this.mAppVersion = appVersion;
    }

    /**
     * 端末機種名.
     */
    public String getDeviceName() {
        return mDeviceName;
    }
    public void setDeviceName(String deviceName) {
        this.mDeviceName = deviceName;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RegistTokenDeviceRequest requestToken= (RegistTokenDeviceRequest) o;
        return (this.mUserId == null ? requestToken.mUserId == null : this.mUserId.equals(requestToken.mUserId)) &&
                (this.mToken == null ? requestToken.mToken == null : this.mToken.equals(requestToken.mToken)) &&
                (this.mOsKind == null ? requestToken.mOsKind == null : this.mOsKind.equals(requestToken.mOsKind)) &&
                (this.mOsVersion == null ? requestToken.mOsVersion == null : this.mOsVersion.equals(requestToken.mOsVersion)) &&
                (this.mAppVersion == null ? requestToken.mAppVersion == null : this.mAppVersion.equals(requestToken.mAppVersion)) &&
                (this.mDeviceName == null ? requestToken.mDeviceName == null : this.mDeviceName.equals(requestToken.mDeviceName));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mToken == null ? 0: this.mToken.hashCode());
        result = 31 * result + (this.mOsKind == null ? 0: this.mOsKind.hashCode());
        result = 31 * result + (this.mOsVersion == null ? 0: this.mOsVersion.hashCode());
        result = 31 * result + (this.mAppVersion == null ? 0: this.mAppVersion.hashCode());
        result = 31 * result + (this.mDeviceName == null ? 0: this.mDeviceName.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class RegistTokenDeviceRequest {\n");

        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mToken: ").append(mToken).append("\n");
        sb.append("  mOsKind: ").append(mOsKind).append("\n");
        sb.append("  mOsVersion: ").append(mOsVersion).append("\n");
        sb.append("  mAppVersion: ").append(mAppVersion).append("\n");
        sb.append("  mDeviceName: ").append(mDeviceName).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
