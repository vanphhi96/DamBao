/*
 * ファイル：AdapterListSelectIconSchedule.java
 * 概要：Adapter list schedule icon
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import jp.softbank.assist.R;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.fragment.schedule.ISelectIconSchedule;

import java.util.ArrayList;

/**
 * sch-ed-01.
 *
 * @author Systena
 * @version 1.0
 */
public class AdapterListSelectIconSchedule extends
        RecyclerView.Adapter<AdapterListSelectIconSchedule.ViewHolder> {

    public static final int HEIGHT_KEY_BOARD = 146;
    private ArrayList<String> mListIcon;
    private String mDrawableSelected;
    private ISelectIconSchedule mISelectIconSchedule;

    /**
     * pass data to constructor
     *
     * @param listIcon
     */
    public AdapterListSelectIconSchedule(ArrayList<String> listIcon) {
        this.mListIcon = listIcon;
    }

    /**
     * set interface for adapter
     *
     * @param iSelectIconSchedule
     */
    public void setInterface(ISelectIconSchedule iSelectIconSchedule) {
        this.mISelectIconSchedule = iSelectIconSchedule;
    }

    /**
     * convert dp to px
     *
     * @param dp
     * @param context
     * @return
     */
    private int convertDpToPx(int dp, Context context) {
        return (int) (dp * context.getResources().getDisplayMetrics().density);
    }

    @Override
    @NonNull
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_select_schedule, parent, false);
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.width = view.getContext().getResources().getDisplayMetrics().widthPixels / 5;
        params.height = convertDpToPx(HEIGHT_KEY_BOARD/2,view.getContext());
        view.setLayoutParams(params);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.mImgSchedule.setImageResource(ResourcesUtils.getScheduleIconResourceFromId(mListIcon.get(position)));
        if (mDrawableSelected != null && mDrawableSelected.equals(mListIcon.get(position))) {
            holder.mFrBorder.setVisibility(View.VISIBLE);
        } else {
            holder.mFrBorder.setVisibility(View.GONE);
        }

    }

    /**
     * set position icon selected
     *
     * @param drawable
     */
    public void setIconSelected(String drawable) {
        this.mDrawableSelected = drawable;
    }

    @Override
    public int getItemCount() {
        return mListIcon == null ? 0 : mListIcon.size();
    }

    /**
     * create view holder icon schedule
     */
    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView mImgSchedule;
        FrameLayout mFrBorder;

        ViewHolder(View itemView) {
            super(itemView);
            mImgSchedule = itemView.findViewById(R.id.img_schedule);
            mFrBorder = itemView.findViewById(R.id.fr_border);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (getLayoutPosition() == RecyclerView.NO_POSITION || mISelectIconSchedule == null) {
                        return;
                    }
                    mISelectIconSchedule.selectedIcon(mListIcon.get(getLayoutPosition()));
                }
            });
        }
    }

}
