/*
 * ファイル：EditDictionaryResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * 辞書編集結果.
 */
public class EditDictionaryResult {

    @SerializedName("card_del_info")
    private List<EditDictionaryDeleteCard> mCardDelInfo = null;
    @SerializedName("card_pos_info")
    private List<EditDictionaryResultCardPos> mCardPosInfo = null;
    @SerializedName("card_add_content_info")
    private List<EditDictionaryResultCardContent> mCardAddContentInfo = null;
    @SerializedName("card_edit_content_info")
    private List<EditDictionaryResultCardContent> mCardEditContentInfo = null;
    @SerializedName("dic_edit_content_info")
    private EditDictionaryResultDicEditContent mDicEditContentInfo = null;


    /**
     * カード削除情報.
     */
    public List<EditDictionaryDeleteCard> getCardDelInfo() {
        return mCardDelInfo;
    }
    public void setCardDelInfo(List<EditDictionaryDeleteCard> cardDelInfo) {
        this.mCardDelInfo = cardDelInfo;
    }

    /**
     * カード位置情報.
     */
    public List<EditDictionaryResultCardPos> getCardPosInfo() {
        return mCardPosInfo;
    }
    public void setCardPosInfo(List<EditDictionaryResultCardPos> cardPosInfo) {
        this.mCardPosInfo = cardPosInfo;
    }

    /**
     * カード追加情報.
     */
    public List<EditDictionaryResultCardContent> getCardAddContentInfo() {
        return mCardAddContentInfo;
    }
    public void setCardAddContentInfo(List<EditDictionaryResultCardContent> cardAddContentInfo) {
        this.mCardAddContentInfo = cardAddContentInfo;
    }

    /**
     * カード編集情報.
     */
    public List<EditDictionaryResultCardContent> getCardEditContentInfo() {
        return mCardEditContentInfo;
    }
    public void setCardEditContentInfo(List<EditDictionaryResultCardContent> cardEditContentInfo) {
        this.mCardEditContentInfo = cardEditContentInfo;
    }

    /**
     * 辞書内容情報.
     */
    public EditDictionaryResultDicEditContent getDicEditContentInfo() {
        return mDicEditContentInfo;
    }
    public void setDicEditContentInfo(EditDictionaryResultDicEditContent dicEditContentInfo) {
        this.mDicEditContentInfo = dicEditContentInfo;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EditDictionaryResult dictionaryResult = (EditDictionaryResult) o;
        return (this.mCardDelInfo == null ? dictionaryResult.mCardDelInfo == null : this.mCardDelInfo.equals(dictionaryResult.mCardDelInfo)) &&
                (this.mCardPosInfo == null ? dictionaryResult.mCardPosInfo == null : this.mCardPosInfo.equals(dictionaryResult.mCardPosInfo)) &&
                (this.mCardAddContentInfo == null ? dictionaryResult.mCardAddContentInfo == null : this.mCardAddContentInfo.equals(dictionaryResult.mCardAddContentInfo)) &&
                (this.mCardEditContentInfo == null ? dictionaryResult.mCardEditContentInfo == null : this.mCardEditContentInfo.equals(dictionaryResult.mCardEditContentInfo)) &&
                (this.mDicEditContentInfo == null ? dictionaryResult.mDicEditContentInfo == null : this.mDicEditContentInfo.equals(dictionaryResult.mDicEditContentInfo));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mCardDelInfo == null ? 0: this.mCardDelInfo.hashCode());
        result = 31 * result + (this.mCardPosInfo == null ? 0: this.mCardPosInfo.hashCode());
        result = 31 * result + (this.mCardAddContentInfo == null ? 0: this.mCardAddContentInfo.hashCode());
        result = 31 * result + (this.mCardEditContentInfo == null ? 0: this.mCardEditContentInfo.hashCode());
        result = 31 * result + (this.mDicEditContentInfo == null ? 0: this.mDicEditContentInfo.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class EditDictionaryResult {\n");

        sb.append("  mCardDelInfo: ").append(mCardDelInfo).append("\n");
        sb.append("  mCardPosInfo: ").append(mCardPosInfo).append("\n");
        sb.append("  mCardAddContentInfo: ").append(mCardAddContentInfo).append("\n");
        sb.append("  mCardEditContentInfo: ").append(mCardEditContentInfo).append("\n");
        sb.append("  mDicEditContentInfo: ").append(mDicEditContentInfo).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
