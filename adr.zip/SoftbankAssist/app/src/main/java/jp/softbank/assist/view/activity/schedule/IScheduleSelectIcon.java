/*
 * ファイル：IScheduleSelectIcon.java
 * 概要：Interface select icon schedule
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.schedule;

/**
 * sch-cr-01.
 *
 * @author Systena
 * @version 1.0
 */
public interface IScheduleSelectIcon {
    /**
     * onclick icon in recycler view
     *
     * @param drawableName drawable name
     */
    void selectIcon(String drawableName);
}
