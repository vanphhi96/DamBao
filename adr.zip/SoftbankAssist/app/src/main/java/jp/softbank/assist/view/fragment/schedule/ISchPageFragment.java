/*
 * ファイル：ISchPageFragment.java
 * 概要：Interface click item in sch-01
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.fragment.schedule;

import jp.softbank.assist.model.database.ScheduleInfo;

/**
 * sch-01.
 *
 * @author Systena
 * @version 1.0
 */
public interface ISchPageFragment {
    /**
     * click item schedule
     *
     * @param scheduleInfo schedule info
     */
    void onClickSchedule(ScheduleInfo scheduleInfo);
}
