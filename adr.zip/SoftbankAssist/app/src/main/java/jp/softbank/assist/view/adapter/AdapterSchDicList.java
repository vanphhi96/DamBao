/*
 * ファイル：AdapterSchDicList.java
 * 概要：Adapter list dictionary detail
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.app.Activity;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetImageResultListener;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.activity.dictionary.IOnClickItemDicList;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.RecyclerBaseAdapter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


/**
 * Adapter SchDictionaryList
 *
 * @author Systena
 * @version 1.0
 */
public class AdapterSchDicList extends RecyclerBaseAdapter {
    private List<DictionaryInfo> mListDictionary = new ArrayList<>();
    private List<CategoryInfo> mListCategoryOther = new ArrayList<>();
    private IOnClickItemDicList mOnClickItemDicList;
    private boolean mSort = false;
    private int mColorBackgroundItem;
    private int mColorFlagItem;
    private Activity mActivity;

    /**
     * set show footer view
     */ {
        setFooterVisibility(true);
    }

    public AdapterSchDicList() {
    }

    /**
     * set activity, use when runOnUiThread
     *
     * @param activity
     */
    public void setActivity(Activity activity) {
        this.mActivity = activity;
    }

    /**
     * set color background item dictionary.
     *
     * @param colorBackgroundItem
     * @param colorFlagItem
     */
    public void setColorItem(int colorBackgroundItem, int colorFlagItem) {
        this.mColorBackgroundItem = colorBackgroundItem;
        this.mColorFlagItem = colorFlagItem;
    }

    /**
     * set interface for adapter
     *
     * @param iOnClickItemDicList
     */
    public void setOnClickItemDicList(IOnClickItemDicList iOnClickItemDicList) {
        this.mOnClickItemDicList = iOnClickItemDicList;
    }

    /**
     * add data to list model
     *
     * @param listDictionary list DictionaryMode model
     */
    public void setListDictionary(List<DictionaryInfo> listDictionary) {
        this.mListDictionary = listDictionary;
    }

    /**
     * add data to list model
     *
     * @param listCategoryOther list DictionaryOtherModel model
     */
    public void setListCategoryOther(List<CategoryInfo> listCategoryOther) {
        this.mListCategoryOther = listCategoryOther;
    }

    /**
     * get total content item
     *
     * @return
     */
    @Override
    public int getContentItemCount() {
        return mListDictionary.size();
    }

    /**
     * create header view holder
     *
     * @param parent view parent
     * @return header view holder
     */
    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        return null;
    }

    /**
     * create footer view holder
     *
     * @param parent view parent
     * @return footer view holder
     */
    @Override
    public BaseViewHolder onCreateFooterHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_footer_dic_category_other, parent, false);
        return new DicCategoryItemHolder(view);
    }

    /**
     * create content view holder
     *
     * @param parent   view parent
     * @param viewType view type
     * @return
     */
    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_dic_detail, parent, false);
        return new DictionaryHolder(view);
    }

    /**
     * category view holder
     */
    private class DictionaryHolder extends BaseViewHolder implements GetImageResultListener {
        private ImageView mImvCreatorIcon;
        private TextView mTvComment;
        private ImageView mImgThumbnail;
        private FrameLayout mFrameFlag;
        private CardView mCardView;
        private ImageView mIconDrag;
        private ProgressBar mProgressBar;

        DictionaryHolder(@NonNull View itemView) {
            super(itemView);
            mIconDrag = itemView.findViewById(R.id.imv_sort_item_dic);
            mFrameFlag = itemView.findViewById(R.id.frame_flag_dic_item);
            mCardView = itemView.findViewById(R.id.card_dic_item);
            mTvComment = itemView.findViewById(R.id.tv_comment_dic_item);
            mImgThumbnail = itemView.findViewById(R.id.imv_thumbnail_dic_item);
            mProgressBar = itemView.findViewById(R.id.progress_card);
            mImvCreatorIcon = itemView.findViewById(R.id.imv_user_card_dic);

        }

        @Override
        public void onBindView(final int position) {
            DictionaryInfo mModel = mListDictionary.get(toContentPosition(position));
            mProgressBar.setVisibility(View.INVISIBLE);
            Bitmap bitmap = ResourcesUtils.getImageFromPath(mModel.getImageFileAbsolutePath());
            if (bitmap != null) {
                mImgThumbnail.setImageBitmap(bitmap);
            } else {
                mImgThumbnail.setImageDrawable(mImgThumbnail.getContext().getDrawable(R.drawable.ic_card_default));
            }
            if (!mModel.isCalledGetImageMethod() && bitmap == null) {
                AppController.getInstance().getAssistServerInterface().getDictionaryImage(mListDictionary.get(position).getDictionaryId(), this);
                mModel.setIsCalledGetImageMethod(true);
            }
            mImgThumbnail.setClipToOutline(true);
            try {
                mImvCreatorIcon.setVisibility(View.VISIBLE);
                mImvCreatorIcon.setImageDrawable(mImvCreatorIcon.getContext().getDrawable(ResourcesUtils.getUserIconResourceFromId((int) mModel.getCreatorIconId())));
            } catch (Resources.NotFoundException e) {
                mImvCreatorIcon.setVisibility(View.INVISIBLE);
                AssistLog.e(e.toString());
            }

            mIconDrag.setVisibility(View.GONE);
            mFrameFlag.setBackgroundColor(mFrameFlag.getContext().getColor(mColorFlagItem));
            mCardView.setCardBackgroundColor(mFrameFlag.getContext().getColor(mColorBackgroundItem));
            mTvComment.setText(mModel.getName());
            mCardView.setFocusableInTouchMode(false);
            mCardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!mSort && mOnClickItemDicList != null) {
                        mOnClickItemDicList.onClickItemDic(mListDictionary.get(toContentPosition(position)));
                    }
                }
            });
        }

        @Override
        public void onResult(AssistServerResult result, final String filepath) {
            if (mActivity != null) {
                mActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mProgressBar.setVisibility(View.GONE);
                        if (getLayoutPosition() != RecyclerView.NO_POSITION) {
                            File file = new File(filepath);
                            mListDictionary.get(getLayoutPosition()).setImageFileName(file.getName());
                            Bitmap bitmap = ResourcesUtils.getImageFromPath(filepath);
                            if (bitmap != null) {
                                mImgThumbnail.setImageBitmap(bitmap);
                            }
                        }
                    }
                });
            }
        }

        @Override
        public void onStartConnection() {
            mProgressBar.setVisibility(View.VISIBLE);
        }
    }

    /**
     * dictionary view holder
     */
    public class DicCategoryItemHolder extends BaseViewHolder {
        private RecyclerView mRecyclerView;
        private AdapterDicListOther mAdapter;

        DicCategoryItemHolder(@NonNull View itemView) {
            super(itemView);
            mRecyclerView = itemView.findViewById(R.id.recycler_category_other);
            mAdapter = new AdapterDicListOther(mOnClickItemDicList);
            LinearLayoutManager layoutManager = new LinearLayoutManager(itemView.getContext().getApplicationContext());
            layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            mRecyclerView.setLayoutManager(layoutManager);
            mAdapter.setListCategory(mListCategoryOther);
            mRecyclerView.setAdapter(mAdapter);

        }

        @Override
        public void onBindView(int position) {

        }
    }
}
