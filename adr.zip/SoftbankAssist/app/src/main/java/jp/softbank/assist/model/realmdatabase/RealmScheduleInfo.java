/*
 * ファイル：RealmScheduleInfo.java
 * 概要：Realm用スケジュール情報一覧テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

import java.util.Date;

/**
 * Realm用スケジュール情報一覧テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmScheduleInfo extends RealmObject {

    @PrimaryKey
    private long mScheduleId; // スケジュール日時ID
    private Date mScheduleStartDate; // スケジュール開始日時
    private Date mScheduleEndDate; // スケジュール終了日時
    private boolean mIsCompleted; // 完了済みフラグ
    private boolean mIsAllDay; // 終日フラグ
    private long mScheduleMetaId; // スケジュール内容ID
    private String mTitle; // スケジュールタイトル
    private String mNote; // スケジュールノート
    private String mLocation; // 場所
    private String mIconName; // 予定アイコン名
    private long mCreatorIconId; // 作成者アイコンID
    private String mCreatorNickname; // 作成者ニックネーム
    private Date mCreatedDate; // 作成日時
    private Date mUpdatedDate; // 更新日時
    private long mDictionaryId1; // 関連辞書ID1
    private long mDictionaryId2; // 関連辞書ID2
    private long mDictionaryId3; // 関連辞書ID3
    private Date mRepeatStartDate; // 繰り返し開始日時
    private Date mRepeatEndDate; // 繰り返し終了日時
    private long mInterval; // インターバル
    private boolean mIsRepeatSunday; // 日曜日繰り返し
    private boolean mIsRepeatMonday; // 月曜日繰り返し
    private boolean mIsRepeatTuesday; // 火曜日繰り返し
    private boolean mIsRepeatWednesday; // 水曜日繰り返し
    private boolean mIsRepeatThursday; // 木曜日繰り返し
    private boolean mIsRepeatFriday; // 金曜日繰り返し
    private boolean mIsRepeatSaturday; // 土曜日繰り返し

    public long getScheduleId() {
        return mScheduleId;
    }

    public void setScheduleId(long mScheduleId) {
        this.mScheduleId = mScheduleId;
    }

    public Date getScheduleStartDate() {
        return mScheduleStartDate;
    }

    public void setScheduleStartDate(Date mScheduleStartDate) {
        this.mScheduleStartDate = mScheduleStartDate;
    }

    public Date getScheduleEndDate() {
        return mScheduleEndDate;
    }

    public void setScheduleEndDate(Date mScheduleEndDate) {
        this.mScheduleEndDate = mScheduleEndDate;
    }

    public boolean isCompleted() {
        return mIsCompleted;
    }

    public void setCompleted(boolean mIsCompleted) {
        this.mIsCompleted = mIsCompleted;
    }

    public boolean isAllDay() {
        return mIsAllDay;
    }

    public void setAllDay(boolean mIsAllDay) {
        this.mIsAllDay = mIsAllDay;
    }

    public long getScheduleMetaId() {
        return mScheduleMetaId;
    }

    public void setScheduleMetaId(long mScheduleMetaId) {
        this.mScheduleMetaId = mScheduleMetaId;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public String getNote() {
        return mNote;
    }

    public void setNote(String mNote) {
        this.mNote = mNote;
    }

    public String getLocation() {
        return mLocation;
    }

    public void setLocation(String location) {
        this.mLocation = location;
    }

    public String getIconName() {
        return mIconName;
    }

    public void setIconName(String mIconName) {
        this.mIconName = mIconName;
    }

    public long getCreatorIconId() {
        return mCreatorIconId;
    }

    public void setCreatorIconId(long mCreatorIconId) {
        this.mCreatorIconId = mCreatorIconId;
    }

    public String getCreatorNickname() {
        return mCreatorNickname;
    }

    public void setCreatorNickname(String mCreatorNickname) {
        this.mCreatorNickname = mCreatorNickname;
    }

    public Date getCreatedDate() {
        return mCreatedDate;
    }

    public void setCreatedDate(Date mCreatedDate) {
        this.mCreatedDate = mCreatedDate;
    }

    public Date getUpdatedDate() {
        return mUpdatedDate;
    }

    public void setUpdatedDate(Date mUpdatedDate) {
        this.mUpdatedDate = mUpdatedDate;
    }

    public long getDictionaryId1() {
        return mDictionaryId1;
    }

    public void setDictionaryId1(long mDictionaryId1) {
        this.mDictionaryId1 = mDictionaryId1;
    }

    public long getDictionaryId2() {
        return mDictionaryId2;
    }

    public void setDictionaryId2(long mDictionaryId2) {
        this.mDictionaryId2 = mDictionaryId2;
    }

    public long getDictionaryId3() {
        return mDictionaryId3;
    }

    public void setDictionaryId3(long mDictionaryId3) {
        this.mDictionaryId3 = mDictionaryId3;
    }

    public Date getRepeatStartDate() {
        return mRepeatStartDate;
    }

    public void setRepeatStartDate(Date mRepeatStartDate) {
        this.mRepeatStartDate = mRepeatStartDate;
    }

    public Date getRepeatEndDate() {
        return mRepeatEndDate;
    }

    public void setRepeatEndDate(Date mRepeatEndDate) {
        this.mRepeatEndDate = mRepeatEndDate;
    }

    public long getInterval() {
        return mInterval;
    }

    public void setInterval(long mInterval) {
        this.mInterval = mInterval;
    }

    public boolean isRepeatSunday() {
        return mIsRepeatSunday;
    }

    public void setIsRepeatSunday(boolean mIsRepeatSunday) {
        this.mIsRepeatSunday = mIsRepeatSunday;
    }

    public boolean isRepeatMonday() {
        return mIsRepeatMonday;
    }

    public void setIsRepeatMonday(boolean mIsRepeatMonday) {
        this.mIsRepeatMonday = mIsRepeatMonday;
    }

    public boolean isRepeatTuesday() {
        return mIsRepeatTuesday;
    }

    public void setIsRepeatTuesday(boolean mIsRepeatTuesday) {
        this.mIsRepeatTuesday = mIsRepeatTuesday;
    }

    public boolean isRepeatWednesday() {
        return mIsRepeatWednesday;
    }

    public void setIsRepeatWednesday(boolean mIsRepeatWednesday) {
        this.mIsRepeatWednesday = mIsRepeatWednesday;
    }

    public boolean isRepeatThursday() {
        return mIsRepeatThursday;
    }

    public void setIsRepeatThursday(boolean mIsRepeatThursday) {
        this.mIsRepeatThursday = mIsRepeatThursday;
    }

    public boolean isRepeatFriday() {
        return mIsRepeatFriday;
    }

    public void setIsRepeatFriday(boolean mIsRepeatFriday) {
        this.mIsRepeatFriday = mIsRepeatFriday;
    }

    public boolean isRepeatSaturday() {
        return mIsRepeatSaturday;
    }

    public void setIsRepeatSaturday(boolean mIsRepeatSaturday) {
        this.mIsRepeatSaturday = mIsRepeatSaturday;
    }

}
