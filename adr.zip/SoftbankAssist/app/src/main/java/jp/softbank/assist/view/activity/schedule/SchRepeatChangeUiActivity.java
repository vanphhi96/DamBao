/*
 * ファイル：SchRepeatChangeUiActivity.java
 * 概要：Select type repeat for schedule
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.schedule;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.activity.BaseUiActivity;

/**
 * sch-cr-01_wireFrame_06
 *
 * @author Systena
 * @version 1.0
 */
public class SchRepeatChangeUiActivity extends BaseUiActivity implements View.OnClickListener {
    private ImageView mImvNoRepeat;
    private ImageView mImvDailyRepeat;
    private ImageView mImvWeeklyRepeat;
    private ImageView mImvMonthlyRepeat;
    private ImageView mImvAnnualRepeat;
    private TextView mTvBackRepeat;
    private String mStrBack;
    private ScheduleInfo.IntervalType mIntervalType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repeat_schedule);
        mIntervalType = getIntentRepeat();
        RelativeLayout rlNoRepeat = findViewById(R.id.relative_ac_repeat_schedule_no_repeat);
        RelativeLayout rlDailyRepeat = findViewById(R.id.relative_ac_repeat_schedule_daily);
        RelativeLayout rlWeeklyRepeat = findViewById(R.id.relative_ac_repeat_schedule_weekly);
        RelativeLayout rlMonthlyRepeat = findViewById(R.id.relative_ac_repeat_schedule_monthly);
        RelativeLayout rlAnnuallyRepeat = findViewById(R.id.relative_ac_repeat_schedule_annual);
        LinearLayout mLnBack = findViewById(R.id.ln_back);

        mImvNoRepeat = findViewById(R.id.image_view_ac_repeat_schedule_no_repeat);
        mImvDailyRepeat = findViewById(R.id.image_view_ac_repeat_schedule_daily);
        mImvWeeklyRepeat = findViewById(R.id.image_view_ac_repeat_schedule_weekly);
        mImvMonthlyRepeat = findViewById(R.id.image_view_ac_repeat_schedule_monthly);
        mImvAnnualRepeat = findViewById(R.id.image_ac_repeat_schedule_annual);
        mTvBackRepeat = findViewById(R.id.tv_back_repeat);
        mTvBackRepeat.setText(getIntentBack());
        setVisibleIconSelect(mIntervalType);

        mLnBack.setOnClickListener(this);
        rlNoRepeat.setOnClickListener(this);
        rlDailyRepeat.setOnClickListener(this);
        rlWeeklyRepeat.setOnClickListener(this);
        rlMonthlyRepeat.setOnClickListener(this);
        rlAnnuallyRepeat.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.relative_ac_repeat_schedule_no_repeat:
                setVisibleIconSelect(ScheduleInfo.IntervalType.None);
                goBackSchCreateUiActivity(ScheduleInfo.IntervalType.None);
                break;

            case R.id.relative_ac_repeat_schedule_daily:
                setVisibleIconSelect(ScheduleInfo.IntervalType.Daily);
                goBackSchCreateUiActivity(ScheduleInfo.IntervalType.Daily);
                break;

            case R.id.relative_ac_repeat_schedule_weekly:
                setVisibleIconSelect(ScheduleInfo.IntervalType.Weekly);
                goBackSchCreateUiActivity(ScheduleInfo.IntervalType.Weekly);
                break;

            case R.id.relative_ac_repeat_schedule_monthly:
                setVisibleIconSelect(ScheduleInfo.IntervalType.Monthly);
                goBackSchCreateUiActivity(ScheduleInfo.IntervalType.Monthly);
                break;

            case R.id.relative_ac_repeat_schedule_annual:
                setVisibleIconSelect(ScheduleInfo.IntervalType.Yearly);
                goBackSchCreateUiActivity(ScheduleInfo.IntervalType.Yearly);
                break;

            case R.id.ln_back:
                onBackPressed();
                break;

            default:
                break;
        }
    }

    /**
     * get string key repeat from intent
     *
     * @return string
     */
    private ScheduleInfo.IntervalType getIntentRepeat() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_INTERVAL_TYPE)) {
            return (ScheduleInfo.IntervalType) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_INTERVAL_TYPE);
        } else {
            return ScheduleInfo.IntervalType.None;
        }
    }

    /**
     * get string key back repeat from intent
     *
     * @return string
     */
    private String getIntentBack() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_BACK_REPEAT_TITLE)) {
            return getIntent().getExtras().getString(Constants.Schedule.KEY_BACK_REPEAT_TITLE);
        } else {
            return getString(R.string.sch_cr);
        }
    }

    /**
     * set visible icon when select type repeat
     *
     * @param intervalType
     */
    private void setVisibleIconSelect(ScheduleInfo.IntervalType intervalType) {
        ImageView[] images = new ImageView[]{
                mImvNoRepeat, mImvDailyRepeat, mImvWeeklyRepeat, mImvMonthlyRepeat,
                mImvAnnualRepeat
        };
        int position = 0;
        switch (intervalType) {
            case None:
                position = 0; //position of not repeat in list
                break;
            case Daily:
                position = 1;//position of day repeat in list
                break;
            case Weekly:
                position = 2;//position of week repeat in list
                break;
            case Monthly:
                position = 3;//position of month repeat in list
                break;
            case Yearly:
                position = 4;//position of year repeat in list
                break;
            default:
                break;
        }
        for (int i = 0; i < images.length; i++) {
            if (i == position) {
                images[i].setVisibility(View.VISIBLE);
            } else {
                images[i].setVisibility(View.GONE);
            }
        }
    }

    /**
     * go back to SchCreateUIActivity after choose type repeat
     *
     * @param repeat
     */
    private void goBackSchCreateUiActivity(ScheduleInfo.IntervalType repeat) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Constants.Schedule.KEY_GO_BACK_REPEAT, repeat);
        backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_REPEAT);
    }
}
