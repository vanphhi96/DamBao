/*
 * ファイル：DicCreateUiActivity.java
 * 概要：辞書作成画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.dictionary;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.TempDictionaryInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.adapter.DicCreateAdapter;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


/**
 * dic-cr-01
 *
 * @author Systena
 * @version 1.0
 */
public class DicCreateUiActivity extends BaseDicEditUiActivity implements IOnClickItemDicCreate,
        View.OnClickListener, DialogInterface.OnClickListener, NotifyOnlyResultListener {
    private RecyclerView mRecyclerView;
    private DicCreateAdapter mDicCreateAdapter;
    private TextView mTvSave;
    private RelativeLayout mLayoutBack;
    private boolean mChooseThumbnailCard = false;
    private int mPositionCardUpdate;
    private TempDictionaryInfo mTempDictionaryInfo;
    private TextView mTvBack;
    private CategoryInfo mCategoryInfo;
    private long mCategoryId;
    private int mPositionCardDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dic_create);
        mCategoryInfoList = getIntentListCategory();
        mCategoryId = getIntentCategory();
        mCategoryInfo = getCategoryById(mCategoryId);
        mTempDictionaryInfo = new TempDictionaryInfo(mCategoryInfo.getCategoryId());
        mLayoutBack = findViewById(R.id.rlt_dic_create_back);
        mTvSave = findViewById(R.id.tv_save_dic_create_action_bar);
        mRecyclerView = findViewById(R.id.recycle_view_dic_create);
        mTvBack = findViewById(R.id.tv_back_dic_create);

        if (mCategoryId != Constants.Ids.ID_NONE) {
            mTvBack.setText(mCategoryInfo.getName());
        }
        mLayoutBack.setOnClickListener(this);
        mTvSave.setOnClickListener(this);
        mRecyclerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                hideKeyboard(view);
                return false;
            }
        });
        initListCard();
    }

    /**
     * init list card
     */
    private void initListCard() {
        mDicCreateAdapter = new DicCreateAdapter();
        mDicCreateAdapter.setInterface(this);
        mDicCreateAdapter.setDictionaryInfo(mTempDictionaryInfo);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayout.VERTICAL);
        mDicCreateAdapter.setShowButtonDelete(false);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setAdapter(mDicCreateAdapter);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.rlt_dic_create_back:
                onBackPressed();
                break;
            case R.id.tv_save_dic_create_action_bar:
                setOnClickSave();
                break;
            default:
                break;
        }
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        super.onClick(dialog, which);
        if (which == DialogInterface.BUTTON_POSITIVE) {
            if (DialogTypeControl.DialogType.DIC_EDIT_DEL_ITEM.name().equals(mDialogTag)) {
                if (mTempDictionaryInfo.getCardList().size() > mPositionCardDelete) {
                    mTempDictionaryInfo.removeCard(mPositionCardDelete);
                    buildDicDelItemDialogEnd();
                }
            } else if (DialogTypeControl.DialogType.DIC_EDIT_DEL_ITEM_END.name().equals(mDialogTag)) {
                mDicCreateAdapter.notifyDataSetChanged();
            } else if (DialogTypeControl.DialogType.DIC_CR_END.name().equals(mDialogTag)) {
                goBackScreen();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constants.Dictionary.REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bitmap imageBitmap = null;
            if (!TextUtils.isEmpty(mTemporaryPhotoPath)) {
                // get full data and rotate image
                imageBitmap = ResourcesUtils.rotateImage(mTemporaryPhotoPath);
                // delete temporary file
                File file = new File(mTemporaryPhotoPath);
                file.delete();
            }
            // get thumbnail
            if (imageBitmap == null) {
                Bundle extras = data.getExtras();
                imageBitmap = (Bitmap) extras.get(Constants.Dictionary.KEY_GET_PICTURE);
            }

            //set image to card or dic
            setImage(imageBitmap);
        } else if (requestCode == Constants.Dictionary.REQUEST_CODE_GALLERY && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            try {
                Bitmap imageBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);

                //set image to card or dic
                setImage(imageBitmap);
            } catch (IOException e) {
                AssistLog.e(e.getMessage());
            }

        } else if (requestCode == Constants.Dictionary.REQUEST_CODE_CATEGORY && resultCode == Constants.Dictionary.REQUEST_CODE_CATEGORY) {
            mCategoryInfo = getCategoryById(Long.valueOf(data.getStringExtra(Constants.Dictionary.KEY_GO_BACK_CATEGORY)));
            if (mCategoryInfo != null) {
                mTempDictionaryInfo.setCategoryId(mCategoryInfo.getCategoryId());
                mDicCreateAdapter.notifyDataSetChanged();
            }
        }
    }

    /**
     * event click button delete in Item Dic Create
     *
     * @param position is position item
     */
    @Override
    public void onClickButtonDelete(int position) {
        if (mTempDictionaryInfo.getCardList().size() > position) {
            mPositionCardDelete = position;
            buildDicDelItemDialogConfirm();
        }
    }

    /**
     * event click button create in Item Dic Create
     *
     * @param position is position item onclick
     */
    @Override
    public void onClickButtonCreate(int position) {
        hideKeyboard(getCurrentFocus());
        if (mTempDictionaryInfo.getCardList().size() == Constants.Dictionary.MAX_CARD_DICTIONARY) {
            buildDialogDicCardMax();
        } else {
            mTempDictionaryInfo.addCard(position);
            mDicCreateAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClickChooseThumbnail() {
        hideKeyboard(getCurrentFocus());
        mChooseThumbnailCard = false;
        buildSingleChoiceDialog();
    }

    @Override
    public void onClickChooseCategory() {
        goToDicCategoryActivity(mCategoryInfo.getCategoryId(), getString(R.string.dic_cr_dic));
    }

    @Override
    public void onClickHeader() {
        hideKeyboard(getCurrentFocus());
    }

    @Override
    public void updateAvatar(int position) {
        mPositionCardUpdate = position;
        mChooseThumbnailCard = true;
        buildSingleChoiceDialog();
    }


    /**
     * show dialog dic-cr-02
     */
    private void buildDicCreateEndDialog() {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIC_CR_END);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * set thumbnail card dictionary
     *
     * @param imageBitmap is image bitmap
     */
    private void setImage(Bitmap imageBitmap) {
        if (imageBitmap != null) {
            if (mChooseThumbnailCard) {
                mTempDictionaryInfo.getCardList().get(mPositionCardUpdate).clearImage();
                if (mTempDictionaryInfo.getCardList().get(mPositionCardUpdate).setImage(imageBitmap)) {
                    mDicCreateAdapter.notifyItemChanged(mPositionCardUpdate + 1);
                }
            } else {
                mTempDictionaryInfo.clearImage();
                if (mTempDictionaryInfo.setImage(imageBitmap)) {
                    mDicCreateAdapter.notifyItemChanged(0);
                }
            }
        }
    }

    /**
     * get intent list category
     *
     * @return List<CategoryInfo>
     */
    private List<CategoryInfo> getIntentListCategory() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_LIST_CATEGORY)) {
            return (List<CategoryInfo>) getIntent().getExtras().getSerializable(Constants.Dictionary.KEY_LIST_CATEGORY);
        }
        return new ArrayList<>();
    }

    /**
     * get category intent
     *
     * @return id category
     */
    private Long getIntentCategory() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_TYPE_CATEGORY)) {
            return Long.valueOf(getIntent().getExtras().getString(Constants.Dictionary.KEY_TYPE_CATEGORY));
        } else {
            return Constants.Ids.ID_NONE;
        }
    }

    /**
     * get category by id
     *
     * @param idCategory
     * @return CategoryInfo
     */
    private CategoryInfo getCategoryById(long idCategory) {
        CategoryInfo categoryDefault = null;
        for (CategoryInfo categoryInfo : mCategoryInfoList) {
            if (idCategory == categoryInfo.getCategoryId()) {
                return categoryInfo;
            }
            if (categoryInfo.getCategoryId() == Constants.Ids.CATEGORY_ID_HOW_TO_DO) {
                categoryDefault = categoryInfo;
            }
        }
        return categoryDefault;
    }


    @Override
    public void onResult(AssistServerResult result) {
        closeIndicator();
        if (result.mResult == AssistServerResult.Result.Success) {
            buildDicCreateEndDialog();//show dialog dic-cr-end
        } else {
            buildDialogError(result.mMessage);
        }
    }

    @Override
    public void onStartConnection() {
        displayIndicator();
    }


    /**
     * check card info is empty
     *
     * @return boolean
     */
    private boolean checkCardEmpty() {
        for (CardInfo cardInfo : mTempDictionaryInfo.getCardList()) {
            if ((TextUtils.isEmpty(cardInfo.getText()) ||
                    TextUtils.isEmpty(cardInfo.getText().trim()))
                    && TextUtils.isEmpty(cardInfo.getImageFileAbsolutePath())) {
                return true;
            }
        }
        return false;
    }

    /**
     * dialog create error
     *
     * @return boolean
     */
    private void buildDialogError(String errorMessage) {
        mDialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIALOG_MESSAGE, errorMessage);
        mDialogTag = mDialogFactory.getDialogTag();
        new DialogGenerator(this, mDialogFactory).show();
    }

    /**
     * set onclick save dictionary
     */
    private void setOnClickSave() {
        hideKeyboard(getCurrentFocus());
        if ((TextUtils.isEmpty(mTempDictionaryInfo.getName()) ||
                TextUtils.isEmpty(mTempDictionaryInfo.getName().trim())) && checkCardEmpty()) {
            buildDialogDicValidateNoTitleEmptyCard();
        } else if (TextUtils.isEmpty(mTempDictionaryInfo.getName()) ||
                TextUtils.isEmpty(mTempDictionaryInfo.getName().trim())) {
            buildDialogDicValidateNoTitle();
        } else if (checkCardEmpty()) {
            buildDialogDicValidateEmptyCard();
        } else if (mTempDictionaryInfo.getCardList().size() == 0) {
            buildDialogDicNoCard();
        } else {
            AppController.getInstance().getAssistServerInterface().addDictionary(mTempDictionaryInfo, this);
        }
    }

    /**
     * back screen previous
     */
    private void goBackScreen() {
        Bundle bundle = new Bundle();
        bundle.putString(Constants.Dictionary.KEY_TYPE_CATEGORY, String.valueOf(mCategoryInfo.getCategoryId()));
        backScreenResult(this, bundle, Constants.Dictionary.REQUEST_CODE_DIC_CREATE);
    }

}
