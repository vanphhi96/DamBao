/*
 * ファイル：CustomSampleDialogFactory.java
 * 概要：カスタムダイアログサンプルFactoryクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
// TODO: 2019/01/30 このファイルはテストのため、後で消す/ This file is just for test, delete later.

package jp.softbank.assist.view.dialog.factories.customfactories;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl.DialogType;

/**
 * カスタムダイアログサンプル
 *
 * @author Systena
 * @version 1.0
 */
public class CustomSampleDialogFactory extends BaseDialogFactory implements View.OnClickListener {

    private DialogType mDialogType;

    /**
     * コンストラクタ
     *
     * @param dialogType ダイアログ種別
     */
    public CustomSampleDialogFactory(DialogType dialogType) {
        this.mDialogType = dialogType;
    }

    private ImageView mImage;
    private TextView mText;
    private int mBtnColor;

    public int getBtnColor() {
        return mBtnColor;
    }

    public void setBtnColor(int color) {
        this.mBtnColor = color;
    }

    /**
     * ダイアログ設定
     *
     * @param activity ダイアログ表示するActivity
     */
    @Override
    public AlertDialog getReadyAlertDialog(FragmentActivity activity) {

        AlertDialog.Builder builder = createDialogBuilder(activity);
        LayoutInflater inflater = activity.getLayoutInflater();
        final View view = inflater.inflate(R.layout.assist_custom_sample_dialog, null);
        setPositivelyDialog(false);
        builder.setView(view);

        mImage = (ImageView) view.findViewById(R.id.color_select_Image);
        mImage.setBackgroundColor(getBtnColor());
        mText = (TextView) view.findViewById(R.id.text_ib_title);
        view.findViewById(R.id.colorSelectButton1).setOnClickListener(this);
        view.findViewById(R.id.colorSelectButton2).setOnClickListener(this);
        view.findViewById(R.id.colorSelectButton3).setOnClickListener(this);
        view.findViewById(R.id.colorSelectButton4).setOnClickListener(this);

        if (activity instanceof DialogInterface.OnClickListener) {
            builder.setNegativeButton(R.string.cancel,
                    (DialogInterface.OnClickListener) activity);
            builder.setNeutralButton("default",
                    (DialogInterface.OnClickListener) activity);
            builder.setPositiveButton(R.string.ok,
                    (DialogInterface.OnClickListener) activity);
        }
        return builder.create();
    }

    /**
     * ダイアログ上onClick処理
     *
     * @param view メッセージ種別
     */
    @Override
    public void onClick(View view) {

        ColorDrawable background = (ColorDrawable) view.getBackground();
        mBtnColor = background.getColor();
        mImage.setBackgroundColor(mBtnColor);
        mText.setText("Please Press OK");
    }

    /**
     * ダイアログ名取得処理
     *
     * @return String ダイアログ名
     */
    @Override
    public String getDialogTag() {
        return mDialogType.name();
    }

}
