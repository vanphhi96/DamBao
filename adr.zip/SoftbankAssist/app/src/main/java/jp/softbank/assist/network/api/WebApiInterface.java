/*
 * ファイル：WebApiInterface.java
 * 概要：http(s)を使用した通信を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.api;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import jp.softbank.assist.network.json.dictionary.DeleteDictionaryRequest;
import jp.softbank.assist.network.json.dictionary.GetCategoriesParam;
import jp.softbank.assist.network.json.dictionary.SynchronizeDictionaryParam;

/**
 * 通信用クラス.
 *
 * @author Systena
 * @version 1.0
 */
public class WebApiInterface {

    private static final String BASE_URL = "https://assistguide.mb.softbank.jp/";

    public enum Api {
        // schedule
        GET_SCHEDULE_LIST(1), // 1.スケジュール取得（期間指定）
        COUNT_SCHEDULE_LIST(3), // 3.スケジュール件数の取得
        COMPLETE_SCHEDULE(4), // 4.スケジュール終了
        DELETE_SCHEDULE(5), // 5.スケジュール削除
        ADD_SCHEDULE(6), // 6.スケジュール追加
        EDIT_SCHEDULE(7), // 7.スケジュール編集

        // dictionary
        GET_CATEGORY_LIST(11), // 1.カテゴリ情報取得
        DELETE_DICTIONARY(12), // 2.辞書削除
        ADD_DICTIONARY(13), // 3.辞書追加
        EDIT_DICTIONARY(14), // 4.辞書編集
        GET_SYNC_DICTIONARY_LIST(17), // 7.辞書取得（差分）

        // location
        REGIST_USER_LOCATION(22), // 2.ユーザ位置登録

        // history
        GET_HISTORY_LIST_HTML(31), // 1.操作履歴取得

        // notice
        GET_NOTICE_LIST(41), // 1.お知らせ一覧取得

        // setting
        REGIST_DEVICE_INFO(51), // 1.端末トークン登録
        GET_APP_VERSION(52), // 2.最新アプリバージョン取得
        SET_LOCATION_SETTING(53), // 3.位置情報送出の拒否許可設定

        // user
        REGIST_USER_INFO(61), // 1.ユーザ登録
        UPDATE_USER_INFO(62), // 2.ユーザ情報編集
        GET_USER_INFO(63), // 3.ユーザ情報取得
        // 6.紐づけ情報仮登録（利用者から管理者）
        // 7.紐づけ本登録

        ;

        private final int mValue;

        private Api(int value) {
            this.mValue = value;
        }
        public int getValue() {
            return this.mValue;
        }

    }

    public interface WebApiLinstener {
        public void onSuccessWebApi(String response);
        public void onErrorWebApi(int status, byte[] response);
    }

    private static WebApiInterface sInstance;
    protected final Context mCtx;
    private RequestQueue mRequestQueue;

    protected WebApiInterface(Context ctx) {
        this.mCtx = ctx;
        mRequestQueue = Volley.newRequestQueue(ctx.getApplicationContext());
    }

    public static WebApiInterface getInstance(Context ctx) {
        if (sInstance == null) {
//            sInstance = new WebApiInterface(ctx);
            sInstance = new WebApiInterfaceDebug(ctx);
        }
        return sInstance;
    }

    public boolean getCategories(final String access_token, final GetCategoriesParam params, final WebApiLinstener listener) {
        // TODO:テスト用
        String url ="https://www.google.co.jp/";

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (null != listener) {
                            listener.onSuccessWebApi(response);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (null != listener) {
                            listener.onErrorWebApi(error.networkResponse.statusCode, error.networkResponse.data);
                        }
                    }
                });

        // Add the request to the RequestQueue.
        mRequestQueue.add(stringRequest);

        return true;
    }

    public boolean deleteDictionary(final String access_token, final DeleteDictionaryRequest body, final WebApiLinstener listener) {
        return true;
    }

    public boolean getSyncDictionaryList(final String access_token, final SynchronizeDictionaryParam params, final WebApiLinstener listener) {
        return true;
    }
}
