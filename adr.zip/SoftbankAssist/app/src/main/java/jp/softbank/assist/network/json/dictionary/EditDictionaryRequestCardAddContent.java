/*
 * ファイル：EditDictionaryRequestCardAddContent.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

/**
 * カード追加内容情報.
 */
public class EditDictionaryRequestCardAddContent {

    @SerializedName("mText")
    private String mText = null;
    @SerializedName("image")
    private String mImage = null;


    /**
     * カードテキスト.
     */
    public String getText() {
        return mText;
    }
    public void setText(String text) {
        this.mText = text;
    }

    /**
     * カード画像（base64形式　ファイル拡張子：jpg、jpeg、png　最大ファイルサイズ：2.5MB）.
     */
    public String getImage() {
        return mImage;
    }
    public void setImage(String image) {
        this.mImage = image;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EditDictionaryRequestCardAddContent cardAddContent = (EditDictionaryRequestCardAddContent) o;
        return (this.mText == null ? cardAddContent.mText == null : this.mText.equals(cardAddContent.mText)) &&
                (this.mImage == null ? cardAddContent.mImage == null : this.mImage.equals(cardAddContent.mImage));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mText == null ? 0: this.mText.hashCode());
        result = 31 * result + (this.mImage == null ? 0: this.mImage.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class EditDictionaryRequestCardAddContent {\n");

        sb.append("  mText: ").append(mText).append("\n");
        sb.append("  mImage: ").append(mImage).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
