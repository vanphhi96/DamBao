/*
 * ファイル：ISchDictionaryDelete.java
 * 概要：interface for schedule dictionary change pager adapter.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.activity.schedule;

/**
 * @author Systena
 * @version 1.0
 */
public interface ISchDictionaryDelete {
    /**
     * onclick button delete dic
     */
    void deleteDictionary();
}
