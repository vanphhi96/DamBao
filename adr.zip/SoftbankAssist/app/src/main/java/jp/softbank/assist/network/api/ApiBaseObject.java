/*
 * ファイル：ApiBaseObject.java
 * 概要：リクエスト用オブジェクト
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.api;

import android.os.Handler;

import jp.softbank.assist.network.json.ErrorResult;
import jp.softbank.assist.network.listener.BaseResultListener;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * リクエスト用ベースクラス.
 */
public abstract class ApiBaseObject implements WebApiInterface.WebApiLinstener {

    private static long START_SEQ_NO = 1L;
    private static long END_SEQ_NO = 100000L;
    private static long sSeqNo = START_SEQ_NO;

    protected long mSeqNo;
    protected String mAccessToken;
    protected ErrorResult mError;
    protected int mStatusCode;
    protected List<BaseResultListener> mCallbacks;
    protected Handler mHandler;


    /**
     * コンストラクタ.
     */
    protected ApiBaseObject() {
        mCallbacks = new ArrayList<BaseResultListener>();
    }

    /**
     * 次のシーケンス番号を取得する.
     *
     * @return シーケンス番号
     */
    protected static long nextSeqNo() {
        sSeqNo++;
        if (sSeqNo > END_SEQ_NO) {
            sSeqNo = START_SEQ_NO;
        }
        return sSeqNo;
    }

    /**
     * コールバックの関連付け.
     *
     * @param listener BaseResultListener
     */
    public void addCallback(BaseResultListener listener) {
        mCallbacks.add(listener);
    }

    /**
     * UI向け処理の登録.
     */
    protected void registPostProcess() {
        if (null != mHandler) {
            mHandler.sendMessage(
                    mHandler.obtainMessage(getApi().getValue(), this));
        }
    }

    /**
     * 接続開始前通知.
     */
    protected void notifyStartConnection() {
        Iterator<BaseResultListener> ite = mCallbacks.iterator();
        while (ite.hasNext()) {
            BaseResultListener temp = ite.next();
            temp.onStartConnection();
        }
    }

    public abstract WebApiInterface.Api getApi();
    public abstract void asyncProcess(WebApiInterface webApiIf);
    public abstract void resultSuccess(String response);
    public abstract void resultError(int status, byte[] response);
    public abstract void postProcess();

    /**
     * 通信成功時のイベント.
     *
     * @param response レスポンスデータ
     */
    @Override
    public void onSuccessWebApi(String response) {
        resultSuccess(response);
        registPostProcess();
    }

    /**
     * 通信失敗時のイベント.
     *
     * @param status HTTPステータスコード
     * @param response レスポンスデータ
     */
    @Override
    public void onErrorWebApi(int status, byte[] response) {
        resultError(status, response);
        registPostProcess();
    }
}
