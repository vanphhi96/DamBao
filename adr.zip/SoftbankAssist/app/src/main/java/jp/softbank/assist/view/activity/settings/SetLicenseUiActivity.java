/*
 * ファイル：SetLicenseUiActivity.java
 * 概要：Screen license.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.settings;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.view.activity.BaseUiActivity;

import java.io.IOException;
import java.io.InputStream;

/**
 * set-lic-01.
 *
 * @author Systena
 * @version 1.0
 */
public class SetLicenseUiActivity extends BaseUiActivity implements View.OnClickListener {
    private TextView mTvLicense;
    private LinearLayout mLnBack;
    private final String LICENSE_PATH = "license/license.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_license);
        mTvLicense = findViewById(R.id.tv_license);
        mLnBack = findViewById(R.id.ln_back);
        mTvLicense.setText(getLicense());
        mLnBack.setOnClickListener(this);
    }

    /**
     * get data from license.txt in asset folder
     *
     * @return string license.
     */
    private String getLicense() {
        try {
            InputStream inputStream = getAssets().open(LICENSE_PATH);
            int license = inputStream.available();
            byte[] buffer = new byte[license];
            inputStream.read(buffer);
            inputStream.close();
            return new String(buffer);
        } catch (IOException e) {
            AssistLog.e(e.toString());
        }
        return null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ln_back:
                onBackPressed();
                break;
            default:
                break;
        }
    }
}

