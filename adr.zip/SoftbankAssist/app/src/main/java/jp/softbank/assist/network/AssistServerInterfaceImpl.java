/*
 * ファイル：AssistServerInterfaceImpl.java
 * 概要：アシストサーバー向けのI/Fを提供する
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network;

import android.content.Context;
import android.util.SparseLongArray;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.model.database.LocationInfo;
import jp.softbank.assist.model.database.LocationSettings;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.model.database.UserInfo;
import jp.softbank.assist.network.api.ApiDeleteDictionary;
import jp.softbank.assist.network.listener.CountScheduleResultListener;
import jp.softbank.assist.network.listener.GetAppVersionResultListener;
import jp.softbank.assist.network.listener.GetDictionaryListResultListener;
import jp.softbank.assist.network.listener.GetHistoryResultListener;
import jp.softbank.assist.network.listener.GetImageResultListener;
import jp.softbank.assist.network.listener.GetNoticeResultListener;
import jp.softbank.assist.network.listener.GetScheduleListResultListener;
import jp.softbank.assist.network.listener.GetUserInfoResultListener;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.Constants;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * アシストサーバー向けI/Fクラスの実装.
 *
 * @author Systena
 * @version 1.0
 */
class AssistServerInterfaceImpl extends AssistServerInterface {

    /**
     * コンストラクタ.
     */
    AssistServerInterfaceImpl(Context ctx) {
        super(ctx);
    }

//    /**
//     * 辞書カテゴリ一覧取得.
//     *
//     * @param listener コールバックリスナ
//     */
//    @Override
//    public void getCategoryList(final GetCategoryListResultListener listener) {
//    }

    /**
     * 辞書カテゴリ一覧取得.
     *
     * @return カテゴリ情報一覧
     */
    @Override
    public List<CategoryInfo> getCategoryList() {

        List<CategoryInfo> list = new ArrayList<CategoryInfo>();

        CategoryInfo info = new CategoryInfo();
        info.setCategoryId(Constants.Ids.CATEGORY_ID_HOW_TO_DO);
        info.setName(getAppContext().getString(R.string.how_to_do));
        info.setCount(6); // TODO:DBから辞書数を取得する
        list.add(info);

        info = new CategoryInfo();
        info.setCategoryId(Constants.Ids.CATEGORY_ID_HOW_TO_GO);
        info.setName(getAppContext().getString(R.string.how_to_go));
        info.setCount(7); // TODO:DBから辞書数を取得する
        list.add(info);

        info = new CategoryInfo();
        info.setCategoryId(Constants.Ids.CATEGORY_ID_PROPERTY);
        info.setName(getAppContext().getString(R.string.belongings));
        info.setCount(8); // TODO:DBから辞書数を取得する
        list.add(info);

        return list;
    }

    /**
     * 辞書差分一覧取得.
     */
    @Override
    public void getDifferenceListDictionary() {
        // TODO:Run in the background. No notification to UI.
    }

    /**
     * カテゴリ別辞書一覧取得.
     *
     * @param categoryId カテゴリID
     * @param listener   コールバックリスナ
     */
    @Override
    public void getDictionaryList(final long categoryId, final GetDictionaryListResultListener listener) {

    }

    /**
     * 辞書登録.
     *
     * @param info     辞書情報
     * @param listener コールバックリスナ
     */
    @Override
    public void addDictionary(final DictionaryInfo info, final NotifyOnlyResultListener listener) {

    }

    /**
     * 辞書編集.
     *
     * @param info     辞書情報
     * @param listener コールバックリスナ
     */
    @Override
    public void editDictionary(final DictionaryInfo info, final NotifyOnlyResultListener listener) {

    }

    /**
     * 辞書削除.
     *
     * @param dictionaryId 辞書ID
     * @param listener     コールバックリスナ
     */
    @Override
    public void deleteDictionary(final long dictionaryId, final NotifyOnlyResultListener listener) {
        AssistLog.d("[ASI_DBG] deleteDictionary start");

        ApiDeleteDictionary api = ApiDeleteDictionary.newInstance(getHandler(),
                getAccessToken(), getUserId(), dictionaryId, listener);

        addQueue(api);

        AssistLog.d("[ASI_DBG] deleteDictionary end");
    }

    /**
     * 辞書画像取得.
     *
     * @param dictionaryId 辞書ID
     * @param listener     コールバックリスナ
     */
    @Override
    public void getDictionaryImage(final long dictionaryId, final GetImageResultListener listener) {

    }

    /**
     * カード画像取得.
     *
     * @param cardInfo   辞書
     * @param listener コールバックリスナ
     */
    @Override
    public void getCardImage(final CardInfo cardInfo, final GetImageResultListener listener) {

    }

    /**
     * 辞書の並び替えを保存.
     *
     * @param list 辞書一覧
     */
    @Override
    public void saveDictionaryOrder(final List<DictionaryInfo> list) {
        // TODO:Save to DB
    }

    /**
     * 辞書の並び替えを保存.
     *
     * @param categoryId カテゴリID
     * @param idArray    辞書ID配列
     */
    @Override
    public void saveDictionaryOrder(final long categoryId, final SparseLongArray idArray) {
        // TODO:Save to DB
    }

    /**
     * スケジュール同期.
     */
    @Override
    public void syncScheduleList() {
        // TODO:Run in the background. No notification to UI.
    }

    /**
     * スケジュール取得（日付指定）.
     *
     * @param date     日付
     * @param listener コールバックリスナ
     */
    @Override
    public void getScheduleList(final Date date, final GetScheduleListResultListener listener) {

    }

    /**
     * スケジュール追加.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    @Override
    public void addSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener) {

    }

    /**
     * スケジュール編集.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    @Override
    public void editSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener) {

    }

    /**
     * スケジュール削除.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    @Override
    public void deleteSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener) {

    }

    /**
     * スケジュール完了.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    @Override
    public void completeSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener) {

    }

    /**
     * スケジュール件数の取得.
     *
     * @param yearmonth 年月
     * @param listener  コールバックリスナ
     */
    @Override
    public void countSchedule(final Date yearmonth, final CountScheduleResultListener listener) {

    }

    /**
     * 位置測位結果の送信.
     *
     * @param info 位置測位結果.
     */
    @Override
    public void registLocation(final LocationInfo info) {
        // TODO:Run in the background. No notification to UI.
    }

    /**
     * 操作履歴取得.
     *
     * @param displayPage         表示ページ
     * @param displayCountPerPage ページあたりの表示件数
     * @param listener            コールバックリスナ
     */
    @Override
    public void getHistory(final int displayPage, final int displayCountPerPage, final GetHistoryResultListener listener) {

    }

    /**
     * 最新のお知らせ取得.
     *
     * @param listener コールバックリスナ
     * @deprecated WebViewへ変更
     */
    @Deprecated
    @Override
    public void getLatestNotice(final GetNoticeResultListener listener) {

    }

    /**
     * デバイス情報の登録・更新.
     */
    @Override
    public void registDeviceInfo() {
        // TODO:Run in the background. No notification to UI.
    }

    /**
     * FCMトークン更新.
     *
     * @param token トークン
     */
    @Override
    public void updateFcmToken(final String token) {
        // TODO:Save to DB
    }

    /**
     * 最新のアプリバージョン取得.
     *
     * @param listener コールバックリスナ
     */
    @Override
    public void getLatestAppVersion(final GetAppVersionResultListener listener) {

    }

    /**
     * 位置情報更新可否設定の取得.
     *
     * @return LocationSettings
     */
    @Override
    public LocationSettings getLocationSettings() {
        LocationSettings settings = new LocationSettings();
        // TODO:Load from DB
        return settings;
    }

    /**
     * 位置情報更新可否設定の更新.
     *
     * @param settings 設定値
     */
    @Override
    public void setLocationSettings(final LocationSettings settings) {
        // TODO:Save to DB
    }

    /**
     * 位置情報更新可否設定の送信.
     */
    @Override
    public void sendLocationSettings(final LocationSettings settings, final NotifyOnlyResultListener listener) {
        // TODO:Run in the background. No notification to UI.
    }

    /**
     * 最新の利用者情報取得.
     *
     * @param listener コールバックリスナ
     */
    @Override
    public void getLatestUserInfo(final GetUserInfoResultListener listener) {

    }

    /**
     * 利用者情報の更新.
     *
     * @param info 利用者情報
     * @param listener コールバックリスナ
     */
    @Override
    public void editUserInfo(final UserInfo info, final NotifyOnlyResultListener listener) {

    }

    /**
     * 自身の利用者アイコンIDの取得.
     *
     * @return 利用者アイコンID（0:未設定もしくは初期設定未完了）
     */
    @Override
    public int getMyUserIcon() {
        // TODO:Get from DB
        return 1;
    }
}
