/*
 * ファイル：GetScheduleParam.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.schedule;

import jp.softbank.assist.network.json.RequestParam;

import java.util.Date;

/**
 * スケジュール取得パラメータ.
 */
public class GetScheduleParam extends RequestParam {

    private Long mUserId;
    private Date mStartDate;
    private Date mEndDate;


    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * 開始日(YYYYMMDD).
     */
    public Date getStartDate() {
        return mStartDate;
    }
    public void setStartDate(Date startDate) {
        this.mStartDate = startDate;
    }

    /**
     * 終了日(YYYYMMDD),
     */
    public Date getEndDate() {
        return mEndDate;
    }
    public void setEndDate(Date endDate) {
        this.mEndDate = endDate;
    }
}
