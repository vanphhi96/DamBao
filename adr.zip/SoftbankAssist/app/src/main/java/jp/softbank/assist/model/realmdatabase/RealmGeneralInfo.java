/*
 * ファイル：RealmGeneralInfo.java
 * 概要：Realm用共通情報テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Realm用共通情報テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmGeneralInfo extends RealmObject {

    @PrimaryKey
    private String mKey; // key
    private String mValue;  // 値

    public String getKey() {
        return mKey;
    }

    public void setKey(String mKey) {
        this.mKey = mKey;
    }

    public String getValue() {
        return mValue;
    }

    public void setValue(String mValue) {
        this.mValue = mValue;
    }

}
