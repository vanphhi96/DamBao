/*
 * ファイル：EditCardInfo.java
 * 概要：辞書カード情報（編集時）
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import android.graphics.Bitmap;
import android.text.TextUtils;

import jp.softbank.assist.model.ModelInterface;
import jp.softbank.assist.util.Constants;

import java.io.File;
import java.util.Date;

/**
 * 辞書カード情報（編集時）.
 *
 * @author Systena
 * @version 1.0
 */
public class EditCardInfo extends CardInfo {

    private final CardInfo mOrigin;
    private boolean mEdited = false; // TODO:unused


    EditCardInfo(CardInfo info) {
        setCardId(info.getCardId());
        setDictionaryId(info.getDictionaryId());
        setNextCardId(info.getNextCardId());
        setImageUrl(info.getImageUrl());
        setImageFileName(info.getImageFileName());
        setText(info.getText());
        setCreatedDate((Date)info.getCreatedDate().clone());
        setUpdatedDate((Date)info.getUpdatedDate().clone());
        setIsDeleted(info.isDeleted());

        mOrigin = info;
        mEdited = false;
    }

    @Override
    public void setText(String text) {
        super.setText(text);
        mEdited = true;
    }



    /**
     * 編集済みか確認する.
     *
     * @return true:編集済み、false:未編集
     */
    @Override
    public boolean isEdited() {
        if (mOrigin == null) {
            return false; // あり得ないエラー
        }

        if (!TextUtils.equals(getText(), mOrigin.getText())) {
            return true;
        }
        if (!TextUtils.equals(getImageUrl(), mOrigin.getImageUrl())) {
            return true;
        }
        if (!TextUtils.equals(getImageFileName(), mOrigin.getImageFileName())) {
            return true;
        }
        return false;
    }

    /**
     * 追加・編集時のキャンセル.
     */
    @Override
    public void cancel() {
        getImagePath(Constants.Dictionary.getEditCardFileName(getCardId())).delete();
    }

    /**
     * 画像ファイルが有効（保存済み）か確認する.
     *
     * @return true:有効、false:無効
     */
    @Override
    public boolean isImageEnabled() {
        return Constants.Dictionary.getEditCardFileName(getCardId()).equals(getImageFileName()) ||
                Constants.Dictionary.getCardFileName(getCardId()).equals(getImageFileName());
    }

    /**
     * 画像の保存.
     *
     * @param bitmap ビットマップ
     * @return true:成功、false:失敗
     */
    @Override
    public boolean setImage(Bitmap bitmap) {
        bitmap = ModelInterface.scaleDictionaryImage(bitmap);
        boolean result = ModelInterface.saveDictionaryImage(bitmap,
                getImagePath(Constants.Dictionary.getEditCardFileName(getCardId())));
        if (result) {
            setImageFileName(Constants.Dictionary.getEditCardFileName(getCardId()));
            mEdited = true;
        }
        return result;
    }

    /**
     * 画像設定の削除.
     */
    @Override
    public void clearImage() {
        getImagePath(Constants.Dictionary.getEditCardFileName(getCardId())).delete();
        setImageUrl("");
        setImageFileName("");
        mEdited = true;
    }

    /**
     * 画像ファイルパスの取得.
     *
     * @return ファイルパス
     */
    @Override
    public String getImageFileAbsolutePath() {
        if (isImageEnabled()) {
            File file = getImagePath(getImageFileName());
            if (file.exists()) {
                return file.getAbsolutePath();
            }
        }
        return null;
    }
}
