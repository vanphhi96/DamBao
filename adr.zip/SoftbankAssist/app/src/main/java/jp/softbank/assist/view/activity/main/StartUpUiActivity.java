/*
 * ファイル：StartUpUiActivity.java
 * 概要：起動時スプラッシュ画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.main;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;

/**
 * 起動時スプラッシュ
 *
 * @author Systena
 * @version 1.0
 */
public class StartUpUiActivity extends BaseUiActivity {

    @Override
    protected void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        AssistLog.d("StartUpUiActivity onCreate");

        if (intent != null) {
            // NOTIFICATION_BUNDLE_KEYでデータ取得できた場合、Notificationからの起動と判定
            // スプラッシュ画面は表示せず、今日の予定画面へ遷移する
            Bundle bundle = intent.getBundleExtra(Constants.NotificationControl.NOTIFICATION_BUNDLE_KEY);
            if (bundle != null) {
                AssistLog.d("bundle OK");
                long schduleId = bundle.getLong(Constants.TimerControl.SCHEDULE_ID);
                changeScreen(ScreenId.START_MENU);
                finishActivity();
            }
        }
        // スプラッシュ用のビューを取得する
        setContentView(R.layout.activity_startup);
        updateTokenCallback();

        // 2秒したらMainActivityを呼び出してSplashActivityを終了する
        LinearLayout linearLayout = findViewById(R.id.linear_layout_container);
        Animation splashAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.splash_animation);
        linearLayout.startAnimation(splashAnimation);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                changeScreen(ScreenId.START_CHECK_APP);
                finish();
            }
        }, Constants.Tab.SPLASH_TIME_OUT);
    }

    /**
     * FCMトークン更新 Callback.
     */
    private void updateTokenCallback() {
        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(StartUpUiActivity.this, new OnSuccessListener<InstanceIdResult>() {
            @Override
            public void onSuccess(InstanceIdResult instanceIdResult) {
                String newToken = instanceIdResult.getToken();
                AppController.getInstance().getAssistServerInterface().updateFcmToken(newToken);
            }
        });
    }
}



