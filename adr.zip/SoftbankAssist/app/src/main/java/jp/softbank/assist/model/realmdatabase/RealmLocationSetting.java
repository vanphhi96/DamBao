/*
 * ファイル：RealmLocationSetting.java
 * 概要：Realm位置更新可否設定テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import java.util.Date;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Realm位置更新可否設定テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmLocationSetting extends RealmObject {

    @PrimaryKey
    private int mId; //位置設定
    private boolean mIsSendSettingOn; // 設定送信状態
    private boolean mIsRequestLocationOn; // リクエスト位置取得
    private boolean mIsRegularLocationOn; // 定期位置取得
    private Date mRegularStartTime; // 定期位置取得開始時刻
    private Date mRegularEndTime; // 定期位置取得終了時刻
    private boolean mIsFenceLocationOn; // みまもるフェンス
    private long mType; // 定期位置取得期間種別


    public int getId() {
        return mId;
    }

    public void setId(int mId) {
        this.mId = mId;
    }

    public boolean isSendSetting() {
        return mIsSendSettingOn;
    }

    public void setIsSendSetting(boolean mSendSettingOn) {
        this.mIsSendSettingOn = mSendSettingOn;
    }

    public boolean isRequestLocation() {
        return mIsRequestLocationOn;
    }

    public void setIsRequestLocation(boolean mRequestLocationOn) {
        this.mIsRequestLocationOn = mRequestLocationOn;
    }

    public boolean isRegularLocation() {
        return mIsRegularLocationOn;
    }

    public void setIsRegularLocation(boolean mRegularLocationOn) {
        this.mIsRegularLocationOn = mRegularLocationOn;
    }

    public long getType() {
        return mType;
    }

    public void setType(long type) {
        this.mType = type;
    }

    public Date getRegularStartTime() {
        return mRegularStartTime;
    }

    public void setRegularStartTime(Date mRegularStartTime) {
        this.mRegularStartTime = mRegularStartTime;
    }

    public Date getRegularEndTime() {
        return mRegularEndTime;
    }

    public void setRegularEndTime(Date mRegularEndTime) {
        this.mRegularEndTime = mRegularEndTime;
    }

    public boolean isFenceLocation() {
        return mIsFenceLocationOn;
    }

    public void setIsFenceLocation(boolean mFenceLocationOn) {
        this.mIsFenceLocationOn = mFenceLocationOn;
    }


}
