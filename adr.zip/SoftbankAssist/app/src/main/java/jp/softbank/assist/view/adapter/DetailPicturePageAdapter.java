/*
 * ファイル：DetailPicturePageAdapter.java
 * 概要：adapter page of base detail picture.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.app.Activity;
import android.graphics.Bitmap;
import android.support.v4.view.PagerAdapter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetImageResultListener;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.activity.schedule.ISchDictionaryDetailPicturePageAdapter;

import java.util.List;

/**
 * sch-dic-02, dic-05.
 *
 * @author Systena
 * @version 1.0
 */
public class DetailPicturePageAdapter extends PagerAdapter implements View.OnClickListener, GetImageResultListener {
    private static final int FIRST_PAGE_POSITION = 0;
    private View mViewLeft;
    private View mViewRight;
    private TextView mTvNumber;
    private TextView mTvDescription;
    private CheckBox mCheckBox;
    private List<CardInfo> mListCardInfo;
    private ImageView mImageView;
    private TextView mTvDicNoPic;
    private DictionaryInfo.DictionaryType mDictionaryType = DictionaryInfo.DictionaryType.Step;
    private ProgressBar mProgressBar;
    private Activity mActivity;
    private ISchDictionaryDetailPicturePageAdapter mISchDictionaryDetailPicturePageAdapter;

    public DetailPicturePageAdapter(ISchDictionaryDetailPicturePageAdapter iSchDictionaryDetailPicturePageAdapter,
                                    List<CardInfo> mListCardInfo) {
        this.mISchDictionaryDetailPicturePageAdapter = iSchDictionaryDetailPicturePageAdapter;
        this.mListCardInfo = mListCardInfo;
    }

    /**
     * set Activity, use when runOnUiThread
     *
     * @param activity
     */
    public void setActivity(Activity activity) {
        this.mActivity = activity;
    }

    /**
     * set dictionary type (Step of Check)
     *
     * @param dictionaryType
     */
    public void setDictionaryType(DictionaryInfo.DictionaryType dictionaryType) {
        this.mDictionaryType = dictionaryType;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return getSizeListPicture();
    }

    @Override
    public Object instantiateItem(final ViewGroup parent, final int position) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_detail_picture, parent, false);
        mViewLeft = view.findViewById(R.id.view_left);
        mViewRight = view.findViewById(R.id.view_right);
        mImageView = view.findViewById(R.id.img_schedule);
        mTvDescription = view.findViewById(R.id.tv_description);
        mTvNumber = view.findViewById(R.id.tv_number);
        mTvDicNoPic = view.findViewById(R.id.tv_dic_no_pic);
        mCheckBox = view.findViewById(R.id.checkbox_detail_dic);
        mProgressBar = view.findViewById(R.id.progress_load_imv);

        mProgressBar.setVisibility(View.INVISIBLE);
        enableCheckOrStep(mDictionaryType == DictionaryInfo.DictionaryType.Step);
        if (mListCardInfo != null || !mListCardInfo.isEmpty()) {
            mTvDescription.setText(mListCardInfo.get(position).getText());
            mTvNumber.setText(String.valueOf(position + 1));
            mCheckBox.setChecked(mListCardInfo.get(position).isChecked());
            Bitmap bitmap = ResourcesUtils.getImageFromPath(mListCardInfo.get(position).getImageFileAbsolutePath());
            if (bitmap != null) {
                mImageView.setImageBitmap(bitmap);
                mTvDicNoPic.setVisibility(View.GONE);
            } else if (!mListCardInfo.get(position).isDownloaded() && !TextUtils.isEmpty(mListCardInfo.get(position).getImageUrl())) {
                AppController.getInstance().getAssistServerInterface().getCardImage(mListCardInfo.get(position), this);
                mListCardInfo.get(position).setIsDownloaded(true);
            } else {
                mTvDicNoPic.setVisibility(View.VISIBLE);
            }
        }
        mCheckBox.setClickable(false);
        mViewLeft.setOnClickListener(this);
        mViewRight.setOnClickListener(this);
        parent.addView(view, 0);
        return view;
    }

    /**
     * set enable checkbox or step
     *
     * @param enableStep
     */
    private void enableCheckOrStep(boolean enableStep) {
        mTvNumber.setVisibility(enableStep ? View.VISIBLE : View.INVISIBLE);
        mCheckBox.setVisibility(enableStep ? View.INVISIBLE : View.VISIBLE);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }

    /**
     * position of last page.
     *
     * @return position last page
     */
    public int getLastPagePosition() {
        return getSizeListPicture();
    }

    /**
     * position of fist page.
     *
     * @return position fist page
     */
    public int getFistPagePosition() {
        return FIRST_PAGE_POSITION;
    }

    /**
     * get size list picture of adapter
     *
     * @return int: size mListCardInfo
     */
    private int getSizeListPicture() {
        if (mListCardInfo != null) {
            return mListCardInfo.size();
        }
        return 0;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.view_left:
                mISchDictionaryDetailPicturePageAdapter.previousPage();
                break;
            case R.id.view_right:
                mISchDictionaryDetailPicturePageAdapter.nextPage();
                break;
        }
    }

    @Override
    public void onResult(final AssistServerResult result, final String filepath) {
        if (mActivity != null) {
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (result.mResult == AssistServerResult.Result.Success) {
                        notifyDataSetChanged();
                    }
                    mProgressBar.setVisibility(View.INVISIBLE);
                }
            });
        }
    }

    @Override
    public void onStartConnection() {
        mProgressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

}
