/*
 * ファイル：SetUserPagerFragment.java
 * 概要：利用者設定画面のViewPager Fragment.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment.settings;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import jp.softbank.assist.R;
import jp.softbank.assist.view.adapter.SetUserListIconAdapter;
import jp.softbank.assist.view.fragment.BaseFragment;

import java.util.ArrayList;

/**
 * (set-acc-01/ViewPager用) Fragment
 *
 * @author Systena
 * @version 1.0
 */
public class SetUserPagerFragment extends BaseFragment {
    private static final String LIST_ICON_KEY = "LIST ICON KEY"; // Bundle用
    private static final String FRAGMENT_POSITION_KEY = "FRAGMENT POSITION KEY"; // Bundle用
    private static final int SPAN_COUNT = 4; // Fragment毎の最大アイコンカラム
    private SetUserListIconAdapter mListIconAdapter;
    private RecyclerView mRvListIcon;
    private GridLayoutManager mGridManager;
    private ArrayList<Integer> mIconList = new ArrayList<>();
    private int mFragmentPosition;

    public static SetUserPagerFragment newInstance(ArrayList<Integer> iconList, int position) {
        Bundle args = new Bundle();
        args.putIntegerArrayList(LIST_ICON_KEY, iconList);
        args.putInt(FRAGMENT_POSITION_KEY, position);
        SetUserPagerFragment fragment = new SetUserPagerFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_set_user, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRvListIcon = view.findViewById(R.id.recycler_view_set_user);
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            mIconList = bundle.getIntegerArrayList(LIST_ICON_KEY);
            mFragmentPosition = bundle.getInt(FRAGMENT_POSITION_KEY);
        }

        // AdapterとRecyclerViewを初期化
        mListIconAdapter = new SetUserListIconAdapter(getContext());
        mListIconAdapter.setIconList(mIconList);
        mListIconAdapter.setFragmentPosition(mFragmentPosition);

        mGridManager = new GridLayoutManager(mRvListIcon.getContext(), SPAN_COUNT);
        mRvListIcon.setLayoutManager(mGridManager);
        mRvListIcon.setAdapter(mListIconAdapter);
    }
}
