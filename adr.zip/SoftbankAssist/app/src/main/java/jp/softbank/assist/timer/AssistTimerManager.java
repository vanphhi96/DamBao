/*
 * ファイル：AssistTimerManager.java
 * 概要：タイマ設定時の処理を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.timer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.model.database.TimerInfo;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.DateUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * タイマ管理用クラス.
 *
 * @author Systena
 * @version 1.0
 */
public class AssistTimerManager {

    public AssistTimerManager() {
    }

    /**
     * タイマの設定を行う
     *
     * @param context    Context
     * @param scheduleId スケジュール日時ID
     * @param timerType  タイマ種別 10分前/定刻
     * @param text       Notificationに設定するtext
     * @param title      Notificationに設定するtitle
     * @param timerMilis タイマに設定する時間(ミリ秒)
     * @param type       タイマ設定種別(scheduleId)
     */
    public int timerSetSchedule(Context context, long scheduleId, int timerType,
                                String text, String title, long timerMilis, String type) {

        AssistLog.i("Start");
        int requestCode = AppController.getInstance().getModelInterface().getTimerInfoNumber();

        // Intent設定
        PendingIntent sender = createTimerSchIntent(context, scheduleId, timerType, requestCode,
                text, title, type);
        AlarmManager mng = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        mng.setExactAndAllowWhileIdle(AlarmManager.RTC, timerMilis, sender);
        return requestCode;
    }

    /**
     * タイマをすべてキャンセルする
     *
     * @param context Context
     */
    public void timerCancelAll(Context context) {

        AssistLog.i("Start");

        AlarmManager mng = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        // TimerInfoを全件取得し、登録されているタイマとIntentをキャンセルする
        List<TimerInfo> timerList = AppController.getInstance().getModelInterface().getTimerInfo();
        if (timerList != null && !timerList.isEmpty()) {
            for (TimerInfo info : timerList) {
                Intent intent = new Intent(context, AssistTimerService.class);
                intent.setType(info.getType());
                PendingIntent sender = PendingIntent.getBroadcast(context, info.getRequestCode(), intent, 0);
                mng.cancel(sender);
                sender.cancel();
            }
            AppController.getInstance().getModelInterface().deleteTimerInfoAll();
        }
    }

    /**
     * タイマの設定を行う
     *
     * @param context    Context
     * @param scheduleId スケジュール日時ID
     * @param timerType  タイマ種別 10分前/定刻
     * @param text       Notificationに設定するtext
     * @param title      Notificationに設定するtitle
     * @param type       タイマ設定種別(scheduleId)
     */
    private PendingIntent createTimerSchIntent(Context context, long scheduleId, int timerType, int requestCode,
                                               String text, String title, String type) {
        Bundle bundle = new Bundle();
        bundle.putInt(Constants.TimerControl.TIMER_TYPE, timerType);
        bundle.putLong(Constants.TimerControl.SCHEDULE_ID, scheduleId);
        bundle.putString(Constants.TimerControl.TIMER_NOTIFICATION_TEXT, text);
        bundle.putString(Constants.TimerControl.TIMER_NOTIFICATION_TITLE, title);
        Intent intent = new Intent(context, AssistTimerService.class);
        intent.putExtra(Constants.TimerControl.TIMER_BUNDLE_KEY, bundle);
        intent.setType(type);
        return PendingIntent.getBroadcast(context, requestCode, intent, 0);
    }

    /**
     * スケジュール情報一覧よりタイマの設定を行う
     *
     * @param context Context
     */
    public void timerSetSchedulebyData(Context context) {

        AssistLog.d("Start");

        // スケジュール情報の取得
        List<ScheduleInfo> schInfoList = AppController.getInstance().getModelInterface().getScheduleInfoForTimer();
        AssistLog.i("Schedule Select");
        if (schInfoList != null && !schInfoList.isEmpty()) {
            for (ScheduleInfo info : schInfoList) {
                Date dateNow = DateUtils.getDateNow();
                // 予定開始時間を設定
                Date date10min = DateUtils.getDateAdd(info.getScheduleStartDate(), Calendar.MINUTE,
                        Constants.TimerControl.TIMER_PRE_NOTICE);

                // 予定開始が10分後以降の場合
                if (dateNow.before(date10min)) {
                    // 10分前まで10(TBD)ミリ秒以上の場合、10分前アラームを設定
                    String text = info.getTitle();
                    String title = context.getString(R.string.timer_before_10minute);
                    long timerMillis = DateUtils.getTimerSetMillis(date10min);
                    long scheduleId = info.getScheduleId();

                    String type = String.valueOf(scheduleId);
                    int reqCode = timerSetSchedule(context, scheduleId,
                            Constants.TimerControl.TIMER_SCHEDULE_10MIN,
                            text, title, timerMillis, type);

                    updateTimerInfo(reqCode, type);
                    // 予定開始が10分後いないの場合
                } else if (dateNow.before(info.getScheduleStartDate())) {
                    // 10分前まで10(TBD)ミリ秒以上の場合、10分前アラームを設定
                    String text = info.getTitle();
                    String title = context.getString(R.string.timer_before_ontime);
                    long timerMillis = DateUtils.getTimerSetMillis(info.getScheduleStartDate());
                    long scheduleId = info.getScheduleId();

                    String type = String.valueOf(scheduleId);
                    int reqCode = timerSetSchedule(context, scheduleId,
                            Constants.TimerControl.TIMER_SCHEDULE_ONTIME,
                            text, title, timerMillis, type);

                    updateTimerInfo(reqCode, type);
                } else if (dateNow.after(info.getScheduleStartDate())) {
                    // 予定開始時刻超過※基本的にはありえないはず
                    AssistLog.i("Schedule is over! ScheduleId = [" + String.valueOf(info.getScheduleId()) + "]");
                }
            }
        }
    }

    /**
     * タイマ情報の登録・更新
     *
     * @param reqCode リクエストコード
     * @param type    タイマ設定
     */
    public void updateTimerInfo(int reqCode, String type) {

        TimerInfo timerInfo = new TimerInfo();
        timerInfo.setRequestCode(reqCode);
        timerInfo.setType(type);
        AppController.getInstance().getModelInterface().insUpdTimerInfo(timerInfo);
    }

    /**
     * タイマをすべてキャンセルし、再設定を行う
     *
     * @param context Context
     */
    public void timerReset(Context context) {

        timerCancelAll(context);
        timerSetDateChange(context);
        timerSetSchedulebyData(context);

    }

    private static final int SET_DATECHANGE_MINUTE = 5;

    /**
     * 日付変更タイマ設定
     *
     * @param context Context
     */
    private void timerSetDateChange(Context context) {

        AssistLog.i("Start");
        Date dateTomorrow = DateUtils.getDateAdd(DateUtils.getDateNow(), Calendar.DATE,1);
        Calendar cal = Calendar.getInstance();
        cal.setTime(dateTomorrow);

        // 翌日の00:05を設定
        dateTomorrow = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 0, SET_DATECHANGE_MINUTE, 0).getTime();

        Bundle bundle = new Bundle();
        bundle.putInt(Constants.TimerControl.TIMER_TYPE, Constants.TimerControl.TIMER_DATE_CHANGED);
        Intent intent = new Intent(context, AssistTimerService.class);
        intent.putExtra(Constants.TimerControl.TIMER_BUNDLE_KEY, bundle);
        intent.setType(Constants.TimerControl.TIMER_TYPE_DATE_CHANGED);

        // Intent設定
        PendingIntent sender = PendingIntent.getBroadcast(context, Constants.TimerControl.TIMER_CODE_DATE_CHANGED, intent, 0);
        AlarmManager mng = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        long timerMilis = DateUtils.getTimerSetMillis(dateTomorrow);
        mng.setExactAndAllowWhileIdle(AlarmManager.RTC, timerMilis, sender);

        updateTimerInfo(Constants.TimerControl.TIMER_CODE_DATE_CHANGED, Constants.TimerControl.TIMER_TYPE_DATE_CHANGED);
    }

}
