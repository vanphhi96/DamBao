/*
 * ファイル：SetAboutUiActivity.java
 * 概要：このアプリについて画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.settings;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.BuildConfig;
import jp.softbank.assist.R;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;

/**
 * set-abo-01
 *
 * @author Systena
 * @version 1.0
 */
public class SetAboutUiActivity extends BaseUiActivity implements View.OnClickListener {
    private FrameLayout mFfTermsOfService;
    private FrameLayout mFrAppInfo;
    private FrameLayout mFrPersonalInfoHandling;
    private FrameLayout mFrFrequentlyAskedQuestions;
    private FrameLayout mFrContactUs;
    private LinearLayout mLayoutBack;
    private TextView mTvVersion;
    private FrameLayout mFrLicense;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_about);
        mFfTermsOfService = findViewById(R.id.fr_terms_of_service);
        mFrAppInfo = findViewById(R.id.fr_app_info);
        mFrPersonalInfoHandling = findViewById(R.id.fr_personal_info_handling);
        mFrFrequentlyAskedQuestions = findViewById(R.id.fr_frequently_asked_questions);
        mFrContactUs = findViewById(R.id.fr_contact_us);
        mLayoutBack = findViewById(R.id.ln_back);
        mTvVersion = findViewById(R.id.tv_version);
        mFrLicense = findViewById(R.id.fr_license);

        mTvVersion.setText(BuildConfig.VERSION_NAME);
        mLayoutBack.setOnClickListener(this);
        mFfTermsOfService.setOnClickListener(this);
        mFrAppInfo.setOnClickListener(this);
        mFrPersonalInfoHandling.setOnClickListener(this);
        mFrFrequentlyAskedQuestions.setOnClickListener(this);
        mFrContactUs.setOnClickListener(this);
        mFrLicense.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fr_terms_of_service:
                changeScreen(ScreenId.START_SET_POLICY);
                break;
            case R.id.fr_app_info:
                break;
            case R.id.fr_personal_info_handling:
                changeScreen(ScreenId.START_SET_PERSONAL_INFO);
                break;
            case R.id.fr_frequently_asked_questions:
                changeScreen(ScreenId.START_SET_FAQ);
                break;
            case R.id.fr_contact_us:
                changeScreen(ScreenId.START_SET_CONTACT_US);
                break;
            case R.id.ln_back:
                onBackPressed();
                break;
            case R.id.fr_license:
                changeScreen(ScreenId.START_SET_LICENSE);
                break;
            default:
                break;
        }
    }
}
