/*
 * ファイル：AssistNotificationManager.java
 * 概要：通知の管理を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.notification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;

import com.google.firebase.messaging.RemoteMessage;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.activity.main.MenuUiActivity;

import java.util.Locale;

/**
 * 通知管理用クラス.
 *
 * @author Systena
 * @version 1.0
 */
public class AssistNotificationManager {
    private String mLongitude;
    private String mLatitude;

    // Push通知種別
    private static final String PUSH_TYPE_SCH_ADD = "schedule_add"; // スケジュール追加通知
    private static final String PUSH_TYPE_SCH_MOD = "schedule_mod"; // スケジュール変更通知
    private static final String PUSH_TYPE_SCH_DEL = "schedule_del"; // スケジュール削除通知
    // Notification区別用下一桁定義
    // Notificationを上書きしないために種別ごとにNotifyIdの下一桁を固定値とする
    private static final String NOTIFICATION_TYPE_TIMER = "1";
    private static final String NOTIFICATION_TYPE_SCH_ADD = "2";
    private static final String NOTIFICATION_TYPE_SCH_MOD = "3";
    private static final String NOTIFICATION_TYPE_SCH_DEL = "4";

    private static final int NOTIFICATION_ID_CALC = 8; // NotificationId計算用 桁数

    public AssistNotificationManager() {
    }

    /**
     * サーバーにGps送信
     */
    public void sendGpsToServer() {
        mLongitude = AppController.getInstance().getLocationRecordingManager().getLongitude();
        mLatitude = AppController.getInstance().getLocationRecordingManager().getLatitude();
        // TODO: 2019/02/15 Send GPS Location to server (タン)
    }

    /**
     * Notification 初期化
     */
    public void initNotification(Context context, RemoteMessage remoteMessage) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            String channelId = "assist";
            String channelName = "push";

            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build();
            Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

            NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setLightColor(Color.RED);
            channel.setShowBadge(true);
            channel.enableVibration(true);
            channel.setSound(soundUri, audioAttributes);

            if (manager != null) {
                manager.createNotificationChannel(channel);
            }

            // TODO:PUSH通知からscheduleId取得
            String schaduleIdStr = remoteMessage.getData().get("schedule_id");
            long schaduleId = 0;
            int notificationId = 0;
            if (schaduleIdStr != null) {
                schaduleId = Long.parseLong(schaduleIdStr);
            }

            String type = remoteMessage.getData().get("type");
            if (type != null) {
                switch (type) {
                    case PUSH_TYPE_SCH_ADD:
                        notificationId = getNotifyId(schaduleId, NOTIFICATION_TYPE_SCH_ADD);
                        break;
                    case PUSH_TYPE_SCH_MOD:
                        notificationId = getNotifyId(schaduleId, NOTIFICATION_TYPE_SCH_MOD);
                        break;
                    case PUSH_TYPE_SCH_DEL:
                        notificationId = getNotifyId(schaduleId, NOTIFICATION_TYPE_SCH_DEL);
                        break;
                    default:
                        break;

                }
            }

            Notification notification = new NotificationCompat.Builder(context.getApplicationContext(), channelId)
                    .setSmallIcon(R.drawable.ic_tab_schedule)
                    .setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                    .setContentTitle(remoteMessage.getData().get("text"))
                    .setContentText(remoteMessage.getData().get("title"))
                    .setSound(soundUri)
                    .setChannelId(channelId)
                    .setAutoCancel(true)
                    .build();
            manager.notify(notificationId, notification);
        }
    }

    /**
     * Notification設定(Timer契機による通知)
     *
     * @param context context
     * @param bundle  パラメータ
     */
    public void sendNotificationByTimer(Context context, Bundle bundle) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelId = "assist";
            String channelName = "timer";

            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build();
            Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

            NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setLightColor(Color.RED);
            channel.setShowBadge(true);
            channel.enableVibration(true);
            channel.setSound(soundUri, audioAttributes);

            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
            String text = bundle.getString(Constants.TimerControl.TIMER_NOTIFICATION_TEXT);
            String title = bundle.getString(Constants.TimerControl.TIMER_NOTIFICATION_TITLE);
            long schaduleId = bundle.getLong(Constants.TimerControl.SCHEDULE_ID);

            Intent intent = new Intent(context, MenuUiActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);

            intent.putExtra(Constants.NotificationControl.NOTIFICATION_BUNDLE_KEY, bundle);
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

            Notification notification = new NotificationCompat.Builder(context.getApplicationContext(), channelId)
                    .setSmallIcon(R.drawable.ic_tab_schedule)
                    .setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                    .setContentTitle(text)
                    .setContentText(title)
                    .setChannelId(channelId)
                    .setExtras(bundle)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .build();
            manager.notify(getNotifyId(schaduleId, NOTIFICATION_TYPE_TIMER), notification);
        }
    }

    /**
     * NotificationId取得(スケジュールIdより算出)
     *
     * @param scheduleId スケジュールID
     * @param suffix     notificationId作成用
     */
    private int getNotifyId(long scheduleId, String suffix) {
        String id = String.format(Locale.JAPAN, "%08d", scheduleId);
        if (id.length() > NOTIFICATION_ID_CALC) {
            id = id.substring(id.length() - NOTIFICATION_ID_CALC);
        }
        return Integer.parseInt(id + suffix);
    }
}
