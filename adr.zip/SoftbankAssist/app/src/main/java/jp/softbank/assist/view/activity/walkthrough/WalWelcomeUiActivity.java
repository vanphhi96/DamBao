/*
 * ファイル：WalWelcomeUiActivity.java
 * 概要：Welcomeページ画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.walkthrough;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.fragment.walkthrough.WalkWelcomeUiFragmentOne;
import jp.softbank.assist.view.fragment.walkthrough.WalkWelcomeUiFragmentTwo;
import jp.softbank.assist.view.ScreenId;

import java.util.ArrayList;
import java.util.List;

/**
 * wal-01
 *
 * @author Systena
 * @version 1.0
 */
public class WalWelcomeUiActivity extends BaseUiActivity implements View.OnClickListener, ViewPager.OnPageChangeListener {
    private ViewPager mViewPager;
    private TextView mTextView;
    private List<Fragment> mFragmentsList = new ArrayList<>();
    private WelcomeAdapter mWelcomeAdapter;
    private LinearLayout mLlDots;
    private ImageView[] mImgDots;
    private int mDotsCount;

    @Override
    protected void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wal_welcome);
        initView();
        handleDots();
        initFragments();
        setUpViewPager();
    }

    /**
     * View 初期化
     */
    private void initView() {
        mTextView = findViewById(R.id.text_view_start_WELCOME);
        mLlDots = findViewById(R.id.linear_layout_slider_dots);
        mTextView.setOnClickListener(this);
    }

    /**
     * ドット対応
     */
    private void handleDots() {
        mDotsCount = Constants.Tab.TAB_ITEM_NUMBER_WELCOME;
        mImgDots = new ImageView[mDotsCount];
        for (int i = 0; i < mDotsCount; i++) {
            mImgDots[i] = new ImageView(this);
            mImgDots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_active_dot));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(8, 0, 8, 0);
            mLlDots.addView(mImgDots[i], params);
        }
        mImgDots[0].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));
    }

    /**
     * ViewPager　初期化
     */
    private void setUpViewPager() {
        mViewPager = findViewById(R.id.view_pager_wal01);
        mViewPager.addOnPageChangeListener(this);
        mViewPager.setOffscreenPageLimit(Constants.Tab.TAB_ITEM_NUMBER_WELCOME);
        mWelcomeAdapter = new WelcomeAdapter(getSupportFragmentManager(), mFragmentsList);
        mViewPager.setAdapter(mWelcomeAdapter);
    }

    /**
     * Fragment初期化
     */
    private void initFragments() {
        mFragmentsList.add(new WalkWelcomeUiFragmentOne());
        mFragmentsList.add(new WalkWelcomeUiFragmentTwo());
    }

    @Override
    public void onClick(View v) {
        changeScreen(ScreenId.START_MENU);
        finishActivity();
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        for (int i = 0; i < mDotsCount; i++) {
            mImgDots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_active_dot));
        }
        mImgDots[position].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    /**
     * PagerAdapter初期化
     */
    private class WelcomeAdapter extends FragmentStatePagerAdapter {
        private List<Fragment> mFragments;

        WelcomeAdapter(FragmentManager fm, List<Fragment> fragmentList) {
            super(fm);
            mFragments = fragmentList;
        }

        @Override
        public Fragment getItem(int position) {
            return mFragments.get(position);
        }

        @Override
        public int getCount() {
            return Constants.Tab.TAB_ITEM_NUMBER_WELCOME;
        }
    }
}
