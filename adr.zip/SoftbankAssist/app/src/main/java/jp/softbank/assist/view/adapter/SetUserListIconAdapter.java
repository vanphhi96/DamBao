/*
 * ファイル：SetUserListIconAdapter.java
 * 概要：利用者設定画面のRecyclerView Adapter.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import jp.softbank.assist.R;
import jp.softbank.assist.view.activity.settings.ISetOnIconItemClick;

import java.util.ArrayList;


/**
 * (set-acc-01/RecyclerView用) Adapter
 *
 * @author Systena
 * @version 1.0
 */
public class SetUserListIconAdapter extends RecyclerView.Adapter<SetUserListIconAdapter.SetUserListViewHolder> {

    // Fragmentが消える時、Adapterの返却がNullになるので staticを使う.
    private static int sSelectedPosition = -1; // Positionが0から始めるので -1 を初期化
    private static int sFragmentPosition = 0;
    private Context mContext;
    private ArrayList<Integer> mIconList;
    private ISetOnIconItemClick mISetOnIconItemClick;
    private int mFragmentPosition;


    public SetUserListIconAdapter(Context context) {
        mContext = context;
        mISetOnIconItemClick = (ISetOnIconItemClick) context;
    }

    /**
     * Icon Listをセット
     *
     * @param iconList
     */
    public void setIconList(ArrayList<Integer> iconList) {
        this.mIconList = iconList;
    }

    /**
     * FragmentのPositionをセット
     *
     * @param fragmentPosition
     */
    public void setFragmentPosition(int fragmentPosition) {
        this.mFragmentPosition = fragmentPosition;
    }

    @NonNull
    @Override
    public SetUserListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_icon_list_user_setting, viewGroup, false);
        return new SetUserListViewHolder(view, mIconList);
    }

    @Override
    public void onBindViewHolder(@NonNull SetUserListViewHolder setUserListViewHolder, int position) {
        setUserListViewHolder.onBindView(position);
    }

    @Override
    public int getItemCount() {
        if (mIconList != null && mIconList.size() != 0) {
            return mIconList.size();
        }
        return 0;
    }

    /**
     * AdapterのViewHolder
     */
    public class SetUserListViewHolder extends RecyclerView.ViewHolder {
        private ImageView mImgIcon;
        private ArrayList<Integer> mIconList;

        SetUserListViewHolder(@NonNull View itemView, ArrayList<Integer> iconList) {
            super(itemView);
            mIconList = iconList;
            mImgIcon = itemView.findViewById(R.id.img_icon);
            mImgIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mISetOnIconItemClick.onItemSelected(getAdapterPosition(), mFragmentPosition);
                    sSelectedPosition = getAdapterPosition();
                    sFragmentPosition = mFragmentPosition;
                }
            });
        }

        /**
         * ViewをRecyclerViewに実装
         *
         * @param position
         */
        public void onBindView(int position) {
            mImgIcon.setImageResource(mIconList.get(position));
            if (position == sSelectedPosition && mFragmentPosition == sFragmentPosition) {
                mImgIcon.setBackgroundResource(R.drawable.bgr_set_icon_selected);
            } else {
                mImgIcon.setBackgroundResource(R.drawable.bgr_set_icon_unselected);
            }
        }
    }

}
