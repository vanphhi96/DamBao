/*
 * ファイル：DicSelectCategoryActivity.java
 * 概要：Select category when create dic
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.activity.dictionary;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.activity.BaseUiActivity;

import java.util.ArrayList;
import java.util.List;


/**
 * Select dictionary category
 *
 * @author Systena
 * @version 1.0
 */
public class DicSelectCategoryActivity extends BaseUiActivity implements View.OnClickListener {
    private RelativeLayout mLayoutHowToDo;
    private RelativeLayout mLayoutHowToGo;
    private RelativeLayout mLayoutBelongings;
    private TextView mTvHowToDoCount;
    private TextView mTvHowToGoCount;
    private TextView mTvBelongingsCount;
    private ImageView mImvHowToDoCheck;
    private ImageView mImvHowToGoCheck;
    private ImageView mImvBelongingsCheck;
    private RelativeLayout mLayoutBack;
    private List<CategoryInfo> mCategoryInfoList = new ArrayList<>();
    private long mIDCategorySelect = Constants.Ids.ID_NONE;
    private TextView mTvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_select_category_dic);
        mCategoryInfoList = getIntentListCategory();
        mIDCategorySelect = getIntentCategory();

        mLayoutHowToDo = findViewById(R.id.rlt_item_category_how_to_do);
        mLayoutHowToGo = findViewById(R.id.rlt_item_category_how_to_go);
        mLayoutBelongings = findViewById(R.id.rlt_item_category_belongings);

        mImvHowToDoCheck = findViewById(R.id.imv_check_item_category_how_to_do);
        mImvHowToGoCheck = findViewById(R.id.imv_check_item_category_how_to_go);
        mImvBelongingsCheck = findViewById(R.id.imv_item_category_belongings);

        mTvHowToDoCount = findViewById(R.id.tv_count_item_category_how_to_do);
        mTvHowToGoCount = findViewById(R.id.tv_count_item_category_how_to_go);
        mTvBelongingsCount = findViewById(R.id.tv_count_item_category_belongings);

        mLayoutBack = findViewById(R.id.rlt_dic_category_back);
        mTvBack = findViewById(R.id.tv_back);
        mLayoutBack.setOnClickListener(this);
        mLayoutHowToDo.setOnClickListener(this);
        mLayoutHowToGo.setOnClickListener(this);
        mLayoutBelongings.setOnClickListener(this);

        mTvBack.setText(getIntentNameScreen());
        fillData();
        setVisibleIconCheck();
    }

    /**
     * fill data to textView
     */
    private void fillData() {
        for (CategoryInfo categoryInfo : mCategoryInfoList) {
            if (categoryInfo.getCategoryId() == Constants.Ids.CATEGORY_ID_HOW_TO_DO) {
                mTvHowToDoCount.setText(Integer.toString(categoryInfo.getCount()));
            } else if (categoryInfo.getCategoryId() == Constants.Ids.CATEGORY_ID_HOW_TO_GO) {
                mTvHowToGoCount.setText(Integer.toString(categoryInfo.getCount()));
            } else if (categoryInfo.getCategoryId() == Constants.Ids.CATEGORY_ID_PROPERTY) {
                mTvBelongingsCount.setText(Integer.toString(categoryInfo.getCount()));
            }

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rlt_item_category_how_to_do:
                setIDCategorySelect(Constants.Ids.CATEGORY_ID_HOW_TO_DO);
                break;
            case R.id.rlt_item_category_how_to_go:
                setIDCategorySelect(Constants.Ids.CATEGORY_ID_HOW_TO_GO);
                break;
            case R.id.rlt_item_category_belongings:
                setIDCategorySelect(Constants.Ids.CATEGORY_ID_PROPERTY);
                break;
            case R.id.rlt_dic_category_back:
                onBackPressed();
                break;
            default:
                break;
        }
    }

    /**
     * set category select when click
     *
     * @param idCategory
     */
    private void setIDCategorySelect(long idCategory) {
        mIDCategorySelect = idCategory;
        setVisibleIconCheck();
        goBackDicCreateUiActivity();
    }

    /**
     * set visible icon check when select
     */
    private void setVisibleIconCheck() {
        mImvHowToDoCheck.setVisibility(View.INVISIBLE);
        mImvHowToGoCheck.setVisibility(View.INVISIBLE);
        mImvBelongingsCheck.setVisibility(View.INVISIBLE);
        if (mIDCategorySelect == Constants.Ids.CATEGORY_ID_HOW_TO_DO) {
            mImvHowToDoCheck.setVisibility(View.VISIBLE);
        } else if (mIDCategorySelect == Constants.Ids.CATEGORY_ID_HOW_TO_GO) {
            mImvHowToGoCheck.setVisibility(View.VISIBLE);
        } else if (mIDCategorySelect == Constants.Ids.CATEGORY_ID_PROPERTY) {
            mImvBelongingsCheck.setVisibility(View.VISIBLE);
        }
    }

    /**
     * get string key category from intent
     *
     * @return string
     */
    private long getIntentCategory() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_CATEGORY_SELECT)) {
            return Long.valueOf(getIntent().getExtras().getString(Constants.Dictionary.KEY_CATEGORY_SELECT));
        } else {
            return Constants.Ids.ID_NONE;
        }
    }

    /**
     * go back to DicCreateUiActivity after choose type repeat
     */
    private void goBackDicCreateUiActivity() {
        Bundle bundle = new Bundle();
        bundle.putString(Constants.Dictionary.KEY_GO_BACK_CATEGORY, String.valueOf(mIDCategorySelect));
        backScreenResult(this,bundle, Constants.Dictionary.REQUEST_CODE_CATEGORY);
    }

    /**
     * get intent list category
     *
     * @return List<CategoryInfo>
     */
    private List<CategoryInfo> getIntentListCategory() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_LIST_CATEGORY)) {
            return (List<CategoryInfo>) getIntent().getExtras().getSerializable(Constants.Dictionary.KEY_LIST_CATEGORY);
        }
        return new ArrayList<>();
    }

    /**
     * get intent text back
     *
     * @return String:
     */
    private String getIntentNameScreen() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_LIST_CATEGORY)) {
            return  getIntent().getExtras().getString(Constants.Dictionary.KEY_NAME_SCREEN);
        }
        return getString(R.string.dic_cr_dic);
    }

}
