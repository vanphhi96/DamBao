/*
 * ファイル：RealmGeneralInfo.java
 * 概要：Realm用お知らせ情報一覧テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

import java.util.Date;

/**
 * Realm用お知らせ情報一覧テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmNoticeInfo extends RealmObject {

    @PrimaryKey
    private long mNoticeId;  // お知らせID
    private Date mDeliveredDate; // 配信日時
    private String mTitle; // タイトル
    private String mContents; // 内容
    private long mVersion; // バージョン
    private boolean mIsPriority; // 優先表示フラグ
    private Date mCreatedDate; // 作成日時
    private Date mUpdatedDate; // 更新日時

    public long getNoticeId() {
        return mNoticeId;
    }

    public void setNoticeId(long mNoticeId) {
        this.mNoticeId = mNoticeId;
    }

    public Date getDeliveredDate() {
        return mDeliveredDate;
    }

    public void setDeliveredDate(Date mDeliveredDate) {
        this.mDeliveredDate = mDeliveredDate;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public String getContents() {
        return mContents;
    }

    public void setContents(String mContents) {
        this.mContents = mContents;
    }

    public long getVersion() {
        return mVersion;
    }

    public void setVersion(long mVersion) {
        this.mVersion = mVersion;
    }

    public boolean isPriority() {
        return mIsPriority;
    }

    public void setIsPriority(boolean mPriority) {
        this.mIsPriority = mPriority;
    }

    public Date getCreatedDate() {
        return mCreatedDate;
    }

    public void setCreatedDate(Date mCreatedDate) {
        this.mCreatedDate = mCreatedDate;
    }

    public Date getUpdatedDate() {
        return mUpdatedDate;
    }

    public void setUpdatedDate(Date mUpdatedDate) {
        this.mUpdatedDate = mUpdatedDate;
    }

}
