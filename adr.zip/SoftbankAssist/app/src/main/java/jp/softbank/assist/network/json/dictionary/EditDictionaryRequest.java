/*
 * ファイル：EditDictionaryRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

import java.util.ArrayList;
import java.util.List;

/**
 * 辞書編集リクエスト.
 */
public class EditDictionaryRequest extends RequestBody {

    @SerializedName("delete_card_info")
    private List<EditDictionaryDeleteCard> mDeleteCardInfo = null;
    @SerializedName("card_pos_info")
    private List<EditDictionaryRequestCardPos> mCardPosInfo = null;
    @SerializedName("card_add_content_info")
    private List<EditDictionaryRequestCardAddContent> mCardAddContentInfo = null;
    @SerializedName("card_edit_content_info")
    private List<EditDictionaryRequestCardEditContent> mCardEditContentInfo = null;
    @SerializedName("dic_edit_content_info")
    private EditDictionaryRequestDicEditContent mDicEditContentInfo = null;
    @SerializedName("user_id")
    private Long mUserId = null;


    /**
     * 値初期化.
     */
    public void initializeValues() {
        mCardPosInfo = new ArrayList<EditDictionaryRequestCardPos>();
        mDicEditContentInfo = new EditDictionaryRequestDicEditContent();
        mDicEditContentInfo.initializeValues();
        mUserId = 0L;
    }

    /**
     * カード削除情報.
     */
    public List<EditDictionaryDeleteCard> getDeleteCardInfo() {
        return mDeleteCardInfo;
    }
    public void setDeleteCardInfo(List<EditDictionaryDeleteCard> deleteCardInfo) {
        this.mDeleteCardInfo = deleteCardInfo;
    }

    /**
     * カード位置情報.
     */
    public List<EditDictionaryRequestCardPos> getCardPosInfo() {
        return mCardPosInfo;
    }
    public void setCardPosInfo(List<EditDictionaryRequestCardPos> cardPosInfo) {
        this.mCardPosInfo = cardPosInfo;
    }

    /**
     * カード追加内容情報.
     */
    public List<EditDictionaryRequestCardAddContent> getCardAddContentInfo() {
        return mCardAddContentInfo;
    }
    public void setCardAddContentInfo(List<EditDictionaryRequestCardAddContent> cardAddContentInfo) {
        this.mCardAddContentInfo = cardAddContentInfo;
    }

    /**
     * カード編集内容情報.
     */
    public List<EditDictionaryRequestCardEditContent> getCardEditContentInfo() {
        return mCardEditContentInfo;
    }
    public void setCardEditContentInfo(List<EditDictionaryRequestCardEditContent> cardEditContentInfo) {
        this.mCardEditContentInfo = cardEditContentInfo;
    }

    /**
     * 辞書編集内容情報.
     */
    public EditDictionaryRequestDicEditContent getDicEditContentInfo() {
        return mDicEditContentInfo;
    }
    public void setDicEditContentInfo(EditDictionaryRequestDicEditContent dicEditContentInfo) {
        this.mDicEditContentInfo = dicEditContentInfo;
    }

    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EditDictionaryRequest dictionaryRequest = (EditDictionaryRequest) o;
        return (this.mDeleteCardInfo == null ? dictionaryRequest.mDeleteCardInfo == null : this.mDeleteCardInfo.equals(dictionaryRequest.mDeleteCardInfo)) &&
                (this.mCardPosInfo == null ? dictionaryRequest.mCardPosInfo == null : this.mCardPosInfo.equals(dictionaryRequest.mCardPosInfo)) &&
                (this.mCardAddContentInfo == null ? dictionaryRequest.mCardAddContentInfo == null : this.mCardAddContentInfo.equals(dictionaryRequest.mCardAddContentInfo)) &&
                (this.mCardEditContentInfo == null ? dictionaryRequest.mCardEditContentInfo == null : this.mCardEditContentInfo.equals(dictionaryRequest.mCardEditContentInfo)) &&
                (this.mDicEditContentInfo == null ? dictionaryRequest.mDicEditContentInfo == null : this.mDicEditContentInfo.equals(dictionaryRequest.mDicEditContentInfo)) &&
                (this.mUserId == null ? dictionaryRequest.mUserId == null : this.mUserId.equals(dictionaryRequest.mUserId));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mDeleteCardInfo == null ? 0: this.mDeleteCardInfo.hashCode());
        result = 31 * result + (this.mCardPosInfo == null ? 0: this.mCardPosInfo.hashCode());
        result = 31 * result + (this.mCardAddContentInfo == null ? 0: this.mCardAddContentInfo.hashCode());
        result = 31 * result + (this.mCardEditContentInfo == null ? 0: this.mCardEditContentInfo.hashCode());
        result = 31 * result + (this.mDicEditContentInfo == null ? 0: this.mDicEditContentInfo.hashCode());
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class EditDictionaryRequest {\n");

        sb.append("  mDeleteCardInfo: ").append(mDeleteCardInfo).append("\n");
        sb.append("  mCardPosInfo: ").append(mCardPosInfo).append("\n");
        sb.append("  mCardAddContentInfo: ").append(mCardAddContentInfo).append("\n");
        sb.append("  mCardEditContentInfo: ").append(mCardEditContentInfo).append("\n");
        sb.append("  mDicEditContentInfo: ").append(mDicEditContentInfo).append("\n");
        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
