/*
 * ファイル：RealmAppVersionInfo.java
 * 概要：Realm最新アプリバージョン情報テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Realm最新アプリバージョン情報テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmAppVersionInfo extends RealmObject {

    @PrimaryKey
    private int mId; // アプリバージョンID
    private boolean mIsMustUpdate; // アップデート必須フラグ
    private String mMessageText; // 表示文言
    private String mUrl; // 遷移先URL
    private String mLatestVersion; // 現在の最新バージョン

    public int getId() {
        return mId;
    }

    public void setId(int mId) {
        this.mId = mId;
    }

    public boolean isMustUpdate() {
        return mIsMustUpdate;
    }

    public void setMustUpdate(boolean mIsMustUpdate) {
        this.mIsMustUpdate = mIsMustUpdate;
    }

    public String getMessageText() {
        return mMessageText;
    }

    public void setMessageText(String mMessageText) {
        this.mMessageText = mMessageText;
    }

    public String getUrl() {
        return mUrl;
    }

    public void setUrl(String mUrl) {
        this.mUrl = mUrl;
    }

    public String getLatestVersion() {
        return mLatestVersion;
    }

    public void setLatestVersion(String mLatestVersion) {
        this.mLatestVersion = mLatestVersion;
    }
}
