package jp.softbank.assist.view.fragmenttemp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.model.database.TimerInfo;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.view.fragment.BaseFragment;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Created by Tan N. Truong on 2019/01/09.
 */

// TODO: 2019/01/09 Just an example Fragment, can be deleted later

public class TimerTest_2 extends BaseFragment implements View.OnClickListener {

    Button mBtnTimerSchedule = null;
    Button mBtnTimerStart = null;
    Button mBtnTimerTableClear = null;
    Button mBtnTimerCheck = null;
    Button mBtnScheduleCheck = null;

    Button mBtnDateTimerCheck = null;
    Button mBtnScheduleSet = null;

    TextView mText1 = null;
    TextView mText2 = null;
    TextView mText3 = null;
    TextView mTextCnt = null;
    TextView mSchNumText = null;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_temp_timer_two, container, false);

        mBtnTimerSchedule = view.findViewById(R.id.button_ScheduleSet);
        mBtnTimerSchedule.setOnClickListener(this);
        mBtnTimerStart = view.findViewById(R.id.button_TimerStart);
        mBtnTimerStart.setOnClickListener(this);
        mBtnTimerTableClear = view.findViewById(R.id.button_TimerTableClear);
        mBtnTimerTableClear.setOnClickListener(this);
        mBtnTimerCheck = view.findViewById(R.id.button_TimerTblCheck);
        mBtnTimerCheck.setOnClickListener(this);
        mBtnScheduleCheck  = view.findViewById(R.id.button_SchduleChk);
        mBtnScheduleCheck.setOnClickListener(this);
        mTextCnt = view.findViewById(R.id.timerTblText);

        mSchNumText  = view.findViewById(R.id.scheduleDataNum);

        mBtnDateTimerCheck = view.findViewById(R.id.button_DateTimerCheck);
        mBtnDateTimerCheck.setOnClickListener(this);
        mBtnScheduleSet = view.findViewById(R.id.button_DataSet);
        mBtnScheduleSet.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_ScheduleSet:
                // スケジュール設定
                setSchedule();
                break;
            case R.id.button_TimerStart:
                timerSet1();
                break;
            case R.id.button_SchduleChk:
//                timerCancel();
                scheduleDataChk();
                break;
            case R.id.button_TimerTableClear:
//                timerAllCancel();
                timerCancel();
                break;
            case R.id.button_TimerTblCheck:
                timerCntInt();
                break;
            case R.id.button_DataSet:
                schSet();
                break;
            case R.id.button_DateTimerCheck:
                dateTimerChk();
                break;
            default:
                break;

        }
    }

    private void timerSet1() {

        AssistLog.i("Start");

        AppController.getInstance().getAssistTimerManager().timerSetSchedulebyData(getContext().createDeviceProtectedStorageContext());

    }

    private void timerCancel() {

        AppController.getInstance().getAssistTimerManager().timerCancelAll(getContext());
    }

    private void setSchedule() {

        ScheduleInfo schInfo = new ScheduleInfo();
        DateFormat df = new SimpleDateFormat("MM/dd HH:mm:ss");

        schInfo.setTitle("おばあちゃんの家にいく");
        Date startDate = DateUtils.getDateAdd(DateUtils.getDateNow(), Calendar.MINUTE, 3);
        schInfo.setScheduleStartDate(startDate);
        schInfo.setScheduleId(1L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);
        mText1.setText("Schedule Set1 [" + df.format(startDate) + "]");

        schInfo.setTitle("バスに乗る");
        startDate = DateUtils.getDateAdd(DateUtils.getDateNow(), Calendar.MINUTE, 4);
        schInfo.setScheduleStartDate(startDate);
        schInfo.setScheduleId(2L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);
        mText2.setText("Schedule Set2 [" + df.format(startDate) + "]");

        schInfo.setTitle("おうちに帰る");
        startDate = DateUtils.getDateAdd(DateUtils.getDateNow(), Calendar.MINUTE, 5);
        schInfo.setScheduleStartDate(startDate);
        schInfo.setScheduleId(3L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);
        mText3.setText("Schedule Set3 [" + df.format(startDate) + "]");

    }

    private void timerAllCancel() {

        AssistLog.i("Start");
        AppController.getInstance().getModelInterface().deleteTimerInfoAll();

    }

    private void timerCntInt() {
        AssistLog.i("Start");
        int cnt = 0;
        List<TimerInfo> list = AppController.getInstance().getModelInterface().getTimerInfo();
        if (list != null && !list.isEmpty()) {
            cnt = list.size();
        }
        mTextCnt.setText(String.valueOf(cnt));

    }

    private void schSet() {

        ScheduleInfo schInfo = new ScheduleInfo();

        final Date toDay = DateUtils.getDateNow();
        final Date dateYesterDay = DateUtils.getDateAdd(toDay, Calendar.DATE,-1);
        final Date dateYesterDay2 = DateUtils.getDateAdd(toDay, Calendar.DATE,-2);
        final Date dateTomorrow = DateUtils.getDateAdd(toDay, Calendar.DATE,1);
        final Date dateTomorrow2 = DateUtils.getDateAdd(toDay, Calendar.DATE,2);
        Calendar cal = Calendar.getInstance();

        // スケジュール1 前日～翌日〇
        schInfo.setTitle("スケジュール1");
        cal.setTime(dateYesterDay);
        Date startDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 11, 30, 0).getTime();
        schInfo.setScheduleStartDate(startDate);
        cal.setTime(dateTomorrow);
        Date endDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 21, 30, 0).getTime();
        schInfo.setScheduleEndDate(endDate);
        schInfo.setScheduleId(1L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);

        // スケジュール2 前々日～前日
        schInfo = new ScheduleInfo();
        schInfo.setTitle("スケジュール2");
        cal.setTime(dateYesterDay2);
        startDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 11, 30, 0).getTime();
        schInfo.setScheduleStartDate(startDate);
        cal.setTime(dateYesterDay);
        endDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 21, 30, 0).getTime();
        schInfo.setScheduleEndDate(endDate);
        schInfo.setScheduleId(2L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);
        // スケジュール3 前日～前日
        schInfo = new ScheduleInfo();
        schInfo.setTitle("スケジュール3");
        cal.setTime(dateYesterDay);
        startDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 11, 30, 0).getTime();
        schInfo.setScheduleStartDate(startDate);
        cal.setTime(dateYesterDay);
        endDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 21, 30, 0).getTime();
        schInfo.setScheduleEndDate(endDate);
        schInfo.setScheduleId(3L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);
        // スケジュール4 当日～当日〇
        schInfo = new ScheduleInfo();
        schInfo.setTitle("スケジュール4");
        cal.setTime(toDay);
        startDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 11, 30, 0).getTime();
        schInfo.setScheduleStartDate(startDate);
        cal.setTime(toDay);
        endDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 21, 30, 0).getTime();
        schInfo.setScheduleEndDate(endDate);
        schInfo.setScheduleId(4L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);
        // スケジュール5 当日～翌日〇
        schInfo = new ScheduleInfo();
        schInfo.setTitle("スケジュール5");
        cal.setTime(toDay);
        startDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 21, 00, 0).getTime();
        schInfo.setScheduleStartDate(startDate);
        cal.setTime(dateTomorrow);
        endDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 15, 30, 0).getTime();
        schInfo.setScheduleEndDate(endDate);
        schInfo.setScheduleId(5L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);
        // スケジュール6 翌日～翌日
        schInfo = new ScheduleInfo();
        schInfo.setTitle("スケジュール6");
        cal.setTime(dateTomorrow);
        startDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 2, 30, 0).getTime();
        schInfo.setScheduleStartDate(startDate);
        cal.setTime(dateTomorrow);
        endDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 21, 30, 0).getTime();
        schInfo.setScheduleEndDate(endDate);
        schInfo.setScheduleId(6L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);
        // スケジュール7 翌日～翌々日
        schInfo = new ScheduleInfo();
        schInfo.setTitle("スケジュール7");
        cal.setTime(dateTomorrow);
        startDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 9, 45, 0).getTime();
        schInfo.setScheduleStartDate(startDate);
        cal.setTime(dateTomorrow2);
        endDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 20, 30, 0).getTime();
        schInfo.setScheduleEndDate(endDate);
        schInfo.setScheduleId(7L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);

        // スケジュール8 翌日～翌日
        schInfo = new ScheduleInfo();
        schInfo.setTitle("スケジュール8");
        cal.setTime(dateTomorrow);
        startDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 12, 30, 0).getTime();
        schInfo.setScheduleStartDate(startDate);
        cal.setTime(dateTomorrow);
        endDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 21, 30, 0).getTime();
        schInfo.setScheduleEndDate(endDate);
        schInfo.setScheduleId(8L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);
        // スケジュール9 翌々日～翌々日
        schInfo = new ScheduleInfo();
        schInfo.setTitle("スケジュール6");
        cal.setTime(dateTomorrow2);
        startDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 2, 30, 0).getTime();
        schInfo.setScheduleStartDate(startDate);
        cal.setTime(dateTomorrow);
        endDate = new GregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                cal.get(Calendar.DATE), 21, 30, 0).getTime();
        schInfo.setScheduleEndDate(endDate);
        schInfo.setScheduleId(9L);
        schInfo.setInterval(ScheduleInfo.IntervalType.None);
        AppController.getInstance().getModelInterface().updateScheduleInfo(schInfo);

        // 取得確認
        List<ScheduleInfo> list = AppController.getInstance().getModelInterface().getScheduleInfo(DateUtils.getDateNow());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

        getView().findViewById(R.id.button_DataSet).setEnabled(false);

//        if (list != null && !list.isEmpty()) {
//            mSchNumText.setText(String.valueOf(list.size()));
//            if (list.size() == 3) {
//                mSchText1.setText("[" + df.format(list.get(0).getScheduleStartDate()) + "]～[" + df.format(list.get(0).getScheduleEndDate()) + "]");
//                mSchText2.setText("[" + df.format(list.get(1).getScheduleStartDate()) + "]～[" + df.format(list.get(1).getScheduleEndDate()) + "]");
//                mSchText3.setText("[" + df.format(list.get(2).getScheduleStartDate()) + "]～[" + df.format(list.get(2).getScheduleEndDate()) + "]");
//            }
//        }
    }

    void scheduleDataChk() {

        // 取得確認
        List<ScheduleInfo> list = AppController.getInstance().getModelInterface().getScheduleInfoForTimer();
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

        LinearLayout linearSch = getView().findViewById(R.id.LinearSch);

        if (list != null && !list.isEmpty()) {
            for (ScheduleInfo info : list) {
                String str = "[" + info.getScheduleId() + "][" + df.format(info.getScheduleStartDate()) + "]～[" + df.format(info.getScheduleEndDate()) + "]";
                TextView text = new TextView(getContext());
                text.setText(str);
                text.setGravity(Gravity.CENTER);
                linearSch.addView(text);
            }
            getView().findViewById(R.id.button_SchduleChk).setEnabled(false);
        }

    }


    void dateTimerChk() {

        AppController.getInstance().getAssistTimerManager().timerReset(getContext());
        List<TimerInfo> list = AppController.getInstance().getModelInterface().getTimerInfo();

        LinearLayout linearSch = getView().findViewById(R.id.LinearTimer);

        if (list != null && !list.isEmpty()) {
            for (TimerInfo info : list) {
                String str = "TimerCode [" + String.valueOf(info.getRequestCode()) + "] TimerType [" + info.getType() + "]";
                TextView text = new TextView(getContext());
                text.setText(str);
                text.setGravity(Gravity.CENTER);
                linearSch.addView(text);
            }
        }
    }

}