/*
 * ファイル：BaseFragment.java
 * 概要：フラグメントのベースクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;

import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.util.AssistEventLog;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.ViewManager;
import jp.softbank.assist.view.activity.BaseActivity;
import jp.softbank.assist.view.activity.BaseUiActivity;

/**
 * フラグメントのベースクラス
 *
 * @author Systena
 * @version 1.0
 */
public class BaseFragment extends Fragment implements DialogInterface.OnClickListener {

    private BaseActivity mBaseActivity;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppController.getInstance().getViewManager().setFragment(this);
        mBaseActivity = (BaseActivity) getActivity();
    }

    @Override
    public void onResume() {
        super.onResume();
        AppController.getInstance().getViewManager().setFragment(this);
    }

    @Override
    public void onDestroy() {
        AppController.getInstance().getViewManager().clearFragment(this);
        super.onDestroy();
    }

    /**
     * replace fragment
     *
     * @param containerViewId  containerViewId
     * @param fragment         fragment
     * @param isAddToBackStack isBackStack
     */
    public void replaceFragment(int containerViewId, Fragment fragment, boolean isAddToBackStack) {
        if (getActivity() instanceof BaseUiActivity) {
            ((BaseUiActivity) getActivity()).replaceFragment(containerViewId, fragment, isAddToBackStack);
        }
    }

    /**
     * add fragment
     *
     * @param containerViewId  containerViewId
     * @param fragment         fragment
     * @param isAddToBackStack isBackStack
     */
    public void addFragment(int containerViewId, Fragment fragment, boolean isAddToBackStack) {
        if (getActivity() instanceof BaseUiActivity) {
            ((BaseUiActivity) getActivity()).addFragment(containerViewId, fragment, isAddToBackStack);
        }
    }

    /**
     * add child fragment
     *
     * @param containerViewId  containerViewId
     * @param fragment         fragment
     * @param isAddToBackStack isBackStack
     */
    public void addChildFragment(int containerViewId, Fragment fragment, boolean isAddToBackStack) {
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        if (isAddToBackStack) {
            transaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        transaction.add(containerViewId, fragment, fragment.getClass().getSimpleName());
        transaction.commit();
    }

    /**
     * get count in back stack
     *
     * @param layout layout
     */
    public int getCountBackStack(int layout) {
        getFragmentManager().getFragments();
        return getFragmentManager().findFragmentById(layout).getFragmentManager().getBackStackEntryCount();
    }

    /**
     * remove all item in back stack
     *
     * @param layout layout
     */
    public void removeAllBackStack(int layout) {
        for (int i = 0; i < getCountBackStack(layout); i++) {
            getFragmentManager().findFragmentById(layout).getFragmentManager().popBackStack();
        }
    }

    /**
     * @param layout
     * @return
     */
    public boolean isRootFragment(int layout) {
        if (getCountBackStack(layout) > 0) {
            removeAllBackStack(layout);
            return false;
        }
        return true;
    }

    /**
     * フラグメントを変更する / Change Fragment
     *
     * @param item
     */
    public void changeFragment(ScreenId item) {
        AppController.getInstance().getViewManager().changeFragment(item);
    }

    /**
     * アクティビティを変更する / Change Activity
     *
     * @param item
     */
    public void changeScreen(ScreenId item) {
        AppController.getInstance().getViewManager().changeScreen(item);
    }

    /**
     * フラグメントの名前を取得 / Get Fragment Simple Name
     */
    public String getSimpleName(Fragment fragment) {
        return fragment.getClass().getSimpleName();
    }

    /**
     * フラグメントからScreenIDの取得 / Get Screen ID from Fragment
     */
    public ScreenId getScreenId() {
        return AppController.getInstance().getViewManager().getScreenId();
    }

    /**
     * ダイアログクリック時に使用
     */
    @Override
    public void onClick(DialogInterface dialog, int which) {

    }

    /**
     * Firebaseイベントを送信
     *
     * @param fragmentBaseId
     */
    public void sendEventFirebaseScreenId(int fragmentBaseId) {
        Fragment fragment = getFragmentManager().findFragmentById(fragmentBaseId);
        if (fragment != null) {
            AppController.getInstance().getViewManager().setFragment(fragment);
            sendEventFirebaseScreenId();
        }
    }

    /**
     * Firebaseイベントを送信
     */
    public void sendEventFirebaseScreenId() {
        AssistEventLog.sendEventFirebaseScreenId(getActivity(), getScreenId());
    }

    /**
     * change screen result in fragment
     *
     * @param screenId
     * @param resultCode
     * @param bundle
     */
    public void changeScreenResultFragment(ScreenId screenId, int resultCode, Bundle bundle) {
        Intent i = new Intent(getActivity(), ViewManager.convertKeyToClass(screenId));
        i.putExtras(bundle);
        startActivityForResult(i, resultCode);
    }
}
