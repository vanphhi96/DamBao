/*
 * ファイル：IOnClickItemDicList.java
 * 概要：
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.activity.dictionary;

import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DictionaryInfo;

/**
 * @author Systena
 * @version 1.0
 */
public interface IOnClickItemDicList {
    /**
     * set onClick item dic of dic-02
     */
    void onClickItemDic(DictionaryInfo dictionaryModel);

    /**
     * click other category
     *
     * @param categoryModel
     */
    void clickOtherCategory(CategoryInfo categoryModel);
}
