/*
 * ファイル：CategoryInfo.java
 * 概要：辞書カテゴリ情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import java.io.Serializable;

/**
 * 辞書カテゴリ情報.
 *
 * @author Systena
 * @version 1.0
 */
public class CategoryInfo implements Serializable {

    private long mCategoryId; // カテゴリID
    private String mName; // カテゴリ名
    private long mIconId; // アイコンID
    private int mCount; // 登録辞書数


    public long getCategoryId() {
        return mCategoryId;
    }

    public void setCategoryId(long categoryId) {
        this.mCategoryId = categoryId;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public long getIconId() {
        return mIconId;
    }

    public void setIconId(long iconId) {
        this.mIconId = iconId;
    }

    public int getCount() {
        return mCount;
    }

    public void setCount(int count) {
        this.mCount = count;
    }
}
