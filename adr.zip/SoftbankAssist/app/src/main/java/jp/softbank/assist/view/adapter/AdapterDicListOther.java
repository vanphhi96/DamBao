/*
 * ファイル：AdapterDicListOther.java
 * 概要：Adapter list dictionary detail other
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.view.activity.dictionary.IOnClickItemDicList;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.FooterSpaceAdapter;

import java.util.ArrayList;
import java.util.List;


/**
 * Adapter list dictionary detail other
 *
 * @author Systena
 * @version 1.0
 */
public class AdapterDicListOther extends FooterSpaceAdapter {
    private List<CategoryInfo> mListCategory = new ArrayList<>();
    private IOnClickItemDicList mIOnClickItemDicList;

    public AdapterDicListOther(IOnClickItemDicList clickItemCategoryOther) {
        mIOnClickItemDicList = clickItemCategoryOther;
    }

    /**
     * add data to list category
     *
     * @param listCategory
     */
    public void setListCategory(List<CategoryInfo> listCategory) {
        this.mListCategory = listCategory;
    }

    @Override
    public int getContentItemCount() {
        return mListCategory.size();
    }

    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category_dic_other, parent, false);
        return new DicItemOtherHolder(view);
    }

    /**
     * create view holder for dictionary item
     */
    private class DicItemOtherHolder extends BaseViewHolder {
        private TextView mTvNameCategory;
        private TextView mTvCount;
        private FrameLayout mFrameFlag;
        private CardView mCardView;

        public DicItemOtherHolder(@NonNull View itemView) {
            super(itemView);
            mTvNameCategory = itemView.findViewById(R.id.tv_name_dic_category);
            mTvCount = itemView.findViewById(R.id.tv_count_dic_category_other);
            mFrameFlag = itemView.findViewById(R.id.frame_flag_dic_category_other);
            mCardView = itemView.findViewById(R.id.card_dic_category_other);
        }

        @Override
        public void onBindView(final int position) {
            CategoryInfo mModel = mListCategory.get(toContentPosition(position));
            Context context = mTvCount.getContext();
            int colorCard = R.color.dic_card_how_to_do;
            int colorBgrCard = R.color.dic_bgr_how_to_do;
            if (mListCategory.get(position).getName().equals(context.getString(R.string.how_to_go))) {
                colorCard = R.color.dic_card_how_to_go;
                colorBgrCard = R.color.dic_bgr_how_to_go;
            } else if (mListCategory.get(position).getName().equals(context.getString(R.string.belongings))) {
                colorCard = R.color.dic_card_belongings;
                colorBgrCard = R.color.dic_bgr_belongings;
            }
            mFrameFlag.setBackgroundColor(context.getColor(colorCard));
            mCardView.setCardBackgroundColor(context.getColor(colorBgrCard));
            mTvNameCategory.setText(mModel.getName());
            mTvCount.setText(Integer.toString(mModel.getCount()));
            mCardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickItemDicList != null) {
                        mIOnClickItemDicList.clickOtherCategory(mListCategory.get(position));
                    }
                }
            });
        }
    }
}
