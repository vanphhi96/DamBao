/*
 * ファイル：SetHistoryUiActivity.java
 * 概要：操作履歴画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.settings;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetHistoryResultListener;
import jp.softbank.assist.view.activity.BaseActivity;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.AssistAlertDialogFactory;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;

/**
 * set-log-01
 *
 * @author Systena
 * @version 1.0
 */
public class SetHistoryUiActivity extends BaseActivity implements View.OnClickListener, GetHistoryResultListener {
    public static final int COUNT_PER_PAGE = 7;//TODO[8140] T.B.D displayCountPerPage
    public static final String MINE_TYPE = "text/html";
    public static final String ENCODING = "UTF-8";
    public static final float ALPHA_DISABLE = 0.5f;
    private int mCurrentPage = 0;
    private LinearLayout mLayoutBack;
    private WebView mWebView;
    private LinearLayout mLnPrev;
    private LinearLayout mLnNext;
    private TextView mTvPrev;
    private int mPageBefore = 0;
    private String mDialogTag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_history);
        mLayoutBack = findViewById(R.id.ln_back);
        mWebView = findViewById(R.id.web_view);
        FrameLayout frameLayout = findViewById(R.id.frame_footer);
        mLnPrev = frameLayout.findViewById(R.id.ln_prev);
        mLnNext = frameLayout.findViewById(R.id.ln_next);
        mTvPrev = frameLayout.findViewById(R.id.tv_prev);

        mLnPrev.setOnClickListener(this);
        mLnNext.setOnClickListener(this);
        mLayoutBack.setOnClickListener(this);
        initWebView();
        setEnablePrevious();
        AppController.getInstance().getAssistServerInterface().getHistory(mCurrentPage, COUNT_PER_PAGE, this);
    }

    /**
     * init web.
     */
    private void initWebView() {
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setSupportZoom(false);
        mWebView.setWebViewClient(new WebViewClient());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ln_back:
                onBackPressed();
                break;
            case R.id.ln_prev:
                getPageHistory(false);
                break;
            case R.id.ln_next:
                getPageHistory(true);
                break;
            default:
                break;
        }
    }

    /**
     * call getPageHistory when change page
     *
     * @param nextPage is boolean true: next page, false: previous
     */
    private void getPageHistory(boolean nextPage) {
        mPageBefore = mCurrentPage;
        if (nextPage) {
            mCurrentPage++;
        } else if (mCurrentPage > 0) {
            mCurrentPage--;
        } else {
            return;
        }
        AppController.getInstance().getAssistServerInterface().getHistory(mCurrentPage, COUNT_PER_PAGE, this);
    }

    /**
     * set enable button previous page
     */
    private void setEnablePrevious() {
        if (mCurrentPage == 0) {
            mLnPrev.setFocusableInTouchMode(false);
            mLnPrev.setAlpha(ALPHA_DISABLE);
            mTvPrev.setAlpha(ALPHA_DISABLE);
        } else {
            mLnPrev.setFocusableInTouchMode(true);
            mLnPrev.setAlpha(1f);
            mTvPrev.setAlpha(1f);
        }
    }

    @Override
    public void onResult(AssistServerResult result, final String html) {
        closeIndicator();
        if (result.mResult == AssistServerResult.Result.Success) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mWebView.loadData(html, MINE_TYPE, ENCODING);
                    setEnablePrevious();
                }
            });

        } else {
            mCurrentPage = mPageBefore;
            //show dialog error
            buildDialogError(result.mMessage);
        }
    }

    @Override
    public void onStartConnection() {
        displayIndicator();
    }

    /**
     * dialog create error
     *
     * @return boolean
     */
    private void buildDialogError(String errorMessage) {
        BaseDialogFactory dialogFactory = new AssistAlertDialogFactory(
                DialogTypeControl.DialogType.DIALOG_MESSAGE, errorMessage);
        mDialogTag = dialogFactory.getDialogTag();
        new DialogGenerator(this, dialogFactory).show();
    }
}
