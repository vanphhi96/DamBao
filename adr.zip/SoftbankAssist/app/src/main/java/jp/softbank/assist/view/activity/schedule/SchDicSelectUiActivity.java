/*
 * ファイル：SchDicSelectUiActivity.java
 * 概要：list dictionary category.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.schedule;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.adapter.AdapterDicTop;
import jp.softbank.assist.view.fragment.dictionary.IDicTopFragment;

import java.io.Serializable;
import java.util.List;

/**
 * sch-ed-dic-02
 *
 * @author Systena
 * @version 1.0
 */
public class SchDicSelectUiActivity extends BaseUiActivity implements View.OnClickListener, IDicTopFragment {
    private RelativeLayout mBtnBack;
    private RecyclerView mRvCategory;
    private TextView mTvCancel;
    private List<CategoryInfo> mCategoryInfoList;
    private AdapterDicTop mAdapterDicTop;
    private DictionaryInfo mDictionaryInfo;
    private TextView mTvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sch_dic_select);
        mDictionaryInfo = getIntentDicInfo();
        mRvCategory = findViewById(R.id.recycle_dic_category);
        mTvCancel = findViewById(R.id.tv_cancel);
        mBtnBack = findViewById(R.id.rlt_sch_dic_select_back);
        mTvBack = findViewById(R.id.tv_back_sch_dic);
        mTvBack.setText(getIntentFrom());
        mTvCancel.setOnClickListener(this);
        mBtnBack.setOnClickListener(this);
        mCategoryInfoList = AppController.getInstance().getAssistServerInterface().getCategoryList();
        initRecycleCategory();
    }

    /**
     * get DictionaryInfo
     *
     * @return dictionary info
     */
    private DictionaryInfo getIntentDicInfo() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_DICTIONARY_INFO)) {
            return (DictionaryInfo) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_DICTIONARY_INFO);
        } else {
            return null;
        }
    }

    /**
     * get value text back.
     *
     * @return
     */
    private String getIntentFrom() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_GO_TO_FROM)) {
            return getIntent().getExtras().getString(Constants.Schedule.KEY_GO_TO_FROM);
        } else {
            return "";
        }
    }

    /**
     * init recycle view
     */
    private void initRecycleCategory() {
        mAdapterDicTop = new AdapterDicTop();
        mAdapterDicTop.setCategoryInfoList(mCategoryInfoList);
        mAdapterDicTop.setIDicTopFragment(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRvCategory.setLayoutManager(layoutManager);
        mRvCategory.setAdapter(mAdapterDicTop);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rlt_sch_dic_select_back:
                onBackPressed();
                break;
            case R.id.tv_cancel:
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, mDictionaryInfo);
                backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_DICTIONARY);
                break;
            default:
                break;
        }
    }

    @Override
    public void onClickCategory(CategoryInfo categoryInfo) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Constants.Schedule.KEY_TYPE_CATEGORY, categoryInfo);
        bundle.putSerializable(Constants.Schedule.KEY_LIST_CATEGORY, (Serializable) mCategoryInfoList);
        bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, mDictionaryInfo);
        changeScreenResult(ScreenId.START_SCH_DICTIONARY_LIST, Constants.Schedule.REQUEST_CODE_DICTIONARY, bundle);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.Schedule.REQUEST_CODE_DICTIONARY && resultCode == Constants.Schedule.REQUEST_CODE_DICTIONARY) {
            DictionaryInfo dictionaryInfo = (DictionaryInfo) data.getSerializableExtra(Constants.Schedule.KEY_DICTIONARY_INFO);
            Bundle bundle = new Bundle();
            bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, dictionaryInfo);
            backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_DICTIONARY);
        }
    }

    @Override
    public void onBackPressed() {
        if (mDictionaryInfo == null) {
            super.onBackPressed();
        } else {
            Bundle bundle = new Bundle();
            bundle.putSerializable(Constants.Schedule.KEY_DICTIONARY_INFO, mDictionaryInfo);
            backScreenResult(this, bundle, Constants.Schedule.REQUEST_CODE_DICTIONARY);
        }
    }
}
