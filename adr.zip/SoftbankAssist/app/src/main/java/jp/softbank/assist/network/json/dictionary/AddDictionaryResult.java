/*
 * ファイル：AddDictionaryResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * 辞書登録結果.
 */
public class AddDictionaryResult {

    @SerializedName("dictionary_id")
    private Long mDictionaryId = null;
    @SerializedName("dictionary_type")
    private Long mDictionaryType = null;
    @SerializedName("dictionary_version")
    private Long mDictionaryVersion = null;
    @SerializedName("mCard")
    private List<AddDictionaryResultCard> mCard = null;


    /**
     * 辞書ID.
     */
    public Long getDictionaryId() {
        return mDictionaryId;
    }
    public void setDictionaryId(Long dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }

    /**
     * 辞書種別（0：ステップ形式、1：チェック形式）.
     */
    public Long getDictionaryType() {
        return mDictionaryType;
    }
    public void setDictionaryType(Long dictionaryType) {
        this.mDictionaryType = dictionaryType;
    }

    /**
     * 辞書バージョン.
     */
    public Long getDictionaryVersion() {
        return mDictionaryVersion;
    }
    public void setDictionaryVersion(Long dictionaryVersion) {
        this.mDictionaryVersion = dictionaryVersion;
    }

    /**
     * カード情報.
     */
    public List<AddDictionaryResultCard> getCard() {
        return mCard;
    }
    public void setCard(List<AddDictionaryResultCard> card) {
        this.mCard = card;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AddDictionaryResult dictionaryResult = (AddDictionaryResult) o;
        return (this.mDictionaryId == null ? dictionaryResult.mDictionaryId == null : this.mDictionaryId.equals(dictionaryResult.mDictionaryId)) &&
                (this.mDictionaryType == null ? dictionaryResult.mDictionaryType == null : this.mDictionaryType.equals(dictionaryResult.mDictionaryType)) &&
                (this.mDictionaryVersion == null ? dictionaryResult.mDictionaryVersion == null : this.mDictionaryVersion.equals(dictionaryResult.mDictionaryVersion)) &&
                (this.mCard == null ? dictionaryResult.mCard == null : this.mCard.equals(dictionaryResult.mCard));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mDictionaryId == null ? 0: this.mDictionaryId.hashCode());
        result = 31 * result + (this.mDictionaryType == null ? 0: this.mDictionaryType.hashCode());
        result = 31 * result + (this.mDictionaryVersion == null ? 0: this.mDictionaryVersion.hashCode());
        result = 31 * result + (this.mCard == null ? 0: this.mCard.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class AddDictionaryResult {\n");

        sb.append("  mDictionaryId: ").append(mDictionaryId).append("\n");
        sb.append("  mDictionaryType: ").append(mDictionaryType).append("\n");
        sb.append("  mDictionaryVersion: ").append(mDictionaryVersion).append("\n");
        sb.append("  mCard: ").append(mCard).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
