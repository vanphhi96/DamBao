/*
 * ファイル：SchDictionaryCheckDialogFactory.java
 * 概要：Dialog schedule dictionary check.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories.customfactories;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;

import jp.softbank.assist.R;
import jp.softbank.assist.view.adapter.AdapterDialogSchDictionary;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;

/**
 * sch-dic-01.
 *
 * @author Systena
 * @version 1.0
 */
public class SchDictionaryCheckDialogFactory extends BaseDialogFactory implements View.OnClickListener {

    private DialogTypeControl.DialogType mDialogType;
    private ISchDictionaryCheck mISchDictionaryCheck;
    private RecyclerView mRvScheduleDictionary;

    public SchDictionaryCheckDialogFactory(DialogTypeControl.DialogType dialogType, ISchDictionaryCheck iSchDictionaryCheck) {
        this.mDialogType = dialogType;
        this.mISchDictionaryCheck = iSchDictionaryCheck;
    }

    @Override
    public AlertDialog getReadyAlertDialog(FragmentActivity activity) {
        AlertDialog.Builder builder = createDialogBuilder(activity);
        LayoutInflater inflater = activity.getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_sch_dictionary_check, null);
        mRvScheduleDictionary = view.findViewById(R.id.rv_schedule_dic);
        AdapterDialogSchDictionary adapterDialogSchDictionary = new AdapterDialogSchDictionary();
        LinearLayoutManager layoutManager = new LinearLayoutManager(view.getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRvScheduleDictionary.setLayoutManager(layoutManager);
        mRvScheduleDictionary.setAdapter(adapterDialogSchDictionary);
        setData();
        setPositivelyDialog(false);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return alertDialog;
    }

    @Override
    public String getDialogTag() {
        return mDialogType.name();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_btn_ok_dialog_sch_cr:
                break;
            default:
                break;
        }
    }

    /**
     * set data for dialog
     */
    public void setData() {

    }
}
