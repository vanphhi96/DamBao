/*
 * ファイル：ISetTimePicker.java
 * 概要：Time Picker in Setting Interface
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories.customfactories;

import java.util.Date;

/**
 * sch-pos-02.
 *
 * @author Systena
 * @version 1.0
 */
public interface ISetTimePicker {
    void onOkClick(int viewId, Date date);

    void onCancelClick();
}
