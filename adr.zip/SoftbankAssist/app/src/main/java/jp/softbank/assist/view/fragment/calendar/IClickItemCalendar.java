/*
 * ファイル：IClickItemCalendar.java
 * 概要：Interface click item calendar
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment.calendar;

import jp.softbank.assist.model.database.ScheduleCount;

/**
 * sch-cal.
 *
 * @author Systena
 * @version 1.0
 */
public interface IClickItemCalendar {
    /**
     * interface click item in grid calendar
     *
     * @param scheduleCount item schedule count click.
     */
    void onItemClick(ScheduleCount scheduleCount);
}
