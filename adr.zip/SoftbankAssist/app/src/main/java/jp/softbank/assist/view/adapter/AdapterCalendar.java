/*
 * ファイル：AdapterCalendar.java
 * 概要：Adapter month view calendar
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.ScheduleCount;
import jp.softbank.assist.util.CalendarUtils;
import jp.softbank.assist.view.fragment.calendar.IClickItemCalendar;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * sch-cal.
 *
 * @author Systena
 * @version 1.0
 */
public class AdapterCalendar extends RecyclerView.Adapter<AdapterCalendar.ViewHolder> {

    private final ArrayList<ScheduleCount> mListScheduleCount;
    private IClickItemCalendar mClickListener;
    private Date mDate;
    private int mNumberRows;

    /**
     * constructor adapter grid calendar
     *
     * @param days       list date
     * @param date       date show
     * @param numberRows number row
     */
    public AdapterCalendar(ArrayList<ScheduleCount> days, Date date, int numberRows) {
        this.mListScheduleCount = days;
        this.mDate = date;
        this.mNumberRows = numberRows;
    }

    @Override
    @NonNull
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout view = (LinearLayout) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.calendar_item, parent, false);
        //update height item in grid calendar
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.width = ViewGroup.LayoutParams.MATCH_PARENT;
        params.height = CalendarUtils.setHeightItemCalendar(view.getContext(), mNumberRows);
        view.setLayoutParams(params);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ScheduleCount scheduleCount = mListScheduleCount.get(position);
        Calendar cal = Calendar.getInstance();
        // get value of current day
        int currentDay = cal.get(Calendar.DAY_OF_MONTH);
        int currentMonth = cal.get(Calendar.MONTH);
        int currentYear = cal.get(Calendar.YEAR);
        // get value of day in cell
        cal.setTime(scheduleCount.getDate());
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        cal.setTime(mDate);
        // if days of another month
        if (month != cal.get(Calendar.MONTH)) {
            holder.mTvDay.setVisibility(View.INVISIBLE);
            holder.mTvTotalEvents.setVisibility(View.INVISIBLE);
        }

        if (isSunday(scheduleCount.getDate())) {
            holder.mTvDay.setTextColor(holder.mTvDay.getContext().getResources()
                    .getColor(R.color.calendar_color_sunday, null));
        } else if (isSaturday(scheduleCount.getDate())) {
            holder.mTvDay.setTextColor(holder.mTvDay.getContext().getResources()
                    .getColor(R.color.calendar_color_saturday, null));
        } else if (day == currentDay && month == currentMonth && year == currentYear) {
            //if is today
            holder.mTvDay.setTextColor(Color.WHITE);
            holder.mTvDay.setBackground(holder.mTvDay.getContext().getResources()
                    .getDrawable(R.drawable.bgr_layout_date, null));
        } else {
            holder.mTvDay.setTextColor(Color.WHITE);
        }

        if (scheduleCount.getCount() > 0) {
            if (year < currentYear || (year == currentYear && month < currentMonth)
                    || (month == currentMonth && year == currentYear && day < currentDay)) {
                holder.mTvTotalEvents.setBackground(holder.mTvTotalEvents.getContext().getResources()
                        .getDrawable(R.drawable.bgr_layout_total_disable, null));
                holder.mTvTotalEvents.setTextColor(Color.WHITE);
            } else {
                holder.mTvTotalEvents.setBackground(holder.mTvTotalEvents.getContext().getResources()
                        .getDrawable(R.drawable.bgr_layout_total, null));
                holder.mTvTotalEvents.setTextColor(holder.mTvTotalEvents.getResources().getColor(R.color.background, null));
            }
            holder.mTvTotalEvents.setText(String.valueOf(scheduleCount.getCount()));
        } else {
            holder.mTvTotalEvents.setVisibility(View.INVISIBLE);
        }
        holder.mTvDay.setText(String.valueOf(day));
    }

    @Override
    public int getItemCount() {
        return mListScheduleCount == null ? 0 : mListScheduleCount.size();
    }

    /**
     * view holder item of grid day
     */
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView mTvDay;
        TextView mTvTotalEvents;

        ViewHolder(View itemView) {
            super(itemView);
            mTvDay = itemView.findViewById(R.id.tv_date);
            mTvTotalEvents = itemView.findViewById(R.id.tv_total_schedule);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null && getLayoutPosition() != RecyclerView.NO_POSITION) {
                mClickListener.onItemClick(mListScheduleCount.get(getLayoutPosition()));
            }
        }
    }

    /**
     * set interface for adapter
     *
     * @param iClickItemCalendar IClickItemCalendar
     */
    public void setClickListener(IClickItemCalendar iClickItemCalendar) {
        this.mClickListener = iClickItemCalendar;
    }

    /**
     * check day is  Sunday
     *
     * @param date position of day in grid
     * @return true: day is Sunday, false: another day
     */
    private boolean isSunday(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;
    }

    /**
     * check day is  Saturday
     *
     * @param date position of day in grid
     * @return true: day is Saturday, false: another day
     */
    private boolean isSaturday(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY;
    }
}