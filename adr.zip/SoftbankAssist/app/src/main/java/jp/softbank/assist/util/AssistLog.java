/*
 * ファイル：AssistLog.java
 * 概要：ログの出力制御を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.util;

/**
 * ログ出力用クラス.
 *
 * @author Systena
 * @version 1.0
 */
public class AssistLog {

    // TODO:デバッグモードの設定をどこで行うか決めてほしい
//    private static final boolean DBG = !BuildConfig.DEBUG; // DebugフラグのON/OFF
    private static final boolean DBG = false; // DebugフラグのON/OFF
    private static final int STACK_NUM = 4;

    static String TAG = "ASSIST"; // Log出力用タグ

    /**
     * コンストラクタ. ログ出力時のTAGも合わせて指定可.
     *
     * @param tag タグ文字列
     */
    public AssistLog(String tag) {
        setTag(tag);
    }

    /**
     * ログ出力時のTAGを指定.
     *
     * @param tag タグ文字列
     */
    public static void setTag(String tag) {
        TAG = tag;
    }

    // ------------------------------------------------------------
    // 通常ログ出力用
    // ------------------------------------------------------------
    /**
     * ログ出力(Level:VERBOSE)
     *
     * @param msg メッセージ
     */
    public static void v(String msg) {
        if (DBG) {
            android.util.Log.v(TAG, getTrace() + msg);
        }
    }

    /**
     * ログ出力(Level:DEBUG)
     *
     * @param msg メッセージ
     */
    public static void d(String msg) {
        if (DBG) {
            android.util.Log.d(TAG, getTrace() + msg);
        }
    }

    /**
     * ログ出力(Level:INFO)
     *
     * @param msg メッセージ
     */
    public static void i(String msg) {
        android.util.Log.i(TAG, getTrace() + msg);
    }

    /**
     * ログ出力(Level:WARN)
     *
     * @param msg メッセージ
     */
    public static void w(String msg) {
        android.util.Log.w(TAG, getTrace() + msg);
    }

    /** ログ出力
     *  Level:ERROR
     */
    public static void e(String msg) {
        android.util.Log.e(TAG, getTrace() + msg, new Throwable());
    }

    /**
     * ログ出力(Level:ERROR)
     *   Throwable出力用
     *
     * @param msg メッセージ
     * @param throwable Throwable
     */
    public static void e(String msg, Throwable throwable) {
        android.util.Log.e(TAG, getTrace() + msg, throwable);
    }

    // ------------------------------------------------------------
    // 画面ID/アクションID確認用
    // ------------------------------------------------------------
    /**
     * ログ出力(Level:INFO)
     *
     * @param screenId 画面ID
     * @param actionId アクションID
     * @param msg メッセージ
     */
    public static void idInfo(String screenId, String actionId, String msg) {
        android.util.Log.i(TAG, getIdInfo(screenId, actionId) + msg);
    }

    /**
     * スタックトレース出力
     *
     * @param msg メッセージ
     */
    public static void trace(String msg) {
        if (DBG) {
            android.util.Log.d(TAG, getTrace() + msg, new Throwable());
        }
    }

    /**
     * タグを生成する
     *
     * @return className#methodName:line
     */
    private static String getTrace() {
        final StackTraceElement trace = Thread.currentThread().getStackTrace()[STACK_NUM];
        final String cla = trace.getClassName();
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("[\\.]+");
        final String[] splitedStr = pattern.split(cla);
        final String simpleClass = splitedStr[splitedStr.length - 1];
        final String mthd = trace.getMethodName();
        final int line = trace.getLineNumber();

        return "[" + simpleClass + "#" + mthd + ":" + line + "]";
    }

    /**
     * 画面ID、アクションID文字列生成
     *
     * @param screenId 画面ID
     * @param actionId アクションID
     * @return String
     */
    private static String getIdInfo(String screenId, String actionId) {
        return "[画面ID：" + screenId + ", アクションID：" + actionId +  "]";
    }

}
