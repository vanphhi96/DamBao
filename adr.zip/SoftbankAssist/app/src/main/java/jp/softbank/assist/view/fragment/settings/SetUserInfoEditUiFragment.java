/*
 * ファイル：SetUserInfoEditUiFragment.java
 * 概要：利用者情報編集画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment.settings;

import jp.softbank.assist.view.fragment.BaseFragment;

/**
 * set-acc-ed-01
 *
 * @author Systena
 * @version 1.0
 */
public class SetUserInfoEditUiFragment extends BaseFragment {
}
