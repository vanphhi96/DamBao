/*
 * ファイル：RegistUserRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.user;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

/**
 * ユーザ登録リクエスト.
 */
public class RegistUserRequest extends RequestBody {

    @SerializedName("user_kind")
    private Long mUserKind = null;
    @SerializedName("mCuid")
    private String mCuid = null;
    @SerializedName("mNickname")
    private String mNickname = null;
    @SerializedName("icon_id")
    private Long mIconId = null;


    /**
     * ユーザ種別（0:利用者、1:管理者）.
     */
    public Long getUserKind() {
        return mUserKind;
    }
    public void setUserKind(Long userKind) {
        this.mUserKind = userKind;
    }

    /**
     * CUID.
     */
    public String getCuid() {
        return mCuid;
    }
    public void setCuid(String cuid) {
        this.mCuid = cuid;
    }

    /**
     * ニックネーム.
     */
    public String getNickname() {
        return mNickname;
    }
    public void setNickname(String nickname) {
        this.mNickname = nickname;
    }

    /**
     * アイコンID.
     */
    public Long getIconId() {
        return mIconId;
    }
    public void setIconId(Long iconId) {
        this.mIconId = iconId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RegistUserRequest requestRegistUser = (RegistUserRequest) o;
        return (this.mUserKind == null ? requestRegistUser.mUserKind == null : this.mUserKind.equals(requestRegistUser.mUserKind)) &&
                (this.mCuid == null ? requestRegistUser.mCuid == null : this.mCuid.equals(requestRegistUser.mCuid)) &&
                (this.mNickname == null ? requestRegistUser.mNickname == null : this.mNickname.equals(requestRegistUser.mNickname)) &&
                (this.mIconId == null ? requestRegistUser.mIconId == null : this.mIconId.equals(requestRegistUser.mIconId));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mUserKind == null ? 0: this.mUserKind.hashCode());
        result = 31 * result + (this.mCuid == null ? 0: this.mCuid.hashCode());
        result = 31 * result + (this.mNickname == null ? 0: this.mNickname.hashCode());
        result = 31 * result + (this.mIconId == null ? 0: this.mIconId.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class RegistUserRequest {\n");

        sb.append("  mUserKind: ").append(mUserKind).append("\n");
        sb.append("  mCuid: ").append(mCuid).append("\n");
        sb.append("  mNickname: ").append(mNickname).append("\n");
        sb.append("  mIconId: ").append(mIconId).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
