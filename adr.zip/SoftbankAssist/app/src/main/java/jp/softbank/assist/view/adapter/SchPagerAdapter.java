/*
 * ファイル：SchPagerAdapter.java
 * 概要：Schedule pager adapter (sch-01)
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import jp.softbank.assist.view.fragment.schedule.SchPageFragment;

import java.util.Date;
import java.util.List;

/**
 * Schedule pager adapter (sch-01)
 *
 * @author Systena
 * @version 1.0
 */
public class SchPagerAdapter extends FragmentStatePagerAdapter {
    private List<Date> mListDays;

    public SchPagerAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);
    }


    @Override
    public int getCount() {
        return mListDays.size();
    }

    @Override
    public Fragment getItem(int position) {
        return new SchPageFragment(mListDays.get(position));
    }

    /**
     * get date from position
     *
     * @param position current page position
     * @return Date
     */
    public Date getDate(int position) {
        return mListDays.get(position);
    }

    /**
     * set data for list days
     *
     * @param listDays list days
     */
    public void setListDate(List<Date> listDays) {
        this.mListDays = listDays;
    }

    @Override
    public Parcelable saveState() {
        Bundle bundle = (Bundle) super.saveState();
        bundle.putParcelableArray("states", null); // Never maintain any states from the base class, just null it out
        return bundle;
    }
}
