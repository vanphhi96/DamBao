/*
 * ファイル：SetInformationDetailWebActivity.java
 * 概要：お知らせ詳細画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.settings;

import android.view.View;

import jp.softbank.assist.R;
import jp.softbank.assist.view.activity.BaseWebActivity;

/**
 * set-abo-inf-01
 *
 * @author Systena
 * @version 1.0
 */
public class SetInformationDetailWebActivity extends BaseWebActivity implements View.OnClickListener {
    public static final String URL_INFORMATION = "https://google.com";

    @Override
    protected void getDataIntent() {
        super.getDataIntent();
        mTitleWeb = getString(R.string.set_notice_title);
        mTextBack = getString(R.string.set_setting);

        //TODO[8142] fake data to test
        mUrlWebView = URL_INFORMATION;
    }
}
