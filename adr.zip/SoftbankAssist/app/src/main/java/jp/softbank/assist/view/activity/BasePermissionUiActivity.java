/*
 * ファイル：BasePermissionUiActivity.java
 * 概要：パーミッションのベースクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.activity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;

import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.view.activity.main.CheckAppUiActivity;

import java.util.ArrayList;

/**
 * パーミッションのベースクラス
 *
 * @author Systena
 * @version 1.0
 */
public abstract class BasePermissionUiActivity extends BaseUiActivity {

    private static final int ALL_PERMISSIONS_RESULT = 1011;
    //Permissionのリスト
    private ArrayList<String> mPermissionsToRequest;
    private ArrayList<String> mPermissionsRejected = new ArrayList<>();
    private ArrayList<String> mPermissions = new ArrayList<>();

    /**
     * 拒否されたパーミッション取得
     *
     * @return 拒否されたパーミッション
     */
    public ArrayList<String> getPermissionsRejected() {
        return mPermissionsRejected;
    }

    /**
     * Permissionを追加ため。
     */
    public void addPermission() {
        if (mPermissionsRejected != null && mPermissionsRejected.size() != 0) {
            requestPermissions(mPermissionsRejected.
                    toArray(new String[mPermissionsRejected.size()]), ALL_PERMISSIONS_RESULT);
        } else {
            mPermissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
            mPermissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            mPermissions.add(Manifest.permission.CAMERA);
            mPermissions.add(Manifest.permission.WAKE_LOCK);
            mPermissionsToRequest = permissionsToRequest(mPermissions);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (mPermissionsToRequest.size() > 0) {
                    requestPermissions(mPermissionsToRequest.toArray(
                            new String[mPermissionsToRequest.size()]), ALL_PERMISSIONS_RESULT);
                } else {
                    AppController.getInstance().getAssistServerInterface().getLatestAppVersion((CheckAppUiActivity) this);
                }
            }
        }
    }

    /**
     * Permissionを追加ため。
     *
     * @return
     */
    private ArrayList<String> permissionsToRequest(ArrayList<String> wantedPermissions) {
        ArrayList<String> result = new ArrayList<>();
        for (String perm : wantedPermissions) {
            if (!hasPermission(perm)) {
                result.add(perm);
            }
        }
        return result;
    }

    /**
     * Permissionを追加ため。
     *
     * @return
     * @Param permission
     */

    private boolean hasPermission(String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (this instanceof CheckAppUiActivity) {
            switch (requestCode) {
                case ALL_PERMISSIONS_RESULT:
                    for (String perm : mPermissionsToRequest) {
                        if (!hasPermission(perm)) {
                            mPermissionsRejected.add(perm);
                        }
                    }
                    // 2019/04/02 [#7396]  Dialogで表示するかまだ不明。一旦Dialogで / Not yet described。(タン)
                    // [ Updated 2019/04/03 ] 一旦 Dialog無しでRuntimeのPermissionができるようにします。

          /*          if (mPermissionsRejected.size() > 0) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(mPermissionsRejected.get(0))) {
                                new AlertDialog.Builder(this)
                                        .setMessage("このパーミッションが必要です。")
                                        .setPositiveButton("許可", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                    requestPermissions(mPermissionsRejected
                                                            .toArray(new String[mPermissionsRejected.size()]), ALL_PERMISSIONS_RESULT);
                                                }
                                            }
                                        })
                                        .setCancelable(false)
                                        .create()
                                        .show();
                                return;
                            }
                        }
                    }*/
                    AppController.getInstance().getAssistServerInterface().getLatestAppVersion((CheckAppUiActivity) this);
                    break;
            }
        }
    }
}
