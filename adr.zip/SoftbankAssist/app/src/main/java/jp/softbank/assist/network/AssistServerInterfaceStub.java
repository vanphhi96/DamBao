/*
 * ファイル：AssistServerInterfaceStub.java
 * 概要：アシストサーバー向けのI/Fを提供する
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network;

import android.content.Context;
import android.os.Build;
import android.util.SparseLongArray;

import jp.softbank.assist.BuildConfig;
import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.AppVersionInfo;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DeviceInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.model.database.LocationInfo;
import jp.softbank.assist.model.database.LocationSettings;
import jp.softbank.assist.model.database.NoticeInfo;
import jp.softbank.assist.model.database.ScheduleCount;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.model.database.UserInfo;
import jp.softbank.assist.network.listener.CountScheduleResultListener;
import jp.softbank.assist.network.listener.GetAppVersionResultListener;
import jp.softbank.assist.network.listener.GetDictionaryListResultListener;
import jp.softbank.assist.network.listener.GetHistoryResultListener;
import jp.softbank.assist.network.listener.GetImageResultListener;
import jp.softbank.assist.network.listener.GetNoticeResultListener;
import jp.softbank.assist.network.listener.GetScheduleListResultListener;
import jp.softbank.assist.network.listener.GetUserInfoResultListener;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.Constants;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * 開発用スタブクラス.
 *
 * @author Systena
 * @version 1.0
 */
class AssistServerInterfaceStub extends AssistServerInterface {

    /**
     * コンストラクタ.
     */
    AssistServerInterfaceStub(Context ctx) {
        super(ctx);
    }

    /**
     * 辞書カテゴリ一覧取得.
     *
     * @return カテゴリ情報一覧
     */
    @Override
    public List<CategoryInfo> getCategoryList() {
        /**
         * TODO:sample stub code.
         */

        List<CategoryInfo> list = new ArrayList<CategoryInfo>();

        CategoryInfo info = new CategoryInfo();
        info.setCategoryId(Constants.Ids.CATEGORY_ID_HOW_TO_DO);
        info.setName(getAppContext().getString(R.string.how_to_do));
        info.setCount(6);
        list.add(info);

        info = new CategoryInfo();
        info.setCategoryId(Constants.Ids.CATEGORY_ID_HOW_TO_GO);
        info.setName(getAppContext().getString(R.string.how_to_go));
        info.setCount(7);
        list.add(info);

        info = new CategoryInfo();
        info.setCategoryId(Constants.Ids.CATEGORY_ID_PROPERTY);
        info.setName(getAppContext().getString(R.string.belongings));
        info.setCount(8);
        list.add(info);

        return list;
    }


    /**
     * 辞書差分一覧取得.
     */
    @Override
    public void getDifferenceListDictionary() {
        // TODO:Run in the background. No notification to UI.
    }

    /**
     * カテゴリ別辞書一覧取得.
     *
     * @param categoryId カテゴリID
     * @param listener   コールバックリスナ
     */
    @Override
    public void getDictionaryList(final long categoryId, final GetDictionaryListResultListener listener) {
        /**
         * TODO:sample stub code.
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Call when communication occurs.
        if (true) {
            listener.onStartConnection(); // not UI thread
        }

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                listener.onResult(result, makeDictionaryList(categoryId));
            }
        }, 2 * 1000);

    }

    private List<DictionaryInfo> makeDictionaryList(final long categoryId) {
        List<DictionaryInfo> list = new ArrayList<DictionaryInfo>();
        DictionaryInfo.DictionaryType typeDic = DictionaryInfo.DictionaryType.Step;
        int count = 6;
        if (categoryId == Constants.Ids.CATEGORY_ID_HOW_TO_GO) {
            count = 7;
            typeDic = DictionaryInfo.DictionaryType.Step;
        } else if (categoryId == Constants.Ids.CATEGORY_ID_PROPERTY) {
            count = 8;
            typeDic = DictionaryInfo.DictionaryType.Check;
        }
        if (categoryId != Constants.Ids.ID_NONE) {
            for (int j = 0; j < count; j++) {
                DictionaryInfo dictionaryInfo = new DictionaryInfo();
                dictionaryInfo.setType(typeDic);
                dictionaryInfo.setCategoryId(categoryId);
                dictionaryInfo.setCreatedDate(Calendar.getInstance().getTime());
                dictionaryInfo.setDictionaryId(j);
                dictionaryInfo.setVersion(1L);
                dictionaryInfo.setName(j + "バスの乗り方 バスの乗り方");
                dictionaryInfo.setCreatorNickname("おかあさん");
                String pathImage = "";
                //pathImage = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath() + "/Camera/1111.jpg"; //edit when test
                dictionaryInfo.setCreatorIconId(2);
                dictionaryInfo.setCreatedDate(Calendar.getInstance().getTime());
                dictionaryInfo.setUpdatedDate(Calendar.getInstance().getTime());
                List<CardInfo> cardInfoList = new ArrayList<>();
                for (int i = 0; i < 10; i++) {
                    CardInfo cardInfo = new CardInfo();
                    if (i % 2 == 0) {

                        cardInfo.setImageUrl("http://test.png");
                    }
                    cardInfo.setDictionaryId(j);
                    cardInfo.setCardId(i);
                    cardInfo.setCreatedDate(Calendar.getInstance().getTime());
                    cardInfo.setText(i + "校門を出てすぐ左の「杉田平和町」乗り場へ行く");
                    cardInfo.setCreatedDate(Calendar.getInstance().getTime());
                    cardInfo.setUpdatedDate(Calendar.getInstance().getTime());
                    cardInfoList.add(cardInfo);
                }
                dictionaryInfo.setCardList(cardInfoList);
                list.add(dictionaryInfo);
            }
        }
        return list;
    }

    /**
     * 辞書登録.
     *
     * @param info     辞書情報
     * @param listener コールバックリスナ
     */
    @Override
    public void addDictionary(final DictionaryInfo info, final NotifyOnlyResultListener listener) {
        /**
         * TODO:sample stub code.
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
//                // ResponseError
//                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
//                        101, "invalid parameter", "user_id");

                listener.onResult(result);
            }
        }, 2 * 1000);
    }

    /**
     * 辞書編集.
     *
     * @param info     辞書情報
     * @param listener コールバックリスナ
     */
    @Override
    public void editDictionary(final DictionaryInfo info, final NotifyOnlyResultListener listener) {
        /**
         * TODO:sample stub code.
         * @see addDictionary
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
//                // ResponseError
//                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
//                        101, "invalid parameter", "user_id");

                listener.onResult(result);
            }
        }, 2 * 1000);
    }

    /**
     * 辞書削除.
     *
     * @param dictionaryId 辞書ID
     * @param listener     コールバックリスナ
     */
    @Override
    public void deleteDictionary(final long dictionaryId, final NotifyOnlyResultListener listener) {
        /**
         * TODO:sample stub code.
         * @see addDictionary
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
//                // ResponseError
//                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
//                        101, "invalid parameter", "user_id");

                listener.onResult(result);
            }
        }, 2 * 1000);
    }

    /**
     * 辞書画像取得.
     *
     * @param dictionaryId 辞書ID
     * @param listener     コールバックリスナ
     */
    @Override
    public void getDictionaryImage(final long dictionaryId, final GetImageResultListener listener) {
        /**
         * TODO:sample stub code.
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Call when communication occurs.
        if (true) {
            listener.onStartConnection(); // not UI thread
        }

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                String filepath = ""; // TODO:Set the image file path in the device.
//                // ResponseError
//                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
//                        101, "invalid parameter", "user_id");
//                String filepath = "";

                listener.onResult(result, filepath);
            }
        }, 2 * 1000);

    }

    /**
     * カード画像取得.
     *
     * @param cardInfo 辞書
     * @param listener コールバックリスナ
     */
    @Override
    public void getCardImage(final CardInfo cardInfo, final GetImageResultListener listener) {
        /**
         * TODO:sample stub code.
         * @see getDictionaryImage
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Call when communication occurs.
        if (true) {
            listener.onStartConnection(); // not UI thread
        }

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                String filepath = ""; // TODO:Set the image file path in the device.
                File file = new File(filepath);
                cardInfo.setImageFileName(file.getName());
//                // ResponseError
//                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
//                        101, "invalid parameter", "user_id");
//                String filepath = "";

                listener.onResult(result, filepath);
            }
        }, 2 * 1000);
    }

    /**
     * 辞書の並び替えを保存.
     *
     * @param list 辞書一覧
     */
    @Override
    public void saveDictionaryOrder(final List<DictionaryInfo> list) {
        // TODO:Save to DB
    }

    /**
     * 辞書の並び替えを保存.
     *
     * @param categoryId カテゴリID
     * @param idArray    辞書ID配列
     */
    @Override
    public void saveDictionaryOrder(final long categoryId, final SparseLongArray idArray) {
        // TODO:Save to DB
    }

    /**
     * スケジュール同期.
     */
    @Override
    public void syncScheduleList() {
        // TODO:Run in the background. No notification to UI.
    }

    /**
     * スケジュール取得（日付指定）.
     *
     * @param date     日付
     * @param listener コールバックリスナ
     */
    @Override
    public void getScheduleList(final Date date, final GetScheduleListResultListener listener) {
        /**
         * TODO:sample stub code.
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Call when communication occurs.
        if (true) {
            listener.onStartConnection(); // not UI thread
        }

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                listener.onResult(result, makeScheduleList(date));
            }
        }, 2 * 1000);

    }

    private List<ScheduleInfo> makeScheduleList(Date date) {
        List<ScheduleInfo> list = new ArrayList<ScheduleInfo>();
        List<CardInfo> cardInfoList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            CardInfo cardInfo = new CardInfo();
            if (i % 2 == 0) {
                cardInfo.setImageUrl("http://test.png");
            }
            cardInfo.setDictionaryId(i);
            cardInfo.setCardId(i);
            cardInfo.setCreatedDate(Calendar.getInstance().getTime());
            cardInfo.setText(i + "校門を出てすぐ左の「杉田平和町」乗り場へ行く");
            cardInfo.setCreatedDate(Calendar.getInstance().getTime());
            cardInfo.setUpdatedDate(Calendar.getInstance().getTime());
            cardInfoList.add(cardInfo);
        }
        for (int i = 0; i < 10; i++) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            ScheduleInfo scheduleInfo = new ScheduleInfo();
            scheduleInfo.setIconName("schedule_icon_name_05");
            scheduleInfo.setCreatorNickname("おかあさん");
            scheduleInfo.setTitle(i + "学校に到着学校に到着");
            scheduleInfo.setNote("たくさん食べてねたくさん食べてたくさん食べてねたくさん食べ");
            scheduleInfo.setLocation("〇〇学校〇〇学校〇学校〇〇学校〇〇学校〇学校〇〇学校〇");
            scheduleInfo.setCreatorIconId(2);
            List<DictionaryInfo> list1 = new ArrayList<>();
            List<DictionaryInfo> list2 = new ArrayList<>();
            DictionaryInfo dictionaryInfo = new DictionaryInfo();
            dictionaryInfo.setName("1手を爪の中までしっかり30秒ゴシゴシ洗いましょう。手の甲と手");
            dictionaryInfo.setCategoryId(Constants.Ids.CATEGORY_ID_HOW_TO_DO);
            dictionaryInfo.setCardList(cardInfoList);
            dictionaryInfo.setType(DictionaryInfo.DictionaryType.Step);
            dictionaryInfo.setCreatedDate(Calendar.getInstance().getTime());
            dictionaryInfo.setCreatorIconId(1);
            list1.add(dictionaryInfo);
            DictionaryInfo dictionaryInfo1 = new DictionaryInfo();
            dictionaryInfo1.setName("2手を爪の中までしっかり30秒ゴシゴシ洗いましょう。手の甲と手");
            dictionaryInfo1.setCategoryId(Constants.Ids.CATEGORY_ID_HOW_TO_GO);
            dictionaryInfo1.setCardList(cardInfoList);
            dictionaryInfo1.setType(DictionaryInfo.DictionaryType.Step);
            dictionaryInfo1.setCreatedDate(Calendar.getInstance().getTime());
            dictionaryInfo1.setCreatorIconId(2);
            list1.add(dictionaryInfo1);
            DictionaryInfo dictionaryInfo2 = new DictionaryInfo();
            dictionaryInfo2.setName("3手を爪の中までしっかり30秒ゴシゴシ洗いましょう。手の甲と手");
            dictionaryInfo2.setCategoryId(Constants.Ids.CATEGORY_ID_PROPERTY);
            dictionaryInfo2.setCardList(cardInfoList);
            dictionaryInfo2.setType(DictionaryInfo.DictionaryType.Check);
            dictionaryInfo2.setCreatedDate(Calendar.getInstance().getTime());
            dictionaryInfo2.setCreatorIconId(3);
            list1.add(dictionaryInfo2);
            scheduleInfo.setAttachedDictionaries(list1);
            switch (i) {
                case 0:
                    scheduleInfo.setIsAllDay(true);
                    calendar.set(Calendar.HOUR_OF_DAY, 8);
                    calendar.set(Calendar.MINUTE, 30);
                    scheduleInfo.setScheduleStartDate(calendar.getTime());
                    calendar.set(Calendar.HOUR_OF_DAY, 8);
                    calendar.set(Calendar.MINUTE, 50);
                    scheduleInfo.setScheduleEndDate(calendar.getTime());
                    scheduleInfo.setRepeatStartDate(date);
                    scheduleInfo.setRepeatEndDate(calendar.getTime());
                    break;
                case 1:
                    scheduleInfo.setIsAllDay(true);
                    scheduleInfo.setIsCompleted(true);
                    calendar.set(Calendar.HOUR_OF_DAY, 8);
                    calendar.set(Calendar.MINUTE, 20);
                    scheduleInfo.setScheduleStartDate(calendar.getTime());
                    calendar.set(Calendar.HOUR_OF_DAY, 8);
                    calendar.set(Calendar.MINUTE, 50);
                    scheduleInfo.setScheduleEndDate(calendar.getTime());
                    scheduleInfo.setRepeatStartDate(date);
                    scheduleInfo.setRepeatEndDate(calendar.getTime());
                    break;
                case 2:
                    scheduleInfo.setIsAllDay(true);
                    scheduleInfo.setIsCompleted(true);
                    calendar.set(Calendar.HOUR_OF_DAY, 8);
                    calendar.set(Calendar.MINUTE, 30);
                    scheduleInfo.setScheduleStartDate(calendar.getTime());
                    calendar.set(Calendar.HOUR_OF_DAY, 8);
                    calendar.set(Calendar.MINUTE, 40);
                    scheduleInfo.setScheduleEndDate(calendar.getTime());
                    scheduleInfo.setRepeatStartDate(date);
                    scheduleInfo.setRepeatEndDate(calendar.getTime());
                    break;
                case 3:
                    calendar.set(Calendar.DAY_OF_MONTH, 8);
                    calendar.set(Calendar.MONTH, 3);
                    calendar.set(Calendar.HOUR_OF_DAY, 10);
                    calendar.set(Calendar.MINUTE, 0);
                    scheduleInfo.setScheduleStartDate(calendar.getTime());
                    calendar.set(Calendar.DAY_OF_MONTH, 9);
                    calendar.set(Calendar.MONTH, 3);
                    calendar.set(Calendar.HOUR_OF_DAY, 11);
                    calendar.set(Calendar.MINUTE, 00);
                    scheduleInfo.setScheduleEndDate(calendar.getTime());
                    scheduleInfo.setRepeatStartDate(date);
                    scheduleInfo.setRepeatEndDate(calendar.getTime());
                    break;
                case 4:
                    calendar.set(Calendar.DAY_OF_MONTH, 9);
                    calendar.set(Calendar.MONTH, 3);
                    calendar.set(Calendar.HOUR_OF_DAY, 9);
                    calendar.set(Calendar.MINUTE, 0);
                    scheduleInfo.setScheduleStartDate(calendar.getTime());
                    calendar.set(Calendar.HOUR_OF_DAY, 11);
                    calendar.set(Calendar.MINUTE, 0);
                    scheduleInfo.setScheduleEndDate(calendar.getTime());
                    scheduleInfo.setRepeatStartDate(date);
                    scheduleInfo.setRepeatEndDate(calendar.getTime());
                    scheduleInfo.setAttachedDictionaries(list2);
                    break;
                case 5:
                    scheduleInfo.setCreatorIconId(0);
                    calendar.set(Calendar.DAY_OF_MONTH, 7);
                    calendar.set(Calendar.MONTH, 3);
                    calendar.set(Calendar.HOUR_OF_DAY, 10);
                    calendar.set(Calendar.MINUTE, 0);
                    scheduleInfo.setScheduleStartDate(calendar.getTime());
                    calendar.set(Calendar.DAY_OF_MONTH, 10);
                    calendar.set(Calendar.MONTH, 3);
                    calendar.set(Calendar.HOUR_OF_DAY, 12);
                    calendar.set(Calendar.MINUTE, 0);
                    scheduleInfo.setScheduleEndDate(calendar.getTime());
                    scheduleInfo.setRepeatStartDate(date);
                    scheduleInfo.setRepeatEndDate(calendar.getTime());
                    break;
                case 6:
                    calendar.set(Calendar.DAY_OF_MONTH, 9);
                    calendar.set(Calendar.MONTH, 3);
                    calendar.set(Calendar.HOUR_OF_DAY, 9);
                    calendar.set(Calendar.MINUTE, 0);
                    scheduleInfo.setScheduleStartDate(calendar.getTime());
                    calendar.set(Calendar.DAY_OF_MONTH, 10);
                    calendar.set(Calendar.MONTH, 3);
                    calendar.set(Calendar.HOUR_OF_DAY, 11);
                    calendar.set(Calendar.MINUTE, 0);
                    scheduleInfo.setScheduleEndDate(calendar.getTime());
                    scheduleInfo.setRepeatStartDate(date);
                    scheduleInfo.setRepeatEndDate(calendar.getTime());
                    break;
                case 7:
                    calendar.set(Calendar.HOUR_OF_DAY, 14);
                    calendar.set(Calendar.MINUTE, 30);
                    scheduleInfo.setScheduleStartDate(calendar.getTime());
                    calendar.set(Calendar.HOUR_OF_DAY, 15);
                    calendar.set(Calendar.MINUTE, 40);
                    scheduleInfo.setScheduleEndDate(calendar.getTime());
                    scheduleInfo.setRepeatStartDate(date);
                    scheduleInfo.setRepeatEndDate(calendar.getTime());
                    break;
                case 8:
                    calendar.set(Calendar.HOUR_OF_DAY, 16);
                    calendar.set(Calendar.MINUTE, 30);
                    scheduleInfo.setScheduleStartDate(calendar.getTime());
                    calendar.set(Calendar.HOUR_OF_DAY, 17);
                    calendar.set(Calendar.MINUTE, 40);
                    scheduleInfo.setScheduleEndDate(calendar.getTime());
                    scheduleInfo.setRepeatStartDate(date);
                    scheduleInfo.setRepeatEndDate(calendar.getTime());
                    break;
                case 9:
                    calendar.set(Calendar.DAY_OF_MONTH, 10);
                    calendar.set(Calendar.MONTH, 3);
                    calendar.set(Calendar.HOUR_OF_DAY, 14);
                    calendar.set(Calendar.MINUTE, 40);
                    scheduleInfo.setScheduleStartDate(calendar.getTime());
                    calendar.set(Calendar.HOUR_OF_DAY, 15);
                    calendar.set(Calendar.MINUTE, 00);
                    scheduleInfo.setScheduleEndDate(calendar.getTime());
                    scheduleInfo.setRepeatStartDate(date);
                    scheduleInfo.setRepeatEndDate(calendar.getTime());
                    break;
            }
            list.add(scheduleInfo);
        }
        return list;
    }

    /**
     * スケジュール追加.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    @Override
    public void addSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener) {
        /**
         * TODO:sample stub code.
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
//                // ResponseError
//                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
//                        101, "invalid parameter", "user_id");

                listener.onResult(result);
            }
        }, 2 * 1000);
    }

    /**
     * スケジュール編集.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    @Override
    public void editSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener) {
        /**
         * TODO:sample stub code.
         * @see addSchedule
         */
        if (listener == null) {
            return; // No callback required.
        }

        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
//                // ResponseError
//                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
//                        101, "invalid parameter", "user_id");

                listener.onResult(result);
            }
        }, 2 * 1000);
    }

    /**
     * スケジュール削除.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    @Override
    public void deleteSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener) {
        /**
         * TODO:sample stub code.
         * @see addSchedule
         */
        if (listener == null) {
            return; // No callback required.
        }

        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
//                // ResponseError
//                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
//                        101, "invalid parameter", "user_id");

                listener.onResult(result);
            }
        }, 2 * 1000);
    }

    /**
     * スケジュール完了.
     *
     * @param info     スケジュール情報
     * @param listener コールバックリスナ
     */
    @Override
    public void completeSchedule(final ScheduleInfo info, final NotifyOnlyResultListener listener) {
        /**
         * TODO:sample stub code.
         * @see addSchedule
         */
        if (listener == null) {
            return; // No callback required.
        }

        // Call when communication occurs.
        if (true) {
            listener.onStartConnection(); // not UI thread
        }

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                listener.onResult(result);
            }
        }, 2 * 1000);
    }

    /**
     * スケジュール件数の取得.
     *
     * @param yearmonth 年月
     * @param listener  コールバックリスナ
     */
    @Override
    public void countSchedule(final Date yearmonth, final CountScheduleResultListener listener) {
        /**
         * TODO:sample stub code.
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Call when communication occurs.
        if (true) {
            listener.onStartConnection(); // not UI thread
        }

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                listener.onResult(result, makeScheduleCountList(yearmonth));
            }
        }, 2 * 1000);

    }

    private List<ScheduleCount> makeScheduleCountList(Date yearmonth) {
        List<ScheduleCount> list = new ArrayList<ScheduleCount>();

        // TODO:Prepare the data here.
        for (int i = 1; i < 25; i++) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(yearmonth);
            calendar.set(Calendar.DAY_OF_MONTH, i);
            int count = new Random().nextInt(10);
            if (count > 0) {
                ScheduleCount scheduleCount = new ScheduleCount();
                scheduleCount.setDate(calendar.getTime());
                scheduleCount.setCount(count);
                list.add(scheduleCount);
            }
        }
        return list;
    }

    /**
     * 位置測位結果の送信.
     *
     * @param info 位置測位結果.
     */
    @Override
    public void registLocation(final LocationInfo info) {
        // TODO:Run in the background. No notification to UI.
    }

    /**
     * 操作履歴取得.
     *
     * @param displayPage         表示ページ
     * @param displayCountPerPage ページあたりの表示件数
     * @param listener            コールバックリスナ
     */
    @Override
    public void getHistory(final int displayPage, final int displayCountPerPage, final GetHistoryResultListener listener) {
        // TODO:It is unclear what HTML data is returned from the server.
        if (listener == null) {
            return; // No callback required.
        }
        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                String html = "<!DOCTYPE html>\n" +
                        "<html>\n" +
                        "<body>\n" +
                        "<p>TODO[#8140] create html web to test</p>\n" +
                        "\n" +
                        "</body>\n" +
                        "</html>";
                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                listener.onResult(result, html);
            }
        }, 2 * 1000);

    }

    /**
     * 最新のお知らせ取得.
     *
     * @param listener コールバックリスナ
     * @deprecated WebViewへ変更
     */
    @Deprecated
    @Override
    public void getLatestNotice(final GetNoticeResultListener listener) {
        /**
         * TODO:sample stub code.
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                listener.onResult(result, makeNoticeInfo());
            }
        }, 2 * 1000);

    }

    private NoticeInfo makeNoticeInfo() {
        NoticeInfo info = new NoticeInfo();

        info.setTitle("お知らせタイトル");
        info.setContents("お知らせ内容");
        info.setIsPriority(false);
        Calendar cal = Calendar.getInstance();
        cal.set(2019, 3, 13, 8, 00);
        info.setDeliveredDate(cal.getTime());

        return info;
    }

    /**
     * デバイス情報の登録・更新.
     */
    @Override
    public void registDeviceInfo() {
        // TODO:Run in the background. No notification to UI.
    }

    /**
     * FCMトークン更新.
     *
     * @param token トークン
     */
    @Override
    public void updateFcmToken(final String token) {
        // TODO:Save to DB
        DeviceInfo deviceInfo = AppController.getInstance().getModelInterface().getDeviceInfo();
        if (deviceInfo == null) {
            return;
        }

        if (deviceInfo.getFcmToken().equals(token)
                && deviceInfo.getAppVersion().equals(BuildConfig.VERSION_NAME)
                && deviceInfo.getOsVersion().equals(String.valueOf(Build.VERSION.SDK_INT))) {
            return;
        }
        deviceInfo.setSendToken(false);
        deviceInfo.setFcmToken(token);
        AppController.getInstance().getModelInterface().updateDeviceInfo(deviceInfo);
    }

    /**
     * 最新のアプリバージョン取得.
     *
     * @param listener コールバックリスナ
     */
    @Override
    public void getLatestAppVersion(final GetAppVersionResultListener listener) {
        /**
         * TODO:sample stub code.
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                listener.onResult(result, makeVersionInfo());
            }
        }, 2 * 1000);

    }

    private AppVersionInfo makeVersionInfo() {
        AppVersionInfo info = new AppVersionInfo();

        info.setMessage("強制アップデートが必要です");
        info.setUrl("https://www.google.co.jp/");
        info.setVersion("1.0.0");

        return info;
    }

    /**
     * 位置情報更新可否設定の取得.
     *
     * @return LocationSettings
     */
    @Override
    public LocationSettings getLocationSettings() {
        // Load from DB
        LocationSettings settings = AppController.getInstance().getModelInterface().getLocationSettings();

        // TODO: 2019/04/19 Fake Data to test, delete later
        LocationSettings fakeSetting = new LocationSettings();
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        Date startDate = calendar.getTime();
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        Date endDate = calendar.getTime();
        fakeSetting.setIsFence(false);
        fakeSetting.setRegularLocation(false);
        fakeSetting.setRequestedLocation(true);
        fakeSetting.setRegularLocationStartTime(startDate);
        fakeSetting.setRegularLocationEndTime(endDate);
        fakeSetting.setRegularLocationTermKind(LocationSettings.TermType.AllDay);
        return fakeSetting;
    }

    /**
     * 位置情報更新可否設定の更新.
     *
     * @param settings 設定値
     */
    @Override
    public void setLocationSettings(final LocationSettings settings) {
        // TODO:Save to DB
    }

    /**
     * 位置情報更新可否設定の送信.
     */
    @Override
    public void sendLocationSettings(final LocationSettings settings, final NotifyOnlyResultListener listener) {
        // TODO:Run in the background. No notification to UI.
        /**
         * TODO:sample stub code.
         * @see addSchedule
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Call when communication occurs.
        if (true) {
            listener.onStartConnection(); // not UI thread
        }

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AppController.getInstance().getModelInterface().updateLocationSettings(settings); // Update to DB
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                listener.onResult(result);
            }
        }, 2 * 1000);
    }

    /**
     * 最新の利用者情報取得.
     *
     * @param listener コールバックリスナ
     */
    @Override
    public void getLatestUserInfo(final GetUserInfoResultListener listener) {
        /**
         * TODO:sample stub code.
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
                listener.onResult(result, makeUserInfo());
            }
        }, 2 * 1000);

    }

    private UserInfo makeUserInfo() {
        UserInfo info = new UserInfo();

        info.setUserId(1);
        info.setNickname("ニックネーム");
        info.setIconId(1);

        return info;
    }

    /**
     * 利用者情報の更新.
     *
     * @param info     利用者情報
     * @param listener コールバックリスナ
     */
    @Override
    public void editUserInfo(final UserInfo info, final NotifyOnlyResultListener listener) {
        /**
         * TODO:sample stub code.
         */

        if (listener == null) {
            return; // No callback required.
        }

        // Communication required.
        listener.onStartConnection(); // not UI thread

        // use post or postDelayed
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // Success
                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.Success);
//                // ResponseError
//                AssistServerResult result = new AssistServerResult(AssistServerResult.Result.ResponseError,
//                        101, "invalid parameter", "user_id");

                listener.onResult(result);
            }
        }, 2 * 1000);
    }

    /**
     * 自身の利用者アイコンIDの取得.
     *
     * @return 利用者アイコンID（0:未設定もしくは初期設定未完了）
     */
    @Override
    public int getMyUserIcon() {
        // TODO:Get from DB
        return 1;
    }

}
