/*
 * ファイル：TempCardInfo.java
 * 概要：辞書カード情報（追加時）
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import android.graphics.Bitmap;

import jp.softbank.assist.model.ModelInterface;
import jp.softbank.assist.util.Constants;

import java.io.File;

/**
 * 辞書カード情報（追加時）.
 *
 * @author Systena
 * @version 1.0
 */
public class TempCardInfo extends CardInfo {

    private static final int MAX_TEMP_ID = 1000000;
    private static final int MIN_TEMP_ID = 1;
    private static int sTempId = MIN_TEMP_ID;


    private TempCardInfo() {
    }

    /**
     * 辞書作成時のカード情報.
     *
     * @return TempCardInfo
     */
    static TempCardInfo newInstance() {
        TempCardInfo card = new TempCardInfo();
        card.setCardId(sTempId++);
        if (sTempId > MAX_TEMP_ID) {
            sTempId = MIN_TEMP_ID;
        }
        return card;
    }

    /**
     * 辞書編集時のカード情報.
     *
     * @param dictionaryId 辞書ID
     * @return TempCardInfo
     */
    static TempCardInfo newInstance(final long dictionaryId) {
        TempCardInfo card = new TempCardInfo();
        card.setDictionaryId(dictionaryId);
        card.setCardId(sTempId++);
        if (sTempId > MAX_TEMP_ID) {
            sTempId = MIN_TEMP_ID;
        }
        return card;
    }

    private boolean isEditingDictionary() {
        return (getDictionaryId() != Constants.Ids.ID_NONE);
    }

    /**
     * 編集済みか確認する.
     *
     * @return true:編集済み、false:未編集
     */
    @Override
    public boolean isEdited() {
        return true;
    }

    /**
     * 追加・編集時のキャンセル.
     */
    @Override
    public void cancel() {
        getImagePath(Constants.Dictionary.getTempCardFileName(getCardId())).delete();
    }

    /**
     * 辞書画像のパス.
     *
     * @param fileName ファイル名
     * @return File
     */
    @Override
    protected File getImagePath(final String fileName) {
        if (isEditingDictionary()) {
            File file = ModelInterface.getDictionaryDir(getDictionaryId());
            return new File(file, fileName);
        } else {
            File file = ModelInterface.getDictionaryTempDir();
            return new File(file, fileName);
        }
    }

    /**
     * 画像ファイルが有効（保存済み）か確認する.
     *
     * @return true:有効、false:無効
     */
    @Override
    public boolean isImageEnabled() {
        return Constants.Dictionary.getTempCardFileName(getCardId()).equals(getImageFileName());
    }

    /**
     * 画像の保存.
     *
     * @param bitmap ビットマップ
     * @return true:成功、false:失敗
     */
    @Override
    public boolean setImage(Bitmap bitmap) {
        bitmap = ModelInterface.scaleDictionaryImage(bitmap);
        boolean result = ModelInterface.saveDictionaryImage(bitmap,
                getImagePath(Constants.Dictionary.getTempCardFileName(getCardId())));
        if (result) {
            setImageFileName(Constants.Dictionary.getTempCardFileName(getCardId()));
        }
        return result;
    }

    /**
     * 画像設定の削除.
     */
    @Override
    public void clearImage() {
        getImagePath(Constants.Dictionary.getTempCardFileName(getCardId())).delete();
        setImageFileName("");
    }

    /**
     * 画像ファイルパスの取得.
     *
     * @return ファイルパス
     */
    @Override
    public String getImageFileAbsolutePath() {
        if (isImageEnabled()) {
            File file = getImagePath(getImageFileName());
            if (file.exists()) {
                return file.getAbsolutePath();
            }
        }
        return null;
    }
}
