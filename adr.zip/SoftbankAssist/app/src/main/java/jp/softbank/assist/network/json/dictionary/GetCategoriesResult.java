/*
 * ファイル：GetCategoriesResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

/**
 * 辞書カテゴリ一覧取得結果.
 */
public class GetCategoriesResult {

    @SerializedName("category_id")
    private Long mCategoryId = null;
    @SerializedName("category_name")
    private String mCategoryName = null;
    @SerializedName("category_icon_path")
    private String mCategoryIconPath = null;
    @SerializedName("category_icon_id")
    private Long mCategoryIconId = null;
    @SerializedName("dic_count")
    private Long mDicCount = null;
    @SerializedName("dic_memorize_count")
    private Long mDicMemorizeCount = null;


    /**
     * カテゴリID.
     */
    public Long getCategoryId() {
        return mCategoryId;
    }
    public void setCategoryId(Long categoryId) {
        this.mCategoryId = categoryId;
    }

    /**
     * カテゴリ名.
     */
    public String getCategoryName() {
        return mCategoryName;
    }
    public void setCategoryName(String categoryName) {
        this.mCategoryName = categoryName;
    }

    /**
     * カテゴリアイコンパス.
     */
    public String getCategoryIconPath() {
        return mCategoryIconPath;
    }
    public void setCategoryIconPath(String categoryIconPath) {
        this.mCategoryIconPath = categoryIconPath;
    }

    /**
     * カテゴリアイコンID.
     */
    public Long getCategoryIconId() {
        return mCategoryIconId;
    }
    public void setCategoryIconId(Long categoryIconId) {
        this.mCategoryIconId = categoryIconId;
    }

    /**
     * 件数.
     */
    public Long getDicCount() {
        return mDicCount;
    }
    public void setDicCount(Long dicCount) {
        this.mDicCount = dicCount;
    }

    /**
     * 覚えた件数.
     */
    public Long getDicMemorizeCount() {
        return mDicMemorizeCount;
    }
    public void setDicMemorizeCount(Long dicMemorizeCount) {
        this.mDicMemorizeCount = dicMemorizeCount;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GetCategoriesResult categoriesResult = (GetCategoriesResult) o;
        return (this.mCategoryId == null ? categoriesResult.mCategoryId == null : this.mCategoryId.equals(categoriesResult.mCategoryId)) &&
                (this.mCategoryName == null ? categoriesResult.mCategoryName == null : this.mCategoryName.equals(categoriesResult.mCategoryName)) &&
                (this.mCategoryIconPath == null ? categoriesResult.mCategoryIconPath == null : this.mCategoryIconPath.equals(categoriesResult.mCategoryIconPath)) &&
                (this.mCategoryIconId == null ? categoriesResult.mCategoryIconId == null : this.mCategoryIconId.equals(categoriesResult.mCategoryIconId)) &&
                (this.mDicCount == null ? categoriesResult.mDicCount == null : this.mDicCount.equals(categoriesResult.mDicCount)) &&
                (this.mDicMemorizeCount == null ? categoriesResult.mDicMemorizeCount == null : this.mDicMemorizeCount.equals(categoriesResult.mDicMemorizeCount));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mCategoryId == null ? 0: this.mCategoryId.hashCode());
        result = 31 * result + (this.mCategoryName == null ? 0: this.mCategoryName.hashCode());
        result = 31 * result + (this.mCategoryIconPath == null ? 0: this.mCategoryIconPath.hashCode());
        result = 31 * result + (this.mCategoryIconId == null ? 0: this.mCategoryIconId.hashCode());
        result = 31 * result + (this.mDicCount == null ? 0: this.mDicCount.hashCode());
        result = 31 * result + (this.mDicMemorizeCount == null ? 0: this.mDicMemorizeCount.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class GetCategoriesResult {\n");

        sb.append("  mCategoryId: ").append(mCategoryId).append("\n");
        sb.append("  mCategoryName: ").append(mCategoryName).append("\n");
        sb.append("  mCategoryIconPath: ").append(mCategoryIconPath).append("\n");
        sb.append("  mCategoryIconId: ").append(mCategoryIconId).append("\n");
        sb.append("  mDicCount: ").append(mDicCount).append("\n");
        sb.append("  mDicMemorizeCount: ").append(mDicMemorizeCount).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
