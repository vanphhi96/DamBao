/*
 * ファイル：RealmCategoryInfo.java
 * 概要：Realm用辞書カード一覧テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

import java.util.Date;

/**
 * Realm用辞書カード一覧テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmCardInfo extends RealmObject {

    @PrimaryKey
    private long mCardId; // カードID
    private long mDictionaryId; // 辞書ID
    private long mNextCardId; // 次のカードID
    private String mImageUrl; // 画像URL
    private String mImageFileName; // 画像ファイル名
    private String mText; // テキスト
    private long mVersion; // バージョン
    private Date mCreatedDate; // 作成日時
    private Date mUpdatedDate; // 更新日時
    private boolean mIsDeleted; // 削除済みフラグ


    public long getCardId() {
        return mCardId;
    }

    public void setCardId(long cardId) {
        this.mCardId = cardId;
    }

    public long getDictionaryId() {
        return mDictionaryId;
    }

    public void setDictionaryId(long dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }

    public long getNextCardId() {
        return mNextCardId;
    }

    public void setNextCardId(long nextCardId) {
        this.mNextCardId = nextCardId;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.mImageUrl = imageUrl;
    }

    public String getImageFileName() {
        return mImageFileName;
    }

    public void setImageFileName(String imageFileName) {
        this.mImageFileName = imageFileName;
    }

    public String getText() {
        return mText;
    }

    public void setText(String text) {
        this.mText = text;
    }

    public long getVersion() {
        return mVersion;
    }

    public void setVersion(long version) {
        this.mVersion = version;
    }

    public Date getCreatedDate() {
        return mCreatedDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.mCreatedDate = createdDate;
    }

    public Date getUpdatedDate() {
        return mUpdatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.mUpdatedDate = updatedDate;
    }

    public boolean isDeleted() {
        return mIsDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        mIsDeleted = deleted;
    }
}
