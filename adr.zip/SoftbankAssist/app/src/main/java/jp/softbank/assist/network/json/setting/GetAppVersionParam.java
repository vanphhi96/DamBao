/*
 * ファイル：GetAppVersionParam.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.setting;

import jp.softbank.assist.network.json.RequestParam;

/**
 * 最新アプリバージョン取得パラメータ.
 */
public class GetAppVersionParam extends RequestParam {

    private Long mOsKind;


    /**
     * 端末OS種別（0:iOS、1:Android）.
     */
    public Long getOsKind() {
        return mOsKind;
    }
    public void setOsKind(Long osKind) {
        this.mOsKind = osKind;
    }
}
