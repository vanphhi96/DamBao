/*
 * ファイル：IBaseDetailPicture.java
 * 概要：Interface of base detail picture.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity;

import java.io.Serializable;

/**
 * sch-dic-02, dic-05.
 *
 * @author Systena
 * @version 1.0
 */
public interface IBaseDetailPicture extends Serializable {
    String link();

    String position();

    String description();

    boolean checked();
}
