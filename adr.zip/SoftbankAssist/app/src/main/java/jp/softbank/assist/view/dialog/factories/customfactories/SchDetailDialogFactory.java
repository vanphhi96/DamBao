/*
 * ファイル：SchDetailDialogFactory.java
 * 概要：Schedule Detail Dialog
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */
package jp.softbank.assist.view.dialog.factories.customfactories;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.NotifyOnlyResultListener;
import jp.softbank.assist.util.AssistLog;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.adapter.ScheduleDetailDialogAdapter;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl.DialogType;

import java.util.Date;

/**
 * sch-02
 *
 * @author Systena
 * @version 1.0
 */
@SuppressLint("ValidFragment")
public class SchDetailDialogFactory extends BaseDialogFactory implements View.OnClickListener, NotifyOnlyResultListener {
    private ISchDetailDialog mISchDetailDialog;
    private RecyclerView mRvScheduleDetail;
    private ScheduleInfo mScheduleInfo;

    private LinearLayoutManager mLayoutManager;
    private DialogType mDialogType;
    private TextView mTvCompleted;
    private ImageView mImgCompleted;
    private ImageView mImgClose;
    private ImageView mImgEdit;
    private TextView mTvUserName;
    private ImageView mImgUser;
    private LinearLayout mLnCompleted;
    private Date mDate;
    private int mIconUser;
    private ImageView mImgLoading;
    private Activity mActivity;
    private AnimationDrawable mAnim;
    private FrameLayout mFrameLoading;

    /**
     * constructor of dialog
     *
     * @param iSchDetailDialog
     * @param dialogType
     */
    public SchDetailDialogFactory(ISchDetailDialog iSchDetailDialog, DialogType dialogType, int iconUser) {
        this.mISchDetailDialog = iSchDetailDialog;
        this.mDialogType = dialogType;
        this.mIconUser = iconUser;
    }

    /**
     * set current activity for dialog.
     *
     * @param activity activity display dialog.
     */
    public void setActivity(Activity activity) {
        this.mActivity = activity;
    }

    /**
     * set data schedule
     *
     * @param schedule
     */
    public void setSchedule(ScheduleInfo schedule) {
        this.mScheduleInfo = schedule;
    }

    /**
     * set data date
     *
     * @param date
     */
    public void setDate(Date date) {
        this.mDate = date;
    }

    @Override
    public AlertDialog getReadyAlertDialog(FragmentActivity activity) {

        AlertDialog.Builder builder = createDialogBuilder(activity, R.style.DialogFullWidth);
        LayoutInflater inflater = activity.getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_sch_detail, null);
        mRvScheduleDetail = view.findViewById(R.id.rv_sch_detail);
        mImgLoading = view.findViewById(R.id.img_anim);
        mFrameLoading = view.findViewById(R.id.fr_loading);
        mAnim = (AnimationDrawable) mImgLoading.getDrawable();
        mTvCompleted = view.findViewById(R.id.tv_complete);
        mImgCompleted = view.findViewById(R.id.img_completed);
        mImgClose = view.findViewById(R.id.img_close);
        mImgEdit = view.findViewById(R.id.img_edit);
        mTvUserName = view.findViewById(R.id.tv_user_name);
        mImgUser = view.findViewById(R.id.img_user);
        mLnCompleted = view.findViewById(R.id.ln_completed);
        mLnCompleted.setOnClickListener(this);
        mImgClose.setOnClickListener(this);
        mImgEdit.setOnClickListener(this);
        setPositivelyDialog(false);
        setCancelable(true);
        setData();
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        return alertDialog;
    }

    /**
     * data from model to View
     */
    private void setData() {
        if (mScheduleInfo == null) {
            return;
        }
        if (mScheduleInfo.isCompleted()) {
            mImgCompleted.setImageDrawable(mImgCompleted.getContext().getDrawable(ResourcesUtils.getUserIconResourceFromId(mIconUser)));
            mLnCompleted.setBackgroundColor(mLnCompleted.getContext().getColor(R.color.sch_detail_layout_completed));
            mTvCompleted.setText(mTvCompleted.getContext().getString(R.string.sch_achieved));
            mImgCompleted.setVisibility(View.GONE);
        } else {
            mLnCompleted.setBackgroundColor(mLnCompleted.getContext().getColor(R.color.sch_detail_layout_done));
            mTvCompleted.setText(mTvCompleted.getContext().getString(R.string.sch_ach));
            mImgCompleted.setVisibility(View.VISIBLE);
            mImgCompleted.setImageDrawable(mImgCompleted.getContext().getDrawable(ResourcesUtils.getUserIconResourceFromId(mIconUser)));
        }
        mTvUserName.setText(mScheduleInfo.getCreatorNickname());
        try {
            mImgUser.setVisibility(View.VISIBLE);
            mImgUser.setImageDrawable(mImgUser.getContext().getDrawable(ResourcesUtils.getUserIconResourceFromId((int) mScheduleInfo.getCreatorIconId())));
        } catch (Resources.NotFoundException e) {
            mImgUser.setVisibility(View.INVISIBLE);
            AssistLog.e(e.toString());
        }
        mLayoutManager = new LinearLayoutManager(mRvScheduleDetail.getContext());
        mRvScheduleDetail.setLayoutManager(mLayoutManager);
        ScheduleDetailDialogAdapter scheduleDetailDialogAdapter =
                new ScheduleDetailDialogAdapter(mISchDetailDialog);
        scheduleDetailDialogAdapter.setData(mScheduleInfo);
        scheduleDetailDialogAdapter.setDate(mDate);
        mRvScheduleDetail.setAdapter(scheduleDetailDialogAdapter);
    }

    /**
     * Process event tapped view
     *
     * @param view
     */
    @Override
    public void onClick(View view) {
        if (mISchDetailDialog == null) {
            return;
        }
        switch (view.getId()) {
            case R.id.ln_completed:
                if (!mScheduleInfo.isCompleted()) {
                    AppController.getInstance().getAssistServerInterface().completeSchedule(mScheduleInfo, this);
                }
                break;
            case R.id.img_close:
                mISchDetailDialog.dismissScheduleDetail();
                break;
            case R.id.img_edit:
                mISchDetailDialog.editSchedule(mScheduleInfo);
                break;
            default:
                break;
        }
    }

    @Override
    public String getDialogTag() {
        return mDialogType.name();
    }


    @Override
    public void onResult(final AssistServerResult result) {
        if (mActivity != null) {
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mAnim.stop();
                    mFrameLoading.setVisibility(View.GONE);
                    if (result.mResult == AssistServerResult.Result.Success) {
                        mISchDetailDialog.completedSchedule(mScheduleInfo);
                    }
                }
            });
        }
    }

    @Override
    public void onStartConnection() {
        mFrameLoading.setVisibility(View.VISIBLE);
        mAnim.start();
    }
}
