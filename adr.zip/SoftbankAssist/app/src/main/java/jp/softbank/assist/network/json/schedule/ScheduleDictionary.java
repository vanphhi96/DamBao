/*
 * ファイル：ScheduleDictionary.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.schedule;

import com.google.gson.annotations.SerializedName;

/**
 * 辞書情報.
 */
public class ScheduleDictionary {

    @SerializedName("dictionary_id")
    private Long mDictionaryId = null;


    /**
     * コンストラクタ.
     */
    public ScheduleDictionary() {
    }

    /**
     * コンストラクタ.
     *
     * @param dictionaryId 辞書ID
     */
    public ScheduleDictionary(long dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }

    /**
     * 値初期化.
     */
    public void initializeValues() {
        mDictionaryId = 0L;
    }

    /**
     * 辞書ID.
     */
    public Long getDictionaryId() {
        return mDictionaryId;
    }
    public void setDictionaryId(Long dictionaryId) {
        this.mDictionaryId = dictionaryId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ScheduleDictionary dictionary = (ScheduleDictionary) o;
        return (this.mDictionaryId == null ? dictionary.mDictionaryId == null : this.mDictionaryId.equals(dictionary.mDictionaryId));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mDictionaryId == null ? 0: this.mDictionaryId.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class ScheduleDictionary {\n");

        sb.append("  mDictionaryId: ").append(mDictionaryId).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
