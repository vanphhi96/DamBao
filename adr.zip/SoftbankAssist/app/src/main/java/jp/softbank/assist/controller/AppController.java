/*
 * ファイル：AppController.java
 * 概要：アプリの共通インスタンスの生成とアプリ制御を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.controller;

import android.content.Context;

import jp.softbank.assist.app.AssistApplication;
import jp.softbank.assist.location.LocationRecordingManager;
import jp.softbank.assist.model.ModelInterface;
import jp.softbank.assist.network.AssistServerInterface;
import jp.softbank.assist.notification.AssistNotificationManager;
import jp.softbank.assist.timer.AssistTimerManager;
import jp.softbank.assist.util.AssistEventLog;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.ViewManager;

import java.io.File;
import java.util.Locale;

/**
 * アプリ制御クラス.
 *
 * @author Systena
 * @version 1.0
 */
public final class AppController {

    private static AppController sInstance;

    private boolean mInit = false;
    private ModelInterface mModelInterface;
    private ViewManager mViewManager;
    private AssistServerInterface mAssistServerInterface;
    private LocationRecordingManager mLocationRecordingManager;
    private AssistNotificationManager mAssistNotificationManager;
    private AssistTimerManager mAssistTimerManager;
    private Context mAppContext;
    private AssistEventLog mAssistEventLog;


    private AppController() {
    }

    /**
     * インスタンスを取得します.
     *
     * @return AppController
     */
    public static synchronized AppController getInstance() {
        if (sInstance == null) {
            sInstance = new AppController();
        }
        return sInstance;
    }

    /**
     * 初期化処理（一度だけ呼ぶこと）.
     *
     * @param context ApplicationContext
     */
    public void init(Context context) {
        if (mInit) {
            return;
        }

        mAppContext = context;
        mModelInterface = new ModelInterface();
        mViewManager = new ViewManager();
        mAssistServerInterface = AssistServerInterface.newInstance(context);
        mLocationRecordingManager = new LocationRecordingManager();
        mAssistNotificationManager = new AssistNotificationManager();
        mAssistTimerManager =  new AssistTimerManager();
        mAssistEventLog = new AssistEventLog();

        mInit = true;
    }

    /**
     * アプリケーションコンテキストの取得.
     *
     * @return Context
     */
    public Context getAppContext() {
        return mAppContext;
    }

    /**
     * ModelInterfaceのインスタンスを返す.
     *
     * @return ModelInterface
     */
    public ModelInterface getModelInterface() {
        return mModelInterface;
    }

    /**
     * ViewManagerのインスタンスを返す.
     *
     * @return ViewManager
     */
    public ViewManager getViewManager() {
        return mViewManager;
    }

    /**
     * AssistServerInterfaceのインスタンスを返す.
     *
     * @return AssistServerInterface
     */
    public AssistServerInterface getAssistServerInterface() {
        return mAssistServerInterface;
    }

    /**
     * LocationRecordingManagerのインスタンスを返す.
     *
     * @return LocationRecordingManager
     */
    public LocationRecordingManager getLocationRecordingManager() {
        return mLocationRecordingManager;
    }

    /**
     * AssistNotificationManagerのインスタンスを返す.
     *
     * @return AssistNotificationManager
     */
    public AssistNotificationManager getAssistNotificationManager() {
        return mAssistNotificationManager;
    }

    /**
     * AssistTimerManager.のインスタンスを返す.
     *
     * @return AssistTimerManager
     */
    public AssistTimerManager getAssistTimerManager() {
        return mAssistTimerManager;
    }

    /**
     * フォアグラウンドへの遷移開始.
     *
     * @see AssistApplication
     */
    public void onStartApplication() {
    }

    /**
     * フォアグラウンドへ遷移完了.
     *
     * @see AssistApplication
     */
    public void onResumeApplication() {
        getAssistServerInterface().notifyDidForeground();
    }

    /**
     * バックグラウンドへの遷移開始.
     *
     * @see AssistApplication
     */
    public void onPauseApplication() {
    }

    /**
     * バックグラウンドへ遷移完了.
     *
     * @see AssistApplication
     */
    public void onStopApplication() {
        getAssistServerInterface().notifyDidBackground();
    }

    /**
     * AssistEventLogの取得.
     *
     * @return AssistEventLog
     */
    public AssistEventLog getAssistEventLog() {
        return mAssistEventLog;
    }

    /**
     * ドキュメントパス取得.
     *
     * @return File:Success,null:Error
     */
    public File getDocumentPath() {
        if (mAppContext == null) {
            return null;
        }
        return mAppContext.getDir(Constants.SAVED_FILE_DIRECTORY, Context.MODE_PRIVATE);
    }
}
