/*
 * ファイル：GetCategoriesParam.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import jp.softbank.assist.network.json.RequestParam;

/**
 * 辞書カテゴリ取得パラメータ.
 */
public class GetCategoriesParam extends RequestParam {

    private Long mUserId;

    /**
     * コンストラクタ.
     *
     * @param userId 利用者ID
     */
    public GetCategoriesParam(Long userId) {
        this.mUserId = userId;
    }

    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }
}
