/*
 * ファイル：RegistLinkRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.user;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

/**
 * 紐づけ情報本登録.
 */
public class RegistLinkRequest extends RequestBody {

    @SerializedName("bind_id")
    private String mBindId = null;


    /**
     * 紐づけID.
     */
    public String getBindId() {
        return mBindId;
    }
    public void setBindId(String bindId) {
        this.mBindId = bindId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RegistLinkRequest requestRegistLink = (RegistLinkRequest) o;
        return (this.mBindId == null ? requestRegistLink.mBindId == null : this.mBindId.equals(requestRegistLink.mBindId));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mBindId == null ? 0: this.mBindId.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class RegistLinkRequest {\n");

        sb.append("  mBindId: ").append(mBindId).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
