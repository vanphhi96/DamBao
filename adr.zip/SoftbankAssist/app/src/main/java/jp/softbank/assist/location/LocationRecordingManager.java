/*
 * ファイル：LocationRecordingManager.java
 * 概要：位置測位の制御を行う
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.location;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

import java.util.Timer;
import java.util.TimerTask;

/**
 * 位置測位制御用クラス.
 *
 * @author Systena
 * @version 1.0
 */
public class LocationRecordingManager {
    private String mLongitude;
    private String mLatitude;
    private int mTimerSecond;
    private boolean mIsTimerStarted;
    private Handler mHandler = new Handler();
    private Timer mTimer;

    private final static int TIMER_PERIOD = 1000; // 1s
    private final static int SET_PERIOD = 60; //  まだ決めてないから、とりあいず60sで

    public LocationRecordingManager() {
    }

    public void setLongitude(String mLongitude) {
        this.mLongitude = mLongitude;
    }

    public void setLatitude(String mLatitude) {
        this.mLatitude = mLatitude;
    }

    public String getLongitude() {
        return mLongitude;
    }

    public String getLatitude() {
        return mLatitude;
    }
    /*
     * GPS Request を開始
     */

    public void startGetGpsRequest(Context context) {
        Intent startIntent = new Intent(context, LocationRecordingService.class);
        context.startForegroundService(startIntent);
    }

    /*
     * GPS Request を終了
     */
    public void stopGetGpsRequest(Context context) {
        Intent stopIntent = new Intent(context, LocationRecordingService.class);
        context.stopService(stopIntent);
    }

    /*
     * GPSをサーバーに送信
     */
    public void sendGps() {

    }

    /*
     * Check if Location GPS is available or not
     * If available -> Get Location GPS at every 5s
     * If not available -> Start timer counting to 60s -> if timer > 60s, send error request to server
     *
     * 位置測位可能があるかチェックする。
     * 可能になったら -> ５秒間隔でGPSを取得
     * 可能になったら -> Timerを開始、もしTimer>60秒になったらエラーリクエストをサーバーに送信。
     *
     */

    public void checkGpsAvailable(boolean locationAvailable) {
        if (locationAvailable) {
            if (mIsTimerStarted) {
                mTimer.cancel();
            }
            mTimerSecond = 0;
            mIsTimerStarted = false;
        } else {
            if (!mIsTimerStarted) {
                mTimer = new Timer();
                mTimer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        mTimerSecond++;
                        Log.i("tntan", "run: " + mTimerSecond);
                        if (mTimerSecond >= SET_PERIOD) {
                            mHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    // TODO: 2019/02/15 Send Error Request To Server (タン）
                                }
                            });
                        }
                    }
                }, 0, TIMER_PERIOD);
            }
            mIsTimerStarted = true;
        }
    }
}
