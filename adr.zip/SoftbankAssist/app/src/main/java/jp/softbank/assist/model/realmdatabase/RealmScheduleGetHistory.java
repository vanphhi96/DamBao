/*
 * ファイル：RealmGeneralInfo.java
 * 概要：Realm用スケジュール取得履歴テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;


import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

import java.util.Date;

/**
 * Realm用スケジュール取得履歴テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmScheduleGetHistory extends RealmObject {

    @PrimaryKey
    private long mId; // 管理ID
    private Date mScheduleFromOn; // 開始日
    private Date mScheduleToOn; // 終了日

    public long getId() {
        return mId;
    }

    public void setId(long mId) {
        this.mId = mId;
    }

    public Date getScheduleFromOn() {
        return mScheduleFromOn;
    }

    public void setScheduleFromOn(Date mScheduleFromOn) {
        this.mScheduleFromOn = mScheduleFromOn;
    }

    public Date getScheduleToOn() {
        return mScheduleToOn;
    }

    public void setScheduleToOn(Date mScheduleToOn) {
        this.mScheduleToOn = mScheduleToOn;
    }

}
