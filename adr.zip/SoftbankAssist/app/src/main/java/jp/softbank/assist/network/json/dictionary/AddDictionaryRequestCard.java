/*
 * ファイル：AddDictionaryRequestCard.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.dictionary;

import com.google.gson.annotations.SerializedName;

/**
 * 辞書登録カード情報.
 */
public class AddDictionaryRequestCard {

    @SerializedName("card_image")
    private String mCardImage = null;
    @SerializedName("card_text")
    private String mCardText = null;


    /**
     * 値初期化.
     */
    public void initializeValues() {
        mCardImage = "";
        mCardText = "";
    }

    /**
     * カード画像（base64形式　ファイル拡張子：jpg、jpeg、png　最大ファイルサイズ：2.5MB）.
     */
    public String getCardImage() {
        return mCardImage;
    }
    public void setCardImage(String cardImage) {
        this.mCardImage = cardImage;
    }

    /**
     * カード内容.
     */
    public String getCardText() {
        return mCardText;
    }
    public void setCardText(String cardText) {
        this.mCardText = cardText;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AddDictionaryRequestCard dictionaryCard = (AddDictionaryRequestCard) o;
        return (this.mCardImage == null ? dictionaryCard.mCardImage == null : this.mCardImage.equals(dictionaryCard.mCardImage)) &&
                (this.mCardText == null ? dictionaryCard.mCardText == null : this.mCardText.equals(dictionaryCard.mCardText));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mCardImage == null ? 0: this.mCardImage.hashCode());
        result = 31 * result + (this.mCardText == null ? 0: this.mCardText.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class AddDictionaryRequestCard {\n");

        sb.append("  mCardImage: ").append(mCardImage).append("\n");
        sb.append("  mCardText: ").append(mCardText).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
