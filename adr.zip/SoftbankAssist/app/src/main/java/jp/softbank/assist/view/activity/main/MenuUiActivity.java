/*
 * ファイル：MenuUiActivity.java
 * 概要：メニュー画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.main;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.customview.ViewPagerDisableSwipe;
import jp.softbank.assist.view.fragment.DicBaseUiFragment;
import jp.softbank.assist.view.fragment.SchBaseUiFragment;
import jp.softbank.assist.view.fragment.SetBaseUiFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * メニュー
 *
 * @author Systena
 * @version 1.0
 */
public class MenuUiActivity extends BaseUiActivity implements android.view.View.OnClickListener, TabLayout.OnTabSelectedListener {
    private TabLayout mTabLayout;
    private ViewPagerDisableSwipe mViewPager;
    private FragmentPagerAdapter mMyPagerAdapter;

    private int[] mTabIconId = {R.drawable.ic_tab_schedule,
            R.drawable.ic_tab_dic,
            R.drawable.ic_tab_setting};

    private int[] mTabIconSelectedId = {R.drawable.ic_tab_schedule_selected,
            R.drawable.ic_tab_dic_selected,
            R.drawable.ic_tab_setting_selected};

    private String[] mTabTitles;

    private List<Fragment> mFragmentsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        initBaseFragments();
        setUpViewPagerAndTabLayout();
        AppController.getInstance().getAssistServerInterface().registDeviceInfo();     // デバイス情報の送信
    }

    @Override
    protected void onResume() {
        super.onResume();
        Bundle bundle = getIntent().getBundleExtra(Constants.NotificationControl.NOTIFICATION_BUNDLE_KEY);
        if (bundle != null) {
            mViewPager.setCurrentItem(Constants.NotificationControl.DEFAULT_NOTIFICATION_TAB, true);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }
    /*
     * ViewPager&TabLayoutの初期化。
     */
    private void setUpViewPagerAndTabLayout() {
        mTabTitles = getResources().getStringArray(R.array.tab_title);
        mViewPager = findViewById(R.id.view_pager_menu);
        mTabLayout = findViewById(R.id.tab_layout_menu);
        mViewPager.setOffscreenPageLimit(Constants.Tab.TAB_ITEM_NUMBER_MENU);
        mMyPagerAdapter = new MenuPagerAdapter(getSupportFragmentManager(), mFragmentsList);
        mViewPager.setAdapter(mMyPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        setUpTabIcons();
        mTabLayout.addOnTabSelectedListener(this);
    }

    /*
     * TabLayoutの作成。
     */
    private void setUpTabIcons() {
        mTabLayout.setupWithViewPager(mViewPager);
        for (int i = 0; i < mTabTitles.length; i++) {
            setCustomViewTab(false, i, false);
        }
        setCustomViewTab(true, Constants.Tab.DEFAULT_TAB_POSITION, true);
    }

    /*
     * TabLayoutの作成。
     */
    private void setCustomViewTab(boolean isCreateTab, int pos, boolean isSelected) {
        View view;
        TabLayout.Tab tab = mTabLayout.getTabAt(pos);
        if (!isCreateTab) {
            view = LayoutInflater.from(this).inflate(R.layout.item_bottom_tab_main_bar, null);
        } else {
            assert tab != null;
            view = tab.getCustomView();
        }

        View tabView = ((ViewGroup) mTabLayout.getChildAt(Constants.Tab.DEFAULT_TAB_POSITION)).getChildAt(pos);
        tabView.requestLayout();
        assert view != null;
        ImageView imageView = view.findViewById(R.id.img_tab_bottom_bar);
        TextView tvTitle = view.findViewById(R.id.text_view_title_tab_bar);
        imageView.setBackgroundResource(isSelected ? mTabIconSelectedId[pos] : mTabIconId[pos]);
        tvTitle.setText(mTabTitles[pos]);
        if (isSelected) {
            tvTitle.setTextColor(getColor(R.color.tab_select));
        } else {
            tvTitle.setTextColor(getColor(R.color.tab_unselect));
        }
        assert tab != null;
        tab.setCustomView(view);
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        setCustomViewTab(true, tab.getPosition(), true);
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {
        setCustomViewTab(true, tab.getPosition(), false);
    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

    /*
     * ３つのBaseFragmentを作る。
     */
    private void initBaseFragments() {
        mFragmentsList.add(new SchBaseUiFragment());
        mFragmentsList.add(new DicBaseUiFragment());
        mFragmentsList.add(new SetBaseUiFragment());
    }

    @Override
    public void onClick(View view) {

    }
}
