/*
 * ファイル：SetTopUiFragment.java
 * 概要：設定トップ画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.fragment.settings;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import jp.softbank.assist.R;
import jp.softbank.assist.model.SetModel;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.main.MenuUiActivity;
import jp.softbank.assist.view.adapter.SetTopAdapter;
import jp.softbank.assist.view.fragment.BaseFragment;

import java.util.ArrayList;

/**
 * set-01
 *
 * @author Systena
 * @version 1.0
 */
public class SetTopUiFragment extends BaseFragment implements View.OnClickListener, ISetTopFragment {
    private LinearLayout mLnHelp;
    private RecyclerView mRvSet;
    private MenuUiActivity mCurrentActivity;
    private SetTopAdapter mAdapter;

    /**
     * インスタンスを初期化.
     *
     * @return SetTopUiFragment
     */
    public static SetTopUiFragment newInstance() {
        Bundle args = new Bundle();
        SetTopUiFragment fragment = new SetTopUiFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCurrentActivity = (MenuUiActivity) getActivity();
        mCurrentActivity.setCurrentFraggment(this);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_set_top, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mLnHelp = view.findViewById(R.id.ln_help);
        mRvSet = view.findViewById(R.id.rv_set);
        mLnHelp.setOnClickListener(this);
        initRvSet();
    }

    /**
     * init list set
     */
    private void initRvSet() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRvSet.setLayoutManager(layoutManager);

        mAdapter = new SetTopAdapter();
        mAdapter.setData(initData());
        mAdapter.setInterface(this);
        mRvSet.setAdapter(mAdapter);
    }

    /**
     * init data for list set.
     *
     * @return array list SetModel.
     */
    private ArrayList<SetModel> initData() {
        ArrayList<SetModel> listSet = new ArrayList<>();
        listSet.add(new SetModel(getString(R.string.set_user_setting), getString(R.string.set_user_detail), R.drawable.ic_user_setting));
        listSet.add(new SetModel(getString(R.string.set_adm_setting), getString(R.string.set_adm_detail), R.drawable.ic_admin_setting));
        listSet.add(new SetModel(getString(R.string.set_pos_inf), getString(R.string.set_pos_inf_detail), R.drawable.ic_location));
        listSet.add(new SetModel(getString(R.string.set_history), getString(R.string.set_history_detail), R.drawable.ic_history));
        listSet.add(new SetModel(getString(R.string.set_about_app), getString(R.string.set_about_app_detail), R.drawable.ic_info_app));
        listSet.add(new SetModel(getString(R.string.set_notice_sb), getString(R.string.set_notice_sb_detail), R.drawable.ic_notice_soft_bank));
        return listSet;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ln_help:
                break;
            default:
                break;
        }
    }

    @Override
    public void clickItem(SetModel setModel) {
        if (setModel.getTitle().equals(getString(R.string.set_user_setting))) {
            changeScreen(ScreenId.START_SET_USER_SETTING);
        } else if (setModel.getTitle().equals(getString(R.string.set_adm_setting))) {
            changeScreen(ScreenId.START_SET_ADMINISTRATOR_SETTING);
        } else if (setModel.getTitle().equals(getString(R.string.set_pos_inf))) {
            changeScreen(ScreenId.START_SET_LOCATION_SETTING);
        } else if (setModel.getTitle().equals(getString(R.string.set_history))) {
            changeScreen(ScreenId.START_SET_HISTORY);
        } else if (setModel.getTitle().equals(getString(R.string.set_about_app))) {
            changeScreen(ScreenId.START_SET_ABOUT);
        } else if (setModel.getTitle().equals(getString(R.string.set_notice_sb))) {
            changeScreen(ScreenId.START_SET_INFORMATION_DETAIL);
        }
    }
}
