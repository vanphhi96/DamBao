/*
 * ファイル：ListItemAllDayAdapter.java
 * 概要：Adapter for List All Day
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.ScheduleInfo;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.RecyclerBaseAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Adapter for List All Day(sch-01)
 *
 * @author Systena
 * @version 1.0
 */
public class ListItemAllDayAdapter extends RecyclerBaseAdapter {
    private List<ScheduleInfo> mList = new ArrayList<>();

    /**
     * setter data for mList ScheduleInfo
     *
     * @param mList
     */
    public void setList(List<ScheduleInfo> mList) {
        this.mList = mList;
    }

    @Override
    public int getContentItemCount() {
        return mList.size();
    }

    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public BaseViewHolder onCreateFooterHolder(ViewGroup parent) {
        return null;
    }

    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_schedule_all_day_small, parent, false);
        return new ItemAllDayViewHolder(view);
    }

    private class ItemAllDayViewHolder extends BaseViewHolder {
        private TextView mTvTitle;

        public ItemAllDayViewHolder(@NonNull View itemView) {
            super(itemView);
            mTvTitle = itemView.findViewById(R.id.tv_title_item_all_day);
        }

        @Override
        public void onBindView(int position) {
            ScheduleInfo scheduleContent = mList.get(position);
            mTvTitle.setText(scheduleContent.getTitle());
        }
    }
}
