/*
 * ファイル：DicCreateAdapter.java
 * 概要：Dictionary Create Adapter
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.controller.AppController;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.network.AssistServerResult;
import jp.softbank.assist.network.listener.GetImageResultListener;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.activity.dictionary.IOnClickDeleteDic;
import jp.softbank.assist.view.activity.dictionary.IOnClickItemDicCreate;
import jp.softbank.assist.view.adapter.implement.BaseViewHolder;
import jp.softbank.assist.view.adapter.implement.RecyclerBaseAdapter;
import jp.softbank.assist.view.customview.EditTextLinesLimiter;


import java.io.File;
import java.util.List;

/**
 * adapter of dic-cr-01
 *
 * @author Systena
 * @version 1.0
 */
public class DicCreateAdapter extends RecyclerBaseAdapter {
    private DictionaryInfo mDictionaryInfo;
    private IOnClickItemDicCreate mIOnClickItemDicCreate;
    private IOnClickDeleteDic mIOnClickDeleteDic;
    private boolean mShowButtonDelete;// set true when use adapter in dic-edit
    private Activity mActivity;

    /**
     * set visibility for Footer View
     * set visibility for Header View
     */ {
        setFooterVisibility(true);
        setHeaderVisibility(true);
    }

    /**
     * set Activity
     *
     * @param activity
     */
    public void setActivity(Activity activity) {
        this.mActivity = activity;
    }

    /**
     * set interface IOnClickDeleteDic
     *
     * @param iOnClickDeleteDic is interface
     */
    public void setIOnClickDeleteDic(IOnClickDeleteDic iOnClickDeleteDic) {
        this.mIOnClickDeleteDic = iOnClickDeleteDic;
    }

    /**
     * set show button delete dictionary
     *
     * @param showButtonDelete is boolean
     */
    public void setShowButtonDelete(boolean showButtonDelete) {
        mShowButtonDelete = showButtonDelete;
    }

    /**
     * set interface for adapter
     *
     * @param iOnClickItemDicCreate
     */
    public void setInterface(IOnClickItemDicCreate iOnClickItemDicCreate) {
        this.mIOnClickItemDicCreate = iOnClickItemDicCreate;
    }

    /**
     * set ActionDictionary
     *
     * @param dictionaryInfo
     */
    public void setDictionaryInfo(DictionaryInfo dictionaryInfo) {
        this.mDictionaryInfo = dictionaryInfo;
    }

    @Override
    public int getContentItemCount() {
        return mDictionaryInfo.getCardList().size();
    }

    @Override
    public BaseViewHolder onCreateHeaderHolder(ViewGroup parent) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_dic_create_header, parent, false);
        return new HeaderViewHolder(itemView);
    }

    @Override
    public BaseViewHolder onCreateFooterHolder(ViewGroup parent) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_dic_edit_footer, parent, false);
        return new FooterSpaceViewHolder(itemView);
    }

    @Override
    public BaseViewHolder onCreateContentHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_dic_create, parent, false);
        return new ItemViewHolder(itemView);
    }

    /**
     * convert dp to px
     *
     * @param dp
     * @param context
     * @return
     */
    private int convertDpToPx(int dp, Context context) {
        return (int) (dp * context.getResources().getDisplayMetrics().density);
    }

    private class HeaderViewHolder extends BaseViewHolder implements GetImageResultListener {
        private LinearLayout mChooseCategory;
        private ImageView mImvThumbnail;
        private ImageView mEditThumbnail;
        private TextView mTvCategory;
        private EditText mEdtTitle;
        private ProgressBar mProgressBar;

        public HeaderViewHolder(View itemView) {
            super(itemView);
            mChooseCategory = itemView.findViewById(R.id.layout_choose_category_dic_cr);
            mImvThumbnail = itemView.findViewById(R.id.imv_thumbnail_dic_create);
            mEditThumbnail = itemView.findViewById(R.id.imv_edit_thumbnail_dic_create);
            mTvCategory = itemView.findViewById(R.id.tv_category_name);
            mEdtTitle = itemView.findViewById(R.id.edt_input_title_dic_cr);
            mProgressBar = itemView.findViewById(R.id.progress_bar);
            mEdtTitle.addTextChangedListener(new EditTextLinesLimiter(mEdtTitle, 3));
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mIOnClickItemDicCreate != null) {
                        mIOnClickItemDicCreate.onClickHeader();
                    }
                }
            });
            mEdtTitle.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    mDictionaryInfo.setName(mEdtTitle.getText().toString());
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });
        }

        @Override
        public void onBindView(int position) {
            mProgressBar.setVisibility(View.GONE);
            Bitmap bitmap = ResourcesUtils.getImageFromPath(mImvThumbnail.getContext(), mDictionaryInfo.getImageFileAbsolutePath());
            if (bitmap != null) {
                mImvThumbnail.setImageBitmap(bitmap);
                mImvThumbnail.setPadding(0, 0, 0, 0);
                mImvThumbnail.setBackground(mImvThumbnail.getContext().getDrawable(R.drawable.bgr_imv_thumbnail_2));
                mImvThumbnail.setClipToOutline(true);
            } else {
                int padding = convertDpToPx(Constants.Dictionary.PADDING_IMAGE_DIC, mImvThumbnail.getContext());
                mImvThumbnail.setPadding(padding, padding, padding, padding);
                mImvThumbnail.setImageDrawable(mImvThumbnail.getContext().getDrawable(R.drawable.ic_create_dic));
                mImvThumbnail.setBackground(mImvThumbnail.getContext().getDrawable(R.drawable.bgr_imv_thumbnail));
                mImvThumbnail.setClipToOutline(true);
            }
            mImvThumbnail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickItemDicCreate != null) {
                        mIOnClickItemDicCreate.onClickChooseThumbnail();
                    }
                }
            });

            mEditThumbnail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickItemDicCreate != null) {
                        mIOnClickItemDicCreate.onClickChooseThumbnail();
                    }
                }
            });
            mChooseCategory.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickItemDicCreate != null) {
                        mIOnClickItemDicCreate.onClickChooseCategory();
                    }
                }
            });
            mTvCategory.setText(Constants.getCategoryName(mDictionaryInfo.getCategoryId(), mTvCategory.getContext()));
            if (TextUtils.isEmpty(mDictionaryInfo.getName())) {
                mEdtTitle.getText().clear();
            } else {
                mEdtTitle.setText(mDictionaryInfo.getName());
            }

            if (!mDictionaryInfo.isCalledGetImageMethod() && mShowButtonDelete) {
                AppController.getInstance().getAssistServerInterface().getDictionaryImage(mDictionaryInfo.getDictionaryId(), this);
                mDictionaryInfo.setIsCalledGetImageMethod(true);
            }
        }

        @Override
        public void onResult(AssistServerResult result, final String filepath) {
            if (mActivity != null) {
                mActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mProgressBar.setVisibility(View.GONE);
                        Bitmap bitmap = ResourcesUtils.getImageFromPath(filepath);
                        if (bitmap != null) {
                            mImvThumbnail.setImageBitmap(bitmap);
                            File file = new File(filepath);
                            mDictionaryInfo.setImageFileName(file.getName());
                        }
                    }
                });
            }
        }

        @Override
        public void onStartConnection() {
            mProgressBar.setVisibility(View.VISIBLE);
        }
    }

    private class FooterSpaceViewHolder extends BaseViewHolder {
        private TextView mTvDelete;

        public FooterSpaceViewHolder(View itemView) {
            super(itemView);
            mTvDelete = itemView.findViewById(R.id.tv_delete_dic);
        }

        @Override
        public void onBindView(int position) {
            mTvDelete.setVisibility(mShowButtonDelete ? View.VISIBLE : View.INVISIBLE);
            mTvDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickDeleteDic != null) {
                        mIOnClickDeleteDic.onClickDelete();
                    }
                }
            });
        }
    }

    class ItemViewHolder extends BaseViewHolder implements GetImageResultListener {

        private LinearLayout mLayoutAddTop;
        private LinearLayout mLayoutAddBottom;
        private EditText mEdtComment;
        private TextView mTvPosition;
        private ImageView mImvCard;
        private ImageView mImgDelete;
        private CheckBox mCheckBox;
        private ProgressBar mProgressBar;

        public ItemViewHolder(View itemView) {
            super(itemView);
            mImgDelete = itemView.findViewById(R.id.img_delete_dic_cr);
            mTvPosition = itemView.findViewById(R.id.tv_position_dic_cr);
            mEdtComment = itemView.findViewById(R.id.edt_comment_item_dic_cr);
            mLayoutAddTop = itemView.findViewById(R.id.rlt_add_top);
            mLayoutAddBottom = itemView.findViewById(R.id.rlt_add_bottom);
            mImvCard = itemView.findViewById(R.id.img_item_dic_cr);
            mCheckBox = itemView.findViewById(R.id.checkbox_item_dic_cr);
            mProgressBar = itemView.findViewById(R.id.progress_bar);

            mEdtComment.addTextChangedListener(new EditTextLinesLimiter(mEdtComment, 5));
            mCheckBox.setClickable(false);
            mImgDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickItemDicCreate != null) {
                        mIOnClickItemDicCreate.onClickButtonDelete(getAdapterPosition() - 1);
                    }
                }
            });
            mLayoutAddTop.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickItemDicCreate != null) {
                        mIOnClickItemDicCreate.onClickButtonCreate(getAdapterPosition() - 1);
                    }
                }
            });
            mLayoutAddBottom.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickItemDicCreate != null) {
                        mIOnClickItemDicCreate.onClickButtonCreate(getAdapterPosition());
                    }
                }
            });
            mEdtComment.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    mDictionaryInfo.getCardList().get(getAdapterPosition() - 1).setText(mEdtComment.getText().toString());
                }

                @Override
                public void afterTextChanged(Editable editable) {

                }
            });
            mImvCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIOnClickItemDicCreate != null) {
                        mIOnClickItemDicCreate.updateAvatar(getAdapterPosition() - 1);
                    }
                }
            });
        }

        @Override
        public void onBindView(int position) {
            mProgressBar.setVisibility(View.GONE);
            mCheckBox.setVisibility(mDictionaryInfo.getCategoryId() == Constants.Ids.CATEGORY_ID_PROPERTY ? View.VISIBLE : View.INVISIBLE);
            mTvPosition.setVisibility(mDictionaryInfo.getCategoryId() == Constants.Ids.CATEGORY_ID_PROPERTY ? View.INVISIBLE : View.VISIBLE);
            mImgDelete.setVisibility(mDictionaryInfo.getCardList().size() == 1 ? View.INVISIBLE : View.VISIBLE);
            mTvPosition.setText(String.valueOf(position));
            mLayoutAddTop.setVisibility(getAdapterPosition() == 1 ? View.VISIBLE : View.GONE);
            if (mDictionaryInfo != null) {
                List<CardInfo> cardInfoList = mDictionaryInfo.getCardList();
                if (!TextUtils.isEmpty(cardInfoList.get(toContentPosition(position)).getImageFileAbsolutePath())) {
                    Bitmap bitmap = ResourcesUtils.getImageFromPath(mImvCard.getContext(), cardInfoList.get(toContentPosition(position)).getImageFileAbsolutePath());
                    mImvCard.setPadding(0, 0, 0, 0);
                    mImvCard.setBackground(mImvCard.getContext().getDrawable(R.drawable.bgr_imv_thumbnail_2));
                    mImvCard.setImageBitmap(bitmap);

                } else {
                    int padding = convertDpToPx(Constants.Dictionary.PADDING_IMAGE_ITEM, mImvCard.getContext());
                    mImvCard.setPadding(padding, padding, padding, padding);
                    mImvCard.setBackground(mImvCard.getContext().getDrawable(R.drawable.bgr_imv_thumbnail));
                    mImvCard.setImageResource(R.drawable.ic_card_empty);
                }
                mImvCard.setClipToOutline(true);
                if (!TextUtils.isEmpty(cardInfoList.get(toContentPosition(position)).getText())) {
                    mEdtComment.setText(mDictionaryInfo.getCardList().get(getAdapterPosition() - 1).getText());
                } else {
                    mEdtComment.getText().clear();
                }
            }
            if (!mDictionaryInfo.getCardList().get(toContentPosition(position)).isCalledGetImageMethod() && mShowButtonDelete &&
                    !TextUtils.isEmpty(mDictionaryInfo.getCardList().get(toContentPosition(position)).getImageUrl())) {
                AppController.getInstance().getAssistServerInterface().getCardImage(mDictionaryInfo.getCardList().get(toContentPosition(position)), this);
                mDictionaryInfo.getCardList().get(toContentPosition(position)).setIsCalledGetImageMethod(true);
            }
        }

        @Override
        public void onResult(AssistServerResult result, final String filepath) {
            if (mActivity != null && result.mResult == AssistServerResult.Result.Success) {
                mActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mProgressBar.setVisibility(View.GONE);
                        Bitmap bitmap = ResourcesUtils.getImageFromPath(filepath);
                        if (bitmap != null) {
                            mImvCard.setPadding(0, 0, 0, 0);
                            mImvCard.setBackground(mImvCard.getContext().getDrawable(R.drawable.bgr_imv_thumbnail_2));
                            mImvCard.setImageBitmap(bitmap);
                        }
                    }
                });
            }
        }

        @Override
        public void onStartConnection() {
            mProgressBar.setVisibility(View.VISIBLE);
        }
    }
}