package jp.softbank.assist.view.fragmenttemp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.ModelInterface;
import jp.softbank.assist.model.database.UserInfo;
import jp.softbank.assist.view.fragment.BaseFragment;

import static java.lang.Long.parseLong;


/**
 * Created by Tan N. Truong on 2019/01/09.
 */

// TODO: 2019/01/09 Just an example Fragment, can be deleted later

public class IoTest_2 extends BaseFragment implements View.OnClickListener {

    private TextView mTextId;
    private TextView mTextCuId;
    private EditText mTextName;
    private ImageView mImgIcon;
    private TextView mTextInfo;
    private Button mBtnSave;
    private UserInfo mData;

    private ModelInterface mModelInterface;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mModelInterface = new ModelInterface();

        UserInfo info = mModelInterface.getUserInfo();
        if (info == null) {
            UserInfo setData = new UserInfo();
            setData.setUserId(Long.parseLong("100"));
            setData.setCuid("400");
            setData.setNickname("にっくねーむ");
            setData.setIconId(R.drawable.ic_bus);
            mModelInterface.updateUserInfo(setData);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_temp_io_two, container, false);

        view.findViewById(R.id.button_read2_1).setOnClickListener(this);
//        view.findViewById(R.id.button_read2).setOnClickListener(this);
        mBtnSave = view.findViewById(R.id.button_save);
        mBtnSave.setOnClickListener(this);
        view.findViewById(R.id.button_clear).setOnClickListener(this);
        view.findViewById(R.id.button_add).setOnClickListener(this);
        view.findViewById(R.id.button_clear).setEnabled(false);

        mTextId = view.findViewById(R.id.text_id_body);
        mTextCuId = view.findViewById(R.id.text_cuid_body);
        mTextName = view.findViewById(R.id.text_nicname_body);
        mImgIcon = view.findViewById(R.id.img_icon_body);

        mTextInfo = view.findViewById(R.id.text_info);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_read2_1:
                mTextId.setFocusable(false);
                UserInfo info = mModelInterface.getUserInfo();
                if (info == null) {
                    mTextInfo.setText("データがありません");
                    mTextId.setText(null);
                    mTextName.setText(null);
                    mBtnSave.setEnabled(false);
                } else {
                    mData = info;
                    mTextId.setText(String.valueOf(mData.getUserId()));
                    mTextCuId.setText(mData.getCuid());
                    mTextName.setText(mData.getNickname());
                    mImgIcon.setImageResource((int) mData.getIconId());
                    mBtnSave.setEnabled(true);
                }
                break;
            case R.id.button_save:
                UserInfo save = new UserInfo();
                save.setUserId(parseLong(mTextId.getText().toString()));
                save.setCuid(mTextCuId.getText().toString());
                save.setNickname(mTextName.getText().toString());
                save.setIconId(mData.getIconId());
                mModelInterface.updateUserInfo(save);
                break;
            case R.id.button_clear:
//                mTextId.setFocusable(false);
//                RealmResults<RealmTestData> deleteData = mModelInterface.getTestDataById(parseLong(mTextId.getText().toString()));
//                if (!deleteData.isEmpty()) {
//                    mModelInterface.deleteTestData(deleteData);
//                }
                break;
            case R.id.button_add:
                mTextId.setFocusable(true);
                break;
            default:
                break;
        }
    }
}