/*
 * ファイル：RealmDeviceInfo.java
 * 概要：Realmデバイス情報テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Realmデバイス情報テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmDeviceInfo extends RealmObject {

    @PrimaryKey
    private int mId; // デバイス情報ID
    private boolean mIsSendToken; // トークン送信状態
    private String mFcmToken; // FCMトークン
    private String mOsVersion; // OSバージョン
    private String mAppVersion; // アプリバージョン

    public int getId() {
        return mId;
    }

    public void setId(int mId) {
        this.mId = mId;
    }

    public boolean isSendToken() {
        return mIsSendToken;
    }

    public void setIsSendToken(boolean isSendToken) {
        this.mIsSendToken = isSendToken;
    }

    public String getFcmToken() {
        return mFcmToken;
    }

    public void setFcmToken(String mFcmToken) {
        this.mFcmToken = mFcmToken;
    }

    public String getOsVersion() {
        return mOsVersion;
    }

    public void setOsVersion(String mOsVersion) {
        this.mOsVersion = mOsVersion;
    }

    public String getAppVersion() {
        return mAppVersion;
    }

    public void setAppVersion(String mAppVersion) {
        this.mAppVersion = mAppVersion;
    }
}
