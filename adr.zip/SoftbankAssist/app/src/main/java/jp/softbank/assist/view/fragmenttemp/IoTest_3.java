package jp.softbank.assist.view.fragmenttemp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.ModelInterface;
import jp.softbank.assist.model.database.CardInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.view.fragment.BaseFragment;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Long.parseLong;


/**
 * Created by Tan N. Truong on 2019/01/09.
 */

// TODO: 2019/01/09 Just an example Fragment, can be deleted later

public class IoTest_3 extends BaseFragment implements View.OnClickListener {

    private EditText mDictionary;
    private ImageView mImage;
    private TextView mAuthor;
    private EditText mCardName;
    private TextView mTextInfo;
    private Button mBtnSave;
    private Button mBtnAdd;

    private DictionaryInfo mData;
    private int mCardIndex = 0;

    private static final Long DICTIONARY_ID = parseLong("100");

    private ModelInterface mModelInterface;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mModelInterface = new ModelInterface();

        DictionaryInfo dictData = mModelInterface.getDicInfoByDicId(DICTIONARY_ID);
        if (dictData == null) {
            List<CardInfo> cardList = new ArrayList<>();
            CardInfo cardData1 = new CardInfo();
            cardData1.setDictionaryId(DICTIONARY_ID);
            cardData1.setCardId(parseLong("1234"));
            cardData1.setNextCardId(parseLong("5678"));
            cardData1.setText("カード内容1");
            cardList.add(cardData1);
            CardInfo cardData2 = new CardInfo();
            cardData2.setDictionaryId(DICTIONARY_ID);
            cardData2.setCardId(parseLong("5678"));
            cardData2.setNextCardId(parseLong("9999"));
            cardData2.setText("カード内容2");
            cardList.add(cardData2);
            CardInfo cardData3 = new CardInfo();
            cardData3.setDictionaryId(DICTIONARY_ID);
            cardData3.setCardId(parseLong("9999"));
            cardData3.setText("カード内容3");
            cardList.add(cardData3);

            DictionaryInfo setData = new DictionaryInfo();
            setData.setDictionaryId(DICTIONARY_ID);
            setData.setName("辞書のタイトル");
            setData.setCategoryId(parseLong("200"));
            setData.setType(DictionaryInfo.DictionaryType.Step);
            setData.setCreatorNickname("さくせいしゃ");
            setData.setCardList(cardList);

            mModelInterface.updateDictionaryInfo(setData);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_temp_io_three, container, false);

        view.findViewById(R.id.button_read3_1).setOnClickListener(this);
        view.findViewById(R.id.button_read3_2).setOnClickListener(this);
        view.findViewById(R.id.button_read3_3).setOnClickListener(this);
        view.findViewById(R.id.button_add3).setOnClickListener(this);
        mBtnSave = view.findViewById(R.id.button_save3);
        mBtnSave.setOnClickListener(this);
        mBtnAdd = view.findViewById(R.id.button_add3);
        mBtnAdd.setOnClickListener(this);

        mDictionary = view.findViewById(R.id.text_dictionary_body);
        mAuthor = view.findViewById(R.id.text_author_body);
        mCardName = view.findViewById(R.id.text_cardname_body);

        mTextInfo = view.findViewById(R.id.text_info);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_read3_1:
                DictionaryInfo data1 = mModelInterface.getDicInfoByDicId(DICTIONARY_ID);
                mTextInfo.setText(null);
                mData = data1;
                mDictionary.setText(mData.getName());
                mAuthor.setText(mData.getCreatorNickname());
                mCardName.setText(mData.getCardList().get(0).getText());
                mCardIndex = 0;

                mBtnAdd.setEnabled(true);
                break;
            case R.id.button_read3_2:
                DictionaryInfo data2 = mModelInterface.getDicInfoByDicId(DICTIONARY_ID);
                mTextInfo.setText(null);
                mData = data2;
                mDictionary.setText(mData.getName());
                mAuthor.setText(mData.getCreatorNickname());
                mCardName.setText(mData.getCardList().get(1).getText());
                mCardIndex = 1;

                mBtnAdd.setEnabled(true);
                break;
            case R.id.button_read3_3:
                DictionaryInfo data3 = mModelInterface.getDicInfoByDicId(DICTIONARY_ID);
                mTextInfo.setText(null);
                mData = data3;
                mDictionary.setText(mData.getName());
                mAuthor.setText(mData.getCreatorNickname());
                mCardName.setText(mData.getCardList().get(2).getText());
                mCardIndex = 2;

                mBtnAdd.setEnabled(true);
                break;
            case R.id.button_add3:
                mBtnSave.setEnabled(true);
                break;
            case R.id.button_save3:
                mData.setName(mDictionary.getText().toString());
                mData.getCardList().get(mCardIndex).setText(mCardName.getText().toString());
                mModelInterface.updateDictionaryInfo(mData);
                mBtnSave.setEnabled(false);
                mDictionary.setFocusable(false);
                mCardName.setFocusable(false);
                mBtnAdd.setEnabled(false);
                break;
            default:
                break;
        }
    }
}