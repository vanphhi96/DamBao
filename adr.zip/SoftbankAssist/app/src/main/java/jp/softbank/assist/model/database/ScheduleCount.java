/*
 * ファイル：ScheduleCount.java
 * 概要：スケジュール件数情報
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.database;

import java.util.Date;

/**
 * スケジュール件数情報.
 *
 * @author Systena
 * @version 1.0
 */
public class ScheduleCount {

    private Date mDate; // 日付
    private long mCount; // 件数


    public Date getDate() {
        return mDate;
    }

    public void setDate(Date mDate) {
        this.mDate = mDate;
    }

    public long getCount() {
        return mCount;
    }

    public void setCount(long mCount) {
        this.mCount = mCount;
    }
}
