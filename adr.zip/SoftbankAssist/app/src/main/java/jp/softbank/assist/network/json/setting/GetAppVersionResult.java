/*
 * ファイル：GetAppVersionResult.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.setting;

import com.google.gson.annotations.SerializedName;

/**
 * 最新アプリバージョン取得結果.
 */
public class GetAppVersionResult {

    @SerializedName("mId")
    private Long mId = null;
    @SerializedName("os_kind")
    private Long mOsKind = null;
    @SerializedName("is_must_update")
    private Long mIsMustUpdate = null;
    @SerializedName("message_text")
    private String mMessageText = null;
    @SerializedName("mUrl")
    private String mUrl = null;
    @SerializedName("latest_version")
    private String mLatestVersion = null;


    /**
     * アプリ情報ID.
     */
    public Long getId() {
        return mId;
    }
    public void setId(Long id) {
        this.mId = id;
    }

    /**
     * OS種別（0：iOS、1：Android）.
     */
    public Long getOsKind() {
        return mOsKind;
    }
    public void setOsKind(Long osKind) {
        this.mOsKind = osKind;
    }

    /**
     * アップデート必須フラグ.
     */
    public Long getIsMustUpdate() {
        return mIsMustUpdate;
    }
    public void setIsMustUpdate(Long isMustUpdate) {
        this.mIsMustUpdate = isMustUpdate;
    }

    /**
     * 表示文言.
     */
    public String getMessageText() {
        return mMessageText;
    }
    public void setMessageText(String messageText) {
        this.mMessageText = messageText;
    }

    /**
     * 遷移先URL.
     */
    public String getUrl() {
        return mUrl;
    }
    public void setUrl(String url) {
        this.mUrl = url;
    }

    /**
     * 現在の最新バージョン.
     */
    public String getLatestVersion() {
        return mLatestVersion;
    }
    public void setLatestVersion(String latestVersion) {
        this.mLatestVersion = latestVersion;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GetAppVersionResult resultGetAppVersion = (GetAppVersionResult) o;
        return (this.mId == null ? resultGetAppVersion.mId == null : this.mId.equals(resultGetAppVersion.mId)) &&
                (this.mOsKind == null ? resultGetAppVersion.mOsKind == null : this.mOsKind.equals(resultGetAppVersion.mOsKind)) &&
                (this.mIsMustUpdate == null ? resultGetAppVersion.mIsMustUpdate == null : this.mIsMustUpdate.equals(resultGetAppVersion.mIsMustUpdate)) &&
                (this.mMessageText == null ? resultGetAppVersion.mMessageText == null : this.mMessageText.equals(resultGetAppVersion.mMessageText)) &&
                (this.mUrl == null ? resultGetAppVersion.mUrl == null : this.mUrl.equals(resultGetAppVersion.mUrl)) &&
                (this.mLatestVersion == null ? resultGetAppVersion.mLatestVersion == null : this.mLatestVersion.equals(resultGetAppVersion.mLatestVersion));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mId == null ? 0: this.mId.hashCode());
        result = 31 * result + (this.mOsKind == null ? 0: this.mOsKind.hashCode());
        result = 31 * result + (this.mIsMustUpdate == null ? 0: this.mIsMustUpdate.hashCode());
        result = 31 * result + (this.mMessageText == null ? 0: this.mMessageText.hashCode());
        result = 31 * result + (this.mUrl == null ? 0: this.mUrl.hashCode());
        result = 31 * result + (this.mLatestVersion == null ? 0: this.mLatestVersion.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class GetAppVersionResult {\n");

        sb.append("  mId: ").append(mId).append("\n");
        sb.append("  mOsKind: ").append(mOsKind).append("\n");
        sb.append("  mIsMustUpdate: ").append(mIsMustUpdate).append("\n");
        sb.append("  mMessageText: ").append(mMessageText).append("\n");
        sb.append("  mUrl: ").append(mUrl).append("\n");
        sb.append("  mLatestVersion: ").append(mLatestVersion).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
