/*
 * ファイル：ScheduleRepeat.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.schedule;

import com.google.gson.annotations.SerializedName;

/**
 * 繰り返し設定.
 */
public class ScheduleRepeat {

    @SerializedName("mInterval")
    private Long mInterval = null;
    @SerializedName("repeat_sunday")
    private Long mRepeatSunday = null;
    @SerializedName("repeat_monday")
    private Long mRepeatMonday = null;
    @SerializedName("repeat_tuesday")
    private Long mRepeatTuesday = null;
    @SerializedName("repeat_wednesday")
    private Long mRepeatWednesday = null;
    @SerializedName("repeat_thursday")
    private Long mRepeatThursday = null;
    @SerializedName("repeat_friday")
    private Long mRepeatFriday = null;
    @SerializedName("repeat_saturday")
    private Long mRepeatSaturday = null;


    /**
     * 値初期化.
     */
    public void initializeValues() {
        mInterval = 0L;
        mRepeatSunday = 0L;
        mRepeatMonday = 0L;
        mRepeatTuesday = 0L;
        mRepeatWednesday = 0L;
        mRepeatThursday = 0L;
        mRepeatFriday = 0L;
        mRepeatSaturday = 0L;
    }

    /**
     * インターバル（0：設定なし、10：デイリー、20：ウィークリー、30：マンスリー、40：イヤーリー）.
     */
    public Long getInterval() {
        return mInterval;
    }
    public void setInterval(Long interval) {
        this.mInterval = interval;
    }

    /**
     * 日曜日繰返し（0：無効、1：有効）.
     */
    public Long getRepeatSunday() {
        return mRepeatSunday;
    }
    public void setRepeatSunday(Long repeatSunday) {
        this.mRepeatSunday = repeatSunday;
    }

    /**
     * 月曜日繰返し（0：無効、1：有効）.
     */
    public Long getRepeatMonday() {
        return mRepeatMonday;
    }
    public void setRepeatMonday(Long repeatMonday) {
        this.mRepeatMonday = repeatMonday;
    }

    /**
     * 火曜日繰返し（0：無効、1：有効）.
     */
    public Long getRepeatTuesday() {
        return mRepeatTuesday;
    }
    public void setRepeatTuesday(Long repeatTuesday) {
        this.mRepeatTuesday = repeatTuesday;
    }

    /**
     * 水曜日繰返し（0：無効、1：有効）.
     */
    public Long getRepeatWednesday() {
        return mRepeatWednesday;
    }
    public void setRepeatWednesday(Long repeatWednesday) {
        this.mRepeatWednesday = repeatWednesday;
    }

    /**
     * 木曜日繰返し（0：無効、1：有効）.
     */
    public Long getRepeatThursday() {
        return mRepeatThursday;
    }
    public void setRepeatThursday(Long repeatThursday) {
        this.mRepeatThursday = repeatThursday;
    }

    /**
     * 金曜日繰返し（0：無効、1：有効）.
     */
    public Long getRepeatFriday() {
        return mRepeatFriday;
    }
    public void setRepeatFriday(Long repeatFriday) {
        this.mRepeatFriday = repeatFriday;
    }

    /**
     * 土曜日繰返し（0：無効、1：有効）.
     */
    public Long getRepeatSaturday() {
        return mRepeatSaturday;
    }
    public void setRepeatSaturday(Long repeatSaturday) {
        this.mRepeatSaturday = repeatSaturday;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ScheduleRepeat scheduleRepeat = (ScheduleRepeat) o;
        return (this.mInterval == null ? scheduleRepeat.mInterval == null : this.mInterval.equals(scheduleRepeat.mInterval)) &&
                (this.mRepeatSunday == null ? scheduleRepeat.mRepeatSunday == null : this.mRepeatSunday.equals(scheduleRepeat.mRepeatSunday)) &&
                (this.mRepeatMonday == null ? scheduleRepeat.mRepeatMonday == null : this.mRepeatMonday.equals(scheduleRepeat.mRepeatMonday)) &&
                (this.mRepeatTuesday == null ? scheduleRepeat.mRepeatTuesday == null : this.mRepeatTuesday.equals(scheduleRepeat.mRepeatTuesday)) &&
                (this.mRepeatWednesday == null ? scheduleRepeat.mRepeatWednesday == null : this.mRepeatWednesday.equals(scheduleRepeat.mRepeatWednesday)) &&
                (this.mRepeatThursday == null ? scheduleRepeat.mRepeatThursday == null : this.mRepeatThursday.equals(scheduleRepeat.mRepeatThursday)) &&
                (this.mRepeatFriday == null ? scheduleRepeat.mRepeatFriday == null : this.mRepeatFriday.equals(scheduleRepeat.mRepeatFriday)) &&
                (this.mRepeatSaturday == null ? scheduleRepeat.mRepeatSaturday == null : this.mRepeatSaturday.equals(scheduleRepeat.mRepeatSaturday));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mInterval == null ? 0: this.mInterval.hashCode());
        result = 31 * result + (this.mRepeatSunday == null ? 0: this.mRepeatSunday.hashCode());
        result = 31 * result + (this.mRepeatMonday == null ? 0: this.mRepeatMonday.hashCode());
        result = 31 * result + (this.mRepeatTuesday == null ? 0: this.mRepeatTuesday.hashCode());
        result = 31 * result + (this.mRepeatWednesday == null ? 0: this.mRepeatWednesday.hashCode());
        result = 31 * result + (this.mRepeatThursday == null ? 0: this.mRepeatThursday.hashCode());
        result = 31 * result + (this.mRepeatFriday == null ? 0: this.mRepeatFriday.hashCode());
        result = 31 * result + (this.mRepeatSaturday == null ? 0: this.mRepeatSaturday.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class ScheduleRepeat {\n");

        sb.append("  mInterval: ").append(mInterval).append("\n");
        sb.append("  mRepeatSunday: ").append(mRepeatSunday).append("\n");
        sb.append("  mRepeatMonday: ").append(mRepeatMonday).append("\n");
        sb.append("  mRepeatTuesday: ").append(mRepeatTuesday).append("\n");
        sb.append("  mRepeatWednesday: ").append(mRepeatWednesday).append("\n");
        sb.append("  mRepeatThursday: ").append(mRepeatThursday).append("\n");
        sb.append("  mRepeatFriday: ").append(mRepeatFriday).append("\n");
        sb.append("  mRepeatSaturday: ").append(mRepeatSaturday).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
