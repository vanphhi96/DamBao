/*
 * ファイル：FooterSpaceAdapter.java
 * 概要：Adapter footer space of recycler view
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter.implement;

import android.support.annotation.DimenRes;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import jp.softbank.assist.R;
import jp.softbank.assist.util.ResourcesUtils;

/**
 * Adapter footer space of recycler view
 *
 * @author Systena
 * @version 1.0
 */
public abstract class FooterSpaceAdapter extends RecyclerBaseAdapter {
    /**
     * set show footer view
     *
     */
    {
        setFooterVisibility(true);
    }

    @Override
    public BaseViewHolder onCreateFooterHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_footer_space
                , parent, false);
        return new FooterHolder(view);
    }

    /**
     * get dimen for space bottom
     *
     * @return
     */
    @DimenRes
    public int getSpaceBottomResId() {
        return R.dimen.recycler_bottom_space;
    }

    /**
     * create holder for footer item
     */
    private class FooterHolder extends BaseViewHolder {

        public FooterHolder(@NonNull View itemView) {
            super(itemView);
            View space = itemView.findViewById(R.id.view_space);
            ViewGroup.LayoutParams params = space.getLayoutParams();
            params.height = ResourcesUtils.getDimens(itemView.getContext(), getSpaceBottomResId());
            params.width = ResourcesUtils.getDimens(itemView.getContext(), getSpaceBottomResId());
            space.setLayoutParams(params);
        }

        @Override
        public void onBindView(int position) {
        }
    }
}
