/*
 * ファイル：GetNoticeParam.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.notice;

import jp.softbank.assist.network.json.RequestParam;

/**
 * お知らせ一覧取得パラメータ.
 */
public class GetNoticeParam extends RequestParam {

    private Long mVersion;


    /**
     * バージョン.
     */
    public Long getVersion() {
        return mVersion;
    }
    public void setVersion(Long version) {
        this.mVersion = version;
    }
}
