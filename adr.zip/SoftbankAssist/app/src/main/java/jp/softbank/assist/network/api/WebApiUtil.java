/*
 * ファイル：WebApiUtil.java
 * 概要：WebApi向けユーティリティ
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.api;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.network.json.ErrorResult;
import jp.softbank.assist.network.json.dictionary.AddDictionaryResult;
import jp.softbank.assist.network.json.dictionary.AddDictionaryResultCard;
import jp.softbank.assist.network.json.dictionary.EditDictionaryDeleteCard;
import jp.softbank.assist.network.json.dictionary.EditDictionaryResult;
import jp.softbank.assist.network.json.dictionary.EditDictionaryResultCardContent;
import jp.softbank.assist.network.json.dictionary.EditDictionaryResultCardPos;
import jp.softbank.assist.network.json.dictionary.EditDictionaryResultDicEditContent;
import jp.softbank.assist.network.json.dictionary.GetCategoriesResult;
import jp.softbank.assist.network.json.dictionary.GetCategoriesResultList;
import jp.softbank.assist.network.json.dictionary.SynchronizeDictionaryResult;
import jp.softbank.assist.network.json.dictionary.SynchronizeDictionaryResultCard;
import jp.softbank.assist.network.json.dictionary.SynchronizeDictionaryResultDictionary;
import jp.softbank.assist.network.json.notice.GetNoticeResult;
import jp.softbank.assist.network.json.notice.GetNoticeResultList;
import jp.softbank.assist.network.json.schedule.CountScheduleResult;
import jp.softbank.assist.network.json.schedule.CountScheduleResultList;
import jp.softbank.assist.network.json.schedule.GetScheduleResult;
import jp.softbank.assist.network.json.schedule.GetScheduleResultList;
import jp.softbank.assist.network.json.schedule.GetScheduleResultMeta;
import jp.softbank.assist.network.json.schedule.GetScheduleResultReminder;
import jp.softbank.assist.network.json.schedule.GetScheduleResultRepeat;
import jp.softbank.assist.network.json.schedule.GetScheduleResultSchedule;
import jp.softbank.assist.network.json.schedule.ScheduleDictionary;
import jp.softbank.assist.network.json.setting.GetAppVersionResult;
import jp.softbank.assist.network.json.setting.SetAppSettingResult;
import jp.softbank.assist.network.json.user.GetUserResult;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * WebApi向けユーティリティ.
 */
public class WebApiUtil {

    private static GsonBuilder sGsonBuilder;

    static {
        sGsonBuilder = new GsonBuilder();
//        gsonBuilder.serializeNulls();
        sGsonBuilder.setPrettyPrinting();
//        gsonBuilder.setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
//        gsonBuilder.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {
//            public Date deserialize(JsonElement json, Status typeOfT, JsonDeserializationContext context) throws JsonParseException {
//                return new Date(json.getAsJsonPrimitive().getAsLong());
//            }
//        });
    }

    /**
     * Gsonオブジェクトの取得.
     *
     * @return Gson
     */
    public static Gson getGson() {
        return sGsonBuilder.create();
    }

    /**
     * Json文字列への変換.
     *
     * @param obj クラス
     * @return Json文字列
     */
    public static String serialize(Object obj) {
        return getGson().toJson(obj);
    }

    /**
     * Json文字列からオブジェクトを構築.
     *
     * @param jsonString Json文字列
     * @param cls 変換先クラス定義
     * @return 変換先クラスオブジェクト
     */
    public static <T> T deserializeToObject(String jsonString, Class cls) {
        return getGson().fromJson(jsonString, getTypeForDeserialization(cls));
    }

    private static Type getTypeForDeserialization(Class cls) {
        String className = cls.getSimpleName();

        if ("ErrorResult".equalsIgnoreCase(className)) {
            return new TypeToken<ErrorResult>(){}.getType();
        }

        if ("ScheduleDictionary".equalsIgnoreCase(className)) {
            return new TypeToken<ScheduleDictionary>(){}.getType();
        }
        if ("GetScheduleResultReminder".equalsIgnoreCase(className)) {
            return new TypeToken<GetScheduleResultReminder>(){}.getType();
        }
        if ("GetScheduleResultList".equalsIgnoreCase(className)) {
            return new TypeToken<GetScheduleResultList>(){}.getType();
        }
        if ("GetScheduleResult".equalsIgnoreCase(className)) {
            return new TypeToken<GetScheduleResult>(){}.getType();
        }
        if ("GetScheduleResultSchedule".equalsIgnoreCase(className)) {
            return new TypeToken<GetScheduleResultSchedule>(){}.getType();
        }
        if ("GetScheduleResultMeta".equalsIgnoreCase(className)) {
            return new TypeToken<GetScheduleResultMeta>(){}.getType();
        }
        if ("GetScheduleResultRepeat".equalsIgnoreCase(className)) {
            return new TypeToken<GetScheduleResultRepeat>(){}.getType();
        }
        if ("CountScheduleResultList".equalsIgnoreCase(className)) {
            return new TypeToken<CountScheduleResultList>(){}.getType();
        }
        if ("CountScheduleResult".equalsIgnoreCase(className)) {
            return new TypeToken<CountScheduleResult>(){}.getType();
        }

        if ("GetCategoriesResultList".equalsIgnoreCase(className)) {
            return new TypeToken<GetCategoriesResultList>(){}.getType();
        }
        if ("GetCategoriesResult".equalsIgnoreCase(className)) {
            return new TypeToken<GetCategoriesResult>(){}.getType();
        }
        if ("AddDictionaryResult".equalsIgnoreCase(className)) {
            return new TypeToken<AddDictionaryResult>(){}.getType();
        }
        if ("AddDictionaryResultCard".equalsIgnoreCase(className)) {
            return new TypeToken<AddDictionaryResultCard>(){}.getType();
        }
        if ("EditDictionaryDeleteCard".equalsIgnoreCase(className)) {
            return new TypeToken<EditDictionaryDeleteCard>(){}.getType();
        }
        if ("EditDictionaryResult".equalsIgnoreCase(className)) {
            return new TypeToken<EditDictionaryResult>(){}.getType();
        }
        if ("EditDictionaryResultCardPos".equalsIgnoreCase(className)) {
            return new TypeToken<EditDictionaryResultCardPos>(){}.getType();
        }
        if ("EditDictionaryResultCardContent".equalsIgnoreCase(className)) {
            return new TypeToken<EditDictionaryResultCardContent>(){}.getType();
        }
        if ("EditDictionaryResultDicEditContent".equalsIgnoreCase(className)) {
            return new TypeToken<EditDictionaryResultDicEditContent>(){}.getType();
        }
        if ("SynchronizeDictionaryResult".equalsIgnoreCase(className)) {
            return new TypeToken<SynchronizeDictionaryResult>(){}.getType();
        }
        if ("SynchronizeDictionaryResultDictionary".equalsIgnoreCase(className)) {
            return new TypeToken<SynchronizeDictionaryResultDictionary>(){}.getType();
        }
        if ("SynchronizeDictionaryResultCard".equalsIgnoreCase(className)) {
            return new TypeToken<SynchronizeDictionaryResultCard>(){}.getType();
        }

        if ("GetNoticeResultList".equalsIgnoreCase(className)) {
            return new TypeToken<GetNoticeResultList>(){}.getType();
        }
        if ("GetNoticeResult".equalsIgnoreCase(className)) {
            return new TypeToken<GetNoticeResult>(){}.getType();
        }

        if ("GetAppVersionResult".equalsIgnoreCase(className)) {
            return new TypeToken<GetAppVersionResult>(){}.getType();
        }
        if ("SetAppSettingResult".equalsIgnoreCase(className)) {
            return new TypeToken<SetAppSettingResult>(){}.getType();
        }

        if ("GetUserResult".equalsIgnoreCase(className)) {
            return new TypeToken<GetUserResult>(){}.getType();
        }

        return new TypeToken<Object>(){}.getType();
    }

    /**
     * レスポンスデータからErrorResultへ変換.
     *
     * @param response レスポンスデータ
     * @return ErrorResult
     */
    public static ErrorResult convertToError(byte[] response) {

        try {
            String messages = new String(response, "UTF-8");
            ErrorResult temp = deserializeToObject(messages, ErrorResult.class);
            return temp;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JsonSyntaxException e) {
            e.printStackTrace();
        }

        // TODO:その他のエラー処理
        ErrorResult result = new ErrorResult();
        result.setCode("-1");
        result.setItem("");
        result.setMessage("response error");
        return result;
    }

    /**
     * 結果情報をUI向けクラスへ変換.
     *
     * @param result 結果情報
     * @return UI向けクラス
     */
    public static List<CategoryInfo> convertToUiData(GetCategoriesResultList result) {
        List<CategoryInfo> list = new ArrayList<CategoryInfo>();

        Iterator<GetCategoriesResult> ite = result.iterator();
        while (ite.hasNext()) {
            GetCategoriesResult temp = ite.next();

            CategoryInfo info = new CategoryInfo();
            info.setCategoryId(temp.getCategoryId());
            info.setIconId(temp.getCategoryIconId());
            info.setName(temp.getCategoryName());

            list.add(info);
        }
        return list;
    }
}
