/*
 * ファイル：SetTimePickerDialogFactory.java
 * 概要：Time Picker Dialog in Setting Screen
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.dialog.factories.customfactories;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.TimePicker;

import jp.softbank.assist.R;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.view.dialog.factories.BaseDialogFactory;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;

import java.util.Date;

/**
 * set-pos-02
 *
 * @author Systena
 * @version 1.0
 */
public class SetTimePickerDialogFactory extends BaseDialogFactory implements View.OnClickListener, TimePicker.OnTimeChangedListener {
    private DialogTypeControl.DialogType mDialogType;
    private TimePicker mTimePicker;
    private TextView mTvOk;
    private TextView mTvCancel;
    private ISetTimePicker mISetTimePicker;
    private int mViewId;
    private int mMinHour;
    private int mMinMinute;
    private int mMaxHour;
    private int mMaxMinute;
    private Date mDateDisplay;

    public SetTimePickerDialogFactory(DialogTypeControl.DialogType dialogType, ISetTimePicker iSetTimePicker, int viewId) {
        this.mDialogType = dialogType;
        this.mISetTimePicker = iSetTimePicker;
        this.mViewId = viewId;
    }

    /**
     * Set range so that when open ”完了”Time picker, users can not choose time
     * earlier than ”開始” Time picker
     *
     * @param minHour
     * @param minMin
     */
    public void setRangeMin(int minHour, int minMin) {
        this.mMinHour = minHour;
        this.mMinMinute = minMin;
    }

    /**
     * Set range so that when open ”開始”Time picker, users can not choose time
     * later than ”完了” Time picker
     *
     * @param maxHour
     * @param maxMinute
     */
    public void setRangeMax(int maxHour, int maxMinute) {
        this.mMaxHour = maxHour;
        this.mMaxMinute = maxMinute;
    }

    /**
     * Set time to display in Time Picker exactly the same time ”開始” or ”完了”
     * For example : If ”開始” is 6:00 --> Time Picker will show 6:00 at the beginning
     *
     * @param dateDisplay
     */
    public void setDisplayDate(Date dateDisplay) {
        mDateDisplay = dateDisplay;
    }


    @Override
    public AlertDialog getReadyAlertDialog(FragmentActivity activity) {
        AlertDialog.Builder builder = createDialogBuilder(activity);
        LayoutInflater inflater = activity.getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_set_time_picker, null);
        view.setClipToOutline(true);
        initView(view);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return alertDialog;
    }

    @Override
    public String getDialogTag() {
        return null;
    }

    /**
     * View初期化
     *
     * @param view
     */
    private void initView(View view) {
        mTimePicker = view.findViewById(R.id.time_picker);
        mTimePicker.setOnTimeChangedListener(this);
        mTvOk = view.findViewById(R.id.tv_ok);
        mTvCancel = view.findViewById(R.id.tv_cancel);
        mTvOk.setOnClickListener(this);
        mTvCancel.setOnClickListener(this);

        mTimePicker.setHour(DateUtils.getHourFromDate(mDateDisplay));
        mTimePicker.setMinute(DateUtils.getMinFromDate(mDateDisplay));
        mTimePicker.setIs24HourView(true);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_ok:
                if (mISetTimePicker != null) {
                    mISetTimePicker.onOkClick(mViewId, DateUtils.getDateFromTimePicker(mTimePicker.getHour(), mTimePicker.getMinute()));
                }
                break;
            case R.id.tv_cancel:
                if (mISetTimePicker != null) {
                    mISetTimePicker.onCancelClick();
                }
                break;
            default:
                break;
        }
    }

    /**
     * Same with setRangeMin() above
     *
     * @param view
     * @param hourOfDay
     * @param minute
     */
    @Override
    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
        switch (mViewId) {
            case R.id.tv_start_time:
                if (hourOfDay > mMaxHour || (hourOfDay == mMaxHour && minute > mMaxMinute)) {
                    updateToValidTime(mMaxHour, mMaxMinute);
                }
                break;
            case R.id.tv_end_time:
                if (hourOfDay < mMinHour || (hourOfDay == mMinHour && minute < mMinMinute)) {
                    updateToValidTime(mMinHour, mMinMinute);
                }
                break;
            default:
                break;

        }
    }

    /**
     * Reset to valid time
     * For example : if ”開始” is 6:00 and user wants to scroll ”完了” Time Picker to 5:59
     * --> Time Picker will automatically scroll to 6:00 because ”完了” cannot smaller than ”開始”
     *
     * @param hour
     * @param minute
     */
    private void updateToValidTime(int hour, int minute) {
        mTimePicker.setHour(hour);
        mTimePicker.setMinute(minute);
    }
}
