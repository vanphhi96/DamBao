/*
 * ファイル：GetAppVersionResultListener.java
 * 概要：アシストサーバI/Fのコールバック
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.listener;

import jp.softbank.assist.model.database.AppVersionInfo;
import jp.softbank.assist.network.AssistServerResult;

/**
 * 最新アプリバージョン情報取得結果.
 */
public interface GetAppVersionResultListener extends BaseResultListener {

    /**
     * 処理結果通知.
     *
     * @param result 処理結果
     * @param info アプリバージョン情報
     */
    public void onResult(AssistServerResult result, AppVersionInfo info);
}
