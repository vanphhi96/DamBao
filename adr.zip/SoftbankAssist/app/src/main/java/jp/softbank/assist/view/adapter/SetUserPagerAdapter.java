/*
 * ファイル：SetUserPagerAdapter.java
 * 概要：利用者設定画面のAdapter.
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.adapter;


import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import jp.softbank.assist.view.activity.settings.SetUserSettingUiActivity;
import jp.softbank.assist.view.fragment.settings.SetUserPagerFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * (set-acc-01/ViewPager用) Adapter
 *
 * @author Systena
 * @version 1.0
 */
public class SetUserPagerAdapter extends FragmentStatePagerAdapter {

    private List<Integer> mIconList;

    public SetUserPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return SetUserPagerFragment.newInstance(getIconListForEachFragment(mIconList, position), position);
    }

    @Override
    public int getCount() {
        int fragmentCount = mIconList.size() / SetUserSettingUiActivity.LIMIT_ITEM + 1;
        if (mIconList.size() % SetUserSettingUiActivity.LIMIT_ITEM == 0) {
            fragmentCount--;
        }
        return fragmentCount;
    }

    /**
     * Icon Listの取得
     *
     * @param mIconList
     */
    public void setIconList(List<Integer> mIconList) {
        this.mIconList = mIconList;
    }

    /**
     * Fragment毎のIconを取得
     *
     * @param iconList
     * @param position
     * @return
     */
    private ArrayList<Integer> getIconListForEachFragment(List<Integer> iconList, int position) {
        if (iconList.size() >= (position + 1) * SetUserSettingUiActivity.LIMIT_ITEM) {
            /* if current fragment item is still bigger than LIMIT_ITEM (8)
                --> return 8
             */
            return new ArrayList<>(iconList.subList(position * SetUserSettingUiActivity.LIMIT_ITEM, (position + 1) * SetUserSettingUiActivity.LIMIT_ITEM));
        } else if (position * SetUserSettingUiActivity.LIMIT_ITEM < iconList.size()) {
            /* if current fragment item is <= 8 --> return the remaining icon
             */
            return new ArrayList<>(iconList.subList(position * SetUserSettingUiActivity.LIMIT_ITEM, iconList.size()));
        }
        return null;
    }

    /**
     * Fragmentを更新することに必要メソッド
     *
     * @param object
     * @return
     */
    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }
}
