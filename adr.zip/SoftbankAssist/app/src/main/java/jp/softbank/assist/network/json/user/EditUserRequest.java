/*
 * ファイル：EditUserRequest.java
 * 概要：WebAPI I/F用データクラス
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.network.json.user;

import com.google.gson.annotations.SerializedName;

import jp.softbank.assist.network.json.RequestBody;

/**
 * ユーザ編集リクエスト.
 */
public class EditUserRequest extends RequestBody {

    @SerializedName("user_id")
    private Long mUserId = null;
    @SerializedName("mNickname")
    private String mNickname = null;
    @SerializedName("icon_id")
    private Long mIconId = null;


    /**
     * 利用者ID.
     */
    public Long getUserId() {
        return mUserId;
    }
    public void setUserId(Long userId) {
        this.mUserId = userId;
    }

    /**
     * ニックネーム.
     */
    public String getNickname() {
        return mNickname;
    }
    public void setNickname(String nickname) {
        this.mNickname = nickname;
    }

    /**
     * アイコンID.
     */
    public Long getIconId() {
        return mIconId;
    }
    public void setIconId(Long iconId) {
        this.mIconId = iconId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EditUserRequest requestEditUser = (EditUserRequest) o;
        return (this.mUserId == null ? requestEditUser.mUserId == null : this.mUserId.equals(requestEditUser.mUserId)) &&
                (this.mNickname == null ? requestEditUser.mNickname == null : this.mNickname.equals(requestEditUser.mNickname)) &&
                (this.mIconId == null ? requestEditUser.mIconId == null : this.mIconId.equals(requestEditUser.mIconId));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (this.mUserId == null ? 0: this.mUserId.hashCode());
        result = 31 * result + (this.mNickname == null ? 0: this.mNickname.hashCode());
        result = 31 * result + (this.mIconId == null ? 0: this.mIconId.hashCode());
        return result;
    }

    @Override
    public String toString()  {
        StringBuilder sb = new StringBuilder();
        sb.append("class EditUserRequest {\n");

        sb.append("  mUserId: ").append(mUserId).append("\n");
        sb.append("  mNickname: ").append(mNickname).append("\n");
        sb.append("  mIconId: ").append(mIconId).append("\n");
        sb.append("}\n");
        return sb.toString();
    }
}
