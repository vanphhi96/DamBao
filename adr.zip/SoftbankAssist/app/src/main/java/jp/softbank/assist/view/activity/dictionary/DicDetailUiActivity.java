/*
 * ファイル：DicDetailUiActivity.java
 * 概要：じしょ詳細画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.dictionary;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.model.database.CategoryInfo;
import jp.softbank.assist.model.database.DictionaryInfo;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.ResourcesUtils;
import jp.softbank.assist.view.ScreenId;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.adapter.DetailDictionaryAdapter;
import jp.softbank.assist.view.dialog.DialogGenerator;
import jp.softbank.assist.view.dialog.factories.DialogTypeControl;
import jp.softbank.assist.view.dialog.factories.customfactories.DetailPictureDialogFactory;
import jp.softbank.assist.view.dialog.factories.customfactories.IDetailPicture;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * dic-03
 *
 * @author Systena
 * @version 1.0
 */
public class DicDetailUiActivity extends BaseUiActivity implements IOnClickDetailDic, View.OnClickListener,
        IDetailPicture {
    private RecyclerView mRecycleView;
    private DetailDictionaryAdapter mAdapter;
    private DictionaryInfo mDictionaryInfo;
    private RelativeLayout mBtnBack;
    private TextView mTvBack;
    private int mColorBackgroundItem;
    private int mColorFlagItem;
    private DialogFragment mDialogDetailPicture;

    private List<CategoryInfo> mCategoryInfoList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dic_detail);
        mRecycleView = findViewById(R.id.recycle_dic_detail);
        mBtnBack = findViewById(R.id.rlt_dic_detail_back);
        mTvBack = findViewById(R.id.tv_back_dic_detail);
        mBtnBack.setOnClickListener(this);
        mDictionaryInfo = getIntentDicInfo();
        mCategoryInfoList = getIntentListCategory();
        if (mDictionaryInfo != null) {
            mTvBack.setText(Constants.getCategoryName(mDictionaryInfo.getCategoryId(), this));
            mColorFlagItem = ResourcesUtils.getColorFlagItemDictionary(mDictionaryInfo.getCategoryId());
            mColorBackgroundItem = ResourcesUtils.getColorBackgroundItemDictionary(mDictionaryInfo.getCategoryId());
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            linearLayoutManager.setOrientation(LinearLayout.VERTICAL);
            mRecycleView.setLayoutManager(linearLayoutManager);
            initListDictionary();
        }
    }

    /**
     * init list dictionary
     */
    private void initListDictionary() {
        mAdapter = new DetailDictionaryAdapter();
        mAdapter.setDictionary(mDictionaryInfo);
        mAdapter.setActivity(this);
        mAdapter.setShowEdit(true);
        mAdapter.setIOnClickDetailDic(this);
        mAdapter.setColorItem(mColorBackgroundItem, mColorFlagItem);
        mRecycleView.setAdapter(mAdapter);
    }

    @Override
    public void onClickSeeAgain() {
        mRecycleView.smoothScrollToPosition(0);
    }

    @Override
    public void onClickEdit() {
        goToDicEdit();
    }

    @Override
    public void onClickZoomPicture(int position) {
        DetailPictureDialogFactory dialogFactory = new DetailPictureDialogFactory(DialogTypeControl.DialogType.DETAIL_PICTURE_DIALOG,
                this, mDictionaryInfo.getType());
        dialogFactory.setListCardInfo(mDictionaryInfo.getCardList());
        dialogFactory.setPositionStartPage(position);
        dialogFactory.setActivity(this);
        mDialogDetailPicture = new DialogGenerator(this, dialogFactory).show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rlt_dic_detail_back:
                onBackPressed();
                break;
            default:
                break;
        }
    }

    /**
     * get DictionaryInfo
     *
     * @return
     */
    private DictionaryInfo getIntentDicInfo() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_DICTIONARY_INFO)) {
            return (DictionaryInfo) getIntent().getExtras().getSerializable(Constants.Dictionary.KEY_DICTIONARY_INFO);
        } else {
            return null;
        }
    }

    @Override
    public void dismissDialog() {
        mDialogDetailPicture.dismiss();
    }


    /**
     * go to dic-ed-01
     */
    private void goToDicEdit() {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Constants.Dictionary.KEY_DICTIONARY_INFO, mDictionaryInfo);
        bundle.putSerializable(Constants.Dictionary.KEY_LIST_CATEGORY, (Serializable) mCategoryInfoList);
        changeScreenResult(ScreenId.START_DIC_EDIT, Constants.Dictionary.REQUEST_CODE_DIC_EDIT, bundle);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constants.Dictionary.REQUEST_CODE_DIC_EDIT && resultCode == Constants.Dictionary.REQUEST_CODE_DIC_EDIT){
            goBackScreen();
        }
    }

    /**
     * go back dic-02
     */
    private void goBackScreen() {
        Bundle bundle = new Bundle();
        backScreenResult(this, bundle, Constants.Dictionary.REQUEST_CODE_DIC_EDIT);
    }

    /**
     * get intent list category
     *
     * @return List<CategoryInfo>
     */
    private List<CategoryInfo> getIntentListCategory() {
        if (getIntent().hasExtra(Constants.Dictionary.KEY_LIST_CATEGORY)) {
            return (List<CategoryInfo>) getIntent().getExtras().getSerializable(Constants.Dictionary.KEY_LIST_CATEGORY);
        }
        return new ArrayList<>();
    }

}