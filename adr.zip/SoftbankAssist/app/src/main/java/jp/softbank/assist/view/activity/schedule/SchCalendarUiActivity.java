/*
 * ファイル：SchCalendarUiActivity.java
 * 概要：カレンダー画面
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.view.activity.schedule;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import jp.softbank.assist.R;
import jp.softbank.assist.util.Constants;
import jp.softbank.assist.util.DateUtils;
import jp.softbank.assist.view.activity.BaseUiActivity;
import jp.softbank.assist.view.adapter.AdapterPagerCalendar;
import jp.softbank.assist.view.customview.ViewPagerDisableSwipe;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * sch-cal
 *
 * @author Systena
 * @version 1.0
 */
public class SchCalendarUiActivity extends BaseUiActivity implements View.OnClickListener {
    private ViewPagerDisableSwipe mPager;
    private LinearLayout mLnPrev;
    private LinearLayout mLnNext;
    private AdapterPagerCalendar mPagerAdapter;
    private TextView mTvMonth;
    private TextView mTvYear;
    private LinearLayout mLayoutBack;
    private TextView mTvPrev;
    private TextView mTvNext;
    private TextView mTvToday;


    private boolean mDisableNext = false;
    private boolean mDisablePrev = false;
    private Calendar mCalendar = Calendar.getInstance();
    private Date mCurrentDate;
    private List<Date> mListDate;
    private int mPositionStart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
        mListDate = DateUtils.createListCalendar();
        mCurrentDate = getIntentDate();
        mPositionStart = getPositionOfDate();
        mPager = findViewById(R.id.pager);
        mLnPrev = findViewById(R.id.ln_prev);
        mLnNext = findViewById(R.id.ln_next);
        mTvMonth = findViewById(R.id.tv_month);
        mTvYear = findViewById(R.id.tv_year);
        mLayoutBack = findViewById(R.id.ln_back);
        mTvPrev = findViewById(R.id.tv_prev);
        mTvNext = findViewById(R.id.tv_next);
        mTvToday = findViewById(R.id.tv_today);
        mLayoutBack.setOnClickListener(this);
        mLnPrev.setOnClickListener(this);
        mLnNext.setOnClickListener(this);
        mLnNext.setOnClickListener(this);
        mTvToday.setOnClickListener(this);

        mPagerAdapter = new AdapterPagerCalendar(getSupportFragmentManager(), mListDate);
        mPager.setAdapter(mPagerAdapter);
        mPager.setCurrentItem(mPositionStart);
        updateTime();
        updateButton();
        mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                updateTime();
                updateButton();
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    /**
     * get date from intent
     *
     * @return date
     */
    private Date getIntentDate() {
        if (getIntent().hasExtra(Constants.Schedule.KEY_DATA_DATE)) {
            return (Date) getIntent().getExtras().getSerializable(Constants.Schedule.KEY_DATA_DATE);
        }
        return null;
    }

    private int getPositionOfDate() {
        if (mCurrentDate == null || mListDate.isEmpty()) {
            return 0;
        }
        for (int i = 0; i < mListDate.size(); i++) {
            if (DateUtils.compareEqualMonth(mListDate.get(i), mCurrentDate)) {
                return i;
            }
        }
        return 0;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ln_back:
                finish();
                break;
            case R.id.ln_prev:
                prevMonth();
                break;
            case R.id.ln_next:
                nextMonth();
                break;
            case R.id.tv_today:
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.Schedule.KEY_DATE_CALENDAR, new Date());
                backScreenResult(this, bundle, Constants.Schedule.RESULT_CALENDAR);
                break;
            default:
                break;
        }
    }

    /**
     * next month
     */
    private void nextMonth() {
        if (mPager.getCurrentItem() >= mPagerAdapter.getLastPagePosition()) {
            return;
        }
        mPager.setCurrentItem(mPager.getCurrentItem() + 1, true);
    }

    /**
     * previous month
     */
    private void prevMonth() {
        if (mPager.getCurrentItem() <= mPagerAdapter.getFistPagePosition()) {
            return;
        }
        mPager.setCurrentItem(mPager.getCurrentItem() - 1, true);
    }

    /**
     * update text time
     */
    private void updateTime() {
        if (mPagerAdapter == null) {
            return;
        }
        Date date = mListDate.get(mPager.getCurrentItem());
        mCalendar.setTime(date);
        mTvMonth.setText(String.valueOf(mCalendar.get(Calendar.MONTH) + 1));
        mTvYear.setText(mCalendar.get(Calendar.YEAR) + getString(R.string.sch_year));
    }

    /**
     * update background button, text, image when preview and next
     */
    private void updateButton() {
        if (mPager.getCurrentItem() <= mPagerAdapter.getFistPagePosition()) {
            mDisablePrev = true;
            mLnPrev.setBackground(getResources().getDrawable(R.drawable.border_btn_calendar_disable,
                    null));
            mTvPrev.setTextColor(getResources().getColor(R.color.calendar_disable, null));
        } else if (mPager.getCurrentItem() >= mPagerAdapter.getLastPagePosition()) {
            mDisableNext = true;
            mLnNext.setBackground(getResources().getDrawable(R.drawable.border_btn_calendar_disable,
                    null));
            mTvNext.setTextColor(getResources().getColor(R.color.calendar_disable, null));
        } else if (mDisablePrev) {
            mDisablePrev = false;
            mLnPrev.setBackground(getResources().getDrawable(R.drawable.border_btn_calendar,
                    null));
            mTvPrev.setTextColor(getResources().getColor(R.color.content, null));
        } else if (mDisableNext) {
            mDisableNext = false;
            mLnNext.setBackground(getResources().getDrawable(R.drawable.border_btn_calendar,
                    null));
            mTvNext.setTextColor(getResources().getColor(R.color.content, null));
        }
    }
}
