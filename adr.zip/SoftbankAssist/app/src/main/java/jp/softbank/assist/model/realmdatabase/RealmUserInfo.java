/*
 * ファイル：RealmUserInfo.java
 * 概要：Realmユーザー情報テーブル
 * ライセンス：
 * 著作権：Copyright(c) 2019 SoftBank Corp.
 *         All rights are reserved by SoftBank Corp., whether the whole or part of the source code including any modifications.
 */

package jp.softbank.assist.model.realmdatabase;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Realmユーザー情報テーブルクラス
 *
 * @author Systena
 * @version 1.0
 */
public class RealmUserInfo extends RealmObject {

    @PrimaryKey
    private int mId; //ユーザー情報ID
    private long mUserId; // 利用者（ユーザ）ID
    private String mCuid; // 利用者CUID
    private String mNickName; // 利用者ニックネーム
    private long mIconId; // 利用者アイコンID

    public int getId() {
        return mId;
    }

    public void setId(int mId) {
        this.mId = mId;
    }

    public long getUserId() {
        return mUserId;
    }

    public void setUserId(long mUserId) {
        this.mUserId = mUserId;
    }

    public String getCuid() {
        return mCuid;
    }

    public void setCuid(String mCuid) {
        this.mCuid = mCuid;
    }

    public String getNickName() {
        return mNickName;
    }

    public void setNickName(String mNickName) {
        this.mNickName = mNickName;
    }

    public long getIconId() {
        return mIconId;
    }

    public void setIconId(long mIconId) {
        this.mIconId = mIconId;
    }
}
